import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
const next = fileURLToPath(
  new URL("../node_modules/next/dist/bin/next", import.meta.url),
);
// Force the fictional provider for both build and server. Browser fixtures block
// all unmocked external traffic; this never connects to a hosted business.
const env = {
  ...process.env,
  NODE_ENV: "production",
  NEXT_PUBLIC_SUPABASE_URL: "https://register-tests.supabase.co",
  NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: "test-publishable-key-not-a-credential",
};
let child,
  stopping = false;
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => {
    stopping = true;
    child?.kill(signal);
  });
async function run(args) {
  return new Promise((resolve, reject) => {
    child = spawn(process.execPath, [next, ...args], { env, stdio: "inherit" });
    child.on("error", reject);
    child.on("exit", (code) => resolve(code ?? 1));
  });
}
const build = await run(["build"]);
if (build !== 0 || stopping) process.exitCode = build || 1;
else {
  const result = await run([
    "start",
    "--hostname",
    "127.0.0.1",
    "--port",
    "3002",
  ]);
  if (!stopping) process.exitCode = result;
}
