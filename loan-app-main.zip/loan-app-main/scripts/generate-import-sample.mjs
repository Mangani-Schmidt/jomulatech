// Creates only a fictional workbook. Never connects to or seeds a database.
import ExcelJS from "exceljs";
import { mkdir, writeFile } from "node:fs/promises";
import rows from "../lib/import-sample.json" with { type: "json" };

const workbook = new ExcelJS.Workbook();
workbook.creator = "Lendtrack fictional demo";
workbook.created = new Date("2026-11-13T00:00:00Z");
const sheet = workbook.addWorksheet("Fictional Clients");
sheet.addRow(["no#", "name", "man#", "department", "designation", "amount"]);
for (const row of rows)
  sheet.addRow([
    Number(row.source_no),
    row.name,
    row.man_number,
    row.department,
    row.designation,
    Number(row.amount),
  ]);
sheet.getColumn(3).numFmt = "@";
sheet.getColumn(6).numFmt = "0.00";
sheet.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
sheet.getRow(1).fill = {
  type: "pattern",
  pattern: "solid",
  fgColor: { argb: "FF275E46" },
};
sheet.columns.forEach((c) => {
  c.width = 24;
});
sheet.views = [{ state: "frozen", ySplit: 1 }];
sheet.autoFilter = "A1:F11";
const guide = workbook.addWorksheet("Instructions");
for (const text of [
  "FICTIONAL DEMO DATA ONLY — these are not real Clients or actual disbursements.",
  "Use Explore demo → Excel Imports → Try sample import to practice without saving records.",
  "To test an actual upload, use an authorized development/staging business and upload this file in Excel Imports.",
  "Select Client Register Import to create only Client details; amount is ignored and no loans are created.",
  "Loan Disbursement Import treats amount as Amount Disbursed only after explicit confirmation. Set disbursement date, one-time flat interest and days-after-disbursement due-date rule.",
  "There are 10 fictional Clients. All Man# cells are text: 009001–009010. Keep leading zeros.",
  "no# is a source row number, never a Client ID. Only the first worksheet is imported.",
  "Amount column totals ZMW 21,250.00. At 10% entire-term flat interest: ZMW 2,125.00 interest and ZMW 23,375.00 total obligation.",
  "Never upload fictional data to your live business. Reuse of the same confirmed batch is protected against duplicate submission.",
])
  guide.addRow([text]);
guide.getColumn(1).width = 112;
guide.eachRow((row) => {
  row.alignment = { wrapText: true, vertical: "top" };
  row.height = 42;
});
const target = new URL(
  "../public/samples/lendtrack-dummy-clients.xlsx",
  import.meta.url,
);
await mkdir(new URL("../public/samples/", import.meta.url), {
  recursive: true,
});
const bytes = new Uint8Array(await workbook.xlsx.writeBuffer());
await writeFile(target, bytes);
// Retain the previous public URL for existing downloads and bookmarks.
await writeFile(
  new URL("../public/samples/lendwell-dummy-clients.xlsx", import.meta.url),
  bytes,
);
console.log(
  "Created public/samples/lendtrack-dummy-clients.xlsx (10 fictional Clients).",
);
