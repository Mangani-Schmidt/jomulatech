import { readFile, readdir, writeFile } from "node:fs/promises";
import { createIsolatedPostgres } from "../tests/support/isolated-postgres.mjs";
// No connection options: only the harness-owned networkless tmpfs test database.
const db = await createIsolatedPostgres();
const actor = "11111111-1111-4111-8111-111111111111";
try {
  await db.seed(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`,
  );
  for (const name of (
    await readdir(new URL("../supabase/migrations/", import.meta.url))
  ).sort())
    await db.seed(
      await readFile(
        new URL("../supabase/migrations/" + name, import.meta.url),
        "utf8",
      ),
    );
  await db.seed(
    `insert into auth.users values('${actor}');insert into public.businesses(id,name) values('${actor}','Fictional profiling business');insert into public.ledger_settings(owner_id) values('${actor}');insert into public.user_roles(user_id,owner_id,role) values('${actor}','${actor}','administrator');`,
  );
  const setup = `select set_config('request.jwt.claim.sub','${actor}',true);select set_config('request.jwt.claims','{"session_id":"${actor}"}',true);set local role authenticated;select public.touch_app_session();`;
  await db.run(`begin;${setup}
 insert into public.clients(man_number,name,department,designation) select lpad(n::text,6,'0'),'Fictional Client '||n,'Fictional Department','Fictional Designation' from generate_series(1,120) n;
 do $$declare c record;l record;d date:=(statement_timestamp() at time zone 'Africa/Lusaka')::date;i integer;begin
 for c in select id from public.clients loop for i in 1..4 loop
 perform public.originate_loan(jsonb_build_object('client_id',c.id,'expected_client_revision',1,'principal_cents',100000,'rate_bps',1000,'term_days',30,'disbursement_date',d,'settings_revision',1,'calculation_method','one_time_flat','rate_basis','entire_term','override_reason',''),gen_random_uuid(),true);
 end loop;end loop;
 for l in select * from public.loan_register loop
 perform public.post_repayment(jsonb_build_object('loan_id',l.id,'amount_cents',1000,'payment_date',d,'payment_method','cash','expected_balance_cents',l.balance_cents,'expected_terms_revision',l.terms_revision,'expected_interest_outstanding_cents',l.interest_outstanding_cents,'expected_principal_outstanding_cents',l.principal_outstanding_cents),gen_random_uuid(),true);
 end loop;end $$;commit;`);
  await db.run(
    `analyze;create function test_support.plan(q text) returns jsonb language plpgsql as $$declare p jsonb;begin execute 'explain (analyze,buffers,format json) '||q into p;return p;end$$;grant usage on schema test_support to authenticated;grant execute on function test_support.plan(text) to authenticated;`,
  );
  const queries = {
    loan_defaults: "select public.loan_defaults()",
    ledger_snapshot: "select public.ledger_snapshot()",
    report_source_filtered: `select public.report_source_filtered(jsonb_build_object('from',to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-01'),'to',to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD'),'asOf',to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD'),'currency','ZMW'))`,
    client_lookup: `select id from public.clients where owner_id=public.current_ledger_id() and lower(man_number)=lower('000042')`,
    loan_selection: `select l.id from public.loans l join public.clients c on c.id=l.client_id and c.owner_id=l.owner_id where l.owner_id=public.current_ledger_id() and l.currency='ZMW' and l.disbursement_date<=(statement_timestamp() at time zone 'Africa/Lusaka')::date order by l.id limit 10001`,
  };
  const results = {};
  for (const [name, q] of Object.entries(queries)) {
    const plans = [];
    for (let i = 0; i < 4; i++)
      plans.push(
        await db.json(
          `begin;${setup}select test_support.plan('${q.replaceAll("'", "''")}');commit;`,
        ),
      );
    results[name] = {
      execution_ms: plans.slice(1).map((p) => p[0]["Execution Time"]),
      representative_plan: plans[3],
    };
  }
  const indexes = await db.json(
    "select jsonb_agg(jsonb_build_object('table',tablename,'index',indexname,'definition',indexdef) order by tablename,indexname) from pg_indexes where schemaname='public';",
  );
  const output = {
    server: await db.json(
      "select to_jsonb(current_setting('server_version'));",
    ),
    fixture: { clients: 120, loans: 480, repayments: 480 },
    notes:
      "Local isolated PostgreSQL, authenticated RLS, warm samples, no hosted connection. Function EXPLAIN gives total execution, not individual nested statements.",
    results,
    indexes,
  };
  const destination = process.argv[2] ?? "/tmp/lendtrack-query-profile.json";
  await writeFile(destination, JSON.stringify(output, null, 2));
  console.log("Isolated query profile saved to " + destination);
} finally {
  await db.destroy();
}
