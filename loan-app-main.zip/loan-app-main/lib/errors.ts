type ServiceError = { code?: string; message?: string; status?: number };
/** Classify transport/provider failures without encouraging unsafe schema reruns. */
export function serviceError(error: unknown, subject = "records") {
  const e = (error ?? {}) as ServiceError;
  const code = String(e.code ?? "");
  if (e.status === 401 || ["PGRST301", "PGRST302", "PGRST303"].includes(code))
    return "Your session expired. Sign in again and retry.";
  if (e.status === 403 || code === "42501")
    return "Your current business role does not permit this action. Ask an Administrator to review your access.";
  if (code === "28000")
    return "Additional authentication required. Open Account security and verify your authenticator, then retry.";
  if (code === "54000")
    return (
      e.message ??
      "The selection is too large. Narrow the report filters; no partial result is shown."
    );
  if (["PGRST202", "PGRST205", "42883", "42P01"].includes(code))
    return "The application and database versions do not match. Ask your database administrator to apply only pending migrations; do not rerun applied migrations.";
  if (code === "57014" || code === "55P03")
    return `Loading ${subject} timed out. Retry or narrow the selection.`;
  return `Could not load ${subject}. Check your connection and retry. Existing database migrations should not be rerun for a connection error.`;
}
/** A returned SQL error means that RPC's transaction failed atomically. An
 * absent/transport code leaves its outcome uncertain and must retain the key. */
export function definitePostingFailure(error: unknown) {
  const code = String((error as ServiceError | null)?.code ?? "");
  return /^[0-9A-Z]{5}$/.test(code) || /^PGRST(20[025]|30[123])$/.test(code);
}
