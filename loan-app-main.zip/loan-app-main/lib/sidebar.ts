export const sidebarStorageKey = "lendtrack:sidebar";
export const sidebarPreference = (value: unknown) =>
  value === "collapsed" ? "collapsed" : "expanded";
// Apply only the layout preference before paint; never interpolate stored markup.
export const sidebarStartupScript = `(function(){var p="expanded";try{if(localStorage.getItem("lendtrack:sidebar")==="collapsed")p="collapsed";}catch(e){}document.documentElement.dataset.sidebar=p;})();`;
