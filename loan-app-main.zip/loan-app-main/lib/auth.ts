import { z } from "zod";
export const MIN_PASSWORD_LENGTH = 6;
export const emailSchema = z
  .string()
  .trim()
  .pipe(z.email("Enter a valid email address."));
export const passwordSchema = z
  .string()
  .min(MIN_PASSWORD_LENGTH, "Use at least 6 characters.");
export const authSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
});
export const passwordUpdateSchema = z
  .object({ password: passwordSchema, repeat: z.string() })
  .refine((v) => v.password === v.repeat, {
    message: "Passwords must match.",
    path: ["repeat"],
  });
const internalPaths = new Set([
  "/dashboard",
  "/settings",
  "/administration",
  "/users",
  "/audit-logs",
  "/expenses",
  "/security",
]);
export function safeReturnPath(value: string | null) {
  if (
    !value ||
    !value.startsWith("/") ||
    value.startsWith("//") ||
    /[\\\u0000-\u001f\u007f]/.test(value)
  )
    return "/dashboard";
  try {
    const url = new URL(value, "https://internal.invalid");
    return url.origin === "https://internal.invalid" &&
      internalPaths.has(url.pathname)
      ? url.pathname + url.search + url.hash
      : "/dashboard";
  } catch {
    return "/dashboard";
  }
}
export function authError(error: unknown) {
  const e = (error ?? {}) as {
    code?: string;
    status?: number;
    message?: string;
  };
  if (e.code === "user_banned")
    return "This account is disabled. Contact an Administrator.";
  if (e.code === "invalid_credentials")
    return "Email or password is incorrect. Please try again.";
  if (e.code === "email_not_confirmed")
    return "Confirm your email address before logging in. Check your inbox for the confirmation link.";
  if (e.code === "signup_disabled")
    return "Sign up is disabled for this business. Ask an Administrator for an invitation.";
  if (e.code === "weak_password")
    return "The authentication service rejected this password. Use at least 6 characters and meet any additional provider requirements. Ask an Administrator to check the hosted password policy if it requires a different minimum.";
  if (e.status === 429 || e.code?.includes("rate_limit"))
    return "Too many attempts. Please wait a few minutes and try again.";
  if (e.code === "user_already_exists")
    return "If an account already exists, log in or use password recovery.";
  if (e.code === "session_expired" || e.status === 401)
    return "Your session expired. Log in again to continue.";
  return "Could not complete this request. Check your connection and try again. If the problem continues, contact an Administrator.";
}
