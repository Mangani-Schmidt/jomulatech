"use client";
import { createContext, useContext, type ReactNode } from "react";
import { getSupabase } from "./supabase";

const DemoContext = createContext(false);
export function DemoProvider({ children }: { children: ReactNode }) {
  return <DemoContext.Provider value={true}>{children}</DemoContext.Provider>;
}
export function useDemoMode() {
  return useContext(DemoContext);
}
export function useSupabase() {
  const demo = useDemoMode();
  return demo ? null : getSupabase();
}
export function useWorkspaceBase() {
  return useDemoMode() ? "/demo" : "/dashboard";
}
