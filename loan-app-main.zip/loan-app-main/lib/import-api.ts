import { createClient } from "@supabase/supabase-js";
export class ImportHttpError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
export async function importAuth(request: Request, permission = "imports") {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key)
    throw new ImportHttpError("Connect Supabase to use imports.", 503);
  const token = request.headers
    .get("authorization")
    ?.match(/^Bearer (.+)$/i)?.[1];
  if (!token) throw new ImportHttpError("Sign in to use imports.", 401);
  const db = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: `Bearer ${token}` } },
  });
  const { data, error } = await db.auth.getUser(token);
  if (error || !data.user)
    throw new ImportHttpError("Your session expired. Sign in again.", 401);
  const authorization = await db.rpc("has_capability", {
    p_action: permission,
  });
  if (authorization.error || authorization.data !== true)
    throw new ImportHttpError(
      "Your permissions do not allow this import action.",
      403,
    );
  return db;
}
export async function uploadForm(request: Request) {
  if (!request.headers.get("content-type")?.startsWith("multipart/form-data"))
    throw new ImportHttpError("Expected a workbook upload.", 400);
  const bytes = await readBounded(request, 2300000);
  return new Response(bytes, {
    headers: { "content-type": request.headers.get("content-type")! },
  }).formData();
}
export function workbookFile(form: FormData) {
  const file = form.get("file");
  if (!(file instanceof File))
    throw new ImportHttpError("Choose a workbook.", 400);
  return file;
}
export function importFailure(error: unknown) {
  const status = error instanceof ImportHttpError ? error.status : 400;
  return Response.json(
    {
      error:
        error instanceof Error
          ? error.message
          : ((error as { message?: string })?.message ??
            "Import request failed."),
    },
    { status, headers: { "Cache-Control": "no-store" } },
  );
}
export async function boundedJson(request: Request) {
  return JSON.parse(new TextDecoder().decode(await readBounded(request, 2000)));
}

async function readBounded(request: Request, limit: number) {
  const reader = request.body?.getReader();
  if (!reader) throw new ImportHttpError("Empty upload.", 400);
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > limit) {
      await reader.cancel();
      throw new ImportHttpError("Request exceeds the permitted size.", 413);
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  return bytes;
}
