import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { sessionFetch } from "./session-activity";
const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
let client: SupabaseClient | null = null;
// Demo routes never initialize Auth or its background token refresh.
export function getSupabase() {
  if (!url || !key) return null;
  return (client ??= createClient(url, key, {
    global: { fetch: sessionFetch },
  }));
}
