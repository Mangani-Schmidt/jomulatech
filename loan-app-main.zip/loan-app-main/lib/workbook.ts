import ExcelJS from "exceljs";
export type ReportColumn = {
  label: string;
  kind?: "text" | "money" | "date" | "datetime" | "integer" | "number";
  width?: number;
};
export type Cell = string | number | null;
export type WorkbookTable = {
  name: string;
  columns: ReportColumn[];
  rows: Cell[][];
  totals?: Cell[];
  currency?: string;
};
export const generatedTime = (value: string) =>
  new Date(value).toLocaleString("en-GB", {
    timeZone: "Africa/Lusaka",
    hour12: false,
  }) + " Africa/Lusaka";
export function reportWorkbook(
  title: string,
  meta: [string, Cell][],
  tables: WorkbookTable[],
) {
  const wb = new ExcelJS.Workbook();
  wb.creator = "LendTrack";
  wb.title = title;
  wb.subject = "Filtered business report";
  wb.created = new Date();
  const scope = wb.addWorksheet("Report scope");
  scope.columns = [{ width: 34 }, { width: 100 }];
  scope.mergeCells("A1:B1");
  scope.getCell("A1").value = "LendTrack · " + title;
  scope.getRow(1).height = 32;
  scope.getCell("A1").font = {
    name: "Calibri",
    bold: true,
    size: 18,
    color: { argb: "FFFFFFFF" },
  };
  scope.getCell("A1").fill = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FF11243C" },
  };
  for (const [key, value] of meta) {
    const r = scope.addRow([key, value]);
    r.alignment = { vertical: "top", wrapText: true };
    r.height =
      typeof value === "string"
        ? Math.max(32, Math.ceil(value.length / 85) * 16)
        : 32;
    r.getCell(1).font = { bold: true, color: { argb: "FF11243C" } };
    if (typeof value === "string") r.getCell(2).numFmt = "@";
  }
  scope.views = [{ state: "frozen", ySplit: 1 }];
  for (const table of tables) {
    const sheet = wb.addWorksheet(table.name, {
      pageSetup: {
        paperSize: 9,
        orientation: "landscape",
        fitToPage: true,
        fitToWidth: 1,
        fitToHeight: 0,
        printTitlesRow: "1:4",
      },
    });
    sheet.columns = table.columns.map((c) => ({
      width: c.width ?? (c.kind === "money" ? 30 : c.kind === "date" ? 15 : 26),
    }));
    sheet.mergeCells(1, 1, 1, table.columns.length);
    sheet.getCell(1, 1).value = "LendTrack · " + title;
    sheet.getRow(1).height = 30;
    sheet.getCell(1, 1).font = {
      name: "Calibri",
      bold: true,
      size: 16,
      color: { argb: "FF11243C" },
    };
    sheet.mergeCells(2, 1, 2, table.columns.length);
    sheet.getCell(2, 1).value =
      "Scope, generation time and filters: see Report scope. " +
      (table.currency ?? "");
    sheet.getRow(2).height = 24;
    sheet.addRow([]);
    const header = sheet.addRow(table.columns.map((c) => c.label));
    header.height = 46;
    header.eachCell((c) => {
      c.font = { bold: true, color: { argb: "FFFFFFFF" } };
      c.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF11243C" },
      };
      c.alignment = { wrapText: true, vertical: "middle" };
    });
    table.rows.forEach((row, i) => {
      const r = sheet.addRow(row);
      r.height = Math.max(
        38,
        ...row.map(
          (value, n) =>
            Math.ceil(
              String(value ?? "").length / (table.columns[n].width ?? 24),
            ) *
              15 +
            8,
        ),
      );
      r.eachCell({ includeEmpty: true }, (cell, n) => {
        const col = table.columns[n - 1];
        cell.font = { name: "Calibri", size: 11, color: { argb: "FF182C42" } };
        cell.alignment = {
          vertical: "top",
          wrapText: true,
          horizontal:
            col.kind === "money" ||
            col.kind === "number" ||
            col.kind === "integer"
              ? "right"
              : "left",
        };
        if (i % 2 === 1)
          cell.fill = {
            type: "pattern",
            pattern: "solid",
            fgColor: { argb: "FFEEF5F7" },
          };
        if (typeof cell.value === "string") {
          cell.numFmt = "@";
          if (col.kind === "date" && /^\d{4}-\d{2}-\d{2}$/.test(cell.value)) {
            cell.value = new Date(cell.value + "T00:00:00Z");
            cell.numFmt = "dd mmm yyyy";
          }
        } else if (col.kind === "money")
          cell.numFmt = `"${table.currency ?? ""}" #,##0.00;[Red]("${table.currency ?? ""}" #,##0.00)`;
        else if (col.kind === "integer") cell.numFmt = "#,##0";
        else if (col.kind === "number") cell.numFmt = "0.00";
      });
    });
    sheet.autoFilter = {
      from: { row: 4, column: 1 },
      to: { row: Math.max(4, sheet.rowCount), column: table.columns.length },
    };
    sheet.views = [{ state: "frozen", ySplit: 4, xSplit: 1 }];
    if (table.totals) {
      const total = sheet.addRow(table.totals);
      total.height = 30;
      total.eachCell({ includeEmpty: true }, (cell, n) => {
        cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF087F72" },
        };
        cell.alignment = {
          wrapText: true,
          horizontal: table.columns[n - 1].kind === "money" ? "right" : "left",
        };
        if (
          typeof cell.value === "number" &&
          table.columns[n - 1].kind === "money"
        )
          cell.numFmt = `"${table.currency ?? ""}" #,##0.00;[Red]("${table.currency ?? ""}" #,##0.00)`;
      });
    }
  }
  return wb;
}
export async function saveWorkbook(
  wb: ExcelJS.Workbook,
  filename: string,
  authorize?: () => Promise<void>,
) {
  const bytes = await wb.xlsx.writeBuffer();
  if (authorize) await authorize();
  downloadBlob(
    new Blob([bytes], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }),
    filename,
  );
}
export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob),
    a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Excel only retains 15 significant digits. Keep larger exact minor-unit
 * amounts as literal decimal text instead of silently losing a cent. */
export function workbookMoney(cents: number): number | string {
  if (!Number.isSafeInteger(cents))
    throw new Error("Invalid exact monetary value.");
  if (Math.abs(cents) <= 999999999999999) return cents / 100;
  const n = BigInt(cents),
    abs = n < 0n ? -n : n;
  return (
    (n < 0n ? "-" : "") +
    (abs / 100n).toString() +
    "." +
    (abs % 100n).toString().padStart(2, "0")
  );
}
