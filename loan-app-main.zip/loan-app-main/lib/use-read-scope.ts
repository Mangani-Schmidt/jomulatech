"use client";
import { useEffect, useRef } from "react";
import { ReadAccessError } from "./read-access";
/** Stop a delayed download from releasing data after its component's verified
 * actor/session/business/grants scope has changed or the view was unmounted. */
export function useReadScope(scope: string) {
  const current = useRef(scope);
  current.current = scope;
  useEffect(() => {
    current.current = scope;
    return () => {
      current.current = "";
    };
  }, [scope]);
  return () => {
    if (current.current !== scope)
      throw new ReadAccessError(
        "The account, access or report view changed. Reopen the report before downloading or printing.",
        true,
      );
  };
}
