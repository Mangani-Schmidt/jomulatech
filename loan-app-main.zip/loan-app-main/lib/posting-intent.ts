export type PostingOperation =
  "post_repayment" | "correct_repayment" | "originate_loan" | "post_expense";
export type PostingIntent = {
  version: 2;
  id: string;
  operation: PostingOperation;
  body: Record<string, unknown> | null;
  createdAt: string;
  reentered?: boolean;
};
const prefix = "lendwell:pending-posting:";
const memory = new Map<string, PostingIntent>(),
  reentry = new Set<string>();
function reference(intent: PostingIntent) {
  return {
    version: 2,
    id: intent.id,
    operation: intent.operation,
    createdAt: intent.createdAt,
  };
}
export function clearPostingMemory() {
  memory.clear();
  reentry.clear();
}
export function redactPostingStorage() {
  try {
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const key = localStorage.key(i);
      if (!key?.startsWith(prefix)) continue;
      try {
        const old = JSON.parse(localStorage.getItem(key)!);
        localStorage.setItem(
          key,
          JSON.stringify({
            version: 2,
            id: old.id,
            operation: old.operation,
            createdAt: old.createdAt,
          }),
        );
      } catch {
        localStorage.removeItem(key);
      }
    }
  } catch {}
}
export function pendingPosting(actor: string): PostingIntent | null {
  const raw = localStorage.getItem(prefix + actor);
  if (!raw) {
    memory.delete(actor);
    return null;
  }
  let value: PostingIntent & { version: number };
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error(
      "A pending posting cannot be read. Contact an Administrator before entering the transaction again.",
    );
  }
  if (
    !value ||
    typeof value !== "object" ||
    ![1, 2].includes(value.version) ||
    !/^[a-f0-9-]{36}$/i.test(value.id) ||
    ![
      "post_repayment",
      "correct_repayment",
      "originate_loan",
      "post_expense",
    ].includes(value.operation)
  )
    throw new Error(
      "A pending posting cannot be read. Contact an Administrator before entering the transaction again.",
    );
  const cached = memory.get(actor);
  if (cached?.id === value.id) return cached;
  const next: PostingIntent = {
    version: 2,
    id: value.id,
    operation: value.operation,
    createdAt: value.createdAt,
    body:
      value.body && typeof value.body === "object" && !Array.isArray(value.body)
        ? value.body
        : null,
  };
  // Upgrade legacy recovery records immediately; no financial form is persisted.
  localStorage.setItem(prefix + actor, JSON.stringify(reference(next)));
  memory.set(actor, next);
  return next;
}
export function allowPostingReentry(actor: string) {
  reentry.add(actor);
}
export function rememberPosting(
  actor: string,
  operation: PostingOperation,
  body: Record<string, unknown>,
): PostingIntent {
  const existing = pendingPosting(actor);
  if (existing) {
    if (
      existing.operation !== operation ||
      (existing.body &&
        JSON.stringify(existing.body) !== JSON.stringify(body)) ||
      (!existing.body && !reentry.has(actor))
    )
      throw new Error(
        "An earlier posting needs recovery before another transaction can be started.",
      );
    if (!existing.body) {
      const restored = { ...existing, body, reentered: true };
      memory.set(actor, restored);
      reentry.delete(actor);
      return restored;
    }
    return existing;
  }
  const intent: PostingIntent = {
    version: 2,
    id: crypto.randomUUID(),
    operation,
    body,
    createdAt: new Date().toISOString(),
  };
  localStorage.setItem(prefix + actor, JSON.stringify(reference(intent)));
  memory.set(actor, intent);
  return intent;
}
export function forgetPosting(actor: string, id: string) {
  if (pendingPosting(actor)?.id === id) {
    localStorage.removeItem(prefix + actor);
    memory.delete(actor);
    reentry.delete(actor);
  }
}
