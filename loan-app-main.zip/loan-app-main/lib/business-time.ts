export const businessTimezone = "Africa/Lusaka";
/** Exact occurrence times require an explicit offset. Date-only history is never midnight. */
export function formatBusinessTimestamp(value?: string | null) {
  if (!value) return "Not recorded";
  const day = value.slice(0, 10);
  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(day) ||
    !Number.isFinite(Date.parse(day)) ||
    new Date(day + "T12:00:00Z").toISOString().slice(0, 10) !== day
  )
    return "Not recorded";
  const stamp = new Date(value);
  if (
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})$/i.test(
      value,
    ) ||
    !Number.isFinite(stamp.getTime())
  ) {
    return (
      new Date(day + "T12:00:00Z").toLocaleDateString("en-GB", {
        dateStyle: "medium",
        timeZone: "UTC",
      }) + " · Time not recorded"
    );
  }
  return (
    stamp.toLocaleString("en-GB", {
      dateStyle: "medium",
      timeStyle: "medium",
      timeZone: businessTimezone,
    }) + " Africa/Lusaka"
  );
}
