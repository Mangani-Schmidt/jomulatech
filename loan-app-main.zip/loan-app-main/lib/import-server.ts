import ExcelJS from "exceljs";
import yauzl from "yauzl";
import { createHash } from "node:crypto";
import {
  defaultMapping,
  importFields,
  importLabels,
  type ColumnMapping,
  type ImportData,
  type WorkbookInspection,
  type ImportMode,
} from "./import";
const FILE_LIMIT = 2 * 1024 * 1024;
async function checkArchive(buffer: Buffer) {
  await new Promise<void>((resolve, reject) => {
    yauzl.fromBuffer(
      buffer,
      { lazyEntries: true, validateEntrySizes: true },
      (error, zip) => {
        if (error || !zip) {
          reject(new Error("Invalid .xlsx archive."));
          return;
        }
        let entries = 0,
          total = 0;
        let settled = false;
        const fail = (reason: unknown) => {
          if (settled) return;
          settled = true;
          zip.close();
          reject(reason instanceof Error ? reason : new Error(String(reason)));
        };
        zip.on("error", fail);
        zip.on("end", () => {
          if (!settled) {
            settled = true;
            resolve();
          }
        });
        zip.on("entry", (entry) => {
          if (++entries > 1000 || entry.uncompressedSize > 20 * 1024 * 1024) {
            fail(new Error("Workbook exceeds archive limits."));
            return;
          }
          zip.openReadStream(entry, (error, stream) => {
            if (error || !stream) {
              fail(new Error("Could not read workbook archive."));
              return;
            }
            stream.on("error", fail);
            stream.on("data", (chunk: Buffer) => {
              total += chunk.length;
              if (total > 20 * 1024 * 1024) {
                stream.destroy();
                fail(new Error("Workbook expands beyond 20 MB."));
              }
            });
            stream.on("end", () => {
              if (!settled) zip.readEntry();
            });
          });
        });
        zip.readEntry();
      },
    );
  });
}
export async function readWorkbook(file: File) {
  if (
    !file.name.toLowerCase().endsWith(".xlsx") ||
    ![
      "",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/octet-stream",
      "application/zip",
    ].includes(file.type)
  )
    throw new Error("Choose an .xlsx workbook.");
  if (file.size === 0 || file.size > FILE_LIMIT)
    throw new Error("Workbook must be between 1 byte and 2 MB.");
  const buffer = Buffer.from(await file.arrayBuffer());
  await checkArchive(buffer);
  const wb = new ExcelJS.Workbook();
  try {
    await wb.xlsx.load(buffer as unknown as Parameters<typeof wb.xlsx.load>[0]);
  } catch {
    throw new Error("Could not parse the .xlsx workbook.");
  }
  const sheet = wb.worksheets[0];
  if (!sheet || sheet.rowCount < 2 || sheet.rowCount > 501)
    throw new Error("Use 1–500 data rows in the first worksheet.");
  if (sheet.columnCount > 30) throw new Error("Use at most 30 source columns.");
  const columns = Array.from({ length: sheet.columnCount }, (_, i) => ({
    index: i + 1,
    label: sheet
      .getRow(1)
      .getCell(i + 1)
      .text.trim()
      .slice(0, 120),
  }));
  const inspection: WorkbookInspection = {
    columns,
    mapping: defaultMapping(columns),
    rowCount: sheet.rowCount - 1,
    fileHash: createHash("sha256").update(buffer).digest("hex"),
  };
  return { sheet, inspection };
}
export function mappedRows(
  sheet: ExcelJS.Worksheet,
  mapping: ColumnMapping,
  mode: ImportMode = "loans",
): ImportData[] {
  const indices = importFields.map((field) => mapping?.[field]);
  if (
    indices.some(
      (i) => !Number.isInteger(i) || i < 1 || i > sheet.columnCount,
    ) ||
    new Set(indices).size !== 6
  )
    throw new Error("Map all six fields to different source columns.");
  return Array.from({ length: sheet.rowCount - 1 }, (_, i) => {
    const row = sheet.getRow(i + 2);
    const errors: string[] = [];
    const result = Object.fromEntries(
      importFields.map((field) => {
        const cell = row.getCell(mapping[field]);
        if (cell.type === ExcelJS.ValueType.Formula && field !== "amount")
          errors.push(
            `${importLabels[field]} contains a formula; use a plain value.`,
          );
        if (
          cell.type === ExcelJS.ValueType.Error &&
          !(field === "amount" && mode === "clients")
        )
          errors.push(`${importLabels[field]} contains an Excel error.`);
        return [field, cell.text.trim().slice(0, 2001)];
      }),
    ) as Pick<ImportData, (typeof importFields)[number]>;
    const manCell = row.getCell(mapping.man_number);
    const numeric = typeof manCell.value === "number";
    if (numeric) {
      const value = manCell.value as number;
      if (
        !Number.isSafeInteger(value) ||
        value < 0 ||
        String(value).replace(/\D/g, "").length > 15
      )
        errors.push(
          "Numeric Man# exceeds reliable Excel integer precision; obtain a verified text Man#.",
        );
      // Recover displayed leading zeros only for an unambiguous zero-pad format.
      if (/^0{1,50}$/.test(manCell.numFmt ?? ""))
        result.man_number = String(value).padStart(manCell.numFmt.length, "0");
    }
    for (const field of importFields)
      if (
        result[field].length > 2000 &&
        !(field === "amount" && mode === "clients")
      )
        errors.push(`${importLabels[field]} exceeds the cell limit.`);
    return {
      ...result,
      man_numeric: numeric,
      parse_errors: errors,
      amount:
        row.getCell(mapping.amount).type === ExcelJS.ValueType.Formula
          ? "FORMULA_NOT_SUPPORTED"
          : result.amount,
    };
  });
}
