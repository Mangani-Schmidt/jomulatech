export const INACTIVITY_MS = 15 * 60 * 1000;
export const WARNING_MS = 60 * 1000;
export const SESSION_CHANNEL = "lendtrack:session-activity";
export const SESSION_READY_EVENT = "lendtrack:session-ready";
export const SESSION_REVALIDATING_EVENT = "lendtrack:session-revalidating";
export const SESSION_RESUMED_EVENT = "lendtrack:session-resumed";
export const SESSION_EXPIRED_EVENT = "lendtrack:session-expired";
export type ActivityRecord = { session: string; at: number; ended?: boolean };
export function sessionIdentity(session: {
  user: { id: string };
  access_token: string;
}) {
  try {
    const payload = JSON.parse(
      atob(
        session.access_token
          .split(".")[1]
          .replace(/-/g, "+")
          .replace(/_/g, "/"),
      ),
    );
    return `${session.user.id}:${payload.session_id || "session"}`;
  } catch {
    return `${session.user.id}:session`;
  }
}
export function activityKey(session: string) {
  return SESSION_CHANNEL + ":" + session;
}
export function validActivity(
  value: unknown,
  session: string,
  now = Date.now(),
): value is ActivityRecord {
  if (!value || typeof value !== "object") return false;
  const r = value as ActivityRecord;
  return (
    r.session === session &&
    Number.isFinite(r.at) &&
    r.at > 0 &&
    r.at <= now + 5000 &&
    (r.ended === undefined || typeof r.ended === "boolean")
  );
}
export function readActivity(session: string): ActivityRecord | null {
  try {
    const value = JSON.parse(
      localStorage.getItem(activityKey(session)) ?? "null",
    );
    return validActivity(value, session) ? value : null;
  } catch {
    return null;
  }
}
export function saveActivity(record: ActivityRecord) {
  try {
    localStorage.setItem(activityKey(record.session), JSON.stringify(record));
    return true;
  } catch {
    return false;
  }
}
export function inactivityRemaining(at: number, now = Date.now()) {
  return Math.max(0, Math.min(INACTIVITY_MS, INACTIVITY_MS - (now - at)));
}
let binding: { session: string; at: number; blocked: boolean } | null = null;
let verifiedIdentity: string | null = null;
export function setSessionBinding(next: typeof binding) {
  if (!next || next.blocked || next.session !== binding?.session)
    verifiedIdentity = null;
  binding = next;
}
/** This remembers only identity-check ordering, never permissions or tokens.
 * Every recheck still calls getUser and the protected capability RPC. */
export function identityWasVerified(identity: string) {
  return sessionReadyForRead(identity) && verifiedIdentity === identity;
}
export function markIdentityVerified(identity: string) {
  if (sessionReadyForRead(identity)) verifiedIdentity = identity;
}
/** Read coordination only: never start a business RPC while SessionBoundary is
 * registering a different provider session. The server still authorizes it. */
export function sessionReadyForRead(identity: string) {
  return !!binding && binding.session === identity && !binding.blocked;
}
export function assertActiveSession() {
  if (typeof window === "undefined") return;
  const saved = binding ? readActivity(binding.session) : null;
  if (binding && saved && !saved.ended)
    binding.at = Math.max(binding.at, saved.at);
  // A protected request can race initial session verification. Deny the
  // request, but do not revoke a new Auth session that has not yet been
  // assigned a verified activity timestamp.
  if (!binding || (binding.blocked && binding.at === 0)) {
    throw new Error("Your session is being verified. Please retry.");
  }
  if (binding.blocked) {
    throw new Error("Your session is temporarily unavailable. Please retry.");
  }
  if (saved?.ended || inactivityRemaining(binding.at) === 0) {
    window.dispatchEvent(new Event(SESSION_EXPIRED_EVENT));
    throw new Error("Your session expired after inactivity. Log in again.");
  }
}
/** Supabase's own Auth requests retain supported SDK behavior. Application data
 * requests are additionally checked even when timers in a tab are suspended. */
export async function sessionFetch(
  input: RequestInfo | URL,
  init?: RequestInit,
) {
  const url =
    typeof input === "string"
      ? input
      : input instanceof URL
        ? input.href
        : input.url;
  if (
    typeof window !== "undefined" &&
    /\/rest\/v1\//.test(url) &&
    !/\/rpc\/(app_session_status|touch_app_session|end_app_session)(?:\?|$)/.test(
      url,
    )
  ) {
    try {
      assertActiveSession();
    } catch (error) {
      return new Response(
        JSON.stringify({ code: "28000", message: (error as Error).message }),
        { status: 401, headers: { "Content-Type": "application/json" } },
      );
    }
  }
  return fetch(input, init);
}
