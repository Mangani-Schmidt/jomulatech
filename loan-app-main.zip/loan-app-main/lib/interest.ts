import { capabilitiesForRole, type permissionFlags } from "./permissions";
export type LedgerSettings = {
  owner_id: string;
  default_rate_bps: number;
  default_term_days: number;
  calculation_method: "one_time_flat";
  rate_basis: "entire_term";
  currency: "ZMW";
  rounding_rule: "half_up_2";
  business_timezone: "Africa/Lusaka";
  revision: number;
  updated_at: string;
  updated_by: string | null;
};
export type LoanDefaults = {
  settings: LedgerSettings;
  capabilities: Partial<Record<keyof typeof permissionFlags, boolean>> & {
    is_admin: boolean;
    can_override_rate: boolean;
    can_register_clients?: boolean;
    can_originate?: boolean;
    can_post_repayments?: boolean;
    can_import?: boolean;
    can_manage_expenses?: boolean;
    can_read?: boolean;
    can_delete_clients?: boolean;
    role?: "administrator" | "loan_officer" | "cashier" | "viewer";
  };
};
export const demoDefaults: LoanDefaults = {
  settings: {
    owner_id: "demo",
    default_rate_bps: 1000,
    default_term_days: 30,
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    currency: "ZMW",
    rounding_rule: "half_up_2",
    business_timezone: "Africa/Lusaka",
    revision: 1,
    updated_at: "2026-11-12T00:00:00Z",
    updated_by: null,
  },
  capabilities: capabilitiesForRole("loan_officer"),
};
export function rateBps(value: string) {
  if (!/^\d{1,3}(\.\d{1,2})?$/.test(value))
    throw new Error(
      "Enter a percentage from 0 to 100 with up to two decimals.",
    );
  const [whole, fraction = ""] = value.split(".");
  const bps = Number(whole) * 100 + Number(fraction.padEnd(2, "0"));
  if (bps > 10000) throw new Error("Rate must be 0–100%.");
  return bps;
}
export function flatInterest(
  principal: number,
  bps: number,
  method = "one_time_flat",
  basis = "entire_term",
) {
  if (method !== "one_time_flat" || basis !== "entire_term")
    throw new Error("Unsupported interest calculation method or rate basis.");
  if (
    !Number.isSafeInteger(principal) ||
    principal < 1 ||
    principal > 99999999999 ||
    !Number.isInteger(bps) ||
    bps < 0 ||
    bps > 10000
  )
    throw new Error("Invalid principal or rate.");
  return Number((BigInt(principal) * BigInt(bps) + 5000n) / 10000n);
}
export function dueDate(disbursement: string, days: number) {
  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(disbursement) ||
    !Number.isInteger(days) ||
    days < 1 ||
    days > 3650
  )
    throw new Error("Choose a valid date and term.");
  const date = new Date(`${disbursement}T12:00:00Z`);
  if (
    Number.isNaN(date.getTime()) ||
    date.toISOString().slice(0, 10) !== disbursement
  )
    throw new Error("Invalid date.");
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}
