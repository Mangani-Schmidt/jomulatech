export const importFields = [
  "source_no",
  "name",
  "man_number",
  "department",
  "designation",
  "amount",
] as const;
export const importLabels = {
  source_no: "no#",
  name: "name",
  man_number: "man#",
  department: "department",
  designation: "designation",
  amount: "amount",
} as const;
export type ImportField = (typeof importFields)[number];
export type ColumnMapping = Record<ImportField, number>;
export type ImportMode = "clients" | "loans";
export type ImportData = {
  principal_cents?: number;
  interest_cents?: number;
  total_obligation_cents?: number;
  rate_bps?: number;
  due_date?: string;
  source_no: string;
  name: string;
  man_number: string;
  department: string;
  designation: string;
  amount: string;
  man_numeric: boolean;
  parse_errors: string[];
};
export type ImportTerms = {
  disbursement_date: string;
  calculation_method?: "one_time_flat";
  rate_basis?: "entire_term";
  settings_revision?: number;
  default_rate_bps?: number;
  override_reason?: string;
  interest_type: "fixed" | "flat_percent";
  interest_value: string;
  due_rule: "days_after_disbursement";
  term_days: number;
};
export type ImportBatch = {
  id: string;
  filename: string;
  mode: ImportMode;
  terms: Partial<ImportTerms>;
  status: "preview" | "completed";
  preview_version: number;
  accepted: number;
  rejected: number;
  unchanged: number;
  uploaded_by: string;
  created_at: string;
  completed_at: string | null;
};
export type ImportRow = {
  loan_reference?: string | null;
  id: string;
  excel_row: number;
  source_no: string;
  data: ImportData;
  outcome: "accepted" | "rejected" | "unchanged";
  errors: string[];
  warnings: string[];
  client_id: string | null;
  loan_id: string | null;
};
export type ImportReport = { batch: ImportBatch; rows: ImportRow[] };
export type WorkbookInspection = {
  columns: { index: number; label: string }[];
  mapping: ColumnMapping;
  rowCount: number;
  fileHash: string;
};
export function defaultMapping(
  columns: WorkbookInspection["columns"],
): ColumnMapping {
  return Object.fromEntries(
    importFields.map((field) => {
      const matches = columns.filter(
        (c) => c.label.trim().toLowerCase() === importLabels[field],
      );
      return [field, matches.length === 1 ? matches[0].index : 0];
    }),
  ) as ColumnMapping;
}
