export const brand = {
  name: "LendTrack",
  wordmark: "lendtrack",
  initials: "LT",
  description: "Client lending, clearly managed.",
} as const;
