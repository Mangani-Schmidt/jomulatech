import { z } from "zod";
export const manNumberSchema = z
  .string()
  .trim()
  .min(1, "Enter the Client's chosen or assigned Man#.")
  .max(50, "Man# must contain no more than 50 characters.")
  .refine(
    (value) => !/[\u0000-\u001f\u007f]/.test(value),
    "Man# cannot contain control characters.",
  );
export const clientSchema = z.object({
  man_number: manNumberSchema,
  department: z.string().trim().min(1).max(120),
  designation: z.string().trim().min(1).max(120),
  address: z.string().trim().max(500).default(""),
  is_active: z.boolean().default(true),
  name: z.string().trim().min(2).max(120),
  email: z.union([z.email(), z.literal("")]).default(""),
  phone: z.string().trim().max(30).default(""),
});
export type Client = {
  id: string;
  man_number: string | null;
  department: string | null;
  designation: string | null;
  address: string | null;
  is_active: boolean;
  created_by: string;
  updated_at: string;
  revision: number;
  name: string;
  email: string | null;
  phone: string | null;
  created_at: string;
};
export type Loan = {
  interest_repaid_cents?: number;
  principal_repaid_cents?: number;
  interest_outstanding_cents?: number;
  principal_outstanding_cents?: number;
  written_off_request_id?: string | null;
  loan_reference?: string;
  amount_disbursed_cents?: number;
  created_by?: string;
  creator_inferred?: boolean;
  updated_at?: string;
  updated_by?: string;
  lifecycle_status?: "active" | "settled" | "written_off";
  status?: "active" | "overdue" | "settled" | "written_off";
  written_off_cents?: number | null;
  written_off_at?: string | null;
  written_off_by?: string | null;
  written_off_reason?: string | null;

  interest_rate_bps?: number | null;
  calculation_method?: string;
  rate_basis?: string;
  term_days?: number | null;
  currency?: string;
  rounding_rule?: string;
  business_timezone?: string;
  settings_revision?: number | null;
  default_rate_bps_at_origination?: number | null;
  rate_override_reason?: string | null;
  terms_revision?: number;
  total_obligation_cents?: number;
  disbursement_date?: string;
  id: string;
  client_id: string;
  principal_cents: number;
  interest_cents: number;
  balance_cents: number;
  due_date: string;
  created_at: string;
};
export type Repayment = {
  posting_sequence?: number;
  payment_reference?: string;
  payment_date?: string;
  interest_allocation_cents?: number;
  principal_allocation_cents?: number;
  payment_method?: string;
  external_reference?: string | null;
  created_by?: string;
  updated_at?: string;
  metadata_inferred?: boolean;
  allocation_policy?: string;
  posting_status?: "posted" | "reversed";
  reversed_at?: string | null;
  reversed_by?: string | null;
  reversal_reason?: string | null;
  reversal_request_id?: string | null;
  replaces_repayment_id?: string | null;
  replaced_by_reference?: string | null;
  loan_reference?: string;
  client_id?: string;
  receipt_snapshot?: {
    client: { id: string; name: string; man_number: string | null };
    loan_reference: string;
    currency: string;
    balance_after_cents?: number;
    principal_cents?: number;
    interest_charge_cents?: number;
    total_obligation_cents?: number;
    terms_revision?: number;
    allocation_inferred?: boolean;
    historic_note?: string;
  };

  id: string;
  loan_id: string;
  amount_cents: number;
  created_at: string;
};
export function cents(value: string): number {
  if (!/^\d{1,9}(\.\d{1,2})?$/.test(value))
    throw new Error("Enter a positive amount with up to two decimal places.");
  const [whole, fraction = ""] = value.split(".");
  return Number(whole) * 100 + Number(fraction.padEnd(2, "0"));
}
export function money(value: number) {
  return new Intl.NumberFormat("en-ZM", {
    style: "currency",
    currency: "ZMW",
    maximumFractionDigits: 2,
  }).format(value / 100);
}
export function status(loan: Loan, today: string) {
  return loan.lifecycle_status === "written_off" ||
    loan.status === "written_off"
    ? "Written off"
    : loan.balance_cents === 0
      ? "Settled"
      : loan.due_date < today
        ? "Overdue"
        : "Active";
}
export function today() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Lusaka",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

export function businessDate(value: string) {
  return value.length === 10
    ? value
    : new Intl.DateTimeFormat("en-CA", {
        timeZone: "Africa/Lusaka",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      }).format(new Date(value));
}

export type ClientAudit = {
  id: string;
  client_id: string;
  actor_id: string | null;
  action: "baseline" | "create" | "correct";
  reason: string;
  before_data: Client | null;
  after_data: Client;
  created_at: string;
};
export function findClients(clients: Client[], query: string) {
  const key = query.trim().toLowerCase();
  return clients.filter((c) =>
    [c.man_number, c.name, c.department, c.designation].some((value) =>
      value?.toLowerCase().includes(key),
    ),
  );
}

export function isCollectible(loan: Loan) {
  return (
    loan.balance_cents > 0 &&
    loan.lifecycle_status !== "written_off" &&
    loan.status !== "written_off"
  );
}

export function isPosted(receipt: Repayment) {
  return receipt.posting_status !== "reversed" && !receipt.reversed_at;
}

export type Expense = {
  id: string;
  expense_reference: string;
  expense_date: string;
  amount: number;
  amount_cents: number;
  currency: string;
  category: string;
  description: string;
  payee: string | null;
  payment_method: string;
  external_reference: string | null;
  created_by: string;
  created_at: string;
  reversed_at: string | null;
  reversed_by: string | null;
  reversal_reason: string | null;
};
