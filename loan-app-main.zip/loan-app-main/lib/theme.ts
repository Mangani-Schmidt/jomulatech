export const themeStorageKey = "lendtrack:appearance";
export type ThemePreference = "light" | "dark" | "system";
export function themePreference(value: unknown): ThemePreference {
  return value === "light" || value === "dark" ? value : "system";
}
export function resolvedTheme(
  preference: ThemePreference,
  deviceDark: boolean,
) {
  return preference === "system" ? (deviceDark ? "dark" : "light") : preference;
}

// Constant, first-party code only: runs synchronously in <head>, before the
// body can paint or React loads. Never interpolates stored/user-supplied HTML.
export const themeStartupScript = `(function(){var p="system";try{var s=localStorage.getItem(${JSON.stringify(themeStorageKey)});if(s==="light"||s==="dark")p=s;}catch(e){}var d=window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches;var t=p==="system"?(d?"dark":"light"):p;var r=document.documentElement;r.dataset.theme=t;r.dataset.themePreference=p;r.style.colorScheme=t;})();`;
