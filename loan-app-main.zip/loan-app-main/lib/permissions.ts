/** Labels and role presets mirror migration 013; PostgreSQL checks every grant.
 * Runtime UI access uses only capabilities returned by loan_defaults(). */
export const permissionModules = [
  ["view_dashboard", "Dashboard"],
  ["view_clients", "Clients"],
  ["view_loans", "Client Loan History / New Loan"],
  ["view_repayments", "Repayments"],
  ["view_imports", "Excel Imports"],
  ["view_reports", "Reports"],
  ["view_expenses", "Expenses"],
  ["view_settings", "Settings"],
  ["view_users", "User Management"],
  ["view_audit", "Audit Logs"],
] as const;
export const permissionActions = [
  ["clients", "Register and correct Clients"],
  ["delete_clients", "Delete eligible Clients"],
  ["originate", "Originate loans"],
  ["repayments", "Post Repayment Received"],
  ["imports", "Import Clients"],
  ["expenses", "Post expenses"],
  ["settings", "Change default loan settings"],
  ["adjustments", "Approve adjustments, reversals and write-offs"],
  ["users", "Add users and change permissions"],
  ["override_rate", "Override a loan rate"],
  ["security", "Change administrator authentication policy"],
  ["export_reports", "Export and print financial reports"],
] as const;
export type BusinessRole =
  "administrator" | "loan_officer" | "cashier" | "viewer";
export type PermissionKey = (
  typeof permissionModules | typeof permissionActions
)[number][0];
export type UserPermissions = Record<PermissionKey, boolean>;
export const roleLabels: Record<BusinessRole, string> = {
  administrator: "Administrator",
  loan_officer: "Loan Officer",
  cashier: "Cashier",
  viewer: "Viewer",
};
export function rolePermissions(role: BusinessRole): UserPermissions {
  const admin = role === "administrator";
  return {
    view_dashboard: true,
    view_clients: true,
    view_loans: true,
    view_repayments: true,
    view_reports: true,
    view_expenses: true,
    view_imports: admin,
    view_settings: admin,
    view_users: admin,
    view_audit: admin,
    clients: admin || role === "loan_officer",
    originate: admin || role === "loan_officer",
    repayments: admin || role === "cashier",
    imports: admin,
    delete_clients: false,
    expenses: admin,
    settings: admin,
    adjustments: admin,
    users: admin,
    override_rate: admin,
    security: admin,
    export_reports: true,
  };
}
export const permissionFlags = {
  can_view_dashboard: "view_dashboard",
  can_view_clients: "view_clients",
  can_view_loans: "view_loans",
  can_view_repayments: "view_repayments",
  can_view_reports: "view_reports",
  can_view_expenses: "view_expenses",
  can_view_imports: "view_imports",
  can_view_settings: "view_settings",
  can_view_users: "view_users",
  can_view_audit: "view_audit",
  can_register_clients: "clients",
  can_delete_clients: "delete_clients",
  can_originate: "originate",
  can_post_repayments: "repayments",
  can_import: "imports",
  can_manage_expenses: "expenses",
  can_manage_settings: "settings",
  can_approve_adjustments: "adjustments",
  can_manage_users: "users",
  can_override_rate: "override_rate",
  can_manage_security: "security",
  can_export_reports: "export_reports",
} as const satisfies Record<string, PermissionKey>;
export function capabilitiesForRole(role: BusinessRole) {
  const p = rolePermissions(role);
  return {
    ...(Object.fromEntries(
      Object.entries(permissionFlags).map(([flag, key]) => [flag, p[key]]),
    ) as Record<keyof typeof permissionFlags, boolean>),
    role,
    is_admin: role === "administrator",
    can_read: true,
    can_delete_clients: false,
  };
}
