import type { TDocumentDefinitions } from "pdfmake/interfaces";
import type { ExpenseReport } from "./expense-report";
import { businessDate } from "./domain";
export function expensePDFDefinition(r: ExpenseReport): TDocumentDefinitions {
  const money = (n: number) =>
    new Intl.NumberFormat("en-ZM", {
      style: "currency",
      currency: r.filters.currency,
    }).format(n / 100);
  const heading = [
    "Reference / payment date",
    "Category / payee / description",
    "Reversal date",
    "Status",
    "Paid in period",
    "Reversed in period",
    "Net in period",
  ];
  return {
    info: { title: "LendTrack · Expense report", author: "LendTrack" },
    pageSize: "A4",
    pageOrientation: "landscape",
    pageMargins: [30, 38, 30, 40],
    defaultStyle: { font: "Roboto", fontSize: 8, color: "#182c42" },
    footer: (page, pages) => ({
      text: `LendTrack · ${r.filters.currency} · Page ${page} of ${pages}`,
      alignment: "right",
      margin: [30, 12, 30, 0],
      fontSize: 8,
    }),
    content: [
      { text: "LendTrack", fontSize: 22, bold: true, color: "#11243c" },
      { text: "Expense report", fontSize: 16, margin: [0, 5, 0, 12] },
      {
        text: `Activity ${r.filters.from} to ${r.filters.to}, inclusive · ${r.filters.currency} · Africa/Lusaka`,
        margin: [0, 0, 0, 5],
      },
      {
        text: `Search: ${r.filters.search || "All"} · Category: ${r.filters.category || "All"} · Current status: ${r.filters.status || "All"}`,
        margin: [0, 0, 0, 5],
      },
      {
        text: `Generated: ${new Date(r.generated_at).toLocaleString("en-GB", { timeZone: "Africa/Lusaka", hour12: false })} Africa/Lusaka`,
        margin: [0, 0, 0, 12],
      },
      {
        table: {
          headerRows: 1,
          widths: [95, "*", 65, 48, 75, 75, 75],
          body: [
            heading.map((text) => ({
              text,
              bold: true,
              color: "white",
              fillColor: "#11243c",
            })),
            ...r.items.map(({ expense: e, paid, reversed, net }) => [
              `${e.expense_reference}\n${e.expense_date}`,
              `${e.category}\n${e.payee ?? "—"}\n${e.description}`,
              e.reversed_at ? businessDate(e.reversed_at) : "—",
              e.reversed_at ? "Reversed" : "Posted",
              ...[paid, reversed, net].map((n) => ({
                text: money(n),
                alignment: "right" as const,
              })),
            ]),
            [
              { text: "TOTAL", bold: true },
              "",
              "",
              "",
              ...[r.paid, r.reversed, r.net].map((n) => ({
                text: money(n),
                bold: true,
                alignment: "right" as const,
              })),
            ],
          ],
        },
        layout: {
          fillColor: (row) => (row > 0 && row % 2 === 0 ? "#eef5f7" : null),
          hLineColor: () => "#d4dfe7",
          vLineWidth: () => 0,
          paddingTop: () => 6,
          paddingBottom: () => 6,
        },
      },
      {
        text: "Net expenses = payments minus reversals effective in the selected period. Reversal dates use Africa/Lusaka. Shared business costs are not allocated to Clients. This report does not calculate Net Profit.",
        margin: [0, 15, 0, 0],
      },
    ],
  };
}
export async function expensePDFBlob(r: ExpenseReport) {
  const pdfMake = (await import("pdfmake/build/pdfmake")).default;
  const fonts = (await import("pdfmake/build/vfs_fonts")).default;
  pdfMake.addVirtualFileSystem(fonts);
  return pdfMake.createPdf(expensePDFDefinition(r)).getBlob();
}
