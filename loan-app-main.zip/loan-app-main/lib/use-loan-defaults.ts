"use client";
import {
  createContext,
  createElement,
  useContext,
  useEffect,
  useState,
  useCallback,
  useRef,
  type ReactNode,
} from "react";
import { useSupabase } from "@/lib/workspace-context";
import { demoDefaults, type LoanDefaults } from "./interest";
import { serviceError } from "./errors";
export type LoanDefaultsState = {
  value: LoanDefaults | null;
  error: string;
  loading: boolean;
  reload: () => Promise<void>;
};
const DefaultsContext = createContext<LoanDefaultsState | null>(null);
export function LoanDefaultsProvider({
  value,
  children,
}: {
  value: LoanDefaultsState;
  children: ReactNode;
}) {
  return createElement(DefaultsContext.Provider, { value }, children);
}
export function useLoanDefaults(): LoanDefaultsState {
  const inherited = useContext(DefaultsContext);
  const own = useFetchedLoanDefaults(!inherited);
  return inherited ?? own;
}
function useFetchedLoanDefaults(enabled: boolean) {
  const supabase = useSupabase();
  const generation = useRef(0);
  const [value, setValue] = useState<LoanDefaults | null>(
    supabase ? null : demoDefaults,
  );
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(!!supabase);
  const reload = useCallback(async () => {
    if (!enabled || !supabase) return;
    const expected = ++generation.current;
    setLoading(true);
    setError("");
    const { data, error } = await supabase.rpc("loan_defaults");
    if (expected !== generation.current) return;
    setLoading(false);
    if (error) {
      setValue(null);
      setError(serviceError(error, "business access and loan defaults"));
    } else setValue(data as LoanDefaults);
  }, [supabase, enabled]);
  useEffect(() => {
    if (!enabled || !supabase) return;
    let current = true;
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!current) return;
      generation.current++;
      if (!session) {
        setValue(null);
        setLoading(false);
      } else {
        setValue(null);
        void reload();
      }
    });
    return () => {
      current = false;
      generation.current++;
      subscription.unsubscribe();
    };
  }, [reload, enabled]);
  return { value, error, loading, reload };
}
