// Fictional read-only presentation data. Never imported by a server seed or migration.
import type { Client, Loan, Repayment } from "./domain";
const day = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Africa/Lusaka",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
}).format(new Date());
const date = (offset: number) => {
  const d = new Date(day + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + offset);
  return d.toISOString().slice(0, 10);
};
const sampleClients = [
  {
    id: "c1",
    name: "Chanda Mwansa",
    email: "chanda@example.com",
    phone: "+260 97 123 4567",
    created_at: date(-60),
  },
  {
    id: "c2",
    name: "Grace Phiri",
    email: "grace@example.com",
    phone: "+260 96 234 5678",
    created_at: date(-50),
  },
  {
    id: "c3",
    name: "Joseph Banda",
    email: "joseph@example.com",
    phone: "+260 97 345 6789",
    created_at: date(-40),
  },
  {
    id: "c4",
    name: "Mary Tembo",
    email: "mary@example.com",
    phone: "+260 95 456 7890",
    created_at: date(-35),
  },
  {
    id: "c5",
    name: "Peter Zulu",
    email: "peter@example.com",
    phone: "+260 96 567 8901",
    created_at: date(-20),
  },
  {
    id: "c6",
    name: "Ruth Mulenga",
    email: "ruth@example.com",
    phone: "+260 97 678 9012",
    created_at: date(-10),
  },
];
export const demoClients: Client[] = sampleClients.map((c, i) => ({
  ...c,
  man_number: `00${i + 1}24`,
  department: [
    "Finance",
    "Operations",
    "Education",
    "Health",
    "Operations",
    "Finance",
  ][i],
  designation: [
    "Accountant",
    "Supervisor",
    "Teacher",
    "Nurse",
    "Coordinator",
    "Analyst",
  ][i],
  address: null,
  is_active: true,
  created_by: "demo-owner",
  updated_at: c.created_at,
  revision: 1,
}));
const sampleLoans: Loan[] = [
  {
    id: "l1",
    client_id: "c1",
    principal_cents: 1500000,
    interest_cents: 150000,
    balance_cents: 1100000,
    due_date: date(7),
    created_at: date(-45),
  },
  {
    id: "l2",
    client_id: "c2",
    principal_cents: 800000,
    interest_cents: 80000,
    balance_cents: 440000,
    due_date: date(-4),
    created_at: date(-40),
  },
  {
    id: "l3",
    client_id: "c3",
    principal_cents: 2500000,
    interest_cents: 250000,
    balance_cents: 2200000,
    due_date: date(14),
    created_at: date(-30),
  },
  {
    id: "l4",
    client_id: "c4",
    principal_cents: 500000,
    interest_cents: 50000,
    balance_cents: 0,
    due_date: date(-2),
    created_at: date(-35),
  },
  {
    id: "l5",
    client_id: "c5",
    principal_cents: 1200000,
    interest_cents: 120000,
    balance_cents: 1320000,
    due_date: date(21),
    created_at: date(-15),
  },
  {
    id: "l6",
    client_id: "c6",
    principal_cents: 650000,
    interest_cents: 65000,
    balance_cents: 715000,
    due_date: date(5),
    created_at: date(-10),
  },
];
const demoLoanBase: Loan[] = sampleLoans.map((loan, index) => ({
  ...loan,
  loan_reference: `LN-${String(index + 1).padStart(8, "0")}`,
  amount_disbursed_cents: loan.principal_cents,
  lifecycle_status: loan.balance_cents === 0 ? "settled" : "active",
  created_by: "demo-owner",
  creator_inferred: false,
  updated_at: loan.created_at,
  disbursement_date: loan.created_at.slice(0, 10),
}));
const sampleRepayments: Repayment[] = [
  { id: "r1", loan_id: "l1", amount_cents: 550000, created_at: date(-1) },
  { id: "r2", loan_id: "l2", amount_cents: 440000, created_at: date(-2) },
  { id: "r3", loan_id: "l3", amount_cents: 550000, created_at: date(-4) },
  { id: "r4", loan_id: "l4", amount_cents: 550000, created_at: date(-6) },
];

export const demoRepayments: Repayment[] = sampleRepayments.map((r, i) => {
  const loan = demoLoanBase.find((l) => l.id === r.loan_id)!;
  return {
    ...r,
    posting_sequence: sampleRepayments.length - i,
    payment_reference: `PAY-${String(i + 1).padStart(8, "0")}`,
    payment_date: r.created_at.slice(0, 10),
    interest_allocation_cents: loan.interest_cents,
    principal_allocation_cents: r.amount_cents - loan.interest_cents,
    payment_method: "cash",
    created_by: "demo-owner",
    posting_status: "posted",
    updated_at: r.created_at,
    loan_reference: loan.loan_reference,
  };
});

export const demoLoans: Loan[] = demoLoanBase.map((l) => {
  const payments = demoRepayments.filter((r) => r.loan_id === l.id);
  const interest = payments.reduce(
    (sum, r) => sum + (r.interest_allocation_cents ?? 0),
    0,
  );
  const principal = payments.reduce(
    (sum, r) => sum + (r.principal_allocation_cents ?? 0),
    0,
  );
  return {
    ...l,
    interest_repaid_cents: interest,
    principal_repaid_cents: principal,
    interest_outstanding_cents: l.interest_cents - interest,
    principal_outstanding_cents: l.principal_cents - principal,
  };
});

export const demoReportSource = {
  expenses: [],
  generated_at: new Date().toISOString(),
  timezone: "Africa/Lusaka",
  clients: demoClients,
  loans: demoLoans.map((l) => ({ ...l, currency: "ZMW" })),
  repayments: demoRepayments,
  terms_audit: demoLoans.map((l) => ({
    id: `terms-${l.id}`,
    loan_id: l.id,
    action: "originate",
    created_at: l.created_at,
    before_data: null,
    after_data: l,
    reason: "Sample origination",
  })),
  status_audit: [],
  repayment_audit: [],
};
