/** Small component-owned memory cache for display while a fresh RPC runs.
 * It is never persisted, never grants access and never substitutes for an export check. */
export class ScopedSnapshotCache<T> {
  private scope = "";
  private rows = new Map<string, { at: number; value: T }>();
  constructor(private readonly now = Date.now) {}
  setScope(scope: string) {
    if (scope !== this.scope) {
      this.clear();
      this.scope = scope;
    }
  }
  clear() {
    this.rows.clear();
    this.scope = "";
  }
  read(scope: string, key: string) {
    if (scope !== this.scope) return null;
    const row = this.rows.get(key);
    return row && this.now() - row.at <= 60000 ? row.value : null;
  }
  write(scope: string, key: string, value: T) {
    if (scope !== this.scope) return;
    this.rows.delete(key);
    this.rows.set(key, { at: this.now(), value });
    if (this.rows.size > 6) this.rows.delete(this.rows.keys().next().value!);
  }
}
