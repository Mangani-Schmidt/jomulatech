import { clientLabels } from "./ui-labels";
import {
  businessDate,
  type Client,
  type Loan,
  type Repayment,
  type Expense,
} from "./domain";

export type ReportAudit = {
  id: string;
  loan_id: string;
  action: string;
  created_at: string;
  before_data: Partial<Loan> | null;
  after_data: Partial<Loan>;
  reason: string;
  actor_id?: string | null;
  request_id?: string | null;
};
export type ReportSource = {
  ledger_event_count?: number;
  certifications?: ReportingCertification[];
  filter_options?: { department: string[]; designation: string[] };
  generated_at: string;
  timezone: string;
  expenses?: Expense[] | null;
  clients: Client[];
  loans: Loan[];
  repayments: Repayment[];
  terms_audit: ReportAudit[];
  status_audit: ReportAudit[];
  repayment_audit: {
    id: string;
    repayment_id: string;
    action: string;
    created_at: string;
    reason: string;
    actor_id?: string | null;
  }[];
};
export type ReportingCertification = {
  id: string;
  from_date: string;
  to_date: string;
  currency: string;
  ledger_event_count: number;
  created_by: string;
  created_at: string;
  reason: string;
  revoked_at: string | null;
};
export type ReportFilters = {
  from: string;
  to: string;
  asOf: string;
  currency: string;
  search: string;
  department: string;
  designation: string;
  status: string;
  disbursedFrom: string;
  disbursedTo: string;
};
export type ReportAmounts = {
  disbursed: number;
  received: number;
  principalReceived: number;
  interestReceived: number;
  expectedInterest: number;
  interestAdjusted: number;
  principal: number;
  interest: number;
  owed: number;
  collectible: number;
  writtenOff: number;
  overdue: number;
  recognizedLoss: number;
};
export type LoanReport = ReportAmounts & {
  loan_id: string;
  client_id: string;
  loan_reference: string;
  name: string;
  man_number: string;
  department: string;
  designation: string;
  currency: string;
  status: string;
  disbursement_date: string;
  due_date: string;
};
export type ClientReport = ReportAmounts & {
  client_id: string;
  name: string;
  man_number: string;
  department: string;
  designation: string;
  currency: string;
  loanCount: number;
};
export type FinancialReport = {
  netProfit: number | null;
  recordedResult: number | null;
  certification: ReportingCertification | null;
  filters: ReportFilters;
  generated_at: string;
  loans: LoanReport[];
  clients: ClientReport[];
  totals: ReportAmounts;
  overdueCount: number;
  clientsReceivingLoans: number;
  loansIssued: number;
  inferred: boolean;
  expenses: number | null;
  expenseScope: "unrecorded" | "business" | "unallocated";
};
const zero = (): ReportAmounts => ({
  disbursed: 0,
  received: 0,
  principalReceived: 0,
  interestReceived: 0,
  expectedInterest: 0,
  interestAdjusted: 0,
  principal: 0,
  interest: 0,
  owed: 0,
  collectible: 0,
  writtenOff: 0,
  overdue: 0,
  recognizedLoss: 0,
});
export const reportAmountLabels: Record<keyof ReportAmounts, string> = {
  disbursed: "Amount Disbursed in period",
  received: "Net Repayment Received in period",
  principalReceived: "Principal Received in period",
  interestReceived: "Interest Income Received in period",
  expectedInterest: "Expected interest on disbursements in period",
  interestAdjusted: "Interest adjustments in period",
  principal: "Outstanding principal as of date",
  interest: "Unpaid interest as of date",
  owed: "Total amount Clients owe as of date",
  collectible: "Collectible balance as of date",
  writtenOff: "Written-off balance as of date",
  overdue: "Overdue balance as of date",
  recognizedLoss: "Recognized principal losses in period",
};
function add(a: number, b: number) {
  const n = a + b;
  if (!Number.isSafeInteger(n))
    throw new Error(
      "Report exceeds the supported exact monetary range. Narrow the filters.",
    );
  return n;
}
function aggregate(target: ReportAmounts, row: ReportAmounts) {
  for (const k of Object.keys(target) as (keyof ReportAmounts)[])
    if (k in reportAmountLabels) target[k] = add(target[k], row[k]);
}
const inPeriod = (date: string, f: ReportFilters) =>
  date >= f.from && date <= f.to;
function validDate(value: string) {
  return (
    /^\d{4}-\d{2}-\d{2}$/.test(value) &&
    !Number.isNaN(Date.parse(value + "T12:00:00Z")) &&
    new Date(value + "T12:00:00Z").toISOString().slice(0, 10) === value
  );
}
export function defaultReportFilters(day: string): ReportFilters {
  return {
    from: day.slice(0, 7) + "-01",
    to: day,
    asOf: day,
    currency: "ZMW",
    search: "",
    department: "",
    designation: "",
    status: "",
    disbursedFrom: "",
    disbursedTo: "",
  };
}
// A linked replacement is an adjustment, not a second historic cash receipt.
// Its original payment date remains on the receipt; financial effect begins on
// correction posting date alongside the reversal of the original receipt.
export function repaymentEffectiveDate(r: Repayment) {
  return r.replaces_repayment_id
    ? businessDate(r.created_at)
    : (r.payment_date ?? businessDate(r.created_at));
}
function groupBy<T>(rows: T[], key: (row: T) => string) {
  const groups = new Map<string, T[]>();
  for (const row of rows) {
    const id = key(row);
    const group = groups.get(id);
    if (group) group.push(row);
    else groups.set(id, [row]);
  }
  return groups;
}
export function buildReport(
  source: ReportSource,
  f: ReportFilters,
): FinancialReport {
  const current = businessDate(source.generated_at);
  if (
    ![f.from, f.to, f.asOf].every(validDate) ||
    f.from < "1900-01-01" ||
    f.from > f.to ||
    f.to > f.asOf ||
    f.asOf > current
  )
    throw new Error(
      "Choose real dates: activity start ≤ activity end ≤ balance date ≤ today.",
    );
  if (
    [f.disbursedFrom, f.disbursedTo].some((d) => d && !validDate(d)) ||
    (f.disbursedFrom && f.disbursedTo && f.disbursedFrom > f.disbursedTo)
  )
    throw new Error("Choose a valid disbursement date range.");
  if (!/^[A-Z]{3}$/.test(f.currency)) throw new Error("Choose one currency.");
  if (!["", "Active", "Overdue", "Settled", "Written off"].includes(f.status))
    throw new Error("Choose a supported loan status.");
  const clientIndex = new Map(source.clients.map((c) => [c.id, c]));
  const termsIndex = groupBy(source.terms_audit, (a) => a.loan_id);
  const statusIndex = groupBy(source.status_audit, (a) => a.loan_id);
  const receiptIndex = groupBy(source.repayments, (r) => r.loan_id);
  const baselineIndex = new Map(
    source.repayment_audit
      .filter((a) => a.action === "baseline")
      .map((a) => [a.repayment_id, a]),
  );
  const rows: LoanReport[] = [];
  let inferred = false;
  for (const loan of source.loans) {
    const client = clientIndex.get(loan.client_id);
    if (!client) continue;
    const disbursed = loan.disbursement_date ?? businessDate(loan.created_at);
    if (
      (loan.currency ?? "ZMW") !== f.currency ||
      disbursed > f.asOf ||
      (f.disbursedFrom && disbursed < f.disbursedFrom) ||
      (f.disbursedTo && disbursed > f.disbursedTo)
    )
      continue;
    const search = f.search.trim().toLowerCase();
    if (
      search &&
      ![
        client.name,
        client.man_number ?? "",
        loan.loan_reference ?? loan.id,
      ].some((s) => s.toLowerCase().includes(search))
    )
      continue;
    if (
      (f.department && client.department !== f.department) ||
      (f.designation && client.designation !== f.designation)
    )
      continue;
    const terms = (termsIndex.get(loan.id) ?? [])
      .slice()
      .sort(
        (a, b) =>
          a.created_at.localeCompare(b.created_at) ||
          (a.after_data.terms_revision ?? 0) -
            (b.after_data.terms_revision ?? 0),
      );
    const statuses = (statusIndex.get(loan.id) ?? [])
      .slice()
      .sort((a, b) => a.created_at.localeCompare(b.created_at));
    const payments = receiptIndex.get(loan.id) ?? [];
    const baseline = terms.find((a) => a.action === "baseline");
    if (baseline) inferred = true;
    if (!terms.length)
      throw new Error(
        "Loan term history is missing. Reconcile the ledger before reporting.",
      );
    let floor = baseline ? businessDate(baseline.created_at) : "";
    for (const r of payments.filter((r) => r.metadata_inferred)) {
      inferred = true;
      const a = baselineIndex.get(r.id);
      if (!a)
        throw new Error(
          "Historic receipt provenance is missing; reconcile the ledger before reporting.",
        );
      const date = businessDate(a.created_at);
      if (date > floor) floor = date;
    }
    if (floor && (f.asOf < floor || f.from < floor))
      throw new Error(
        `Reliable allocation history for ${loan.loan_reference ?? loan.id} begins ${floor}. Choose activity and balance dates on or after ${floor}; earlier allocations were not recorded.`,
      );
    const initial =
      terms.find((a) => a.action === "originate")?.after_data ??
      baseline?.after_data ??
      terms[0]?.before_data ??
      loan;
    let actual = initial;
    for (const a of terms)
      if (businessDate(a.created_at) <= f.asOf && a.action === "adjust")
        actual = a.after_data;
    const charge = actual.interest_cents ?? loan.interest_cents;
    const due = actual.due_date ?? loan.due_date;
    let principalPaid = 0,
      interestPaid = 0;
    const amounts = zero();
    for (const r of payments) {
      const date = repaymentEffectiveDate(r);
      const reversal = r.reversed_at ? businessDate(r.reversed_at) : null;
      if (
        r.principal_allocation_cents == null ||
        r.interest_allocation_cents == null
      )
        throw new Error(
          "Receipt allocations are missing. Apply migration 006 before reporting.",
        );
      if (date <= f.asOf && (!reversal || reversal > f.asOf)) {
        principalPaid = add(principalPaid, r.principal_allocation_cents);
        interestPaid = add(interestPaid, r.interest_allocation_cents);
      }
      const sign =
        Number(inPeriod(date, f)) - Number(!!reversal && inPeriod(reversal, f));
      amounts.received = add(amounts.received, sign * r.amount_cents);
      amounts.principalReceived = add(
        amounts.principalReceived,
        sign * r.principal_allocation_cents,
      );
      amounts.interestReceived = add(
        amounts.interestReceived,
        sign * r.interest_allocation_cents,
      );
    }
    let writtenOff = !!statuses.find(
      (a) =>
        a.action === "baseline" &&
        a.after_data.lifecycle_status === "written_off" &&
        businessDate(a.created_at) <= f.asOf,
    );
    for (const a of statuses)
      if (businessDate(a.created_at) <= f.asOf) {
        if (a.action === "write_off") writtenOff = true;
        if (a.action === "reverse_write_off") writtenOff = false;
      }
    // A write-off recognizes only unrecovered principal under this cash-interest
    // report policy. Uncollected expected interest was never received income.
    function principalLoss(a: ReportAudit) {
      const paid = payments
        .filter(
          (r) =>
            r.created_at <= a.created_at &&
            (!r.reversed_at || r.reversed_at > a.created_at),
        )
        .reduce((s, r) => add(s, r.principal_allocation_cents ?? 0), 0);
      return loan.principal_cents - paid;
    }
    for (const a of statuses.filter((a) =>
      inPeriod(businessDate(a.created_at), f),
    )) {
      if (a.action === "write_off")
        amounts.recognizedLoss = add(amounts.recognizedLoss, principalLoss(a));
      if (a.action === "reverse_write_off") {
        const original = statuses.find(
          (o) =>
            o.action === "write_off" &&
            o.request_id === a.before_data?.written_off_request_id,
        );
        if (!original)
          throw new Error(
            "Original write-off history is missing; recognized losses require reconciliation.",
          );
        amounts.recognizedLoss = add(
          amounts.recognizedLoss,
          -principalLoss(original),
        );
      }
    }
    amounts.principal = loan.principal_cents - principalPaid;
    amounts.interest = charge - interestPaid;
    if (amounts.principal < 0 || amounts.interest < 0)
      throw new Error(
        `Backdated allocations exceed the terms effective on ${f.asOf} for ${loan.loan_reference ?? loan.id}. Select a later balance date or reconcile the effective-date history.`,
      );
    amounts.owed = add(amounts.principal, amounts.interest);
    const status = writtenOff
      ? "Written off"
      : amounts.owed === 0
        ? "Settled"
        : due < f.asOf
          ? "Overdue"
          : "Active";
    if (f.status && f.status !== status) continue;
    if (inPeriod(disbursed, f)) {
      amounts.disbursed = loan.principal_cents;
      amounts.expectedInterest = initial.interest_cents ?? loan.interest_cents;
    }
    for (const a of terms.filter(
      (a) => a.action === "adjust" && inPeriod(businessDate(a.created_at), f),
    ))
      amounts.interestAdjusted = add(
        amounts.interestAdjusted,
        (a.after_data.interest_cents ?? 0) -
          (a.before_data?.interest_cents ?? 0),
      );
    amounts.writtenOff = writtenOff ? amounts.owed : 0;
    amounts.collectible = writtenOff ? 0 : amounts.owed;
    amounts.overdue = status === "Overdue" ? amounts.owed : 0;
    rows.push({
      ...amounts,
      loan_id: loan.id,
      client_id: client.id,
      loan_reference: loan.loan_reference ?? loan.id,
      name: client.name,
      man_number: client.man_number ?? "",
      department: client.department ?? "",
      designation: client.designation ?? "",
      currency: f.currency,
      status,
      disbursement_date: disbursed,
      due_date: due,
    });
  }
  rows.sort(
    (a, b) =>
      a.name.localeCompare(b.name) ||
      a.loan_reference.localeCompare(b.loan_reference),
  );
  const clients: ClientReport[] = [];
  const clientTotals = new Map<string, ClientReport>();
  const totals = zero();
  for (const row of rows) {
    aggregate(totals, row);
    let c = clientTotals.get(row.client_id);
    if (!c) {
      c = {
        ...zero(),
        client_id: row.client_id,
        name: row.name,
        man_number: row.man_number,
        department: row.department,
        designation: row.designation,
        currency: row.currency,
        loanCount: 0,
      };
      clients.push(c);
      clientTotals.set(c.client_id, c);
    }
    aggregate(c, row);
    c.loanCount++;
  }
  const businessScope = ![
    f.search.trim(),
    f.department,
    f.designation,
    f.status,
    f.disbursedFrom,
    f.disbursedTo,
  ].some(Boolean);
  const certification =
    businessScope && Number.isSafeInteger(source.ledger_event_count)
      ? (source.certifications?.find(
          (c) =>
            !c.revoked_at &&
            c.currency === f.currency &&
            c.from_date === f.from &&
            c.to_date === f.to &&
            c.ledger_event_count === source.ledger_event_count,
        ) ?? null)
      : null;
  // An authorized, loaded empty array is a genuine zero. Missing/redacted
  // expense data must never be interpreted as a zero-cost period.
  const expenseScope = !businessScope
    ? "unallocated"
    : Array.isArray(source.expenses)
      ? "business"
      : "unrecorded";
  let expenses: number | null = expenseScope === "business" ? 0 : null;
  if (expenses !== null)
    for (const expense of source.expenses ?? []) {
      if (expense.currency !== f.currency) continue;
      const sign =
        Number(inPeriod(expense.expense_date, f)) -
        Number(
          !!expense.reversed_at &&
            inPeriod(businessDate(expense.reversed_at), f),
        );
      expenses = add(expenses, sign * expense.amount_cents);
    }
  return {
    recordedResult:
      expenses === null
        ? null
        : add(add(totals.interestReceived, -expenses), -totals.recognizedLoss),
    netProfit:
      certification && expenses !== null
        ? add(add(totals.interestReceived, -expenses), -totals.recognizedLoss)
        : null,
    certification,
    filters: { ...f },
    generated_at: source.generated_at,
    loans: rows,
    clients,
    totals,
    clientsReceivingLoans: new Set(
      rows.filter((r) => r.disbursed > 0).map((r) => r.client_id),
    ).size,
    loansIssued: rows.filter((r) => r.disbursed > 0).length,
    overdueCount: rows.filter((l) => l.status === "Overdue").length,
    inferred,
    expenses,
    expenseScope,
  };
}
export function reportMoney(cents: number, currency: string) {
  return new Intl.NumberFormat("en-ZM", { style: "currency", currency }).format(
    cents / 100,
  );
}
// Spreadsheet applications may execute formulas even in quoted CSV cells.
export function csvCell(value: string | number) {
  let s = String(value);
  if (typeof value === "string" && /^[\s\u0000-\u001f]*[=+\-@]/.test(s))
    s = "'" + s;
  return '"' + s.replaceAll('"', '""') + '"';
}
export function reportCSV(report: FinancialReport, kind: "loans" | "clients") {
  const f = report.filters;
  const meta = [
    ["Report", kind === "loans" ? "Loan report" : "Client report"],
    ["Clients Receiving Loans", report.clientsReceivingLoans],
    ["Loans issued in period", report.loansIssued],
    ["Activity from", f.from],
    ["Activity to", f.to],
    ["Balances as of", f.asOf],
    ["Currency", f.currency],
    ["Generated at", report.generated_at],
    [
      "Net Profit",
      report.netProfit === null
        ? "Unavailable: coverage not certified for this exact snapshot and period"
        : report.netProfit / 100,
    ],
    ["Coverage certification", report.certification?.id ?? "Not certified"],
    ["Search", f.search],
    ["Department (current)", f.department],
    ["Designation (current)", f.designation],
    ["Status as of balance date", f.status],
    ["Disbursed from", f.disbursedFrom],
    ["Disbursed to", f.disbursedTo],
    [
      "Business expenses",
      report.expenses === null
        ? report.expenseScope === "unrecorded"
          ? "Not recorded; Net Profit unavailable"
          : "Unallocated: Client/loan filters applied; Net Profit unavailable"
        : String(report.expenses / 100),
    ],
    [
      "Result from recorded entries (not final profit)",
      report.recordedResult === null
        ? "Unavailable / unallocated"
        : report.recordedResult / 100,
    ],
    [
      "Expense coverage",
      report.certification
        ? `Approved for this snapshot: ${report.certification.id}`
        : "Entries do not certify complete coverage; Net Profit unavailable",
    ],
    [
      "Recognized losses policy",
      "Unrecovered principal at write-off, reversed on write-off reversal; no expense allocation",
    ],
    [
      "History",
      "Restated by effective date; reversal/adjustment/linked replacement date is posting business date",
    ],
  ];
  const keys = Object.keys(reportAmountLabels) as (keyof ReportAmounts)[];
  const headers = [
    "Client",
    "Man#",
    "Department",
    "Designation",
    ...(kind === "loans"
      ? [
          "Loan reference",
          "Loan ID",
          "Client ID",
          "Status as of balance date",
          "Disbursement date",
          "Due date",
        ]
      : ["Client ID", "Loan count"]),
    "Currency",
    ...keys.map((k) =>
      kind === "clients" && k === "disbursed"
        ? clientLabels.totalDisbursed + " in period"
        : kind === "clients" && k === "interestReceived"
          ? clientLabels.interestIncome + " (received in period)"
          : kind === "clients" && k === "owed"
            ? clientLabels.outstanding + " as of date"
            : reportAmountLabels[k],
    ),
  ];
  const data = (kind === "loans" ? report.loans : report.clients).map((r) => [
    r.name,
    r.man_number,
    r.department,
    r.designation,
    ...("loan_id" in r
      ? [
          r.loan_reference,
          r.loan_id,
          r.client_id,
          r.status,
          r.disbursement_date,
          r.due_date,
        ]
      : [r.client_id, r.loanCount]),
    r.currency,
    ...keys.map((k) => r[k] / 100),
  ]);
  return (
    "\uFEFF" +
    [
      ...meta,
      [],
      headers,
      ...data,
      [
        "TOTAL",
        ...Array(headers.length - keys.length - 1).fill(""),
        ...keys.map((k) => report.totals[k] / 100),
      ],
    ]
      .map((row) => row.map(csvCell).join(","))
      .join("\r\n")
  );
}
