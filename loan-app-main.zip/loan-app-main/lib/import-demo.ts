// Presentation-only walkthrough of the bundled fictional rows. Production
// uploads still require server Auth, role checks and PostgreSQL validation.
import sample from "./import-sample.json";
import { demoClients } from "./demo";
import { clientSchema, cents, today, type Client } from "./domain";
import { flatInterest, dueDate, rateBps } from "./interest";
import {
  importFields,
  importLabels,
  defaultMapping,
  type ColumnMapping,
  type ImportMode,
  type ImportTerms,
  type ImportData,
  type ImportReport,
} from "./import";
export const sampleFilename = "lendtrack-dummy-clients.xlsx";
export const sampleDownload = "/samples/" + sampleFilename;
export const sampleColumns = importFields.map((field, index) => ({
  index: index + 1,
  label: importLabels[field],
}));
export const sampleMapping = defaultMapping(sampleColumns);
export const sampleInspection = {
  columns: sampleColumns,
  mapping: sampleMapping,
  rowCount: sample.length,
  fileHash: "bundled-fictional-sample",
};

export function previewSampleImport(
  mode: ImportMode | "",
  mapping: ColumnMapping,
  terms: Partial<ImportTerms>,
  clients: Client[] = demoClients,
): ImportReport {
  if (mode !== "clients" && mode !== "loans")
    throw new Error("Select an explicit import mode.");
  const columns = importFields.map((field) => mapping[field]);
  if (
    new Set(columns).size !== 6 ||
    columns.some((c) => !Number.isInteger(c) || c < 1 || c > 6)
  )
    throw new Error("Map all six fields to different source columns.");
  let bps = 0,
    due = "";
  if (mode === "loans") {
    if (
      !terms.disbursement_date ||
      terms.disbursement_date < "1900-01-01" ||
      terms.disbursement_date > today() ||
      terms.calculation_method !== "one_time_flat" ||
      terms.rate_basis !== "entire_term" ||
      terms.interest_type !== "flat_percent" ||
      terms.due_rule !== "days_after_disbursement"
    )
      throw new Error(
        "Confirm a valid disbursement date, entire-term flat interest and due-date rule.",
      );
    bps = rateBps(terms.interest_value ?? "");
    due = dueDate(terms.disbursement_date, terms.term_days!);
  }
  const data = sample.map((source) => {
    const values = importFields.map((field) => source[field]);
    const mapped = Object.fromEntries(
      importFields.map((field) => [field, values[mapping[field] - 1]]),
    ) as Record<(typeof importFields)[number], string>;
    return { ...mapped, man_numeric: false, parse_errors: [] } as ImportData;
  });
  const counts = new Map<string, number>();
  for (const row of data) {
    const key = row.man_number.trim().toLowerCase();
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  const rows = data.map((row, index) => {
    const errors: string[] = [];
    if (!clientSchema.safeParse(row).success)
      errors.push("Client identity fields are missing or invalid.");
    if (!/^[0-9]{1,9}$/.test(row.source_no) || Number(row.source_no) < 1)
      errors.push("no# must be a positive source row number.");
    if ((counts.get(row.man_number.trim().toLowerCase()) ?? 0) > 1)
      errors.push("Duplicate Man# in this workbook.");
    const client = clients.find(
      (c) =>
        c.man_number?.trim().toLowerCase() ===
        row.man_number.trim().toLowerCase(),
    );
    if (
      client &&
      ["name", "department", "designation"].some(
        (k) => client[k as keyof Client] !== row[k as keyof ImportData],
      )
    )
      errors.push(
        "Conflicting Client details. Use an audited correction; the import will not overwrite them.",
      );
    if (mode === "loans") {
      if (client && !client.is_active) errors.push("Client is inactive.");
      try {
        row.principal_cents = cents(row.amount);
        row.interest_cents = flatInterest(row.principal_cents, bps);
        row.total_obligation_cents = row.principal_cents + row.interest_cents;
        row.rate_bps = bps;
        row.due_date = due;
      } catch (e) {
        errors.push((e as Error).message);
      }
    }
    return {
      id: `demo-row-${index + 1}`,
      excel_row: index + 2,
      source_no: row.source_no,
      data: row,
      outcome: errors.length
        ? ("rejected" as const)
        : client && mode === "clients"
          ? ("unchanged" as const)
          : ("accepted" as const),
      errors,
      warnings: [],
      client_id: client?.id ?? null,
      loan_id: null,
    };
  });
  return {
    batch: {
      id: crypto.randomUUID(),
      filename: sampleFilename,
      mode,
      terms: mode === "loans" ? { ...terms } : {},
      status: "preview",
      preview_version: 1,
      accepted: rows.filter((r) => r.outcome === "accepted").length,
      rejected: rows.filter((r) => r.outcome === "rejected").length,
      unchanged: rows.filter((r) => r.outcome === "unchanged").length,
      uploaded_by: "Fictional demo",
      created_at: new Date().toISOString(),
      completed_at: null,
    },
    rows,
  };
}
