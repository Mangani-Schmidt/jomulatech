"use client";
import { useEffect, useRef, useState } from "react";
import { useSupabase } from "@/lib/workspace-context";
import { definitePostingFailure } from "./errors";
import {
  pendingPosting,
  allowPostingReentry,
  rememberPosting,
  forgetPosting,
  type PostingIntent,
  type PostingOperation,
} from "./posting-intent";
function savedResult(
  operation: PostingOperation,
  data: unknown,
): Record<string, string> {
  const value =
    typeof data === "string"
      ? { loan_id: data }
      : (data as Record<string, string> | null);
  const key =
    operation === "originate_loan"
      ? "loan_id"
      : operation === "post_expense"
        ? "expense_id"
        : "repayment_id";
  if (!value || typeof value[key] !== "string" || !value[key])
    throw new Error(
      "The posting response could not be confirmed. Recover the original transaction before creating another entry.",
    );
  return value;
}

/** Only opaque references survive reload/logout. Reviewed payloads stay in
 * memory. Re-entry after reconciliation always reuses the original key. */
export function usePostingIntent() {
  const supabase = useSupabase();
  const [pending, setPending] = useState<PostingIntent | null>(null);
  const [checking, setChecking] = useState(!!supabase);
  const [storageError, setStorageError] = useState("");
  const binding = useRef<{ actor: string; id: string } | null>(null);
  async function actor() {
    const result = await supabase?.auth.getSession();
    const id = result?.data.session?.user.id;
    if (!id) throw new Error("Sign in before posting.");
    return id;
  }
  useEffect(() => {
    let active = true;
    if (supabase)
      actor()
        .then((id) => {
          if (active) {
            const saved = pendingPosting(id);
            binding.current = saved ? { actor: id, id: saved.id } : null;
            setPending(saved);
          }
        })
        .catch((e) => {
          if (active) setStorageError(e.message);
        })
        .finally(() => {
          if (active) setChecking(false);
        });
    return () => {
      active = false;
    };
  }, []);
  async function execute(intent: PostingIntent, id: string) {
    const status = await supabase!.rpc("posting_request_status", {
      p_request_id: intent.id,
      p_operation: intent.operation,
    });
    if (status.error) throw status.error;
    if (status.data) return savedResult(intent.operation, status.data);
    if (!intent.body) {
      allowPostingReentry(id);
      setPending(null);
      throw new Error(
        "No posted result was found for this reference. Re-enter and review the transaction in its original module. Its original request reference will be reused; no sensitive form contents were saved.",
      );
    }
    if ((await actor()) !== id)
      throw new Error(
        "The signed-in account changed. Sign in with the original account before retrying this request.",
      );
    const result = await supabase!.rpc(intent.operation, {
      ...intent.body,
      p_request_id: intent.id,
    });
    if (result.error) {
      if (definitePostingFailure(result.error) && !intent.reentered) {
        forgetPosting(id, intent.id);
        setPending(null);
      }
      throw result.error;
    }
    return savedResult(intent.operation, result.data);
  }
  async function post(
    operation: PostingOperation,
    body: Record<string, unknown>,
  ) {
    const id = await actor();
    const intent = rememberPosting(id, operation, body);
    binding.current = { actor: id, id: intent.id };
    setPending(intent);
    // The first send needs no status read: there has been no previous request.
    const result = await supabase!.rpc(intent.operation, {
      ...intent.body,
      p_request_id: intent.id,
    });
    if (result.error) {
      if (definitePostingFailure(result.error) && !intent.reentered) {
        forgetPosting(id, intent.id);
        setPending(null);
      }
      throw result.error;
    }
    if ((await actor()) !== id)
      throw new Error(
        "The signed-in account changed. The original request is retained for its original user to recover.",
      );
    return savedResult(intent.operation, result.data);
  }
  async function recover() {
    const id = await actor(),
      intent = pendingPosting(id);
    if (!intent)
      throw new Error(
        "No pending posting was found. Refresh the ledger before starting a new entry.",
      );
    setPending(intent);
    binding.current = { actor: id, id: intent.id };
    const result = await execute(intent, id);
    if ((await actor()) !== id)
      throw new Error(
        "The signed-in account changed. Recover the original request after signing in with its original account.",
      );
    return { operation: intent.operation, result };
  }
  async function complete() {
    const saved = binding.current;
    if (saved) forgetPosting(saved.actor, saved.id);
    binding.current = null;
    setPending(null);
  }
  return { pending, checking, storageError, post, recover, complete };
}
