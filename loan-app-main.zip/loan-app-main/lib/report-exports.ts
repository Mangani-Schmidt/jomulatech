import {
  reportWorkbook,
  workbookMoney,
  generatedTime,
  type WorkbookTable,
  type Cell,
} from "./workbook";
import {
  reportAmountLabels,
  type FinancialReport,
  type ReportAmounts,
} from "./reporting";
import type { ExpenseReport } from "./expense-report";
export function financialWorkbook(r: FinancialReport) {
  const f = r.filters,
    keys = Object.keys(reportAmountLabels) as (keyof ReportAmounts)[];
  const common = [
    { label: "Client", width: 28 },
    { label: "Man#", width: 18 },
    { label: "Department" },
    { label: "Designation" },
  ];
  const amounts = keys.map((k) => ({
    label: reportAmountLabels[k],
    kind: "money" as const,
  }));
  const tables: WorkbookTable[] = [
    {
      name: "Filtered loans",
      currency: f.currency,
      columns: [
        ...common,
        { label: "Loan reference" },
        { label: "Loan ID", width: 38 },
        { label: "Client ID", width: 38 },
        { label: "Status" },
        { label: "Disbursement date", kind: "date" },
        { label: "Due date", kind: "date" },
        { label: "Currency" },
        ...amounts,
      ],
      rows: r.loans.map((l) => [
        l.name,
        l.man_number,
        l.department,
        l.designation,
        l.loan_reference,
        l.loan_id,
        l.client_id,
        l.status,
        l.disbursement_date,
        l.due_date,
        l.currency,
        ...keys.map((k) => workbookMoney(l[k])),
      ]),
      totals: [
        "TOTAL",
        ...Array(10).fill(""),
        ...keys.map((k) => workbookMoney(r.totals[k])),
      ],
    },
    {
      name: "Filtered Clients",
      currency: f.currency,
      columns: [
        ...common,
        { label: "Client ID", width: 38 },
        { label: "Loan count (all matching)", kind: "integer" },
        { label: "Currency" },
        ...amounts,
      ],
      rows: r.clients.map((c) => [
        c.name,
        c.man_number,
        c.department,
        c.designation,
        c.client_id,
        c.loanCount,
        c.currency,
        ...keys.map((k) => workbookMoney(c[k])),
      ]),
      totals: [
        "TOTAL",
        ...Array(6).fill(""),
        ...keys.map((k) => workbookMoney(r.totals[k])),
      ],
    },
  ];
  return reportWorkbook(
    "Loan and Client financial report",
    [
      ["Activity from", f.from],
      ["Activity to (inclusive)", f.to],
      ["Balances as of (end of day)", f.asOf],
      ["Currency", f.currency],
      ["Generated at", generatedTime(new Date().toISOString())],
      ["Data snapshot", generatedTime(r.generated_at)],
      ["Clients Receiving Loans", r.clientsReceivingLoans],
      ["Loans issued in period", r.loansIssued],
      ...Object.entries(f)
        .filter(([k]) => !["from", "to", "asOf", "currency"].includes(k))
        .map(
          ([k, v]) =>
            [
              (
                {
                  search: "Search by Man# or Client Name",
                  department: "Department",
                  designation: "Designation",
                  status: "Loan status as of balance date",
                  disbursedFrom: "Disbursement from",
                  disbursedTo: "Disbursement to",
                } as Record<string, string>
              )[k] ?? k,
              v || "All",
            ] as [string, Cell],
        ),
      [
        "Business expenses",
        r.expenses === null
          ? "Unavailable / unallocated"
          : workbookMoney(r.expenses),
      ],
      [
        "Result from recorded entries (not final profit)",
        r.recordedResult === null
          ? "Unavailable / unallocated"
          : workbookMoney(r.recordedResult),
      ],
      [
        "Net Profit",
        r.netProfit === null
          ? "Unavailable: exact period coverage not certified"
          : workbookMoney(r.netProfit),
      ],
      [
        "Financial policy",
        "Principal repayments are not income. Interest income received is separate from expected interest, expenses and losses. Currency totals are separate.",
      ],
      [
        "Loss policy",
        "Unrecovered principal at write-off; reversed on write-off reversal.",
      ],
      [
        "History",
        "Restated effective financial dates; linked replacements take effect on correction posting date. Client identity fields are current.",
      ],
      ["Coverage certification", r.certification?.id ?? "Not certified"],
      ["Allocation", "Shared business expenses are not allocated to Clients."],
    ],
    tables,
  );
}
export const expenseMeta = (r: ExpenseReport): [string, Cell][] => [
  ["Activity from", r.filters.from],
  ["Activity to (inclusive)", r.filters.to],
  ["Currency", r.filters.currency],
  ["Search", r.filters.search || "All"],
  ["Category", r.filters.category || "All"],
  ["Current status", r.filters.status || "All"],
  ["Generated at", generatedTime(r.generated_at)],
  ["Paid in period", workbookMoney(r.paid)],
  ["Reversed in period", workbookMoney(r.reversed)],
  ["Net expenses in period", workbookMoney(r.net)],
  [
    "Policy",
    "Expense payments minus reversals effective in the period, using Africa/Lusaka. Shared business costs; no Client allocation or Net Profit calculation.",
  ],
];
export function expenseWorkbook(r: ExpenseReport) {
  return reportWorkbook("Expense report", expenseMeta(r), [
    {
      name: "Filtered expenses",
      currency: r.filters.currency,
      columns: [
        { label: "Reference" },
        { label: "Expense date", kind: "date" },
        { label: "Category" },
        { label: "Payee" },
        { label: "Description", width: 60 },
        { label: "Method" },
        { label: "External reference" },
        { label: "Current status" },
        { label: "Reversal date", kind: "date" },
        { label: "Currency" },
        { label: "Original amount", kind: "money" },
        { label: "Paid in period", kind: "money" },
        { label: "Reversed in period", kind: "money" },
        { label: "Net expense in period", kind: "money" },
        { label: "Creator", width: 38 },
      ],
      rows: r.items.map(({ expense: e, paid, reversed, net }) => [
        e.expense_reference,
        e.expense_date,
        e.category,
        e.payee,
        e.description,
        e.payment_method,
        e.external_reference,
        e.reversed_at ? "Reversed" : "Posted",
        e.reversed_at
          ? new Intl.DateTimeFormat("en-CA", {
              timeZone: "Africa/Lusaka",
            }).format(new Date(e.reversed_at))
          : "",
        e.currency,
        workbookMoney(e.amount_cents),
        workbookMoney(paid),
        workbookMoney(reversed),
        workbookMoney(net),
        e.created_by,
      ]),
      totals: [
        "TOTAL",
        ...Array(10).fill(""),
        workbookMoney(r.paid),
        workbookMoney(r.reversed),
        workbookMoney(r.net),
        "",
      ],
    },
  ]);
}
