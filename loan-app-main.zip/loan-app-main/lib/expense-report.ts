import { businessDate, type Expense } from "./domain";
import { exactSum, validateRange } from "./report-period";
export type ExpenseFilters = {
  from: string;
  to: string;
  currency: string;
  search: string;
  category: string;
  status: "" | "Posted" | "Reversed";
};
export function buildExpenseReport(
  source: Expense[],
  filters: ExpenseFilters,
  generated_at = new Date().toISOString(),
) {
  validateRange(filters.from, filters.to);
  if (!/^[A-Z]{3}$/.test(filters.currency))
    throw new Error("Enter one three-letter currency code.");
  const inPeriod = (day: string) => day >= filters.from && day <= filters.to;
  const items = source
    .filter(
      (e) =>
        e.currency === filters.currency &&
        (!filters.category || e.category === filters.category) &&
        (!filters.status ||
          (e.reversed_at ? "Reversed" : "Posted") === filters.status) &&
        [
          e.expense_reference,
          e.category,
          e.description,
          e.payee ?? "",
          e.external_reference ?? "",
        ]
          .join(" ")
          .toLowerCase()
          .includes(filters.search.trim().toLowerCase()),
    )
    .filter(
      (e) =>
        inPeriod(e.expense_date) ||
        (e.reversed_at && inPeriod(businessDate(e.reversed_at))),
    )
    .map((expense) => ({
      expense,
      paid: inPeriod(expense.expense_date) ? expense.amount_cents : 0,
      reversed:
        expense.reversed_at && inPeriod(businessDate(expense.reversed_at))
          ? expense.amount_cents
          : 0,
    }))
    .map((r) => ({ ...r, net: exactSum([r.paid, -r.reversed]) }));
  return {
    filters: { ...filters },
    generated_at,
    items,
    paid: exactSum(items.map((r) => r.paid)),
    reversed: exactSum(items.map((r) => r.reversed)),
    net: exactSum(items.map((r) => r.net)),
  };
}
export type ExpenseReport = ReturnType<typeof buildExpenseReport>;
