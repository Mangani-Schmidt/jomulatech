import type { LoanDefaults } from "./interest";
import type { WorkspaceView } from "./ui-labels";
export type Capabilities = LoanDefaults["capabilities"];
export type Capability = Exclude<keyof Capabilities, "role">;
/** UI requirements refer to the flags returned by loan_defaults(). Roles and
 * assurance policy are defined by PostgreSQL, never inferred in the browser. */
export const viewCapability: Record<WorkspaceView | "Settings", Capability> = {
  Dashboard: "can_view_dashboard",
  Clients: "can_view_clients",
  Loans: "can_view_loans",
  Repayments: "can_view_repayments",
  Reports: "can_view_reports",
  "New Loan": "can_originate",
  "Excel Imports": "can_view_imports",
  Settings: "can_view_settings",
};
export function hasCapability(
  value: Capabilities | undefined | null,
  key: Capability,
) {
  return value?.can_read === true && value[key] === true;
}

export const postingCapability = {
  originate_loan: "can_originate",
  post_repayment: "can_post_repayments",
  correct_repayment: "can_approve_adjustments",
  post_expense: "can_manage_expenses",
} as const satisfies Record<
  import("./posting-intent").PostingOperation,
  Capability
>;

export function firstAccessiblePath(value: Capabilities | null | undefined) {
  for (const view of [
    "Dashboard",
    "Clients",
    "Loans",
    "Repayments",
    "Excel Imports",
    "Reports",
  ] as const)
    if (hasCapability(value, viewCapability[view]))
      return (
        "/dashboard#" +
        (
          {
            Dashboard: "dashboard",
            Clients: "clients",
            Loans: "loan-history",
            Repayments: "repayments",
            "Excel Imports": "excel-imports",
            Reports: "reports",
          } as const
        )[view]
      );
  for (const [flag, path] of [
    ["can_view_expenses", "/expenses"],
    ["can_view_settings", "/settings"],
    ["can_view_users", "/users"],
    ["can_view_audit", "/audit-logs"],
  ] as const)
    if (hasCapability(value, flag)) return path;
  return "/security";
}
export function permittedReturnPath(
  value: Capabilities | null | undefined,
  target: string,
) {
  const url = new URL(target, "https://internal.invalid");
  if (url.origin !== "https://internal.invalid")
    return firstAccessiblePath(value);
  const routes: Record<string, Capability> = {
    "/settings": "can_view_settings",
    "/expenses": "can_view_expenses",
    "/users": "can_view_users",
    "/administration": "can_view_users",
    "/audit-logs": "can_view_audit",
  };
  if (url.pathname === "/security") return target;
  if (url.pathname === "/dashboard") {
    const hash = url.hash.slice(1) || "dashboard";
    const views: Record<string, Capability> = {
      dashboard: "can_view_dashboard",
      clients: "can_view_clients",
      "loan-history": "can_view_loans",
      repayments: "can_view_repayments",
      "new-loan": "can_originate",
      "excel-imports": "can_view_imports",
      reports: "can_view_reports",
    };
    if (views[hash] && hasCapability(value, views[hash])) return target;
  } else if (routes[url.pathname] && hasCapability(value, routes[url.pathname]))
    return target;
  return firstAccessiblePath(value);
}
