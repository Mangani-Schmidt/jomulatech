export const clientLabels = {
  add: "Add Client",
  register: "Client Register",
  details: "Client Details",
  statement: "Client Statement",
  history: "Client Loan History",
  search: "Search by Man# or Client Name",
  totalDisbursed: "Total Amount Disbursed to Client",
  outstanding: "Client Outstanding Balance",
  interestIncome: "Interest Income per Client",
} as const;
export type WorkspaceView =
  | "Dashboard"
  | "Clients"
  | "New Loan"
  | "Repayments"
  | "Excel Imports"
  | "Reports"
  | "Loans";
export const viewHashes: Record<WorkspaceView, string> = {
  Dashboard: "dashboard",
  Clients: "clients",
  "New Loan": "new-loan",
  Repayments: "repayments",
  "Excel Imports": "excel-imports",
  Reports: "reports",
  Loans: "loan-history",
};
