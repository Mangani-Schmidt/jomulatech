import { type Loan, type Repayment, isPosted } from "./domain";
export const paymentMethods = {
  cash: "Cash",
  bank_transfer: "Bank transfer",
  mobile_money: "Mobile money",
  card: "Card",
  other: "Other",
} as const;
export function receivedCents(value: string) {
  if (!/^\d{1,10}(\.\d{1,2})?$/.test(value))
    throw new Error("Enter a positive amount with up to two decimal places.");
  const [whole, fraction = ""] = value.split(".");
  const amount = Number(whole) * 100 + Number(fraction.padEnd(2, "0"));
  if (amount <= 0 || amount > 199999999998)
    throw new Error(
      "Repayment Received must be positive and within supported limits.",
    );
  return amount;
}
export function outstandingParts(loan: Loan) {
  const interest =
    loan.interest_outstanding_cents ??
    Math.min(loan.interest_cents, loan.balance_cents);
  return {
    interest,
    principal:
      loan.principal_outstanding_cents ?? loan.balance_cents - interest,
  };
}
export function repaymentAllocation(
  loan: Loan,
  amount: number,
  original?: Repayment,
) {
  const parts = outstandingParts(loan);
  const interestDue =
    parts.interest + (original?.interest_allocation_cents ?? 0);
  const balance = loan.balance_cents + (original?.amount_cents ?? 0);
  if (amount > balance)
    throw new Error(
      "Overpayment: Repayment Received exceeds the outstanding balance. Reduce the amount or review the loan.",
    );
  const interest = Math.min(amount, interestDue);
  return {
    interest,
    principal: amount - interest,
    balanceAfter: balance - amount,
  };
}
export function netReceived(rows: Repayment[]) {
  return rows.filter(isPosted).reduce((sum, row) => sum + row.amount_cents, 0);
}
