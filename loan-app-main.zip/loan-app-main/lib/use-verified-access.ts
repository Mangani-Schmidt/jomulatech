"use client";
import {
  createContext,
  createElement,
  useContext,
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { usePathname } from "next/navigation";
import { useSessionSafety } from "@/components/session-boundary";
import { getSupabase } from "./supabase";
import { hasCapability, type Capability } from "./access";
import type { LoanDefaults } from "./interest";
import { serviceError } from "./errors";
import {
  sessionIdentity,
  sessionReadyForRead,
  identityWasVerified,
  markIdentityVerified,
  SESSION_RESUMED_EVENT,
  SESSION_REVALIDATING_EVENT,
  SESSION_READY_EVENT,
} from "./session-activity";
import type { Session } from "@supabase/supabase-js";
export type AccessState =
  | "checking"
  | "allowed"
  | "signed-out"
  | "pending"
  | "denied"
  | "unavailable"
  | "error";
type SharedAccess = {
  state: AccessState;
  value: LoanDefaults | null;
  identityVerified: boolean;
  verifiedKey: string | null;
  verifiedPath: string;
  loading: boolean;
  error: string;
  reload: () => Promise<void>;
};
const VerifiedAccessContext = createContext<SharedAccess | null>(null);
const publicPaths = new Set(["/", "/login", "/signup", "/forgot-password"]);
const normalizePath = (path: string) => path.replace(/\/+$/, "") || "/";
/** Persistent route metadata stays in React memory only. All record reads and
 * operations still require their current database permissions and session. */
export function VerifiedAccessProvider({ children }: { children: ReactNode }) {
  const path = normalizePath(usePathname());
  const demo = path === "/demo" || path.startsWith("/demo/");
  const value = useFetchedVerifiedAccess(
    !demo && !publicPaths.has(path),
    demo,
    path,
  );
  return createElement(VerifiedAccessContext.Provider, { value }, children);
}
function useFetchedVerifiedAccess(
  enabled: boolean,
  demo: boolean,
  path: string,
): SharedAccess {
  const supabase = demo ? null : getSupabase();
  const requireBusiness = true,
    capability: Capability = "can_read";
  const safety = useSessionSafety();
  const sessionReady =
    safety.state === "active" ||
    safety.state === "unconfigured" ||
    safety.state === "anonymous";
  const scope = "shared";
  const pathRef = useRef(path);
  pathRef.current = path;
  const previousPath = useRef(path);
  const [result, setResult] = useState<{ state: AccessState; scope: string }>({
    state: "checking",
    scope,
  });
  const [value, setValue] = useState<LoanDefaults | null>(null);
  const [identityVerified, setIdentityVerified] = useState(false);
  const [verifiedKey, setVerifiedKey] = useState<string | null>(null);
  const [verifiedPath, setVerifiedPath] = useState("");
  const [loading, setLoading] = useState(true),
    [error, setError] = useState("");
  const generation = useRef(0),
    actor = useRef<string | null>(null);
  const refresh = useRef<() => Promise<void>>(async () => {});
  const reload = useCallback(async () => refresh.current(), []);
  useEffect(() => {
    if (!enabled) {
      actor.current = null;
      setValue(null);
      setIdentityVerified(false);
      setVerifiedKey(null);
      setVerifiedPath("");
      setResult({ state: "checking", scope });
      setLoading(true);
      setError("");
      return;
    }
    if (!sessionReady) {
      setResult({ state: "checking", scope });
      setLoading(true);
      return;
    }
    let active = true;
    const state = (state: AccessState) => setResult({ state, scope });
    if (!supabase) {
      state("unavailable");
      setLoading(false);
      return;
    }
    let startedAt = 0;
    let inFlight: {
      identity: string;
      token: string | null;
      promise: Promise<void>;
    } | null = null;
    async function verify(session: Session | null, expected: number) {
      if (!active || expected !== generation.current) return;
      if (session && !sessionReadyForRead(sessionIdentity(session))) return;
      startedAt = Date.now();
      const checkedPath = pathRef.current;
      const current = () => active && expected === generation.current;
      if (!session) {
        setIdentityVerified(false);
        setVerifiedKey(null);
        if (current()) {
          setValue(null);
          setIdentityVerified(false);
          setVerifiedKey(null);
          state("signed-out");
          setLoading(false);
        }
        return;
      }
      try {
        // First/changed identities must pass getUser before any membership
        // read. For an already verified session, the two fresh server checks
        // can run in parallel; neither response alone grants UI access.
        const identityRead = supabase!.auth
          .getUser(session.access_token)
          .then((identity) => {
            if (current()) {
              const valid =
                !identity.error &&
                identity.data.user?.id === session.user.id &&
                sessionReadyForRead(sessionIdentity(session));
              setIdentityVerified(valid);
              setVerifiedKey(valid ? sessionIdentity(session) : null);
              // Own account security does not require a business membership.
              // Publish verified identity without waiting for membership lookup.
              if (valid) markIdentityVerified(sessionIdentity(session));
              else setValue(null);
            }
            return identity;
          });
        const membershipRead = !requireBusiness
          ? null
          : identityWasVerified(sessionIdentity(session))
            ? Promise.resolve(supabase!.rpc("loan_defaults"))
            : identityRead.then((identity) => {
                if (
                  !current() ||
                  identity.error ||
                  identity.data.user?.id !== session.user.id ||
                  !sessionReadyForRead(sessionIdentity(session))
                )
                  return null;
                return supabase!.rpc("loan_defaults");
              });
        const [identity, membership] = await Promise.all([
          identityRead,
          membershipRead,
        ]);
        if (!current()) return;
        if (identity.error) {
          setIdentityVerified(false);
          setVerifiedKey(null);
          state(
            identity.error.status === 401 ||
              identity.error.status === 403 ||
              ["bad_jwt", "session_not_found"].includes(
                identity.error.code ?? "",
              )
              ? "signed-out"
              : "error",
          );
          setValue(null);
          setError(serviceError(identity.error, "business access"));
          return;
        }
        if (!identity.data.user || identity.data.user.id !== session.user.id) {
          setValue(null);
          state("signed-out");
          return;
        }
        if (requireBusiness) {
          if (!membership) return;
          if (membership.error) {
            setValue(null);
            setError(serviceError(membership.error, "business access"));
            state(membership.error.code === "42501" ? "pending" : "error");
            return;
          }
          if (!hasCapability(membership.data?.capabilities, "can_read")) {
            setValue(null);
            state("pending");
            return;
          }
          setValue(membership.data as LoanDefaults);
          setVerifiedPath(checkedPath);
          state(
            hasCapability(membership.data.capabilities, capability)
              ? "allowed"
              : "denied",
          );
        } else state("allowed");
      } catch (failure) {
        if (current()) {
          setValue(null);
          setError(serviceError(failure, "business access"));
          state("error");
        }
      } finally {
        if (current()) setLoading(false);
      }
    }
    refresh.current = () => {
      const expected = ++generation.current;
      setLoading(true);
      setError("");
      const operation: NonNullable<typeof inFlight> = {
        identity: actor.current ?? "checking",
        token: null,
        promise: Promise.resolve(),
      };
      inFlight = operation;
      const promise = (async () => {
        try {
          const { data, error } = await supabase!.auth.getSession();
          if (error) throw error;
          if (inFlight === operation)
            operation.token = data.session?.access_token ?? "";
          const nextKey = data.session
            ? sessionIdentity(data.session)
            : "signed-out";
          if (nextKey !== actor.current) {
            actor.current = nextKey;
            setValue(null);
            setIdentityVerified(false);
            setVerifiedKey(null);
            setVerifiedPath("");
            state(data.session ? "checking" : "signed-out");
          }
          await verify(data.session, expected);
        } catch (failure) {
          if (active && expected === generation.current) {
            setValue(null);
            setIdentityVerified(false);
            setVerifiedKey(null);
            setLoading(false);
            setError(serviceError(failure, "business access"));
            state("error");
          }
        }
      })();
      operation.promise = promise;
      void promise.finally(() => {
        if (inFlight?.promise === promise) inFlight = null;
      });
      return promise;
    };
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!active) return;
      const identity = session ? sessionIdentity(session) : "signed-out";
      if (
        inFlight?.identity === identity &&
        (inFlight.token === null ||
          inFlight.token === (session?.access_token ?? ""))
      )
        return;
      const expected = ++generation.current;
      setLoading(true);
      setError("");
      if (identity !== actor.current) {
        actor.current = identity;
        setValue(null);
        setIdentityVerified(false);
        setVerifiedKey(null);
        setVerifiedPath("");
        state(session ? "checking" : "signed-out");
      }
      // Leave the SDK's auth lock before making authenticated requests.
      queueMicrotask(() => {
        if (active) {
          const promise = verify(session, expected);
          inFlight = { identity, token: session?.access_token ?? "", promise };
          void promise.finally(() => {
            if (inFlight?.promise === promise) inFlight = null;
          });
        }
      });
    });
    const resumed = (event: Event) => {
      const began =
        (event as CustomEvent<{ startedAt: number }>).detail?.startedAt ??
        Date.now();
      // The SDK often emits SIGNED_IN on visibility recovery. That request
      // already verifies this return; a focus-only return still verifies here.
      if (startedAt < began && !inFlight) void refresh.current();
    };
    const revalidating = () => {
      if (!inFlight) void refresh.current();
    };
    window.addEventListener(SESSION_REVALIDATING_EVENT, revalidating);
    const activated = () => {
      if (!inFlight) void refresh.current();
    };
    window.addEventListener(SESSION_READY_EVENT, activated);
    window.addEventListener(SESSION_RESUMED_EVENT, resumed);
    return () => {
      window.removeEventListener(SESSION_REVALIDATING_EVENT, revalidating);
      window.removeEventListener(SESSION_READY_EVENT, activated);
      window.removeEventListener(SESSION_RESUMED_EVENT, resumed);
      active = false;
      generation.current++;
      refresh.current = async () => {};
      subscription.unsubscribe();
    };
  }, [supabase, enabled, scope, sessionReady]);
  useEffect(() => {
    const changed = previousPath.current !== path;
    previousPath.current = path;
    if (changed && enabled && sessionReady) void reload();
  }, [path, enabled, sessionReady, reload]);
  return {
    state: enabled ? result.state : "checking",
    value: enabled ? value : null,
    identityVerified: enabled && identityVerified,
    verifiedKey: enabled ? verifiedKey : null,
    verifiedPath,
    loading,
    error,
    reload,
  };
}
export function useVerifiedAccessSnapshot(
  requireBusiness = false,
  capability: Capability = "can_read",
) {
  const shared = useContext(VerifiedAccessContext);
  const safety = useSessionSafety();
  const path = normalizePath(usePathname());
  if (!shared)
    throw new Error("VerifiedAccessProvider must wrap protected routes.");
  const ready = ["active", "unconfigured", "anonymous"].includes(safety.state);
  const currentIdentity =
    shared.identityVerified &&
    !!shared.verifiedKey &&
    sessionReadyForRead(shared.verifiedKey);
  let state: AccessState = ready ? shared.state : "checking";
  if (
    !requireBusiness &&
    currentIdentity &&
    ready &&
    !["signed-out", "unavailable"].includes(state)
  )
    state = "allowed";
  else if (state === "allowed") {
    if (!currentIdentity || shared.verifiedPath !== path) state = "checking";
    else if (
      requireBusiness &&
      !hasCapability(shared.value?.capabilities, capability)
    )
      state = "denied";
  }
  return {
    state,
    value: shared.value,
    error: shared.error,
    loading: state === "allowed" ? false : shared.loading,
    refreshing: requireBusiness && state === "allowed" && shared.loading,
    reload: shared.reload,
  };
}
export function useVerifiedAccess(requireBusiness = false) {
  return useVerifiedAccessSnapshot(requireBusiness).state;
}
