import type { SupabaseClient } from "@supabase/supabase-js";
import { manNumberSchema, type Client } from "./domain";
/** Match the register's existing case-insensitive uniqueness rule without
 * converting identifiers to numbers or changing the stored spelling. */
export function sameManNumber(left: string | null, right: string) {
  return (
    left !== null && left.trim().toLowerCase() === right.trim().toLowerCase()
  );
}
export function localManConflict(
  clients: Client[],
  value: string,
  excludeId?: string,
) {
  const parsed = manNumberSchema.safeParse(value);
  return parsed.success
    ? (clients.find(
        (client) =>
          client.id !== excludeId &&
          sameManNumber(client.man_number, parsed.data),
      ) ?? null)
    : null;
}
export async function findRegisteredMan(
  db: SupabaseClient,
  value: string,
): Promise<Client | null> {
  const { data, error } = await db.rpc("find_client_by_man", {
    p_man_number: manNumberSchema.parse(value),
  });
  if (error)
    throw new Error(
      "Could not verify this Man# against Client Register. Check your access and connection, then try again. No Client was saved.",
    );
  return data as Client | null;
}
