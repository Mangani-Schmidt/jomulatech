import { hasCapability } from "./access";
import { rateBps, type LoanDefaults } from "./interest";
/** Validate the selected rate against the current snapshot. This never updates
 * Settings; PostgreSQL independently rechecks permission, revision and reason. */
export function loanRateTerms(
  value: string,
  defaults: LoanDefaults,
  reason: string,
) {
  const bps = rateBps(value);
  const override = bps !== defaults.settings.default_rate_bps;
  const overrideReason = override ? reason.trim() : "";
  if (override) {
    if (!hasCapability(defaults.capabilities, "can_override_rate"))
      throw new Error(
        "Loan-rate override permission is required to change the default rate.",
      );
    if ([...overrideReason].length < 5 || [...overrideReason].length > 500)
      throw new Error(
        "A rate override reason of 5–500 characters is required.",
      );
  }
  return { bps, override, overrideReason };
}
