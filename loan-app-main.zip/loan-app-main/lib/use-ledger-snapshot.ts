"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useSupabase } from "@/lib/workspace-context";
import { demoClients, demoLoans, demoRepayments } from "./demo";
import { type Client, type Loan, type Repayment } from "./domain";
import { serviceError } from "./errors";
import { SESSION_REVALIDATING_EVENT } from "./session-activity";
export function useLedgerSnapshot(
  account: string | null,
  scope = account ?? "signed-out",
) {
  const supabase = useSupabase(),
    demo = !supabase;
  const [snapshot, setSnapshot] = useState({
    scope,
    clients: demo ? demoClients : ([] as Client[]),
    loans: demo ? demoLoans : ([] as Loan[]),
    repayments: demo ? demoRepayments : ([] as Repayment[]),
    revision: 0,
  });
  const [loading, setLoading] = useState(false),
    [error, setError] = useState("");
  const [reportRevision, setReportRevision] = useState(0);
  const generation = useRef(0),
    identity = useRef(scope),
    loadedAt = useRef(0),
    pending = useRef<Promise<void> | null>(null);
  identity.current = scope;
  const clear = useCallback(() => {
    generation.current++;
    loadedAt.current = 0;
    pending.current = null;
    setSnapshot({
      scope: "",
      clients: [],
      loans: [],
      repayments: [],
      revision: 0,
    });
    setLoading(false);
  }, []);
  const load = useCallback(
    async (notify = true) => {
      if (!supabase || !account) return;
      const expected = ++generation.current;
      setLoading(true);
      setError("");
      // Publish invalidation before the reads so the independent atomic report
      // and ledger RPCs refresh in parallel, after the committed mutation.
      if (notify) setReportRevision((v) => v + 1);
      try {
        const result = await supabase.rpc("ledger_snapshot");
        if (expected !== generation.current || identity.current !== scope)
          return;
        if (result.error) throw result.error;
        if (
          !result.data ||
          !["clients", "loans", "repayments"].every((k) =>
            Array.isArray(result.data[k]),
          )
        )
          throw new Error("Invalid ledger snapshot");
        loadedAt.current = Date.now();
        setSnapshot((prev) => ({
          scope,
          clients: result.data.clients as Client[],
          loans: result.data.loans as Loan[],
          repayments: result.data.repayments as Repayment[],
          revision: prev.revision + 1,
        }));
      } catch (e) {
        if (expected === generation.current && identity.current === scope) {
          setSnapshot({
            scope,
            clients: [],
            loans: [],
            repayments: [],
            revision: 0,
          });
          setError(serviceError(e, "the ledger"));
        }
        throw new Error(serviceError(e, "the ledger"));
      } finally {
        if (expected === generation.current) setLoading(false);
      }
    },
    [account, scope, supabase],
  );
  const refresh = useCallback(() => {
    const p = load();
    pending.current = p;
    void p
      .finally(() => {
        if (pending.current === p) pending.current = null;
      })
      .catch(() => {});
    return p;
  }, [load]);
  const refreshIfStale = useCallback(() => {
    if (!demo && !pending.current && Date.now() - loadedAt.current >= 30000)
      void refresh().catch(() => {});
  }, [demo, refresh]);
  useEffect(() => {
    if (demo) return;
    clear();
    const initial = load(false);
    pending.current = initial;
    void initial
      .finally(() => {
        if (pending.current === initial) pending.current = null;
      })
      .catch(() => {});
    const resumed = () => {
      if (!pending.current) void refresh().catch(() => {});
    };
    window.addEventListener(SESSION_REVALIDATING_EVENT, resumed);
    return () => {
      generation.current++;
      window.removeEventListener(SESSION_REVALIDATING_EVENT, resumed);
    };
  }, [account, scope, clear, demo, load, refresh]);
  const current = demo || snapshot.scope === scope;
  return {
    clients: current ? snapshot.clients : [],
    loans: current ? snapshot.loans : [],
    repayments: current ? snapshot.repayments : [],
    revision: current ? snapshot.revision : 0,
    reportRevision,
    loading: loading || (!demo && !current),
    error: current ? error : "",
    refresh,
    refreshIfStale,
    clear,
  };
}
