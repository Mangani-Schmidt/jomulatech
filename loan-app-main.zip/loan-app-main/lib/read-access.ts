import type { SupabaseClient } from "@supabase/supabase-js";
export class ReadAccessError extends Error {
  constructor(
    message: string,
    public readonly denied = false,
  ) {
    super(message);
  }
}
/** Recheck the existing PostgreSQL read capability before using a cached report
 * for an export or print. Receipt/statement printing already reloads its RPC. */
export async function requireReadAccess(
  db: SupabaseClient,
  permission = "export_reports",
) {
  const result = await db.rpc("has_capability", { p_action: permission });
  if (result.error)
    throw new ReadAccessError(
      "Could not verify read access. Check your connection and try again; no report was exported or printed.",
      ["42501", "PGRST301", "PGRST302", "PGRST303"].includes(
        result.error.code ?? "",
      ),
    );
  if (result.data !== true)
    throw new ReadAccessError(
      "Your current business permissions do not allow reports or exports. Refresh your access or ask an Administrator.",
      true,
    );
}
