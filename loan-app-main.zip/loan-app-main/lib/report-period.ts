import { businessDate, isPosted, type Repayment } from "./domain";
export type PeriodPreset =
  "Today" | "This Week" | "This Month" | "Custom Date Range";
export function periodRange(preset: PeriodPreset, day: string) {
  const date = new Date(day + "T00:00:00Z");
  const from =
    preset === "This Week"
      ? new Date(date.getTime() - ((date.getUTCDay() + 6) % 7) * 86400000)
          .toISOString()
          .slice(0, 10)
      : preset === "This Month"
        ? day.slice(0, 8) + "01"
        : day;
  return { from, to: day };
}
export function validateRange(from: string, to: string) {
  const valid = (s: string) =>
    /^\d{4}-\d{2}-\d{2}$/.test(s) &&
    Number.isFinite(Date.parse(s)) &&
    new Date(s + "T00:00:00Z").toISOString().slice(0, 10) === s;
  if (!valid(from) || !valid(to) || from < "1900-01-01" || from > to)
    throw new Error("Choose real dates with the start on or before the end.");
}
export function exactSum(values: number[]) {
  let n = 0n;
  for (const v of values) {
    if (!Number.isSafeInteger(v))
      throw new Error("Invalid monetary value. Reload or narrow the report.");
    n += BigInt(v);
  }
  if (
    n > BigInt(Number.MAX_SAFE_INTEGER) ||
    n < BigInt(Number.MIN_SAFE_INTEGER)
  )
    throw new Error(
      "Total exceeds the supported exact range. Narrow the filters.",
    );
  return Number(n);
}
// Receipt history filters use the actual payment date, retaining reversed rows.
// Effective correction/reversal activity continues to use the financial Reports engine.
export function repaymentPeriod(rows: Repayment[], from: string, to: string) {
  validateRange(from, to);
  const selected = rows.filter((r) => {
    const day = r.payment_date ?? businessDate(r.created_at);
    return day >= from && day <= to;
  });
  return {
    rows: selected,
    received: exactSum(selected.filter(isPosted).map((r) => r.amount_cents)),
    principal: selected
      .filter(isPosted)
      .every((r) => r.principal_allocation_cents != null)
      ? exactSum(
          selected.filter(isPosted).map((r) => r.principal_allocation_cents!),
        )
      : null,
    interest: selected
      .filter(isPosted)
      .every((r) => r.interest_allocation_cents != null)
      ? exactSum(
          selected.filter(isPosted).map((r) => r.interest_allocation_cents!),
        )
      : null,
  };
}
