import { defineConfig } from "@playwright/test";
import { existsSync } from "node:fs";
export default defineConfig({
  testIgnore: [
    "**/report-delivery-auth.spec.ts",
    "**/usability-auth.spec.ts",
    "**/navigation-refresh-auth.spec.ts",
    "**/client-lifecycle-auth.spec.ts",
    "**/user-access-session.spec.ts",
    "**/manual-man-auth.spec.ts",
    "**/loan-rate-auth.spec.ts",
    "**/permissions-auth.spec.ts",
    "**/dashboard-auth.spec.ts",
    "**/public-auth.spec.ts",
    "**/demo-explorer-auth.spec.ts",
    "**/audit-fixes.spec.ts",
    "**/authorized-register.spec.ts",
    "**/interest-settings.spec.ts",
    "**/loans.spec.ts",
    "**/repayments.spec.ts",
    "**/reports-auth.spec.ts",
    "**/security-auth.spec.ts",
  ],
  testDir: "./tests/browser",
  use: {
    baseURL: "http://127.0.0.1:3000",
    headless: true,
    serviceWorkers: "block",
    launchOptions: {
      executablePath:
        process.env.CHROMIUM_PATH ||
        (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined),
      args: ["--no-sandbox"],
    },
  },
  workers: 1,
  webServer: {
    command: "node scripts/demo-test-server.mjs",
    url: "http://127.0.0.1:3000",
    reuseExistingServer: false,
    timeout: 120000,
  },
});
