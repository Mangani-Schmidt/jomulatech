begin;
-- Preserve existing IDs and loans. Legacy rows require an audited completion;
-- no placeholder Man# or employment details are fabricated.
alter table public.clients
 add column man_number text,
 add column department text,
 add column designation text,
 add column address text,
 add column is_active boolean not null default true,
 add column created_by uuid references auth.users(id),
 add column updated_at timestamptz,
 add column revision integer not null default 1;
update public.clients set created_by = owner_id, updated_at = created_at;
alter table public.clients alter column created_by set not null;
alter table public.clients alter column updated_at set not null;
alter table public.clients alter column updated_at set default now();
alter table public.clients add constraint clients_register_required check (
 man_number is not null and length(man_number) between 1 and 50 and man_number = trim(man_number)
 and department is not null and length(trim(department)) between 1 and 120
 and designation is not null and length(trim(designation)) between 1 and 120
) not valid;
alter table public.clients add constraint clients_address_length check (length(address) <= 500);
create unique index clients_unique_man_number on public.clients(owner_id, lower(man_number));

create table public.client_audit (
 id uuid primary key default gen_random_uuid(),
 client_id uuid not null,
 owner_id uuid not null,
 actor_id uuid references auth.users(id),
 action text not null check (action in ('baseline', 'create', 'correct')),
 reason text not null,
 before_data jsonb,
 after_data jsonb not null,
 created_at timestamptz not null default clock_timestamp(),
 foreign key (client_id, owner_id) references public.clients(id, owner_id)
);
create index client_audit_client on public.client_audit(owner_id, client_id, created_at);
alter table public.client_audit enable row level security;
create policy client_audit_read on public.client_audit for select to authenticated using (owner_id = (select auth.uid()));
revoke all on public.client_audit from public, anon, authenticated;
grant select on public.client_audit to authenticated;
insert into public.client_audit(client_id,owner_id,action,reason,after_data)
 select c.id,c.owner_id,'baseline','Register migration: existing ledger record; creator inferred from ledger ownership.',to_jsonb(c) from public.clients c;

create function public.audit_client_change() returns trigger
language plpgsql security definer set search_path = '' as $$
declare v_reason text;
begin
 if auth.uid() is null or new.owner_id <> auth.uid() then raise exception 'Client authorization required'; end if;
 if tg_op = 'INSERT' then
   new.created_by := auth.uid();
   new.created_at := clock_timestamp();
   new.updated_at := new.created_at;
   new.revision := 1;
 else
   if new.id <> old.id or new.owner_id <> old.owner_id or new.created_by <> old.created_by or new.created_at <> old.created_at then raise exception 'Client identity and creator are immutable'; end if;
   v_reason := current_setting('app.client_correction_reason',true);
   if v_reason is null or length(trim(v_reason)) not between 5 and 500 then raise exception 'A correction reason of 5–500 characters is required'; end if;
   new.updated_at := clock_timestamp();
   new.revision := old.revision + 1;
 end if;
 new.man_number := trim(new.man_number);
 new.name := trim(new.name);
 new.department := trim(new.department);
 new.designation := trim(new.designation);
 new.phone := nullif(trim(new.phone),'');
 new.email := nullif(trim(new.email),'');
 new.address := nullif(trim(new.address),'');
 return new;
end $$;
create trigger client_metadata before insert or update on public.clients for each row execute function public.audit_client_change();

create function public.append_client_audit() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
 insert into public.client_audit(client_id,owner_id,actor_id,action,reason,before_data,after_data)
 values (new.id,new.owner_id,auth.uid(),case when tg_op = 'INSERT' then 'create' else 'correct' end,
 case when tg_op = 'INSERT' then 'Client created' else trim(current_setting('app.client_correction_reason')) end,
 case when tg_op = 'UPDATE' then to_jsonb(old) else null end,to_jsonb(new));
 return new;
end $$;
create trigger client_audit_entry after insert or update on public.clients for each row execute function public.append_client_audit();
revoke all on function public.audit_client_change(), public.append_client_audit() from public, anon, authenticated;

revoke insert on public.clients from authenticated;
grant insert (man_number,name,department,designation,email,phone,address,is_active) on public.clients to authenticated;
create function public.correct_client(p_client_id uuid, p_details jsonb, p_reason text, p_expected_revision integer)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_client public.clients;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 select * into v_client from public.clients where id = p_client_id and owner_id = auth.uid() for update;
 if not found then raise exception 'Client not found'; end if;
 if p_expected_revision is null or v_client.revision <> p_expected_revision then raise exception 'Client changed since you opened it. Reload and review the latest details.'; end if;
 if p_details is null or jsonb_typeof(p_details) <> 'object' then raise exception 'Client details required'; end if;
 if p_reason is null or length(trim(p_reason)) not between 5 and 500 then raise exception 'A correction reason of 5–500 characters is required'; end if;
 if exists (select 1 from jsonb_object_keys(p_details) k where k not in ('man_number','name','department','designation','email','phone','address','is_active')) then raise exception 'Unexpected Client field'; end if;
 if jsonb_typeof(p_details->'is_active') is distinct from 'boolean' then raise exception 'Client active status must be boolean'; end if;
 perform set_config('app.client_correction_reason',trim(p_reason),true);
 update public.clients set
 man_number=p_details->>'man_number', name=p_details->>'name', department=p_details->>'department', designation=p_details->>'designation',
 email=p_details->>'email', phone=p_details->>'phone', address=p_details->>'address', is_active=(p_details->>'is_active')::boolean
 where id=p_client_id;
 return p_client_id;
end $$;
revoke all on function public.correct_client(uuid,jsonb,text,integer) from public,anon;
grant execute on function public.correct_client(uuid,jsonb,text,integer) to authenticated;

create or replace function public.import_clients(p_rows jsonb)
returns integer language plpgsql security definer set search_path = '' as $$
declare v_count integer;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_rows is null or jsonb_typeof(p_rows) <> 'array' then raise exception 'Expected Client rows'; end if;
 v_count := jsonb_array_length(p_rows);
 if v_count not between 1 and 500 then raise exception 'Import 1–500 Clients at a time'; end if;
 insert into public.clients(owner_id,man_number,name,department,designation,email,phone,address,is_active)
 select auth.uid(),trim(r.man_number),trim(r.name),trim(r.department),trim(r.designation),nullif(trim(r.email),''),nullif(trim(r.phone),''),nullif(trim(r.address),''),true
 from jsonb_to_recordset(p_rows) as r(man_number text,name text,department text,designation text,email text,phone text,address text);
 return v_count;
end $$;

create or replace function public.create_loan(p_client_id uuid, p_principal_cents bigint, p_interest_cents bigint, p_due_date date)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_id uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 perform 1 from public.clients where id = p_client_id and owner_id = auth.uid() and is_active and man_number is not null and department is not null and designation is not null for share;
 if not found then raise exception 'Active, complete Client not found'; end if;
 if p_principal_cents is null or p_principal_cents not between 1 and 99999999999 or p_interest_cents is null or p_interest_cents not between 0 and 99999999999 then raise exception 'Invalid loan amounts'; end if;
 if p_due_date is null or p_due_date < (now() at time zone 'Africa/Lusaka')::date or p_due_date > (now() at time zone 'Africa/Lusaka')::date + 36500 then raise exception 'Invalid due date'; end if;
 insert into public.loans(owner_id, client_id, principal_cents, interest_cents, balance_cents, due_date)
 values (auth.uid(), p_client_id, p_principal_cents, p_interest_cents, p_principal_cents + p_interest_cents, p_due_date) returning id into v_id;
 return v_id;
end $$;
commit;
