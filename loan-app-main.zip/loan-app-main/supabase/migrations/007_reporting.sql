begin;
-- One MVCC snapshot: report calculations must never combine independently loaded
-- balances, reversals, or adjustment revisions. Invoker permissions preserve RLS.
create function public.report_source() returns jsonb language plpgsql stable security invoker set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 return (select jsonb_build_object(
  'generated_at',statement_timestamp(), 'timezone','Africa/Lusaka',
  'clients',coalesce((select jsonb_agg(to_jsonb(c) order by c.id) from public.clients c where c.owner_id=auth.uid()),'[]'::jsonb),
  'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.id) from public.loans l where l.owner_id=auth.uid()),'[]'::jsonb),
  'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence) from public.repayments r where r.owner_id=auth.uid()),'[]'::jsonb),
  'terms_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_terms_audit a where a.owner_id=auth.uid()),'[]'::jsonb),
  'status_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_status_audit a where a.owner_id=auth.uid()),'[]'::jsonb),
  'repayment_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.repayment_audit a where a.owner_id=auth.uid()),'[]'::jsonb)));
end $$;
revoke all on function public.report_source() from public,anon;
grant execute on function public.report_source() to authenticated;
commit;
