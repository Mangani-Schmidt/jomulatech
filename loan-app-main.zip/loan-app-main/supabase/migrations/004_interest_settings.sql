begin;
-- Role grants are provisioned by a trusted database administrator, never sign-up metadata.
create table public.account_permissions (
 user_id uuid primary key references auth.users(id), is_admin boolean not null default false,
 can_override_rate boolean not null default false
);
alter table public.account_permissions enable row level security;
create policy permissions_read on public.account_permissions for select to authenticated using(user_id=(select auth.uid()));
revoke all on public.account_permissions from public,anon,authenticated;
grant select on public.account_permissions to authenticated;
create function public.is_ledger_admin() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.account_permissions where user_id=auth.uid() and is_admin);
$$;
create function public.can_override_loan_rate() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.account_permissions where user_id=auth.uid() and (is_admin or can_override_rate));
$$;
revoke all on function public.is_ledger_admin(),public.can_override_loan_rate() from public,anon;
grant execute on function public.is_ledger_admin(),public.can_override_loan_rate() to authenticated;
create table public.ledger_settings (
 owner_id uuid primary key references auth.users(id), default_rate_bps integer not null default 1000 check(default_rate_bps between 0 and 10000),
 calculation_method text not null default 'one_time_flat' check(calculation_method='one_time_flat'),
 rate_basis text not null default 'entire_term' check(rate_basis='entire_term'),
 default_term_days integer not null default 30 check(default_term_days between 1 and 3650),
 currency text not null default 'ZMW' check(currency='ZMW'),
 rounding_rule text not null default 'half_up_2' check(rounding_rule='half_up_2'),
 business_timezone text not null default 'Africa/Lusaka' check(business_timezone='Africa/Lusaka'),
 revision integer not null default 1, updated_by uuid references auth.users(id), updated_at timestamptz not null default clock_timestamp()
);
create table public.settings_audit (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id), actor_id uuid not null references auth.users(id),
 before_data jsonb not null, after_data jsonb not null, reason text not null, created_at timestamptz not null default clock_timestamp()
);
alter table public.ledger_settings enable row level security;
alter table public.settings_audit enable row level security;
create policy settings_read on public.ledger_settings for select to authenticated using(owner_id=(select auth.uid()));
create policy settings_audit_read on public.settings_audit for select to authenticated using(owner_id=(select auth.uid()) and public.is_ledger_admin());
revoke all on public.ledger_settings,public.settings_audit from public,anon,authenticated;
grant select on public.ledger_settings,public.settings_audit to authenticated;
create function public.loan_defaults() returns jsonb language plpgsql security definer set search_path='' as $$
declare v_settings public.ledger_settings;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 insert into public.ledger_settings(owner_id) values(auth.uid()) on conflict do nothing;
 select * into v_settings from public.ledger_settings where owner_id=auth.uid();
 return jsonb_build_object('settings',to_jsonb(v_settings),'capabilities',jsonb_build_object('is_admin',public.is_ledger_admin(),'can_override_rate',public.can_override_loan_rate()));
end $$;
create function public.save_interest_settings(p_settings jsonb,p_expected_revision integer,p_reason text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_before public.ledger_settings; v_after public.ledger_settings;
begin
 if not public.is_ledger_admin() then raise exception 'Administrator permission required'; end if;
 perform public.loan_defaults();
 select * into v_before from public.ledger_settings where owner_id=auth.uid() for update;
 if p_expected_revision is distinct from v_before.revision then raise exception 'Settings changed. Reload current defaults before saving.'; end if;
 if p_reason is null or length(trim(p_reason)) not between 5 and 500 then raise exception 'A settings change reason of 5–500 characters is required'; end if;
 if p_settings->>'calculation_method' is distinct from 'one_time_flat' or p_settings->>'rate_basis' is distinct from 'entire_term' then raise exception 'Only one-time flat interest for the entire term is supported'; end if;
 if p_settings->>'currency' is distinct from 'ZMW' or p_settings->>'rounding_rule' is distinct from 'half_up_2' or p_settings->>'business_timezone' is distinct from 'Africa/Lusaka' then raise exception 'Unsupported currency, rounding rule, or business timezone'; end if;
 if coalesce(p_settings->>'default_rate_bps','') !~ '^[0-9]{1,5}$' or coalesce(p_settings->>'default_term_days','') !~ '^[0-9]{1,4}$' then raise exception 'Invalid rate or term'; end if;
 update public.ledger_settings set default_rate_bps=(p_settings->>'default_rate_bps')::integer,default_term_days=(p_settings->>'default_term_days')::integer,revision=revision+1,updated_by=auth.uid(),updated_at=clock_timestamp() where owner_id=auth.uid() returning * into v_after;
 insert into public.settings_audit(owner_id,actor_id,before_data,after_data,reason) values(auth.uid(),auth.uid(),to_jsonb(v_before),to_jsonb(v_after),trim(p_reason));
 return to_jsonb(v_after);
end $$;
create function public.flat_interest_cents(p_principal bigint,p_rate_bps integer,p_method text,p_basis text) returns bigint
language plpgsql immutable set search_path='' as $$
begin
 if p_method is distinct from 'one_time_flat' or p_basis is distinct from 'entire_term' then raise exception 'Unsupported interest calculation method or rate basis'; end if;
 if p_principal is null or p_principal not between 1 and 99999999999 or p_rate_bps is null or p_rate_bps not between 0 and 10000 then raise exception 'Invalid principal or interest rate'; end if;
 return round(p_principal::numeric*p_rate_bps/10000)::bigint;
end $$;

alter table public.loans
 add column interest_rate_bps integer,
 add column calculation_method text not null default 'legacy_fixed_charge',
 add column rate_basis text not null default 'legacy_unspecified',
 add column term_days integer,
 add column currency text not null default 'ZMW' check(currency='ZMW'),
 add column rounding_rule text not null default 'half_up_2' check(rounding_rule='half_up_2'),
 add column business_timezone text not null default 'Africa/Lusaka' check(business_timezone='Africa/Lusaka'),
 add column settings_revision integer,
 add column default_rate_bps_at_origination integer,
 add column rate_override_reason text,
 add column terms_revision integer not null default 1,
 add column origin_request_id uuid,
 add column origination_payload jsonb,
 add column total_obligation_cents bigint generated always as (principal_cents+interest_cents) stored,
 add unique(owner_id,origin_request_id);
update public.loans set term_days=case when due_date-disbursement_date between 1 and 3650 then due_date-disbursement_date else null end;
-- Only recover an actual historic rate when the original batch recorded it.
update public.loans l set interest_rate_bps=((b.terms->>'interest_value')::numeric*100)::integer,calculation_method='one_time_flat',rate_basis='entire_term'
 from public.import_batches b where l.import_batch_id=b.id and b.terms->>'interest_type'='flat_percent';
alter table public.loans add constraint loan_terms_supported check(
 (calculation_method='legacy_fixed_charge' and interest_rate_bps is null and rate_basis='legacy_unspecified') or
 (calculation_method='one_time_flat' and rate_basis='entire_term' and interest_rate_bps is not null and interest_rate_bps between 0 and 10000 and term_days is not null and term_days between 1 and 3650)
);
create table public.loan_terms_audit (
 id uuid primary key default gen_random_uuid(), loan_id uuid not null, owner_id uuid not null,
 actor_id uuid references auth.users(id), action text not null check(action in ('baseline','originate','adjust')),
 reason text not null, before_data jsonb, after_data jsonb not null,
 request_id uuid, created_at timestamptz not null default clock_timestamp(),
 foreign key(loan_id,owner_id) references public.loans(id,owner_id), unique(owner_id,request_id)
);
create index loan_terms_audit_lookup on public.loan_terms_audit(owner_id,loan_id,created_at desc);
alter table public.loan_terms_audit enable row level security;
create policy loan_audit_read on public.loan_terms_audit for select to authenticated using(owner_id=(select auth.uid()));
revoke all on public.loan_terms_audit from public,anon,authenticated;
grant select on public.loan_terms_audit to authenticated;
insert into public.loan_terms_audit(loan_id,owner_id,action,reason,after_data)
 select id,owner_id,'baseline','Interest-settings migration: historical charges and balances preserved; unspecified historical rates are not inferred.',to_jsonb(l) from public.loans l;

-- Validate settings at the instant an operation creates money obligations.
create function public.checked_loan_terms(p_terms jsonb) returns public.ledger_settings
language plpgsql security definer set search_path='' as $$
declare v_settings public.ledger_settings; v_rate integer;
begin
 perform public.loan_defaults();
 select * into v_settings from public.ledger_settings where owner_id=auth.uid() for share;
 if p_terms->>'calculation_method' is distinct from v_settings.calculation_method or p_terms->>'rate_basis' is distinct from v_settings.rate_basis then raise exception 'Only one-time flat interest for the entire term is supported'; end if;
 if coalesce(p_terms->>'settings_revision','') !~ '^[0-9]{1,9}$' or (p_terms->>'settings_revision')::integer<>v_settings.revision then raise exception 'Defaults changed. Reload and review current defaults.'; end if;
 if coalesce(p_terms->>'rate_bps','') !~ '^[0-9]{1,5}$' or coalesce(p_terms->>'term_days','') !~ '^[0-9]{1,4}$' then raise exception 'Invalid rate or term'; end if;
 v_rate:=(p_terms->>'rate_bps')::integer;
 if v_rate not between 0 and 10000 or (p_terms->>'term_days')::integer not between 1 and 3650 then raise exception 'Rate must be 0–100%% and term 1–3650 days'; end if;
 if v_rate<>v_settings.default_rate_bps then
   if not public.can_override_loan_rate() then raise exception 'Rate override permission required'; end if;
   if length(trim(coalesce(p_terms->>'override_reason',''))) not between 5 and 500 then raise exception 'A rate override reason of 5–500 characters is required'; end if;
 end if;
 return v_settings;
end $$;

create function public.enforce_loan_terms() returns trigger language plpgsql security definer set search_path='' as $$
declare v_batch public.import_batches; v_settings public.ledger_settings; v_terms jsonb;
begin
 if tg_op='UPDATE' then
   if (to_jsonb(new)-array['balance_cents','total_obligation_cents'])=(to_jsonb(old)-array['balance_cents','total_obligation_cents']) then return new; end if;
   if not public.is_ledger_admin() or new.owner_id<>auth.uid() or length(coalesce(current_setting('app.loan_adjustment_reason',true),''))<5 then raise exception 'Loan terms require an authorized audited adjustment'; end if;
   if (to_jsonb(new)-array['interest_cents','interest_rate_bps','calculation_method','rate_basis','term_days','due_date','terms_revision','total_obligation_cents','balance_cents'])<>(to_jsonb(old)-array['interest_cents','interest_rate_bps','calculation_method','rate_basis','term_days','due_date','terms_revision','total_obligation_cents','balance_cents']) then raise exception 'Loan identity, principal, and original snapshot are immutable'; end if;
 else
   if auth.uid() is null or new.owner_id<>auth.uid() then raise exception 'Authentication required'; end if;
   if new.import_batch_id is not null then
     select * into v_batch from public.import_batches where id=new.import_batch_id and owner_id=auth.uid() and status='preview';
     if not found or v_batch.mode<>'loans' then raise exception 'Invalid disbursement batch'; end if;
     v_terms:=v_batch.terms||jsonb_build_object('rate_bps',((v_batch.terms->>'interest_value')::numeric*100)::integer);
     if v_batch.terms->>'interest_type' is distinct from 'flat_percent' then raise exception 'Unsupported import interest method'; end if;
     v_settings:=public.checked_loan_terms(v_terms);
     new.interest_rate_bps:=(v_terms->>'rate_bps')::integer;new.term_days:=(v_terms->>'term_days')::integer;
     new.calculation_method:='one_time_flat';new.rate_basis:='entire_term';new.settings_revision:=v_settings.revision;
     new.default_rate_bps_at_origination:=v_settings.default_rate_bps;new.rate_override_reason:=nullif(trim(v_terms->>'override_reason'),'');
     new.origin_request_id:=gen_random_uuid();
   end if;
   if new.settings_revision is null or new.default_rate_bps_at_origination is null then raise exception 'A current settings snapshot is required'; end if;
 end if;
 if new.interest_cents<>public.flat_interest_cents(new.principal_cents,new.interest_rate_bps,new.calculation_method,new.rate_basis) or new.term_days is null or new.due_date<>new.disbursement_date+new.term_days then raise exception 'Loan amounts or dates do not match the actual terms'; end if;
 return new;
end $$;
create trigger enforce_loan_terms before insert or update on public.loans for each row execute function public.enforce_loan_terms();
create function public.audit_loan_terms() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='UPDATE' and new.terms_revision=old.terms_revision then return new; end if;
 insert into public.loan_terms_audit(loan_id,owner_id,actor_id,action,reason,before_data,after_data,request_id)
 values(new.id,new.owner_id,auth.uid(),case when tg_op='INSERT' then 'originate' else 'adjust' end,
 case when tg_op='INSERT' then coalesce(new.rate_override_reason,'Loan originated at current default rate') else current_setting('app.loan_adjustment_reason') end,
 case when tg_op='UPDATE' then to_jsonb(old) else null end,to_jsonb(new),case when tg_op='INSERT' then new.origin_request_id else nullif(current_setting('app.loan_request_id',true),'')::uuid end);
 return new;
end $$;
create trigger audit_loan_terms after insert or update on public.loans for each row execute function public.audit_loan_terms();

create function public.originate_loan(p_details jsonb,p_request_id uuid,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_settings public.ledger_settings; v_existing public.loans; v_id uuid; v_principal bigint; v_rate integer; v_date date; v_interest bigint;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_confirm is distinct from true or p_request_id is null then raise exception 'Explicit confirmation and request ID required'; end if;
 if p_details is null or jsonb_typeof(p_details)<>'object' or octet_length(p_details::text)>10000 then raise exception 'Invalid loan details'; end if;
 if exists(select 1 from jsonb_object_keys(p_details) k where k not in ('client_id','principal_cents','rate_bps','term_days','disbursement_date','settings_revision','calculation_method','rate_basis','override_reason')) then raise exception 'Unexpected loan field'; end if;

 perform pg_advisory_xact_lock(hashtextextended('loan_request:'||auth.uid()::text||p_request_id::text,0));
 select * into v_existing from public.loans where owner_id=auth.uid() and origin_request_id=p_request_id;
 if found then
   if v_existing.origination_payload is distinct from p_details then raise exception 'Request ID already used for different loan terms'; end if;
   return v_existing.id;
 end if;
 v_settings:=public.checked_loan_terms(p_details);
 if coalesce(p_details->>'principal_cents','') !~ '^[0-9]{1,11}$' then raise exception 'Invalid principal'; end if;
 v_principal:=(p_details->>'principal_cents')::bigint;v_rate:=(p_details->>'rate_bps')::integer;
 v_interest:=public.flat_interest_cents(v_principal,v_rate,p_details->>'calculation_method',p_details->>'rate_basis');
 if coalesce(p_details->>'disbursement_date','') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then raise exception 'Disbursement date required'; end if;
 v_date:=(p_details->>'disbursement_date')::date;
 if v_date<'1900-01-01' or v_date>(now() at time zone v_settings.business_timezone)::date then raise exception 'Invalid disbursement date'; end if;
 perform 1 from public.clients where id=(p_details->>'client_id')::uuid and owner_id=auth.uid() and is_active and man_number is not null and department is not null and designation is not null for share;
 if not found then raise exception 'Active, complete Client not found'; end if;
 insert into public.loans(owner_id,client_id,principal_cents,interest_cents,balance_cents,disbursement_date,due_date,interest_rate_bps,calculation_method,rate_basis,term_days,settings_revision,default_rate_bps_at_origination,rate_override_reason,origin_request_id,origination_payload)
 values(auth.uid(),(p_details->>'client_id')::uuid,v_principal,v_interest,v_principal+v_interest,v_date,v_date+(p_details->>'term_days')::integer,v_rate,'one_time_flat','entire_term',(p_details->>'term_days')::integer,v_settings.revision,v_settings.default_rate_bps,nullif(trim(p_details->>'override_reason'),''),p_request_id,p_details) returning id into v_id;
 return v_id;
end $$;
create function public.adjust_loan_terms(p_loan_id uuid,p_rate_bps integer,p_term_days integer,p_expected_revision integer,p_reason text,p_request_id uuid,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_loan public.loans; v_existing public.loan_terms_audit; v_paid bigint; v_interest bigint;
begin
 if not public.is_ledger_admin() then raise exception 'Administrator permission required'; end if;
 if p_confirm is distinct from true or p_request_id is null then raise exception 'Explicit adjustment confirmation and request ID required'; end if;
 if p_reason is null or length(trim(p_reason)) not between 5 and 500 then raise exception 'An adjustment reason of 5–500 characters is required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('loan_request:'||auth.uid()::text||p_request_id::text,0));
 select * into v_existing from public.loan_terms_audit where owner_id=auth.uid() and request_id=p_request_id;
 if found then
   if v_existing.action<>'adjust' or v_existing.loan_id<>p_loan_id or (v_existing.after_data->>'interest_rate_bps')::integer is distinct from p_rate_bps or (v_existing.after_data->>'term_days')::integer is distinct from p_term_days or v_existing.reason<>trim(p_reason) then raise exception 'Request ID already used for different adjustment'; end if;
   return p_loan_id;
 end if;
 select * into v_loan from public.loans where id=p_loan_id and owner_id=auth.uid() for update;
 if not found then raise exception 'Loan not found'; end if;
 if p_expected_revision is distinct from v_loan.terms_revision then raise exception 'Loan terms changed. Reload the loan before adjusting.'; end if;
 if p_term_days is null or p_term_days not between 1 and 3650 then raise exception 'Term must be 1–3650 days'; end if;
 v_interest:=public.flat_interest_cents(v_loan.principal_cents,p_rate_bps,'one_time_flat','entire_term');
 select coalesce(sum(amount_cents),0) into v_paid from public.repayments where loan_id=v_loan.id and owner_id=auth.uid();
 if v_loan.principal_cents+v_interest<v_paid then raise exception 'Adjusted obligation cannot be less than payments already received'; end if;
 perform set_config('app.loan_adjustment_reason',trim(p_reason),true);perform set_config('app.loan_request_id',p_request_id::text,true);
 update public.loans set interest_rate_bps=p_rate_bps,calculation_method='one_time_flat',rate_basis='entire_term',interest_cents=v_interest,term_days=p_term_days,due_date=disbursement_date+p_term_days,balance_cents=principal_cents+v_interest-v_paid,terms_revision=terms_revision+1 where id=v_loan.id;
 return v_loan.id;
end $$;
-- Disable the fixed-charge origination path, including callers bypassing the UI.
revoke execute on function public.create_loan(uuid,bigint,bigint,date) from authenticated;

-- Preserve the prior import staging/deduplication implementation behind checked wrappers.
alter function public.preview_import(text,text,text,jsonb,jsonb) rename to preview_import_v3;
alter function public.commit_import(uuid,integer,boolean) rename to commit_import_v3;
revoke all on function public.preview_import_v3(text,text,text,jsonb,jsonb),public.commit_import_v3(uuid,integer,boolean) from public,anon,authenticated;
create function public.preview_import(p_filename text,p_file_sha256 text,p_mode text,p_terms jsonb,p_rows jsonb) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_settings public.ledger_settings; v_id uuid; v_terms jsonb; v_rate integer;
begin
 if p_mode='loans' then
   if p_terms->>'interest_type' is distinct from 'flat_percent' or coalesce(p_terms->>'interest_value','') !~ '^[0-9]{1,3}(\.[0-9]{1,2})?$' then raise exception 'Only one-time flat percentage interest for the entire term is supported'; end if;
   v_rate:=((p_terms->>'interest_value')::numeric*100)::integer;
   v_settings:=public.checked_loan_terms(p_terms||jsonb_build_object('rate_bps',v_rate));
 end if;
 v_id:=public.preview_import_v3(p_filename,p_file_sha256,p_mode,p_terms,p_rows);
 if p_mode='loans' then
   update public.import_batches set terms=terms||jsonb_build_object('calculation_method','one_time_flat','rate_basis','entire_term','settings_revision',v_settings.revision,'default_rate_bps',v_settings.default_rate_bps,'override_reason',nullif(trim(p_terms->>'override_reason'),''),'currency',v_settings.currency,'rounding_rule',v_settings.rounding_rule,'business_timezone',v_settings.business_timezone) where id=v_id and status='preview';
   update public.import_rows set data=data||jsonb_build_object('principal_cents',((data->>'amount')::numeric*100)::bigint,'interest_cents',public.flat_interest_cents(((data->>'amount')::numeric*100)::bigint,v_rate,'one_time_flat','entire_term'),'total_obligation_cents',((data->>'amount')::numeric*100)::bigint+public.flat_interest_cents(((data->>'amount')::numeric*100)::bigint,v_rate,'one_time_flat','entire_term'),'rate_bps',v_rate,'due_date',(p_terms->>'disbursement_date')::date+(p_terms->>'term_days')::integer) where batch_id=v_id and outcome='accepted' and exists(select 1 from public.import_batches where id=v_id and status='preview');

 end if;
 return v_id;
end $$;
create function public.commit_import(p_batch_id uuid,p_preview_version integer,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_batch public.import_batches; v_terms jsonb;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('excel_import:'||auth.uid()::text,0));
 select * into v_batch from public.import_batches where id=p_batch_id and owner_id=auth.uid() for update;
 if not found then raise exception 'Import not found'; end if;
 if v_batch.status<>'completed' and v_batch.mode='loans' then
   if v_batch.terms->>'interest_type' is distinct from 'flat_percent' then raise exception 'Unsupported staged interest terms. Generate a new preview.'; end if;
   perform public.checked_loan_terms(v_batch.terms||jsonb_build_object('rate_bps',((v_batch.terms->>'interest_value')::numeric*100)::integer));
 end if;
 return public.commit_import_v3(p_batch_id,p_preview_version,p_confirm);
end $$;
revoke all on function public.checked_loan_terms(jsonb),public.enforce_loan_terms(),public.audit_loan_terms() from public,anon,authenticated;
revoke all on function public.loan_defaults(),public.save_interest_settings(jsonb,integer,text),public.originate_loan(jsonb,uuid,boolean),public.adjust_loan_terms(uuid,integer,integer,integer,text,uuid,boolean),public.preview_import(text,text,text,jsonb,jsonb),public.commit_import(uuid,integer,boolean),public.flat_interest_cents(bigint,integer,text,text) from public,anon;
grant execute on function public.loan_defaults(),public.save_interest_settings(jsonb,integer,text),public.originate_loan(jsonb,uuid,boolean),public.adjust_loan_terms(uuid,integer,integer,integer,text,uuid,boolean),public.preview_import(text,text,text,jsonb,jsonb),public.commit_import(uuid,integer,boolean),public.flat_interest_cents(bigint,integer,text,text) to authenticated;
commit;
