begin;
create table public.import_batches (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id),
 uploaded_by uuid not null references auth.users(id), filename text not null,
 file_sha256 text not null, fingerprint text not null, mode text not null check(mode in ('clients','loans')),
 terms jsonb not null, payload jsonb not null, status text not null default 'preview' check(status in ('preview','completed')),
 preview_version integer not null default 1, accepted integer not null default 0, rejected integer not null default 0, unchanged integer not null default 0,
 created_at timestamptz not null default clock_timestamp(), updated_at timestamptz not null default clock_timestamp(), completed_at timestamptz,
 unique(owner_id,fingerprint), unique(id,owner_id)
);
create table public.import_rows (
 id uuid primary key default gen_random_uuid(), batch_id uuid not null, owner_id uuid not null,
 excel_row integer not null, source_no text, data jsonb not null,
 outcome text not null check(outcome in ('accepted','rejected','unchanged')), errors jsonb not null, warnings jsonb not null,
 matched_client_id uuid, matched_revision integer, client_id uuid, loan_id uuid,
 foreign key(batch_id,owner_id) references public.import_batches(id,owner_id),
 foreign key(matched_client_id,owner_id) references public.clients(id,owner_id),
 foreign key(client_id,owner_id) references public.clients(id,owner_id),
 foreign key(loan_id,owner_id) references public.loans(id,owner_id), unique(batch_id,excel_row)
);
create index import_batches_owner_date on public.import_batches(owner_id,created_at desc);
create index import_rows_owner_batch on public.import_rows(owner_id,batch_id);
alter table public.import_batches enable row level security;
alter table public.import_rows enable row level security;
create policy imports_read on public.import_batches for select to authenticated using(owner_id=(select auth.uid()));
create policy import_rows_read on public.import_rows for select to authenticated using(owner_id=(select auth.uid()));
revoke all on public.import_batches,public.import_rows from public,anon,authenticated;
grant select on public.import_batches,public.import_rows to authenticated;
alter table public.loans add column disbursement_date date;
update public.loans set disbursement_date=(created_at at time zone 'Africa/Lusaka')::date;
alter table public.loans alter column disbursement_date set not null;
alter table public.loans alter column disbursement_date set default ((now() at time zone 'Africa/Lusaka')::date);
alter table public.loans add column import_batch_id uuid;
alter table public.loans add foreign key(import_batch_id,owner_id) references public.import_batches(id,owner_id);

-- Shared database-side classifier. Never writes Clients or financial records.
create function public.classify_import_row(p_row jsonb,p_mode text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_errors jsonb:='[]'; v_warnings jsonb:='[]'; v_client public.clients; v_key text;
begin
 if jsonb_typeof(p_row) is distinct from 'object' then return jsonb_build_object('errors',jsonb_build_array('Invalid row object'),'warnings',v_warnings,'outcome','rejected'); end if;
 foreach v_key in array array['source_no','man_number','name','department','designation'] loop
   if jsonb_typeof(p_row->v_key) is distinct from 'string' or length(trim(p_row->>v_key))=0 then v_errors:=v_errors||jsonb_build_array(v_key||' is required as text'); end if;
 end loop;
 if coalesce(p_row->>'source_no','') !~ '^[0-9]{1,9}$' or coalesce(nullif(p_row->>'source_no',''),'0') ~ '^0+$' then v_errors:=v_errors||jsonb_build_array('no# must be a positive source row number'); end if;
 if length(trim(p_row->>'man_number'))>50 or (p_row->>'man_number') ~ '[[:cntrl:]]' then v_errors:=v_errors||jsonb_build_array('Man# must be at most 50 characters without control characters'); end if;
 if length(trim(p_row->>'name')) not between 2 and 120 or length(trim(p_row->>'department'))>120 or length(trim(p_row->>'designation'))>120 then v_errors:=v_errors||jsonb_build_array('Invalid Client name, department, or designation length'); end if;
 if jsonb_typeof(p_row->'parse_errors')='array' then v_errors:=v_errors||(p_row->'parse_errors'); end if;
 if p_row->>'man_numeric'='true' then v_warnings:=v_warnings||jsonb_build_array('Excel stored Man# numerically. Original leading zeros may be lost; verify this Man# before confirming.'); end if;
 if p_mode='loans' and (jsonb_typeof(p_row->'amount') is distinct from 'string' or coalesce(p_row->>'amount','') !~ '^[0-9]{1,9}(\.[0-9]{1,2})?$') then v_errors:=v_errors||jsonb_build_array('Loan amount must be a positive ZMW amount with up to two decimals');
 elsif p_mode='loans' and (p_row->>'amount')::numeric<=0 then v_errors:=v_errors||jsonb_build_array('Loan amount must be greater than zero'); end if;
 if p_mode='clients' then v_warnings:=v_warnings||jsonb_build_array('amount is ignored in Client Register Import; no loan or repayment will be created.'); end if;
 select * into v_client from public.clients where owner_id=auth.uid() and lower(man_number)=lower(trim(p_row->>'man_number'));
 if found then
   if v_client.name is distinct from trim(p_row->>'name') or v_client.department is distinct from trim(p_row->>'department') or v_client.designation is distinct from trim(p_row->>'designation') then v_errors:=v_errors||jsonb_build_array('Conflicting Client details for this Man#. Correct the register through the audited correction workflow first.'); end if;
   if p_mode='loans' and not v_client.is_active then v_errors:=v_errors||jsonb_build_array('Client is inactive; no new loan may be created'); end if;
 end if;
 return jsonb_build_object('errors',v_errors,'warnings',v_warnings,'outcome',case when jsonb_array_length(v_errors)>0 then 'rejected' when v_client.id is not null and p_mode='clients' then 'unchanged' else 'accepted' end,'matched_client_id',v_client.id,'matched_revision',v_client.revision);
end $$;
revoke all on function public.classify_import_row(jsonb,text) from public,anon,authenticated;

create function public.preview_import(p_filename text,p_file_sha256 text,p_mode text,p_terms jsonb,p_rows jsonb) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_batch public.import_batches; v_terms jsonb:='{}'; v_semantic jsonb; v_fingerprint text; v_row jsonb; v_result jsonb; v_due date; v_key text; v_count integer:=0;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_mode is null or p_mode not in ('clients','loans') then raise exception 'Select an explicit import mode'; end if;
 if p_filename is null or length(p_filename) not between 1 and 200 or lower(p_filename) not like '%.xlsx' or p_file_sha256 is null or p_file_sha256 !~ '^[a-f0-9]{64}$' then raise exception 'Invalid workbook metadata'; end if;
 if jsonb_typeof(p_rows) is distinct from 'array' or jsonb_array_length(p_rows) not between 1 and 500 or octet_length(p_rows::text)>1500000 then raise exception 'Import 1–500 bounded rows'; end if;
 -- Reject malformed RPC envelopes. Workbook cell values are always server-parsed strings;
 -- invalid cell contents still produce per-row diagnostics rather than unsafe JSON shapes.
 for v_row in select value from jsonb_array_elements(p_rows) loop
   if jsonb_typeof(v_row) is distinct from 'object' then raise exception 'Import rows must be objects'; end if;
   foreach v_key in array array['source_no','man_number','name','department','designation','amount'] loop
     if jsonb_typeof(v_row->v_key) is distinct from 'string' then raise exception 'Mapped cell values must be strings'; end if;
   end loop;
   if jsonb_typeof(v_row->'man_numeric') is distinct from 'boolean' or jsonb_typeof(v_row->'parse_errors') is distinct from 'array' then raise exception 'Invalid parsed row metadata'; end if;
   if exists (select 1 from jsonb_array_elements(v_row->'parse_errors') e where jsonb_typeof(e)<>'string') then raise exception 'Invalid row diagnostic'; end if;
 end loop;
 if p_mode='clients' and p_terms is distinct from '{}'::jsonb then raise exception 'Client Register Import does not accept loan terms'; end if;
 if p_mode='loans' then
   if p_terms is null or p_terms->>'disbursement_date' is null or p_terms->>'disbursement_date' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then raise exception 'Disbursement date required'; end if;
   v_due:=(p_terms->>'disbursement_date')::date;
   if v_due > (now() at time zone 'Africa/Lusaka')::date or v_due<'1900-01-01' then raise exception 'Disbursement date must be between 1900 and today'; end if;
   if p_terms->>'due_rule' is distinct from 'days_after_disbursement' or coalesce(p_terms->>'term_days','') !~ '^[0-9]{1,4}$' then raise exception 'Choose a due-date rule and term'; end if;
   if (p_terms->>'term_days')::integer not between 1 and 3650 then raise exception 'Term must be 1–3650 days'; end if;
   if p_terms->>'interest_type' is null or p_terms->>'interest_type' not in ('fixed','flat_percent') or coalesce(p_terms->>'interest_value','') !~ '^[0-9]{1,9}(\.[0-9]{1,2})?$' then raise exception 'Explicit fixed or flat percentage interest terms required'; end if;
   if p_terms->>'interest_type'='flat_percent' and (p_terms->>'interest_value')::numeric>100 then raise exception 'Flat interest percentage must be 0–100'; end if;
   v_terms:=jsonb_build_object('disbursement_date',v_due,'due_rule','days_after_disbursement','term_days',(p_terms->>'term_days')::integer,'interest_type',p_terms->>'interest_type','interest_value',trim_scale((p_terms->>'interest_value')::numeric)::text);
 end if;
 -- Semantic fingerprint ignores filename, source row numbering, and row order.
 -- Equality is also checked, so a digest collision cannot replay another payload.
 select jsonb_agg(s order by s::text) into v_semantic from (
 select jsonb_build_object('man_number',lower(trim(r->>'man_number')),'name',trim(r->>'name'),'department',trim(r->>'department'),'designation',trim(r->>'designation'),
 'amount',case when p_mode='loans' then case when coalesce(r->>'amount','') ~ '^[0-9]{1,9}(\.[0-9]{1,2})?$' then trim_scale((r->>'amount')::numeric)::text else r->>'amount' end else null end,
 'source_valid',coalesce(jsonb_typeof(r->'source_no')='string' and (r->>'source_no') ~ '^[0-9]{1,9}$' and (r->>'source_no') !~ '^0+$',false),'parse_errors',r->'parse_errors') s from jsonb_array_elements(p_rows) r) canonical;
 v_semantic:=jsonb_build_object('mode',p_mode,'terms',v_terms,'rows',v_semantic);
 v_fingerprint:=md5(v_semantic::text);
 perform pg_advisory_xact_lock(hashtextextended('excel_import:'||auth.uid()::text,0));
 select * into v_batch from public.import_batches where owner_id=auth.uid() and fingerprint=v_fingerprint for update;
 if found then
   if v_batch.payload<>v_semantic then raise exception 'Import fingerprint collision; contact support'; end if;
   if v_batch.status='completed' then return v_batch.id; end if;
   delete from public.import_rows where batch_id=v_batch.id;
   update public.import_batches set preview_version=preview_version+1,filename=p_filename,file_sha256=p_file_sha256,updated_at=clock_timestamp() where id=v_batch.id;
 else
   insert into public.import_batches(owner_id,uploaded_by,filename,file_sha256,fingerprint,mode,terms,payload) values(auth.uid(),auth.uid(),p_filename,p_file_sha256,v_fingerprint,p_mode,v_terms,v_semantic) returning * into v_batch;
 end if;
 for v_row in select value from jsonb_array_elements(p_rows) loop
   v_count:=v_count+1;
   v_result:=public.classify_import_row(v_row,p_mode);
   if (select count(*) from jsonb_array_elements(p_rows) r where lower(trim(r->>'man_number'))=lower(trim(v_row->>'man_number')))>1 then
     v_result:=jsonb_set(v_result,'{errors}',(v_result->'errors')||jsonb_build_array('Duplicate Man# in this workbook; all occurrences are rejected'));
     v_result:=jsonb_set(v_result,'{outcome}','"rejected"');
   end if;
   insert into public.import_rows(batch_id,owner_id,excel_row,source_no,data,outcome,errors,warnings,matched_client_id,matched_revision)
   values(v_batch.id,auth.uid(),v_count+1,v_row->>'source_no',v_row,v_result->>'outcome',v_result->'errors',v_result->'warnings',(v_result->>'matched_client_id')::uuid,(v_result->>'matched_revision')::integer);
 end loop;
 update public.import_batches set accepted=(select count(*) from public.import_rows where batch_id=v_batch.id and outcome='accepted'),rejected=(select count(*) from public.import_rows where batch_id=v_batch.id and outcome='rejected'),unchanged=(select count(*) from public.import_rows where batch_id=v_batch.id and outcome='unchanged') where id=v_batch.id;
 return v_batch.id;
end $$;

create function public.commit_import(p_batch_id uuid,p_preview_version integer,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_batch public.import_batches; v_row public.import_rows; v_client public.clients; v_id uuid; v_loan uuid; v_principal bigint; v_interest bigint;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_confirm is distinct from true then raise exception 'Explicit confirmation required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('excel_import:'||auth.uid()::text,0));
 select * into v_batch from public.import_batches where id=p_batch_id and owner_id=auth.uid() for update;
 if not found then raise exception 'Import not found'; end if;
 if v_batch.status='completed' then return v_batch.id; end if;
 if v_batch.accepted=0 and v_batch.rejected>0 then raise exception 'No accepted rows to save. Resolve the errors and preview again.'; end if;
 if p_preview_version is null or p_preview_version<>v_batch.preview_version then raise exception 'Preview changed. Generate and review a new preview.'; end if;
 for v_row in select * from public.import_rows where batch_id=v_batch.id and outcome<>'rejected' order by lower(data->>'man_number') loop
   select * into v_client from public.clients where owner_id=auth.uid() and lower(man_number)=lower(trim(v_row.data->>'man_number')) for update;
   if v_client.id is distinct from v_row.matched_client_id or v_client.revision is distinct from v_row.matched_revision then raise exception 'Client register changed since preview. Generate and review a new preview.'; end if;
   if v_row.outcome='unchanged' then
     update public.import_rows set client_id=v_client.id where id=v_row.id;
     continue;
   end if;
   if v_client.id is null then
     insert into public.clients(man_number,name,department,designation) values(v_row.data->>'man_number',v_row.data->>'name',v_row.data->>'department',v_row.data->>'designation') returning id into v_id;
   else v_id:=v_client.id; end if;
   v_loan:=null;
   if v_batch.mode='loans' then
     v_principal:=((v_row.data->>'amount')::numeric*100)::bigint;
     v_interest:=case when v_batch.terms->>'interest_type'='fixed' then ((v_batch.terms->>'interest_value')::numeric*100)::bigint else round(v_principal*(v_batch.terms->>'interest_value')::numeric/100)::bigint end;
     insert into public.loans(owner_id,client_id,principal_cents,interest_cents,balance_cents,due_date,disbursement_date,import_batch_id)
     values(auth.uid(),v_id,v_principal,v_interest,v_principal+v_interest,(v_batch.terms->>'disbursement_date')::date+(v_batch.terms->>'term_days')::integer,(v_batch.terms->>'disbursement_date')::date,v_batch.id) returning id into v_loan;
   end if;
   update public.import_rows set client_id=v_id,loan_id=v_loan where id=v_row.id;
 end loop;
 update public.import_batches set status='completed',completed_at=clock_timestamp(),updated_at=clock_timestamp() where id=v_batch.id;
 return v_batch.id;
exception when unique_violation then raise exception 'Client register changed or this import is a duplicate. Generate and review a new preview.';
end $$;
create function public.import_report(p_batch_id uuid) returns jsonb
language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('batch',to_jsonb(b)-'payload','rows',coalesce((select jsonb_agg(to_jsonb(r) order by r.excel_row) from public.import_rows r where r.batch_id=b.id),'[]'::jsonb)) from public.import_batches b where b.id=p_batch_id and b.owner_id=auth.uid();
$$;
revoke all on function public.preview_import(text,text,text,jsonb,jsonb),public.commit_import(uuid,integer,boolean),public.import_report(uuid) from public,anon;
grant execute on function public.preview_import(text,text,text,jsonb,jsonb),public.commit_import(uuid,integer,boolean),public.import_report(uuid) to authenticated;
-- Disable the superseded immediate import endpoint; previews and history are mandatory.
revoke execute on function public.import_clients(jsonb) from authenticated;
commit;
