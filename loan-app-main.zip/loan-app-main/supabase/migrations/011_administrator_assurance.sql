begin;
-- Opt-in rollout preserves existing access. Enabling/disabling requires a
-- recently verified TOTP session; no one can enable a policy they cannot satisfy.
alter table public.businesses add column admin_mfa_required boolean not null default false;
create function public.recent_admin_assurance() returns boolean language sql stable security definer set search_path='' as $$
 select coalesce((nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'aal')='aal2' and exists(
  select 1 from jsonb_array_elements(coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb->'amr','[]'::jsonb)) a
  where a->>'method'='totp' and coalesce(a->>'timestamp','') ~ '^[0-9]+(\.[0-9]+)?$'
   and (a->>'timestamp')::numeric between extract(epoch from statement_timestamp())-900 and extract(epoch from statement_timestamp())+30
 ),false);
$$;
create or replace function public.has_capability(p_action text) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce((select case
 when p_action='read' then true
 when p_action in ('admin','imports','expenses') then r.role='administrator' and (not b.admin_mfa_required or public.recent_admin_assurance())
 when p_action in ('clients','originate') then r.role in ('administrator','loan_officer')
 when p_action='repayments' then r.role in ('administrator','cashier')
 else false end from public.user_roles r join public.businesses b on b.id=r.owner_id where r.user_id=auth.uid() and r.is_active),false);
$$;
create or replace function public.require_capability(p_action text) returns void language plpgsql security definer set search_path='' as $$
declare r public.user_roles;v_required boolean;
begin
 select * into r from public.user_roles where user_id=auth.uid() and is_active for share;
 if not found then raise exception 'Permission denied for this role: %',p_action using errcode='42501';end if;
 select admin_mfa_required into v_required from public.businesses where id=r.owner_id;
 if r.role='administrator' and p_action in ('admin','imports','expenses') and v_required and not public.recent_admin_assurance() then raise exception 'Additional authentication required. Verify your authenticator in Account security before this action.' using errcode='28000';end if;
 if not public.has_capability(p_action) then raise exception 'Permission denied for this role: %',p_action using errcode='42501';end if;
end $$;
create or replace function public.can_override_loan_rate() returns boolean language sql stable security definer set search_path='' as $$select public.has_capability('admin');$$;
create function public.set_admin_mfa_policy(p_required boolean,p_reason text,p_request_id uuid,p_confirm boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;v_before boolean;
begin
 perform public.require_capability('admin');
 if p_required is null or p_confirm is distinct from true or length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'Approve the authentication policy with a reason';end if;
 if not public.recent_admin_assurance() then raise exception 'Verify a TOTP authenticator within the last 15 minutes before changing this policy' using errcode='28000';end if;
 v_payload:=jsonb_build_object('required',p_required,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'set_admin_mfa_policy',v_payload);if v_result is not null then return v_result;end if;
 select admin_mfa_required into v_before from public.businesses where id=public.current_ledger_id() for update;
 update public.businesses set admin_mfa_required=p_required where id=public.current_ledger_id();
 insert into public.audit_events(owner_id,actor_id,entity_type,entity_id,action,reason,source_table,source_id,before_data,after_data)
 values(public.current_ledger_id(),auth.uid(),'Security policy',public.current_ledger_id(),'administrator_mfa_policy',trim(p_reason),'businesses',public.current_ledger_id(),jsonb_build_object('admin_mfa_required',v_before),jsonb_build_object('admin_mfa_required',p_required));
 return public.finish_financial_operation(p_request_id,'set_admin_mfa_policy',v_payload,jsonb_build_object('admin_mfa_required',p_required));
end $$;
revoke all on function public.recent_admin_assurance(),public.set_admin_mfa_policy(boolean,text,uuid,boolean) from public,anon;
grant execute on function public.recent_admin_assurance(),public.set_admin_mfa_policy(boolean,text,uuid,boolean) to authenticated;
revoke all on function public.require_capability(text) from public,anon,authenticated;

-- Recovery routes can read their own assurance requirement even before step-up.
create function public.account_security() returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('role',r.role,'admin_mfa_required',b.admin_mfa_required,'recent_assurance',public.recent_admin_assurance())
 from public.user_roles r join public.businesses b on b.id=r.owner_id where r.user_id=auth.uid() and r.is_active;
$$;
revoke all on function public.account_security() from public,anon;
grant execute on function public.account_security() to authenticated;
commit;
