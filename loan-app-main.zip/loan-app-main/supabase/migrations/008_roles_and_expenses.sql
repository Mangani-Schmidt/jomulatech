begin;
-- Existing owner_id values become business workspace keys. Preserve all IDs and
-- all monetary values. Staff identity always remains auth.uid(), never owner_id.
create table public.businesses (
 id uuid primary key references auth.users(id), name text not null default 'Lending business' check(length(trim(name)) between 1 and 120),
 created_at timestamptz not null default clock_timestamp()
);
insert into public.businesses(id)
 select owner_id from public.clients union select owner_id from public.loans union select owner_id from public.ledger_settings union select owner_id from public.import_batches union select user_id from public.account_permissions;
create table public.user_roles (
 user_id uuid primary key references auth.users(id), owner_id uuid not null references public.businesses(id),
 role text not null check(role in ('administrator','loan_officer','cashier','viewer')),
 is_active boolean not null default true, revision integer not null default 1,
 assigned_by uuid references auth.users(id), created_at timestamptz not null default clock_timestamp(), updated_at timestamptz not null default clock_timestamp()
);
create index user_roles_business on public.user_roles(owner_id,role) where is_active;
-- Preserve explicit trusted administrators; all other legacy owners become
-- Viewers until a trusted bootstrap or an Administrator explicitly assigns a role.
insert into public.user_roles(user_id,owner_id,role)
 select b.id,b.id,case when coalesce(p.is_admin,false) then 'administrator' else 'viewer' end from public.businesses b left join public.account_permissions p on p.user_id=b.id;
alter table public.businesses enable row level security;
alter table public.user_roles enable row level security;
revoke all on public.businesses,public.user_roles from public,anon,authenticated;
grant select on public.businesses,public.user_roles to authenticated;
create function public.current_ledger_id() returns uuid language sql stable security definer set search_path='' as $$
 select owner_id from public.user_roles where user_id=auth.uid() and is_active;
$$;
create function public.has_capability(p_action text) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce((select case
 when p_action='read' then true
 when p_action in ('admin','imports','expenses') then role='administrator'
 when p_action in ('clients','originate') then role in ('administrator','loan_officer')
 when p_action='repayments' then role in ('administrator','cashier')
 else false end from public.user_roles where user_id=auth.uid() and is_active),false);
$$;
create function public.require_capability(p_action text) returns void language plpgsql security definer set search_path='' as $$
begin
 -- Hold the membership lock until this financial/identity operation commits.
 -- Revoking/changing the role cannot race an already-authorized posting.
 perform 1 from public.user_roles where user_id=auth.uid() and is_active for share;
 if not found or not public.has_capability(p_action) then raise exception 'Permission denied for this role: %',p_action using errcode='42501'; end if;
end $$;
create or replace function public.is_ledger_admin() returns boolean language sql stable security definer set search_path='' as $$ select public.has_capability('admin'); $$;
create or replace function public.can_override_loan_rate() returns boolean language sql stable security definer set search_path='' as $$ select public.has_capability('admin'); $$;
revoke all on function public.current_ledger_id(),public.has_capability(text),public.require_capability(text) from public,anon;
grant execute on function public.current_ledger_id(),public.has_capability(text) to authenticated;
revoke all on function public.require_capability(text) from authenticated;
create policy business_read on public.businesses for select to authenticated using(id=(select public.current_ledger_id()));
create policy roles_read on public.user_roles for select to authenticated using(user_id=(select auth.uid()) or (owner_id=(select public.current_ledger_id()) and public.has_capability('admin')));
-- account_permissions is retained as migration provenance, never live authority.
revoke all on public.account_permissions from authenticated;
do $$declare r record;begin
 for r in select tablename,policyname from pg_policies where schemaname='public' and tablename in ('clients','loans','repayments','client_audit','ledger_settings','settings_audit','loan_terms_audit','loan_status_audit','import_batches','import_rows','financial_operations','repayment_audit') loop
 execute format('drop policy %I on public.%I',r.policyname,r.tablename);
 end loop;
end $$;
create policy business_read on public.clients for select to authenticated using(owner_id=(select public.current_ledger_id()));
alter table public.clients add constraint clients_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.loans for select to authenticated using(owner_id=(select public.current_ledger_id()));
alter table public.loans add constraint loans_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.repayments for select to authenticated using(owner_id=(select public.current_ledger_id()));
alter table public.repayments add constraint repayments_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.client_audit for select to authenticated using(owner_id=(select public.current_ledger_id()));
alter table public.client_audit add constraint client_audit_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.ledger_settings for select to authenticated using(owner_id=(select public.current_ledger_id()));
alter table public.ledger_settings add constraint ledger_settings_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.settings_audit for select to authenticated using(owner_id=(select public.current_ledger_id()) and public.has_capability('admin'));
alter table public.settings_audit add constraint settings_audit_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.loan_terms_audit for select to authenticated using(owner_id=(select public.current_ledger_id()));
alter table public.loan_terms_audit add constraint loan_terms_audit_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.loan_status_audit for select to authenticated using(owner_id=(select public.current_ledger_id()));
alter table public.loan_status_audit add constraint loan_status_audit_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.import_batches for select to authenticated using(owner_id=(select public.current_ledger_id()) and public.has_capability('admin'));
alter table public.import_batches add constraint import_batches_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.import_rows for select to authenticated using(owner_id=(select public.current_ledger_id()) and public.has_capability('admin'));
alter table public.import_rows add constraint import_rows_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.financial_operations for select to authenticated using(owner_id=(select public.current_ledger_id()) and public.has_capability('admin'));
alter table public.financial_operations add constraint financial_operations_business_fk foreign key(owner_id) references public.businesses(id);
create policy business_read on public.repayment_audit for select to authenticated using(owner_id=(select public.current_ledger_id()));
alter table public.repayment_audit add constraint repayment_audit_business_fk foreign key(owner_id) references public.businesses(id);
create policy clients_create on public.clients for insert to authenticated with check(owner_id=(select public.current_ledger_id()) and public.has_capability('clients'));
alter table public.clients alter column owner_id set default public.current_ledger_id();
drop view public.loan_register;
drop view public.repayment_register;
alter table public.loans drop column total_obligation_cents;
alter table public.loans alter column principal_cents type numeric(14,0), alter column interest_cents type numeric(14,0), alter column balance_cents type numeric(14,0), alter column written_off_cents type numeric(14,0);
alter table public.loans add column total_obligation_cents numeric(14,0) generated always as (principal_cents+interest_cents) stored;
alter table public.repayments alter column amount_cents type numeric(14,0), alter column principal_allocation_cents type numeric(14,0), alter column interest_allocation_cents type numeric(14,0);
create function public.loan_effective_status(p_balance numeric,p_due_date date,p_lifecycle text,p_timezone text,p_as_of date default null) returns text language sql stable set search_path='' as $$
 select public.loan_effective_status(p_balance::bigint,p_due_date,p_lifecycle,p_timezone,p_as_of);
$$;
revoke all on function public.loan_effective_status(numeric,date,text,text,date) from public,anon;
grant execute on function public.loan_effective_status(numeric,date,text,text,date) to authenticated;

create or replace function public.audit_client_change() returns trigger
language plpgsql security definer set search_path = '' as $$
declare v_reason text;
begin
 perform public.require_capability('clients');
 if auth.uid() is null or new.owner_id<>public.current_ledger_id() then raise exception 'Client authorization required'; end if;
 if tg_op = 'INSERT' then
   new.created_by := auth.uid();
   new.created_at := clock_timestamp();
   new.updated_at := new.created_at;
   new.revision := 1;
 else
   if new.id <> old.id or new.owner_id <> old.owner_id or new.created_by <> old.created_by or new.created_at <> old.created_at then raise exception 'Client identity and creator are immutable'; end if;
   v_reason := current_setting('app.client_correction_reason',true);
   if v_reason is null or length(trim(v_reason)) not between 5 and 500 then raise exception 'A correction reason of 5–500 characters is required'; end if;
   new.updated_at := clock_timestamp();
   new.revision := old.revision + 1;
 end if;
 new.man_number := trim(new.man_number);
 new.name := trim(new.name);
 new.department := trim(new.department);
 new.designation := trim(new.designation);
 new.phone := nullif(trim(new.phone),'');
 new.email := nullif(trim(new.email),'');
 new.address := nullif(trim(new.address),'');
 return new;
end $$;

create or replace function public.correct_client(p_client_id uuid, p_details jsonb, p_reason text, p_expected_revision integer)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_client public.clients;
begin
 perform public.require_capability('clients');
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 select * into v_client from public.clients where id = p_client_id and owner_id=public.current_ledger_id() for update;
 if not found then raise exception 'Client not found'; end if;
 if p_expected_revision is null or v_client.revision <> p_expected_revision then raise exception 'Client changed since you opened it. Reload and review the latest details.'; end if;
 if p_details is null or jsonb_typeof(p_details) <> 'object' then raise exception 'Client details required'; end if;
 if p_reason is null or length(trim(p_reason)) not between 5 and 500 then raise exception 'A correction reason of 5–500 characters is required'; end if;
 if exists (select 1 from jsonb_object_keys(p_details) k where k not in ('man_number','name','department','designation','email','phone','address','is_active')) then raise exception 'Unexpected Client field'; end if;
 if jsonb_typeof(p_details->'is_active') is distinct from 'boolean' then raise exception 'Client active status must be boolean'; end if;
 perform set_config('app.client_correction_reason',trim(p_reason),true);
 update public.clients set
 man_number=p_details->>'man_number', name=p_details->>'name', department=p_details->>'department', designation=p_details->>'designation',
 email=p_details->>'email', phone=p_details->>'phone', address=p_details->>'address', is_active=(p_details->>'is_active')::boolean
 where id=p_client_id;
 return p_client_id;
end $$;

create or replace function public.classify_import_row(p_row jsonb,p_mode text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_errors jsonb:='[]'; v_warnings jsonb:='[]'; v_client public.clients; v_key text;
begin
 perform public.require_capability('imports');
 if jsonb_typeof(p_row) is distinct from 'object' then return jsonb_build_object('errors',jsonb_build_array('Invalid row object'),'warnings',v_warnings,'outcome','rejected'); end if;
 foreach v_key in array array['source_no','man_number','name','department','designation'] loop
   if jsonb_typeof(p_row->v_key) is distinct from 'string' or length(trim(p_row->>v_key))=0 then v_errors:=v_errors||jsonb_build_array(v_key||' is required as text'); end if;
 end loop;
 if coalesce(p_row->>'source_no','') !~ '^[0-9]{1,9}$' or coalesce(nullif(p_row->>'source_no',''),'0') ~ '^0+$' then v_errors:=v_errors||jsonb_build_array('no# must be a positive source row number'); end if;
 if length(trim(p_row->>'man_number'))>50 or (p_row->>'man_number') ~ '[[:cntrl:]]' then v_errors:=v_errors||jsonb_build_array('Man# must be at most 50 characters without control characters'); end if;
 if length(trim(p_row->>'name')) not between 2 and 120 or length(trim(p_row->>'department'))>120 or length(trim(p_row->>'designation'))>120 then v_errors:=v_errors||jsonb_build_array('Invalid Client name, department, or designation length'); end if;
 if jsonb_typeof(p_row->'parse_errors')='array' then v_errors:=v_errors||(p_row->'parse_errors'); end if;
 if p_row->>'man_numeric'='true' then v_warnings:=v_warnings||jsonb_build_array('Excel stored Man# numerically. Original leading zeros may be lost; verify this Man# before confirming.'); end if;
 if p_mode='loans' and (jsonb_typeof(p_row->'amount') is distinct from 'string' or coalesce(p_row->>'amount','') !~ '^[0-9]{1,9}(\.[0-9]{1,2})?$') then v_errors:=v_errors||jsonb_build_array('Loan amount must be a positive ZMW amount with up to two decimals');
 elsif p_mode='loans' and (p_row->>'amount')::numeric<=0 then v_errors:=v_errors||jsonb_build_array('Loan amount must be greater than zero'); end if;
 if p_mode='clients' then v_warnings:=v_warnings||jsonb_build_array('amount is ignored in Client Register Import; no loan or repayment will be created.'); end if;
 select * into v_client from public.clients where owner_id=public.current_ledger_id() and lower(man_number)=lower(trim(p_row->>'man_number'));
 if found then
   if v_client.name is distinct from trim(p_row->>'name') or v_client.department is distinct from trim(p_row->>'department') or v_client.designation is distinct from trim(p_row->>'designation') then v_errors:=v_errors||jsonb_build_array('Conflicting Client details for this Man#. Correct the register through the audited correction workflow first.'); end if;
   if p_mode='loans' and not v_client.is_active then v_errors:=v_errors||jsonb_build_array('Client is inactive; no new loan may be created'); end if;
 end if;
 return jsonb_build_object('errors',v_errors,'warnings',v_warnings,'outcome',case when jsonb_array_length(v_errors)>0 then 'rejected' when v_client.id is not null and p_mode='clients' then 'unchanged' else 'accepted' end,'matched_client_id',v_client.id,'matched_revision',v_client.revision);
end $$;

create or replace function public.preview_import_v3(p_filename text,p_file_sha256 text,p_mode text,p_terms jsonb,p_rows jsonb) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_batch public.import_batches; v_terms jsonb:='{}'; v_semantic jsonb; v_fingerprint text; v_row jsonb; v_result jsonb; v_due date; v_key text; v_count integer:=0;
begin
 perform public.require_capability('imports');
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_mode is null or p_mode not in ('clients','loans') then raise exception 'Select an explicit import mode'; end if;
 if p_filename is null or length(p_filename) not between 1 and 200 or lower(p_filename) not like '%.xlsx' or p_file_sha256 is null or p_file_sha256 !~ '^[a-f0-9]{64}$' then raise exception 'Invalid workbook metadata'; end if;
 if jsonb_typeof(p_rows) is distinct from 'array' or jsonb_array_length(p_rows) not between 1 and 500 or octet_length(p_rows::text)>1500000 then raise exception 'Import 1–500 bounded rows'; end if;
 -- Reject malformed RPC envelopes. Workbook cell values are always server-parsed strings;
 -- invalid cell contents still produce per-row diagnostics rather than unsafe JSON shapes.
 for v_row in select value from jsonb_array_elements(p_rows) loop
   if jsonb_typeof(v_row) is distinct from 'object' then raise exception 'Import rows must be objects'; end if;
   foreach v_key in array array['source_no','man_number','name','department','designation','amount'] loop
     if jsonb_typeof(v_row->v_key) is distinct from 'string' then raise exception 'Mapped cell values must be strings'; end if;
   end loop;
   if jsonb_typeof(v_row->'man_numeric') is distinct from 'boolean' or jsonb_typeof(v_row->'parse_errors') is distinct from 'array' then raise exception 'Invalid parsed row metadata'; end if;
   if exists (select 1 from jsonb_array_elements(v_row->'parse_errors') e where jsonb_typeof(e)<>'string') then raise exception 'Invalid row diagnostic'; end if;
 end loop;
 if p_mode='clients' and p_terms is distinct from '{}'::jsonb then raise exception 'Client Register Import does not accept loan terms'; end if;
 if p_mode='loans' then
   if p_terms is null or p_terms->>'disbursement_date' is null or p_terms->>'disbursement_date' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then raise exception 'Disbursement date required'; end if;
   v_due:=(p_terms->>'disbursement_date')::date;
   if v_due > (now() at time zone 'Africa/Lusaka')::date or v_due<'1900-01-01' then raise exception 'Disbursement date must be between 1900 and today'; end if;
   if p_terms->>'due_rule' is distinct from 'days_after_disbursement' or coalesce(p_terms->>'term_days','') !~ '^[0-9]{1,4}$' then raise exception 'Choose a due-date rule and term'; end if;
   if (p_terms->>'term_days')::integer not between 1 and 3650 then raise exception 'Term must be 1–3650 days'; end if;
   if p_terms->>'interest_type' is null or p_terms->>'interest_type' not in ('fixed','flat_percent') or coalesce(p_terms->>'interest_value','') !~ '^[0-9]{1,9}(\.[0-9]{1,2})?$' then raise exception 'Explicit fixed or flat percentage interest terms required'; end if;
   if p_terms->>'interest_type'='flat_percent' and (p_terms->>'interest_value')::numeric>100 then raise exception 'Flat interest percentage must be 0–100'; end if;
   v_terms:=jsonb_build_object('disbursement_date',v_due,'due_rule','days_after_disbursement','term_days',(p_terms->>'term_days')::integer,'interest_type',p_terms->>'interest_type','interest_value',trim_scale((p_terms->>'interest_value')::numeric)::text);
 end if;
 -- Semantic fingerprint ignores filename, source row numbering, and row order.
 -- Equality is also checked, so a digest collision cannot replay another payload.
 select jsonb_agg(s order by s::text) into v_semantic from (
 select jsonb_build_object('man_number',lower(trim(r->>'man_number')),'name',trim(r->>'name'),'department',trim(r->>'department'),'designation',trim(r->>'designation'),
 'amount',case when p_mode='loans' then case when coalesce(r->>'amount','') ~ '^[0-9]{1,9}(\.[0-9]{1,2})?$' then trim_scale((r->>'amount')::numeric)::text else r->>'amount' end else null end,
 'source_valid',coalesce(jsonb_typeof(r->'source_no')='string' and (r->>'source_no') ~ '^[0-9]{1,9}$' and (r->>'source_no') !~ '^0+$',false),'parse_errors',r->'parse_errors') s from jsonb_array_elements(p_rows) r) canonical;
 v_semantic:=jsonb_build_object('mode',p_mode,'terms',v_terms,'rows',v_semantic);
 v_fingerprint:=md5(v_semantic::text);
 perform pg_advisory_xact_lock(hashtextextended('excel_import:'||public.current_ledger_id()::text,0));
 select * into v_batch from public.import_batches where owner_id=public.current_ledger_id() and fingerprint=v_fingerprint for update;
 if found then
   if v_batch.payload<>v_semantic then raise exception 'Import fingerprint collision; contact support'; end if;
   if v_batch.status='completed' then return v_batch.id; end if;
   delete from public.import_rows where batch_id=v_batch.id;
   update public.import_batches set preview_version=preview_version+1,filename=p_filename,file_sha256=p_file_sha256,updated_at=clock_timestamp() where id=v_batch.id;
 else
   insert into public.import_batches(owner_id,uploaded_by,filename,file_sha256,fingerprint,mode,terms,payload) values(public.current_ledger_id(),auth.uid(),p_filename,p_file_sha256,v_fingerprint,p_mode,v_terms,v_semantic) returning * into v_batch;
 end if;
 for v_row in select value from jsonb_array_elements(p_rows) loop
   v_count:=v_count+1;
   v_result:=public.classify_import_row(v_row,p_mode);
   if (select count(*) from jsonb_array_elements(p_rows) r where lower(trim(r->>'man_number'))=lower(trim(v_row->>'man_number')))>1 then
     v_result:=jsonb_set(v_result,'{errors}',(v_result->'errors')||jsonb_build_array('Duplicate Man# in this workbook; all occurrences are rejected'));
     v_result:=jsonb_set(v_result,'{outcome}','"rejected"');
   end if;
   insert into public.import_rows(batch_id,owner_id,excel_row,source_no,data,outcome,errors,warnings,matched_client_id,matched_revision)
   values(v_batch.id,public.current_ledger_id(),v_count+1,v_row->>'source_no',v_row,v_result->>'outcome',v_result->'errors',v_result->'warnings',(v_result->>'matched_client_id')::uuid,(v_result->>'matched_revision')::integer);
 end loop;
 update public.import_batches set accepted=(select count(*) from public.import_rows where batch_id=v_batch.id and outcome='accepted'),rejected=(select count(*) from public.import_rows where batch_id=v_batch.id and outcome='rejected'),unchanged=(select count(*) from public.import_rows where batch_id=v_batch.id and outcome='unchanged') where id=v_batch.id;
 return v_batch.id;
end $$;

create or replace function public.commit_import_v3(p_batch_id uuid,p_preview_version integer,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_batch public.import_batches; v_row public.import_rows; v_client public.clients; v_id uuid; v_loan uuid; v_principal bigint; v_interest bigint;
begin
 perform public.require_capability('imports');
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_confirm is distinct from true then raise exception 'Explicit confirmation required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('excel_import:'||public.current_ledger_id()::text,0));
 select * into v_batch from public.import_batches where id=p_batch_id and owner_id=public.current_ledger_id() for update;
 if not found then raise exception 'Import not found'; end if;
 if v_batch.status='completed' then return v_batch.id; end if;
 if v_batch.accepted=0 and v_batch.rejected>0 then raise exception 'No accepted rows to save. Resolve the errors and preview again.'; end if;
 if p_preview_version is null or p_preview_version<>v_batch.preview_version then raise exception 'Preview changed. Generate and review a new preview.'; end if;
 for v_row in select * from public.import_rows where batch_id=v_batch.id and outcome<>'rejected' order by lower(data->>'man_number') loop
   select * into v_client from public.clients where owner_id=public.current_ledger_id() and lower(man_number)=lower(trim(v_row.data->>'man_number')) for update;
   if v_client.id is distinct from v_row.matched_client_id or v_client.revision is distinct from v_row.matched_revision then raise exception 'Client register changed since preview. Generate and review a new preview.'; end if;
   if v_row.outcome='unchanged' then
     update public.import_rows set client_id=v_client.id where id=v_row.id;
     continue;
   end if;
   if v_client.id is null then
     insert into public.clients(man_number,name,department,designation) values(v_row.data->>'man_number',v_row.data->>'name',v_row.data->>'department',v_row.data->>'designation') returning id into v_id;
   else v_id:=v_client.id; end if;
   v_loan:=null;
   if v_batch.mode='loans' then
     v_principal:=((v_row.data->>'amount')::numeric*100)::bigint;
     v_interest:=case when v_batch.terms->>'interest_type'='fixed' then ((v_batch.terms->>'interest_value')::numeric*100)::bigint else round(v_principal*(v_batch.terms->>'interest_value')::numeric/100)::bigint end;
     insert into public.loans(owner_id,client_id,principal_cents,interest_cents,balance_cents,due_date,disbursement_date,import_batch_id)
     values(public.current_ledger_id(),v_id,v_principal,v_interest,v_principal+v_interest,(v_batch.terms->>'disbursement_date')::date+(v_batch.terms->>'term_days')::integer,(v_batch.terms->>'disbursement_date')::date,v_batch.id) returning id into v_loan;
   end if;
   update public.import_rows set client_id=v_id,loan_id=v_loan where id=v_row.id;
 end loop;
 update public.import_batches set status='completed',completed_at=clock_timestamp(),updated_at=clock_timestamp() where id=v_batch.id;
 return v_batch.id;
exception when unique_violation then raise exception 'Client register changed or this import is a duplicate. Generate and review a new preview.';
end $$;

create or replace function public.preview_import(p_filename text,p_file_sha256 text,p_mode text,p_terms jsonb,p_rows jsonb) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_settings public.ledger_settings; v_id uuid; v_terms jsonb; v_rate integer;
begin
 perform public.require_capability('imports');
 if p_mode='loans' then
   if p_terms->>'interest_type' is distinct from 'flat_percent' or coalesce(p_terms->>'interest_value','') !~ '^[0-9]{1,3}(\.[0-9]{1,2})?$' then raise exception 'Only one-time flat percentage interest for the entire term is supported'; end if;
   v_rate:=((p_terms->>'interest_value')::numeric*100)::integer;
   v_settings:=public.checked_loan_terms(p_terms||jsonb_build_object('rate_bps',v_rate));
 end if;
 v_id:=public.preview_import_v3(p_filename,p_file_sha256,p_mode,p_terms,p_rows);
 if p_mode='loans' then
   update public.import_batches set terms=terms||jsonb_build_object('calculation_method','one_time_flat','rate_basis','entire_term','settings_revision',v_settings.revision,'default_rate_bps',v_settings.default_rate_bps,'override_reason',nullif(trim(p_terms->>'override_reason'),''),'currency',v_settings.currency,'rounding_rule',v_settings.rounding_rule,'business_timezone',v_settings.business_timezone) where id=v_id and status='preview';
   update public.import_rows set data=data||jsonb_build_object('principal_cents',((data->>'amount')::numeric*100)::bigint,'interest_cents',public.flat_interest_cents(((data->>'amount')::numeric*100)::bigint,v_rate,'one_time_flat','entire_term'),'total_obligation_cents',((data->>'amount')::numeric*100)::bigint+public.flat_interest_cents(((data->>'amount')::numeric*100)::bigint,v_rate,'one_time_flat','entire_term'),'rate_bps',v_rate,'due_date',(p_terms->>'disbursement_date')::date+(p_terms->>'term_days')::integer) where batch_id=v_id and outcome='accepted' and exists(select 1 from public.import_batches where id=v_id and status='preview');

 end if;
 return v_id;
end $$;

create or replace function public.commit_import(p_batch_id uuid,p_preview_version integer,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_batch public.import_batches; v_terms jsonb;
begin
 perform public.require_capability('imports');
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('excel_import:'||public.current_ledger_id()::text,0));
 select * into v_batch from public.import_batches where id=p_batch_id and owner_id=public.current_ledger_id() for update;
 if not found then raise exception 'Import not found'; end if;
 if v_batch.status<>'completed' and v_batch.mode='loans' then
   if v_batch.terms->>'interest_type' is distinct from 'flat_percent' then raise exception 'Unsupported staged interest terms. Generate a new preview.'; end if;
   perform public.checked_loan_terms(v_batch.terms||jsonb_build_object('rate_bps',((v_batch.terms->>'interest_value')::numeric*100)::integer));
 end if;
 return public.commit_import_v3(p_batch_id,p_preview_version,p_confirm);
end $$;

create or replace function public.import_report(p_batch_id uuid) returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('batch',to_jsonb(b)-'payload','rows',coalesce((select jsonb_agg(to_jsonb(r)||jsonb_build_object('loan_reference',(select loan_reference from public.loans l where l.id=r.loan_id)) order by r.excel_row) from public.import_rows r where r.batch_id=b.id),'[]'::jsonb)) from public.import_batches b where b.id=p_batch_id and b.owner_id=public.current_ledger_id();
$$;

create or replace function public.loan_defaults() returns jsonb language plpgsql security definer set search_path='' as $$
declare v_settings public.ledger_settings;
begin
 perform public.require_capability('read');
 if auth.uid() is null then raise exception 'Authentication required'; end if;

 select * into v_settings from public.ledger_settings where owner_id=public.current_ledger_id();
 if not found then raise exception 'Business settings are not initialized. Contact an Administrator.';end if;
 return jsonb_build_object('settings',to_jsonb(v_settings),'capabilities',jsonb_build_object('is_admin',public.is_ledger_admin(),'can_override_rate',public.can_override_loan_rate(),'can_register_clients',public.has_capability('clients'),'can_originate',public.has_capability('originate'),'can_post_repayments',public.has_capability('repayments'),'can_import',public.has_capability('imports'),'can_manage_expenses',public.has_capability('expenses'),'can_read',public.has_capability('read'),'role',(select role from public.user_roles where user_id=auth.uid() and is_active)));
end $$;

create or replace function public.save_interest_settings(p_settings jsonb,p_expected_revision integer,p_reason text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_before public.ledger_settings; v_after public.ledger_settings;
begin
 perform public.require_capability('admin');
 if not public.is_ledger_admin() then raise exception 'Administrator permission required'; end if;
 perform public.loan_defaults();
 select * into v_before from public.ledger_settings where owner_id=public.current_ledger_id() for update;
 if p_expected_revision is distinct from v_before.revision then raise exception 'Settings changed. Reload current defaults before saving.'; end if;
 if p_reason is null or length(trim(p_reason)) not between 5 and 500 then raise exception 'A settings change reason of 5–500 characters is required'; end if;
 if p_settings->>'calculation_method' is distinct from 'one_time_flat' or p_settings->>'rate_basis' is distinct from 'entire_term' then raise exception 'Only one-time flat interest for the entire term is supported'; end if;
 if p_settings->>'currency' is distinct from 'ZMW' or p_settings->>'rounding_rule' is distinct from 'half_up_2' or p_settings->>'business_timezone' is distinct from 'Africa/Lusaka' then raise exception 'Unsupported currency, rounding rule, or business timezone'; end if;
 if coalesce(p_settings->>'default_rate_bps','') !~ '^[0-9]{1,5}$' or coalesce(p_settings->>'default_term_days','') !~ '^[0-9]{1,4}$' then raise exception 'Invalid rate or term'; end if;
 update public.ledger_settings set default_rate_bps=(p_settings->>'default_rate_bps')::integer,default_term_days=(p_settings->>'default_term_days')::integer,revision=revision+1,updated_by=auth.uid(),updated_at=clock_timestamp() where owner_id=public.current_ledger_id() returning * into v_after;
 insert into public.settings_audit(owner_id,actor_id,before_data,after_data,reason) values(public.current_ledger_id(),auth.uid(),to_jsonb(v_before),to_jsonb(v_after),trim(p_reason));
 return to_jsonb(v_after);
end $$;

create or replace function public.checked_loan_terms(p_terms jsonb) returns public.ledger_settings
language plpgsql security definer set search_path='' as $$
declare v_settings public.ledger_settings; v_rate integer;
begin
 perform public.require_capability('originate');
 perform public.loan_defaults();
 select * into v_settings from public.ledger_settings where owner_id=public.current_ledger_id() for share;
 if p_terms->>'calculation_method' is distinct from v_settings.calculation_method or p_terms->>'rate_basis' is distinct from v_settings.rate_basis then raise exception 'Only one-time flat interest for the entire term is supported'; end if;
 if coalesce(p_terms->>'settings_revision','') !~ '^[0-9]{1,9}$' or (p_terms->>'settings_revision')::integer<>v_settings.revision then raise exception 'Defaults changed. Reload and review current defaults.'; end if;
 if coalesce(p_terms->>'rate_bps','') !~ '^[0-9]{1,5}$' or coalesce(p_terms->>'term_days','') !~ '^[0-9]{1,4}$' then raise exception 'Invalid rate or term'; end if;
 v_rate:=(p_terms->>'rate_bps')::integer;
 if v_rate not between 0 and 10000 or (p_terms->>'term_days')::integer not between 1 and 3650 then raise exception 'Rate must be 0–100%% and term 1–3650 days'; end if;
 if v_rate<>v_settings.default_rate_bps then
   if not public.can_override_loan_rate() then raise exception 'Rate override permission required'; end if;
   if length(trim(coalesce(p_terms->>'override_reason',''))) not between 5 and 500 then raise exception 'A rate override reason of 5–500 characters is required'; end if;
 end if;
 return v_settings;
end $$;

create or replace function public.enforce_loan_terms() returns trigger language plpgsql security definer set search_path='' as $$
declare v_batch public.import_batches; v_settings public.ledger_settings; v_terms jsonb;
begin
 if tg_op='UPDATE' then
   if (to_jsonb(new)-array['balance_cents','total_obligation_cents','updated_at','updated_by','lifecycle_status','written_off_cents','written_off_at','written_off_by','written_off_reason','written_off_request_id'])=(to_jsonb(old)-array['balance_cents','total_obligation_cents','updated_at','updated_by','lifecycle_status','written_off_cents','written_off_at','written_off_by','written_off_reason','written_off_request_id']) then return new; end if;
   if not public.is_ledger_admin() or new.owner_id<>public.current_ledger_id() or length(coalesce(current_setting('app.loan_adjustment_reason',true),''))<5 then raise exception 'Loan terms require an authorized audited adjustment'; end if;
   if (to_jsonb(new)-array['interest_cents','interest_rate_bps','calculation_method','rate_basis','term_days','due_date','terms_revision','total_obligation_cents','balance_cents','updated_at','updated_by','lifecycle_status','written_off_cents','written_off_at','written_off_by','written_off_reason','written_off_request_id'])<>(to_jsonb(old)-array['interest_cents','interest_rate_bps','calculation_method','rate_basis','term_days','due_date','terms_revision','total_obligation_cents','balance_cents','updated_at','updated_by','lifecycle_status','written_off_cents','written_off_at','written_off_by','written_off_reason','written_off_request_id']) then raise exception 'Loan identity, principal, and original snapshot are immutable'; end if;
 else
   if auth.uid() is null or new.owner_id<>public.current_ledger_id() then raise exception 'Authentication required'; end if;
   if new.import_batch_id is not null then
     select * into v_batch from public.import_batches where id=new.import_batch_id and owner_id=public.current_ledger_id() and status='preview';
     if not found or v_batch.mode<>'loans' then raise exception 'Invalid disbursement batch'; end if;
     v_terms:=v_batch.terms||jsonb_build_object('rate_bps',((v_batch.terms->>'interest_value')::numeric*100)::integer);
     if v_batch.terms->>'interest_type' is distinct from 'flat_percent' then raise exception 'Unsupported import interest method'; end if;
     v_settings:=public.checked_loan_terms(v_terms);
     new.interest_rate_bps:=(v_terms->>'rate_bps')::integer;new.term_days:=(v_terms->>'term_days')::integer;
     new.calculation_method:='one_time_flat';new.rate_basis:='entire_term';new.settings_revision:=v_settings.revision;
     new.default_rate_bps_at_origination:=v_settings.default_rate_bps;new.rate_override_reason:=nullif(trim(v_terms->>'override_reason'),'');
     new.origin_request_id:=gen_random_uuid();
   end if;
   if new.settings_revision is null or new.default_rate_bps_at_origination is null then raise exception 'A current settings snapshot is required'; end if;
 end if;
 if new.interest_cents<>public.flat_interest_cents(new.principal_cents::bigint,new.interest_rate_bps,new.calculation_method,new.rate_basis) or new.term_days is null or new.due_date<>new.disbursement_date+new.term_days then raise exception 'Loan amounts or dates do not match the actual terms'; end if;
 return new;
end $$;

create or replace function public.originate_loan(p_details jsonb,p_request_id uuid,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_settings public.ledger_settings; v_existing public.loans; v_id uuid; v_principal bigint; v_rate integer; v_date date; v_interest bigint;
begin
 perform public.require_capability('originate');
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_confirm is distinct from true or p_request_id is null then raise exception 'Explicit confirmation and request ID required'; end if;
 if p_details is null or jsonb_typeof(p_details)<>'object' or octet_length(p_details::text)>10000 then raise exception 'Invalid loan details'; end if;
 if exists(select 1 from jsonb_object_keys(p_details) k where k not in ('client_id','principal_cents','rate_bps','term_days','disbursement_date','settings_revision','calculation_method','rate_basis','override_reason')) then raise exception 'Unexpected loan field'; end if;

 perform pg_advisory_xact_lock(hashtextextended('loan_request:'||public.current_ledger_id()::text||p_request_id::text,0));
 select * into v_existing from public.loans where owner_id=public.current_ledger_id() and origin_request_id=p_request_id;
 if found then
   if v_existing.origination_payload is distinct from p_details then raise exception 'Request ID already used for different loan terms'; end if;
   return v_existing.id;
 end if;
 v_settings:=public.checked_loan_terms(p_details);
 if coalesce(p_details->>'principal_cents','') !~ '^[0-9]{1,11}$' then raise exception 'Invalid principal'; end if;
 v_principal:=(p_details->>'principal_cents')::bigint;v_rate:=(p_details->>'rate_bps')::integer;
 v_interest:=public.flat_interest_cents(v_principal,v_rate,p_details->>'calculation_method',p_details->>'rate_basis');
 if coalesce(p_details->>'disbursement_date','') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then raise exception 'Disbursement date required'; end if;
 v_date:=(p_details->>'disbursement_date')::date;
 if v_date<'1900-01-01' or v_date>(now() at time zone v_settings.business_timezone)::date then raise exception 'Invalid disbursement date'; end if;
 perform 1 from public.clients where id=(p_details->>'client_id')::uuid and owner_id=public.current_ledger_id() and is_active and man_number is not null and department is not null and designation is not null for share;
 if not found then raise exception 'Active, complete Client not found'; end if;
 insert into public.loans(owner_id,client_id,principal_cents,interest_cents,balance_cents,disbursement_date,due_date,interest_rate_bps,calculation_method,rate_basis,term_days,settings_revision,default_rate_bps_at_origination,rate_override_reason,origin_request_id,origination_payload)
 values(public.current_ledger_id(),(p_details->>'client_id')::uuid,v_principal,v_interest,v_principal+v_interest,v_date,v_date+(p_details->>'term_days')::integer,v_rate,'one_time_flat','entire_term',(p_details->>'term_days')::integer,v_settings.revision,v_settings.default_rate_bps,nullif(trim(p_details->>'override_reason'),''),p_request_id,p_details) returning id into v_id;
 return v_id;
end $$;

create or replace function public.adjust_loan_terms(p_loan_id uuid,p_rate_bps integer,p_term_days integer,p_expected_revision integer,p_reason text,p_request_id uuid,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_loan public.loans; v_existing public.loan_terms_audit; v_paid bigint; v_interest bigint;
begin
 perform public.require_capability('admin');
 if not public.is_ledger_admin() then raise exception 'Administrator permission required'; end if;
 if p_confirm is distinct from true or p_request_id is null then raise exception 'Explicit adjustment confirmation and request ID required'; end if;
 if p_reason is null or length(trim(p_reason)) not between 5 and 500 then raise exception 'An adjustment reason of 5–500 characters is required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('loan_request:'||public.current_ledger_id()::text||p_request_id::text,0));
 select * into v_existing from public.loan_terms_audit where owner_id=public.current_ledger_id() and request_id=p_request_id;
 if found then
   if v_existing.action<>'adjust' or v_existing.loan_id<>p_loan_id or (v_existing.after_data->>'interest_rate_bps')::integer is distinct from p_rate_bps or (v_existing.after_data->>'term_days')::integer is distinct from p_term_days or v_existing.reason<>trim(p_reason) then raise exception 'Request ID already used for different adjustment'; end if;
   return p_loan_id;
 end if;
 select * into v_loan from public.loans where id=p_loan_id and owner_id=public.current_ledger_id() for update;
 if not found then raise exception 'Loan not found'; end if;
 if p_expected_revision is distinct from v_loan.terms_revision then raise exception 'Loan terms changed. Reload the loan before adjusting.'; end if;
 if p_term_days is null or p_term_days not between 1 and 3650 then raise exception 'Term must be 1–3650 days'; end if;
 v_interest:=public.flat_interest_cents(v_loan.principal_cents::bigint,p_rate_bps,'one_time_flat','entire_term');
 select coalesce(sum(amount_cents),0) into v_paid from public.repayments where loan_id=v_loan.id and owner_id=public.current_ledger_id() and reversed_at is null;
 if v_interest<(select coalesce(sum(interest_allocation_cents),0) from public.repayments where loan_id=v_loan.id and owner_id=public.current_ledger_id() and reversed_at is null) then raise exception 'Interest cannot be reduced below posted interest allocations. Reverse or correct affected receipts first.';end if;
 if v_loan.principal_cents+v_interest<v_paid then raise exception 'Adjusted obligation cannot be less than payments already received'; end if;
 perform set_config('app.loan_adjustment_reason',trim(p_reason),true);perform set_config('app.loan_request_id',p_request_id::text,true);
 update public.loans set interest_rate_bps=p_rate_bps,calculation_method='one_time_flat',rate_basis='entire_term',interest_cents=v_interest,term_days=p_term_days,due_date=disbursement_date+p_term_days,balance_cents=principal_cents+v_interest-v_paid,terms_revision=terms_revision+1 where id=v_loan.id;
 return v_loan.id;
end $$;

create or replace function public.maintain_loan_lifecycle() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or new.owner_id<>public.current_ledger_id() then raise exception 'Loan authorization required'; end if;
 if tg_op='INSERT' then
   if new.loan_reference is not null or new.lifecycle_status='written_off' or new.written_off_at is not null or new.written_off_request_id is not null or new.written_off_cents is not null or new.written_off_reason is not null or new.written_off_by is not null then raise exception 'Loan reference and initial status are system assigned'; end if;
   if new.principal_cents<=0 or new.disbursement_date>(now() at time zone new.business_timezone)::date or new.due_date<=new.disbursement_date then raise exception 'Invalid Amount Disbursed or inconsistent dates'; end if;
   if new.balance_cents<>new.principal_cents+new.interest_cents then raise exception 'A new loan must start at its total repayment obligation'; end if;
   new.loan_reference:=public.next_loan_reference();new.created_by:=auth.uid();new.creator_inferred:=false;
   new.created_at:=clock_timestamp();new.updated_at:=new.created_at;
 else
   if new.loan_reference<>old.loan_reference or new.created_by<>old.created_by or new.created_at<>old.created_at or new.creator_inferred<>old.creator_inferred then raise exception 'Loan reference and creator metadata are immutable'; end if;
   if old.lifecycle_status='written_off' then
     if not public.is_ledger_admin() or current_setting('app.reverse_write_off',true) is distinct from old.id::text or length(trim(coalesce(current_setting('app.writeoff_reversal_reason',true),''))) not between 5 and 500 then raise exception 'Reverse the write-off before receipts or adjustments';end if;
     if new.balance_cents<>old.balance_cents or new.terms_revision<>old.terms_revision or new.lifecycle_status='written_off' then raise exception 'Write-off reversal must preserve the obligation and unpaid balance';end if;
   end if;
   if new.lifecycle_status='written_off' then
     if not public.is_ledger_admin() or current_setting('app.loan_write_off',true) is distinct from new.written_off_request_id::text then raise exception 'An administrator must explicitly authorize a write-off'; end if;
     if new.balance_cents<>old.balance_cents or new.balance_cents<=0 or new.written_off_cents<>old.balance_cents or new.written_off_by<>auth.uid() then raise exception 'Write-off must preserve the unpaid balance'; end if;
     new.updated_at:=clock_timestamp();new.updated_by:=auth.uid();return new;
   end if;
   if new.written_off_cents is not null or new.written_off_at is not null or new.written_off_by is not null or new.written_off_reason is not null or new.written_off_request_id is not null then raise exception 'Invalid write-off metadata'; end if;
   new.updated_at:=clock_timestamp();
 end if;
 new.lifecycle_status:=case when new.balance_cents=0 then 'settled' else 'active' end;
 new.updated_by:=auth.uid();
 return new;
end $$;

create or replace function public.write_off_loan_v5(p_loan_id uuid,p_expected_balance_cents bigint,p_expected_terms_revision integer,p_reason text,p_request_id uuid,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_loan public.loans;
begin
 perform public.require_capability('admin');
 if not public.is_ledger_admin() then raise exception 'Administrator permission required'; end if;
 if p_confirm is distinct from true or p_request_id is null then raise exception 'Explicit write-off confirmation and request ID required'; end if;
 if p_reason is null or length(trim(p_reason)) not between 5 and 500 then raise exception 'A write-off reason of 5–500 characters is required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('loan_write_off:'||public.current_ledger_id()::text||p_request_id::text,0));
 select * into v_loan from public.loans where owner_id=public.current_ledger_id() and written_off_request_id=p_request_id;
 if found then
   if v_loan.id<>p_loan_id or v_loan.written_off_cents is distinct from p_expected_balance_cents or v_loan.terms_revision is distinct from p_expected_terms_revision or v_loan.written_off_reason<>trim(p_reason) then raise exception 'Request ID already used for another write-off'; end if;
   return v_loan.id;
 end if;
 select * into v_loan from public.loans where id=p_loan_id and owner_id=public.current_ledger_id() for update;
 if not found then raise exception 'Loan not found'; end if;
 if v_loan.lifecycle_status='written_off' then raise exception 'Loan is already written off'; end if;
 if v_loan.balance_cents=0 then raise exception 'Settled loans have no unpaid balance to write off'; end if;
 if p_expected_balance_cents is distinct from v_loan.balance_cents or p_expected_terms_revision is distinct from v_loan.terms_revision then raise exception 'Loan balance or terms changed. Reload and confirm the current balance.'; end if;
 perform set_config('app.loan_write_off',p_request_id::text,true);
 update public.loans set lifecycle_status='written_off',written_off_cents=balance_cents,written_off_at=clock_timestamp(),written_off_by=auth.uid(),written_off_reason=trim(p_reason),written_off_request_id=p_request_id where id=v_loan.id;
 return v_loan.id;
end $$;

create or replace function public.begin_financial_operation(p_request_id uuid,p_operation text,p_payload jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare v public.financial_operations;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_request_id is null then raise exception 'Financial request ID required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('finance_request:'||public.current_ledger_id()::text||p_request_id::text,0));
 select * into v from public.financial_operations where owner_id=public.current_ledger_id() and request_id=p_request_id;
 if found then
   if v.operation<>p_operation or v.payload is distinct from p_payload then raise exception 'Request ID already used for a different financial operation';end if;
   return v.result;
 end if;
 return null;
end $$;

create or replace function public.finish_financial_operation(p_request_id uuid,p_operation text,p_payload jsonb,p_result jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
begin insert into public.financial_operations(owner_id,request_id,operation,payload,result,created_by) values(public.current_ledger_id(),p_request_id,p_operation,p_payload,p_result,auth.uid());return p_result;end $$;

create or replace function public.protect_repayment() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='DELETE' then raise exception 'Posted financial transactions cannot be deleted'; end if;
 if not public.is_ledger_admin() or public.current_ledger_id()<>old.owner_id or current_setting('app.receipt_reversal',true) is distinct from old.id::text then raise exception 'An authorized audited reversal is required';end if;
 if old.reversed_at is not null then raise exception 'Reversed receipts are immutable';end if;
 if (to_jsonb(new)-array['reversed_at','reversed_by','reversal_reason','reversal_request_id','updated_at','posting_status']) is distinct from (to_jsonb(old)-array['reversed_at','reversed_by','reversal_reason','reversal_request_id','updated_at','posting_status']) then raise exception 'Posted receipt details and allocations are immutable';end if;
 if new.reversed_at is null or new.reversed_by is distinct from auth.uid() or length(trim(coalesce(new.reversal_reason,''))) not between 5 and 500 or new.reversal_request_id is null then raise exception 'Complete reversal metadata required';end if;
 new.updated_at:=clock_timestamp();return new;
end $$;

create or replace function public.post_receipt_internal(p_details jsonb,p_request_id uuid,p_replaces_id uuid default null) returns uuid language plpgsql security definer set search_path='' as $$
declare l public.loans;c public.clients;v_amount bigint;v_interest_paid bigint;v_principal_paid bigint;v_interest bigint;v_date date;v_method text;v_external text;v_id uuid:=gen_random_uuid();v_reference text;v_stamp timestamptz;
begin
 perform public.require_capability('repayments');
 if auth.uid() is null then raise exception 'Authentication required';end if;
 if p_details is null or jsonb_typeof(p_details)<>'object' or octet_length(p_details::text)>5000 then raise exception 'Invalid payment details';end if;
 if exists(select 1 from jsonb_object_keys(p_details) k where k not in ('loan_id','amount_cents','payment_date','payment_method','external_reference','expected_balance_cents','expected_terms_revision','expected_interest_outstanding_cents','expected_principal_outstanding_cents')) then raise exception 'Unexpected payment field';end if;
 if coalesce(p_details->>'amount_cents','') !~ '^[0-9]{1,12}$' then raise exception 'Repayment Received must be a positive amount with up to two decimal places';end if;
 v_amount:=(p_details->>'amount_cents')::bigint;if v_amount<=0 or v_amount>199999999998 then raise exception 'Repayment Received must be positive and within supported limits';end if;
 select * into l from public.loans where id=(p_details->>'loan_id')::uuid and owner_id=public.current_ledger_id() for update;
 if not found then raise exception 'Loan not found';end if;
 if l.lifecycle_status='written_off' then raise exception 'Reverse the write-off before posting a payment';end if;
 if coalesce(p_details->>'payment_date','') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then raise exception 'Payment date required';end if;
 v_date:=(p_details->>'payment_date')::date;
 if v_date<l.disbursement_date or v_date>(statement_timestamp() at time zone l.business_timezone)::date then raise exception 'Payment date must be between disbursement and the current business date';end if;
 v_method:=p_details->>'payment_method';if v_method is null or v_method not in ('cash','bank_transfer','mobile_money','card','other') then raise exception 'Choose a supported payment method';end if;
 v_external:=nullif(trim(p_details->>'external_reference'),'');if length(v_external)>120 then raise exception 'External reference must be at most 120 characters';end if;
 if v_external is not null and exists(select 1 from public.repayments where owner_id=public.current_ledger_id() and payment_method=v_method and lower(external_reference)=lower(v_external) and reversed_at is null) then raise exception 'External reference already belongs to a posted payment with this method';end if;
 if v_amount>l.balance_cents then raise exception 'Overpayment: Repayment Received % ZMW exceeds the outstanding balance of % ZMW. Reduce the amount or review the loan.',to_char(v_amount::numeric/100,'FM9999999990.00'),to_char(l.balance_cents::numeric/100,'FM9999999990.00');end if;
 if coalesce(p_details->>'expected_balance_cents','') !~ '^[0-9]{1,12}$' or coalesce(p_details->>'expected_terms_revision','') !~ '^[0-9]{1,9}$' or (p_details->>'expected_balance_cents')::bigint<>l.balance_cents or (p_details->>'expected_terms_revision')::integer<>l.terms_revision then raise exception 'Loan balance or terms changed. Reload and review the allocation before posting.';end if;
 select coalesce(sum(interest_allocation_cents),0),coalesce(sum(principal_allocation_cents),0) into v_interest_paid,v_principal_paid from public.repayments where loan_id=l.id and owner_id=public.current_ledger_id() and reversed_at is null;
 if v_interest_paid>l.interest_cents or v_principal_paid>l.principal_cents or l.balance_cents<>l.principal_cents+l.interest_cents-v_interest_paid-v_principal_paid then raise exception 'Loan allocation totals require review before posting';end if;
 if coalesce(p_details->>'expected_interest_outstanding_cents','') !~ '^[0-9]{1,12}$' or coalesce(p_details->>'expected_principal_outstanding_cents','') !~ '^[0-9]{1,12}$' or (p_details->>'expected_interest_outstanding_cents')::bigint<>l.interest_cents-v_interest_paid or (p_details->>'expected_principal_outstanding_cents')::bigint<>l.principal_cents-v_principal_paid then raise exception 'Loan allocations changed. Reload and review before posting.';end if;
 v_interest:=least(v_amount,l.interest_cents-v_interest_paid);
 select * into c from public.clients where id=l.client_id and owner_id=public.current_ledger_id();v_reference:=public.next_payment_reference();v_stamp:=clock_timestamp();
 insert into public.repayments(id,posting_sequence,owner_id,loan_id,amount_cents,request_id,payment_reference,payment_date,interest_allocation_cents,principal_allocation_cents,payment_method,external_reference,created_by,created_at,updated_at,terms_revision_at_posting,replaces_repayment_id,receipt_snapshot)
 values(v_id,nextval('public.receipt_posting_sequence'),public.current_ledger_id(),l.id,v_amount,p_request_id,v_reference,v_date,v_interest,v_amount-v_interest,v_method,v_external,auth.uid(),v_stamp,v_stamp,l.terms_revision,p_replaces_id,
 jsonb_build_object('client',jsonb_build_object('id',c.id,'name',c.name,'man_number',c.man_number),'loan_reference',l.loan_reference,'currency',l.currency,'balance_after_cents',l.balance_cents-v_amount,'principal_cents',l.principal_cents,'interest_charge_cents',l.interest_cents,'total_obligation_cents',l.total_obligation_cents,'terms_revision',l.terms_revision));
 perform set_config('app.receipt_request_id',p_request_id::text,true);perform set_config('app.receipt_action','post',true);
 update public.loans set balance_cents=balance_cents-v_amount where id=l.id;
 return v_id;
end $$;

create or replace function public.reverse_receipt_internal(p_id uuid,p_reason text,p_request_id uuid) returns void language plpgsql security definer set search_path='' as $$
declare r public.repayments;l public.loans;
begin
 perform public.require_capability('admin');
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'A reversal reason of 5–500 characters is required';end if;
 select * into r from public.repayments where id=p_id and owner_id=public.current_ledger_id();if not found then raise exception 'Payment not found';end if;
 -- All operations acquire the loan lock before the receipt row lock.
 select * into l from public.loans where id=r.loan_id and owner_id=public.current_ledger_id() for update;
 select * into r from public.repayments where id=p_id and owner_id=public.current_ledger_id() for update;
 if l.lifecycle_status='written_off' then raise exception 'Reverse the write-off before reversing this receipt';end if;
 if r.reversed_at is not null then raise exception 'Payment is already reversed; no further financial effect is allowed';end if;
 perform set_config('app.receipt_reversal',r.id::text,true);perform set_config('app.receipt_reason',trim(p_reason),true);perform set_config('app.receipt_action','reverse',true);perform set_config('app.receipt_request_id',p_request_id::text,true);
 update public.repayments set reversed_at=clock_timestamp(),reversed_by=auth.uid(),reversal_reason=trim(p_reason),reversal_request_id=p_request_id where id=r.id;
 update public.loans set balance_cents=balance_cents+r.amount_cents where id=l.id;
end $$;

create or replace function public.post_repayment(p_details jsonb,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_result jsonb;v_id uuid;
begin
 perform public.require_capability('repayments');
 if p_confirm is distinct from true then raise exception 'Explicit payment confirmation required';end if;
 v_result:=public.begin_financial_operation(p_request_id,'post_repayment',p_details);if v_result is not null then return v_result;end if;
 v_id:=public.post_receipt_internal(p_details,p_request_id);
 return public.finish_financial_operation(p_request_id,'post_repayment',p_details,jsonb_build_object('repayment_id',v_id));
exception when unique_violation then raise exception 'Duplicate payment request or external reference. Review existing posted payments before retrying.';
end $$;

create or replace function public.reverse_repayment(p_repayment_id uuid,p_reason text,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;
begin
 perform public.require_capability('admin');
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if p_confirm is distinct from true then raise exception 'Explicit reversal confirmation required';end if;
 v_payload:=jsonb_build_object('repayment_id',p_repayment_id,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'reverse_repayment',v_payload);if v_result is not null then return v_result;end if;
 perform public.reverse_receipt_internal(p_repayment_id,p_reason,p_request_id);
 return public.finish_financial_operation(p_request_id,'reverse_repayment',v_payload,jsonb_build_object('repayment_id',p_repayment_id));
end $$;

create or replace function public.correct_repayment(p_repayment_id uuid,p_details jsonb,p_reason text,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;r public.repayments;l public.loans;v_id uuid;v_details jsonb;
begin
 perform public.require_capability('admin');
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if p_confirm is distinct from true then raise exception 'Explicit adjustment confirmation required';end if;
 v_payload:=jsonb_build_object('repayment_id',p_repayment_id,'details',p_details,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'correct_repayment',v_payload);if v_result is not null then return v_result;end if;
 select * into r from public.repayments where id=p_repayment_id and owner_id=public.current_ledger_id();if not found then raise exception 'Payment not found';end if;
 select * into l from public.loans where id=r.loan_id and owner_id=public.current_ledger_id() for update;
 if (p_details->>'loan_id')::uuid is distinct from l.id or (p_details->>'expected_balance_cents')::bigint is distinct from l.balance_cents or (p_details->>'expected_terms_revision')::integer is distinct from l.terms_revision then raise exception 'Loan changed or replacement targets another loan. Reload before adjusting.';end if;
 perform public.reverse_receipt_internal(p_repayment_id,p_reason,p_request_id);
 perform set_config('app.receipt_correction_reason','Authorized replacement: '||trim(p_reason),true);
 v_details:=p_details||jsonb_build_object('expected_balance_cents',l.balance_cents+r.amount_cents,'expected_interest_outstanding_cents',(p_details->>'expected_interest_outstanding_cents')::bigint+r.interest_allocation_cents,'expected_principal_outstanding_cents',(p_details->>'expected_principal_outstanding_cents')::bigint+r.principal_allocation_cents);
 v_id:=public.post_receipt_internal(v_details,p_request_id,r.id);
 return public.finish_financial_operation(p_request_id,'correct_repayment',v_payload,jsonb_build_object('reversed_repayment_id',r.id,'repayment_id',v_id));
exception when unique_violation then raise exception 'Duplicate replacement or external reference. No adjustment was saved.';
end $$;

create or replace function public.record_repayment(p_loan_id uuid,p_amount_cents bigint,p_request_id uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare r public.repayments;
begin
 perform public.require_capability('repayments');
 if auth.uid() is null then raise exception 'Authentication required';end if;
 select * into r from public.repayments where owner_id=public.current_ledger_id() and request_id=p_request_id;
 if found and r.loan_id=p_loan_id and r.amount_cents=p_amount_cents then return r.id;end if;
 raise exception 'Use post_repayment with payment date, method, allocation review, and confirmation';
end $$;

create or replace function public.write_off_loan(p_loan_id uuid,p_expected_balance_cents bigint,p_expected_terms_revision integer,p_reason text,p_request_id uuid,p_confirm boolean) returns uuid language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;v_id uuid;
begin
 perform public.require_capability('admin');
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if p_confirm is distinct from true then raise exception 'Explicit write-off confirmation required';end if;
 v_payload:=jsonb_build_object('loan_id',p_loan_id,'balance',p_expected_balance_cents,'revision',p_expected_terms_revision,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'write_off',v_payload);if v_result is not null then return (v_result->>'loan_id')::uuid;end if;
 v_id:=public.write_off_loan_v5(p_loan_id,p_expected_balance_cents,p_expected_terms_revision,p_reason,p_request_id,p_confirm);
 perform public.finish_financial_operation(p_request_id,'write_off',v_payload,jsonb_build_object('loan_id',v_id));return v_id;
end $$;

create or replace function public.reverse_write_off(p_loan_id uuid,p_original_write_off_request_id uuid,p_reason text,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;l public.loans;
begin
 perform public.require_capability('admin');
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if p_confirm is distinct from true or length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'Explicit confirmation and a write-off reversal reason of 5–500 characters are required';end if;
 v_payload:=jsonb_build_object('loan_id',p_loan_id,'original_write_off_request_id',p_original_write_off_request_id,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'reverse_write_off',v_payload);if v_result is not null then return v_result;end if;
 select * into l from public.loans where id=p_loan_id and owner_id=public.current_ledger_id() for update;if not found then raise exception 'Loan not found';end if;
 if l.lifecycle_status<>'written_off' or p_original_write_off_request_id is null or p_original_write_off_request_id is distinct from l.written_off_request_id then raise exception 'Write-off changed or was already reversed. Reload the loan.';end if;
 perform set_config('app.reverse_write_off',l.id::text,true);perform set_config('app.writeoff_reversal_reason',trim(p_reason),true);perform set_config('app.writeoff_reversal_request',p_request_id::text,true);
 update public.loans set lifecycle_status='active',written_off_cents=null,written_off_at=null,written_off_by=null,written_off_reason=null,written_off_request_id=null where id=l.id;
 return public.finish_financial_operation(p_request_id,'reverse_write_off',v_payload,jsonb_build_object('loan_id',l.id));
end $$;

create view public.loan_register with(security_invoker=true) as
 select l.*,(l.principal_cents/100)::numeric(14,2) as amount_disbursed,(l.interest_cents/100)::numeric(14,2) as interest_charge,(l.balance_cents/100)::numeric(14,2) as outstanding_amount,l.principal_cents as amount_disbursed_cents,public.loan_effective_status(l.balance_cents,l.due_date,l.lifecycle_status,l.business_timezone) as status,
 coalesce(a.interest,0)::bigint as interest_repaid_cents,coalesce(a.principal,0)::bigint as principal_repaid_cents,
 (l.interest_cents-coalesce(a.interest,0))::bigint as interest_outstanding_cents,(l.principal_cents-coalesce(a.principal,0))::bigint as principal_outstanding_cents
 from public.loans l left join lateral(select sum(interest_allocation_cents) as interest,sum(principal_allocation_cents) as principal from public.repayments r where r.loan_id=l.id and r.owner_id=l.owner_id and r.reversed_at is null) a on true;
create view public.repayment_register with(security_invoker=true) as select r.*,(r.amount_cents/100)::numeric(14,2) as amount_received,(r.principal_allocation_cents/100)::numeric(14,2) as principal_allocation,(r.interest_allocation_cents/100)::numeric(14,2) as interest_allocation,l.loan_reference,l.client_id,(select payment_reference from public.repayments p where p.replaces_repayment_id=r.id) as replaced_by_reference from public.repayments r join public.loans l on l.id=r.loan_id and l.owner_id=r.owner_id;
revoke all on public.repayment_register from public,anon,authenticated;
grant select on public.repayment_register to authenticated;

revoke all on public.loan_register from public,anon,authenticated;grant select on public.loan_register to authenticated;
create or replace function public.receipt_document(p_repayment_id uuid) returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('generated_at',statement_timestamp(),'receipt',to_jsonb(r),'audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.repayment_audit a where a.repayment_id=r.id),'[]'::jsonb)) from public.repayment_register r where r.id=p_repayment_id and r.owner_id=public.current_ledger_id();
$$;

create or replace function public.client_statement(p_client_id uuid) returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('client',to_jsonb(c),'generated_at',statement_timestamp(),'timezone','Africa/Lusaka','allocation_policy','Interest first, then principal, in posting order; reversals restore original allocations without rewriting later receipts.',
 'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.created_at,l.id) from public.loan_register l where l.client_id=c.id),'[]'::jsonb),
 'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence) from public.repayment_register r where r.client_id=c.id),'[]'::jsonb),
 'repayment_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.repayment_audit a join public.loans l on l.id=(a.after_data->>'loan_id')::uuid where l.client_id=c.id),'[]'::jsonb),
 'terms_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.loan_terms_audit a join public.loans l on l.id=a.loan_id where l.client_id=c.id),'[]'::jsonb),
 'status_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.loan_status_audit a join public.loans l on l.id=a.loan_id where l.client_id=c.id),'[]'::jsonb)) from public.clients c where c.id=p_client_id and c.owner_id=public.current_ledger_id();
$$;

create or replace function public.report_source() returns jsonb language plpgsql stable security invoker set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 return (select jsonb_build_object(
  'generated_at',statement_timestamp(), 'timezone','Africa/Lusaka',
  'expenses',coalesce((select jsonb_agg(to_jsonb(e) order by e.expense_date,e.id) from public.expenses e where e.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'clients',coalesce((select jsonb_agg(to_jsonb(c) order by c.id) from public.clients c where c.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.id) from public.loans l where l.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence) from public.repayments r where r.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'terms_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_terms_audit a where a.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'status_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_status_audit a where a.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'repayment_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.repayment_audit a where a.owner_id=public.current_ledger_id()),'[]'::jsonb)));
end $$;

insert into public.ledger_settings(owner_id) select id from public.businesses on conflict do nothing;

-- Unified, append-only audit index. Detailed source audits remain unchanged.
create table public.audit_events (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.businesses(id),
 actor_id uuid references auth.users(id), entity_type text not null, entity_id uuid not null,
 action text not null, reason text not null, source_table text not null, source_id uuid,
 before_data jsonb, after_data jsonb not null, created_at timestamptz not null default clock_timestamp()
);
create index audit_events_business_time on public.audit_events(owner_id,created_at desc,id);
create index audit_events_entity on public.audit_events(owner_id,entity_type,entity_id,created_at);
alter table public.audit_events enable row level security;
revoke all on public.audit_events from public,anon,authenticated;
grant select on public.audit_events to authenticated;
create policy audit_read on public.audit_events for select to authenticated using(owner_id=(select public.current_ledger_id()) and public.has_capability('admin'));
create function public.append_audit_event() returns trigger language plpgsql security definer set search_path='' as $$
declare d jsonb:=to_jsonb(new);v_entity uuid;v_type text;
begin
 v_type:=case tg_table_name when 'client_audit' then 'Client' when 'repayment_audit' then 'Repayment' when 'settings_audit' then 'Settings' else 'Loan' end;
 v_entity:=coalesce((d->>'client_id')::uuid,(d->>'repayment_id')::uuid,(d->>'loan_id')::uuid,(d->>'owner_id')::uuid);
 insert into public.audit_events(owner_id,actor_id,entity_type,entity_id,action,reason,source_table,source_id,before_data,after_data,created_at)
 values(new.owner_id,(d->>'actor_id')::uuid,v_type,v_entity,coalesce(d->>'action','settings_change'),new.reason,tg_table_name,new.id,d->'before_data',d->'after_data',new.created_at);
 return new;
end $$;
create trigger unified_client_audit after insert on public.client_audit for each row execute function public.append_audit_event();
create trigger unified_terms_audit after insert on public.loan_terms_audit for each row execute function public.append_audit_event();
create trigger unified_status_audit after insert on public.loan_status_audit for each row execute function public.append_audit_event();
create trigger unified_receipt_audit after insert on public.repayment_audit for each row execute function public.append_audit_event();
create trigger unified_settings_audit after insert on public.settings_audit for each row execute function public.append_audit_event();
-- Preserve the original historical event times and actor IDs in the unified index.
insert into public.audit_events(owner_id,actor_id,entity_type,entity_id,action,reason,source_table,source_id,before_data,after_data,created_at)
 select owner_id,actor_id,'Client',client_id,action,reason,'client_audit',id,before_data,after_data,created_at from public.client_audit union all
 select owner_id,actor_id,'Loan',loan_id,action,reason,'loan_terms_audit',id,before_data,after_data,created_at from public.loan_terms_audit union all
 select owner_id,actor_id,'Loan',loan_id,action,reason,'loan_status_audit',id,before_data,after_data,created_at from public.loan_status_audit union all
 select owner_id,actor_id,'Repayment',repayment_id,action,reason,'repayment_audit',id,before_data,after_data,created_at from public.repayment_audit union all
 select owner_id,actor_id,'Settings',owner_id,'settings_change',reason,'settings_audit',id,before_data,after_data,created_at from public.settings_audit;
create function public.audit_user_role() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.audit_events(owner_id,actor_id,entity_type,entity_id,action,reason,source_table,source_id,before_data,after_data)
 values(new.owner_id,auth.uid(),'User',new.user_id,case when tg_op='INSERT' then 'role_assigned' else 'role_changed' end,coalesce(nullif(current_setting('app.role_reason',true),''),'Trusted SQL role provisioning'),'user_roles',new.user_id,case when tg_op='UPDATE' then to_jsonb(old) else null end,to_jsonb(new));return new;
end $$;
create trigger user_role_audit after insert or update on public.user_roles for each row execute function public.audit_user_role();
insert into public.audit_events(owner_id,entity_type,entity_id,action,reason,source_table,source_id,after_data)
 select owner_id,'User',user_id,'role_baseline','Role migration: trusted legacy administrators preserved; all other legacy owners mapped to Viewer.','user_roles',user_id,to_jsonb(r) from public.user_roles r;
create function public.manage_user_role(p_user_id uuid,p_role text,p_is_active boolean,p_expected_revision integer,p_reason text,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_old public.user_roles;v_new public.user_roles;v_payload jsonb;v_result jsonb;
begin
 perform public.require_capability('admin');
 if p_confirm is distinct from true then raise exception 'Explicit role change confirmation required';end if;
 if p_user_id is null or p_role is null or p_role not in ('administrator','loan_officer','cashier','viewer') or p_is_active is null then raise exception 'Choose an existing Auth user and a supported role';end if;
 if length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'A role change reason of 5–500 characters is required';end if;
 v_payload:=jsonb_build_object('user_id',p_user_id,'role',p_role,'active',p_is_active,'revision',p_expected_revision,'reason',trim(p_reason));
 v_result:=public.begin_financial_operation(p_request_id,'manage_user_role',v_payload);if v_result is not null then return v_result;end if;
 -- Serialize membership changes within this business and prevent moving an
 -- existing identity/ledger into another business through this API.
 perform 1 from public.businesses where id=public.current_ledger_id() for update;
 if p_user_id=auth.uid() and (p_role<>'administrator' or not p_is_active) then raise exception 'You cannot demote or disable your own Administrator role';end if;
 if not exists(select 1 from auth.users where id=p_user_id) then raise exception 'Auth user not found. Invite/register the user through Supabase Auth first.';end if;
 select * into v_old from public.user_roles where user_id=p_user_id for update;
 if found and v_old.owner_id<>public.current_ledger_id() then raise exception 'User is already assigned to another business';end if;
 if coalesce(v_old.revision,0) is distinct from p_expected_revision then raise exception 'Role changed. Reload the user list before confirming.';end if;
 perform set_config('app.role_reason',trim(p_reason),true);
 if v_old.user_id is null then
  insert into public.user_roles(user_id,owner_id,role,is_active,assigned_by) values(p_user_id,public.current_ledger_id(),p_role,p_is_active,auth.uid()) returning * into v_new;
 else
  update public.user_roles set role=p_role,is_active=p_is_active,revision=revision+1,assigned_by=auth.uid(),updated_at=clock_timestamp() where user_id=p_user_id returning * into v_new;
 end if;
 return public.finish_financial_operation(p_request_id,'manage_user_role',v_payload,to_jsonb(v_new));
end $$;

create sequence public.expense_reference_sequence;
revoke all on sequence public.expense_reference_sequence from public,anon,authenticated;
create table public.expenses (
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references public.businesses(id),
 expense_reference text not null unique,expense_date date not null check(expense_date>='1900-01-01'),
 amount numeric(14,2) not null check(amount>0 and amount<=999999999.99),
 amount_cents numeric(14,0) generated always as(amount*100) stored,
 currency text not null check(currency='ZMW'),category text not null check(length(trim(category)) between 1 and 120),
 description text not null check(length(trim(description)) between 5 and 500),payee text check(length(payee)<=120),
 payment_method text not null check(payment_method in ('cash','bank_transfer','mobile_money','card','other')),external_reference text check(length(external_reference) between 1 and 120),
 created_by uuid not null references auth.users(id),created_at timestamptz not null default clock_timestamp(),
 request_id uuid not null, reversed_at timestamptz,reversed_by uuid references auth.users(id),reversal_reason text,reversal_request_id uuid,
 unique(owner_id,request_id),unique(id,owner_id),
 check((reversed_at is null and reversed_by is null and reversal_reason is null and reversal_request_id is null) or (reversed_at is not null and reversed_by is not null and length(trim(reversal_reason)) between 5 and 500 and reversal_request_id is not null))
);
create index expenses_business_date on public.expenses(owner_id,expense_date,id);
create unique index expenses_external_unique on public.expenses(owner_id,payment_method,lower(external_reference)) where external_reference is not null and reversed_at is null;
alter table public.expenses enable row level security;
revoke all on public.expenses from public,anon,authenticated;
grant select on public.expenses to authenticated;
create policy expenses_read on public.expenses for select to authenticated using(owner_id=(select public.current_ledger_id()));
create function public.protect_expense() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='DELETE' then raise exception 'Posted expenses cannot be deleted';end if;
 if not public.is_ledger_admin() or public.current_ledger_id()<>old.owner_id or current_setting('app.expense_reversal',true) is distinct from old.id::text then raise exception 'An authorized expense reversal is required';end if;
 if old.reversed_at is not null or new.reversed_at is null or new.reversed_by is distinct from auth.uid() or length(trim(coalesce(new.reversal_reason,''))) not between 5 and 500 or new.reversal_request_id is null then raise exception 'Valid reversal metadata required';end if;
 if (to_jsonb(new)-array['reversed_at','reversed_by','reversal_reason','reversal_request_id','amount_cents']) is distinct from (to_jsonb(old)-array['reversed_at','reversed_by','reversal_reason','reversal_request_id','amount_cents']) then raise exception 'Original expense details are immutable';end if;
 return new;
end $$;
create trigger protect_expense before update or delete on public.expenses for each row execute function public.protect_expense();
create function public.audit_expense() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.audit_events(owner_id,actor_id,entity_type,entity_id,action,reason,source_table,source_id,before_data,after_data)
 values(new.owner_id,auth.uid(),'Expense',new.id,case when tg_op='INSERT' then 'expense_posted' else 'expense_reversed' end,case when tg_op='INSERT' then new.description else new.reversal_reason end,'expenses',new.id,case when tg_op='UPDATE' then to_jsonb(old) else null end,to_jsonb(new));return new;
end $$;
create trigger expense_audit after insert or update on public.expenses for each row execute function public.audit_expense();
create function public.post_expense(p_details jsonb,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_amount numeric;v_date date;v_payload jsonb;v_result jsonb;v_id uuid;v_reference text;
begin
 perform public.require_capability('expenses');
 if p_confirm is distinct from true then raise exception 'Explicit expense confirmation required';end if;
 if p_details is null or jsonb_typeof(p_details)<>'object' or octet_length(p_details::text)>5000 then raise exception 'Invalid expense details';end if;
 if exists(select 1 from jsonb_object_keys(p_details) k where k not in ('amount','expense_date','currency','category','description','payee','payment_method','external_reference')) then raise exception 'Unexpected expense field';end if;
 if coalesce(p_details->>'amount','') !~ '^[0-9]{1,9}(\.[0-9]{1,2})?$' then raise exception 'Expense amount must be positive with at most two decimals';end if;
 v_amount:=(p_details->>'amount')::numeric;if v_amount<=0 or v_amount>999999999.99 then raise exception 'Expense amount is outside supported limits';end if;
 if coalesce(p_details->>'expense_date','') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then raise exception 'Expense date required';end if;
 v_date:=(p_details->>'expense_date')::date;if v_date<'1900-01-01' or v_date>(statement_timestamp() at time zone 'Africa/Lusaka')::date then raise exception 'Expense date must be between 1900 and today';end if;
 if p_details->>'currency' is distinct from 'ZMW' then raise exception 'Unsupported expense currency';end if;
 v_payload:=p_details;v_result:=public.begin_financial_operation(p_request_id,'post_expense',v_payload);if v_result is not null then return v_result;end if;
 v_reference:=nextval('public.expense_reference_sequence')::text;
 insert into public.expenses(owner_id,expense_reference,expense_date,amount,currency,category,description,payee,payment_method,external_reference,created_by,request_id)
 values(public.current_ledger_id(),'EXP-'||lpad(v_reference,greatest(10,length(v_reference)),'0'),v_date,v_amount,'ZMW',trim(p_details->>'category'),trim(p_details->>'description'),nullif(trim(p_details->>'payee'),''),p_details->>'payment_method',nullif(trim(p_details->>'external_reference'),''),auth.uid(),p_request_id) returning id into v_id;
 return public.finish_financial_operation(p_request_id,'post_expense',v_payload,jsonb_build_object('expense_id',v_id));
exception when unique_violation then raise exception 'Duplicate expense request or external reference. Review posted expenses before retrying.';
end $$;
create function public.reverse_expense(p_expense_id uuid,p_reason text,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v public.expenses;v_payload jsonb;v_result jsonb;
begin
 perform public.require_capability('admin');
 if p_confirm is distinct from true or length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'Confirm the reversal with a reason of 5–500 characters';end if;
 v_payload:=jsonb_build_object('expense_id',p_expense_id,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'reverse_expense',v_payload);if v_result is not null then return v_result;end if;
 select * into v from public.expenses where id=p_expense_id and owner_id=public.current_ledger_id() for update;if not found then raise exception 'Expense not found';end if;
 if v.reversed_at is not null then raise exception 'Expense is already reversed';end if;
 perform set_config('app.expense_reversal',v.id::text,true);
 update public.expenses set reversed_at=clock_timestamp(),reversed_by=auth.uid(),reversal_reason=trim(p_reason),reversal_request_id=p_request_id where id=v.id;
 return public.finish_financial_operation(p_request_id,'reverse_expense',v_payload,jsonb_build_object('expense_id',v.id));
end $$;
-- A common trigger also protects source audits and the unified index from
-- ordinary SQL update/delete attempts, in addition to restrictive table grants.
create function public.immutable_audit() returns trigger language plpgsql set search_path='' as $$begin raise exception 'Audit history is immutable';end $$;
create trigger audit_events_immutable before update or delete on public.audit_events for each row execute function public.immutable_audit();
create trigger client_audit_immutable before update or delete on public.client_audit for each row execute function public.immutable_audit();
create trigger loan_terms_audit_immutable before update or delete on public.loan_terms_audit for each row execute function public.immutable_audit();
create trigger loan_status_audit_immutable before update or delete on public.loan_status_audit for each row execute function public.immutable_audit();
create trigger repayment_audit_immutable before update or delete on public.repayment_audit for each row execute function public.immutable_audit();
create trigger settings_audit_immutable before update or delete on public.settings_audit for each row execute function public.immutable_audit();
revoke all on function public.append_audit_event(),public.audit_user_role(),public.protect_expense(),public.audit_expense(),public.immutable_audit() from public,anon,authenticated;
revoke all on function public.manage_user_role(uuid,text,boolean,integer,text,uuid,boolean),public.post_expense(jsonb,uuid,boolean),public.reverse_expense(uuid,text,uuid,boolean) from public,anon;
grant execute on function public.manage_user_role(uuid,text,boolean,integer,text,uuid,boolean),public.post_expense(jsonb,uuid,boolean),public.reverse_expense(uuid,text,uuid,boolean) to authenticated;
create function public.audit_import_batch() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='UPDATE' and new.status=old.status and new.preview_version=old.preview_version then return new;end if;
 insert into public.audit_events(owner_id,actor_id,entity_type,entity_id,action,reason,source_table,source_id,before_data,after_data)
 values(new.owner_id,auth.uid(),'Import',new.id,case when new.status='completed' then 'import_completed' else 'import_previewed' end,'Explicit '||new.mode||' import workflow','import_batches',new.id,case when tg_op='UPDATE' then to_jsonb(old)-'payload' else null end,to_jsonb(new)-'payload');return new;
end $$;
create trigger import_batch_audit after insert or update on public.import_batches for each row execute function public.audit_import_batch();
revoke all on function public.audit_import_batch() from public,anon,authenticated;
commit;
