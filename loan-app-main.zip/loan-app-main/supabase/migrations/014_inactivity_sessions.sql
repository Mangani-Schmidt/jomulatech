begin;
-- Application session enforcement supplements Supabase Auth. It does not alter
-- provider JWT expiry, passwords, Auth sessions or financial records.
create table public.app_sessions (
 session_id uuid primary key,user_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default clock_timestamp(),last_activity_at timestamptz not null default clock_timestamp(),
 revoked_at timestamptz,revocation_reason text check(revocation_reason in ('inactive','signed-out'))
);
alter table public.app_sessions enable row level security;
revoke all on public.app_sessions from public,anon,authenticated;
create index app_sessions_user on public.app_sessions(user_id);
create function public.current_app_session_id() returns uuid language plpgsql stable set search_path='' as $$
declare v text;
begin
 v:=nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'session_id';
 if v is null or v !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' then return null;end if;
 return v::uuid;
end $$;
create function public.app_session_active() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.app_sessions where session_id=public.current_app_session_id() and user_id=auth.uid() and revoked_at is null and last_activity_at>statement_timestamp()-interval '15 minutes');
$$;
create function public.app_session_status() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('active',public.app_session_active(),'registered',exists(select 1 from public.app_sessions where session_id=public.current_app_session_id() and user_id=auth.uid()),'server_now',statement_timestamp(),'last_activity_at',(select last_activity_at from public.app_sessions where session_id=public.current_app_session_id() and user_id=auth.uid()));
$$;
create function public.touch_app_session() returns jsonb language plpgsql security definer set search_path='' as $$
declare s public.app_sessions;v_id uuid:=public.current_app_session_id();
begin
 if auth.uid() is null or v_id is null then raise exception 'A verified Supabase Auth session is required' using errcode='28000';end if;
 -- First use registers this Auth session. A known expired/revoked session is
 -- never revived by activity, navigation, token refresh or another tab.
 insert into public.app_sessions(session_id,user_id) values(v_id,auth.uid()) on conflict(session_id) do nothing;
 select * into s from public.app_sessions where session_id=v_id and user_id=auth.uid() for update;
 if not found then raise exception 'Session identity mismatch' using errcode='28000';end if;
 if s.revoked_at is not null or s.last_activity_at<=clock_timestamp()-interval '15 minutes' then
  update public.app_sessions set revoked_at=coalesce(revoked_at,clock_timestamp()),revocation_reason=coalesce(revocation_reason,'inactive') where session_id=v_id;
  return jsonb_build_object('active',false,'registered',true,'server_now',statement_timestamp(),'last_activity_at',s.last_activity_at);
 end if;
 update public.app_sessions set last_activity_at=clock_timestamp() where session_id=v_id;
 return public.app_session_status();
end $$;
create function public.end_app_session(p_reason text default 'inactive') returns void language plpgsql security definer set search_path='' as $$
declare v_id uuid:=public.current_app_session_id();
begin
 if auth.uid() is null or v_id is null then raise exception 'Authentication required' using errcode='28000';end if;
 if p_reason is null or p_reason not in ('inactive','signed-out') then raise exception 'Unsupported session end reason';end if;
 insert into public.app_sessions(session_id,user_id,revoked_at,revocation_reason) values(v_id,auth.uid(),clock_timestamp(),p_reason)
 on conflict(session_id) do update set revoked_at=coalesce(public.app_sessions.revoked_at,excluded.revoked_at),revocation_reason=coalesce(public.app_sessions.revocation_reason,excluded.revocation_reason)
 where public.app_sessions.user_id=auth.uid();
end $$;
revoke all on function public.current_app_session_id(),public.app_session_active(),public.app_session_status(),public.touch_app_session(),public.end_app_session(text) from public,anon,authenticated;
grant execute on function public.app_session_active(),public.app_session_status(),public.touch_app_session(),public.end_app_session(text) to authenticated;
-- Every RLS business scope also requires an active application session.
create or replace function public.current_ledger_id() returns uuid language sql stable security definer set search_path='' as $$
 select owner_id from public.user_roles where user_id=auth.uid() and is_active and public.app_session_active();
$$;
do $migration$declare d text;begin
 d:=pg_get_functiondef('public.has_capability(text)'::regprocedure);
 if strpos(d,'where r.user_id=auth.uid() and r.is_active')=0 then raise exception 'Expected permission baseline missing';end if;
 execute replace(d,'where r.user_id=auth.uid() and r.is_active','where r.user_id=auth.uid() and r.is_active and public.app_session_active()');
 d:=pg_get_functiondef('public.require_capability(text)'::regprocedure);
 if strpos(d,'begin')=0 then raise exception 'Expected authorization baseline missing';end if;
 execute replace(d,'begin',E'begin\n perform 1 from public.app_sessions where session_id=public.current_app_session_id() and user_id=auth.uid() and revoked_at is null and last_activity_at>clock_timestamp()-interval ''15 minutes'' for share;\n if not found then raise exception ''Your session expired after inactivity. Log in again.'' using errcode=''28000'';end if;');
end $migration$;
comment on table public.app_sessions is 'Session IDs and activity timestamps only. No tokens, passwords, forms or financial payloads. Activity RPCs cannot prove human interaction; the browser tracks trusted input.';
commit;
