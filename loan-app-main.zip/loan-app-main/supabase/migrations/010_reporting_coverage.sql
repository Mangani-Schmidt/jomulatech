begin;
create table public.reporting_certifications (
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references public.businesses(id),
 from_date date not null,to_date date not null,currency text not null check(currency='ZMW'),
 ledger_event_count bigint not null check(ledger_event_count>=0),
 reason text not null check(length(trim(reason)) between 5 and 500),
 created_by uuid not null references auth.users(id),created_at timestamptz not null default clock_timestamp(),
 request_id uuid not null,revoked_at timestamptz,revoked_by uuid references auth.users(id),revocation_reason text,
 unique(owner_id,request_id),check(from_date>='1900-01-01' and to_date>=from_date),
 check((revoked_at is null and revoked_by is null and revocation_reason is null) or (revoked_at is not null and revoked_by is not null and length(trim(revocation_reason)) between 5 and 500))
);
create index reporting_certifications_period on public.reporting_certifications(owner_id,currency,from_date,to_date,created_at desc);
create index audit_events_financial_count on public.audit_events(owner_id) where entity_type in ('Loan','Repayment','Expense');
alter table public.reporting_certifications enable row level security;
revoke all on public.reporting_certifications from public,anon,authenticated;
grant select on public.reporting_certifications to authenticated;
create policy certification_read on public.reporting_certifications for select to authenticated using(owner_id=(select public.current_ledger_id()));
create function public.protect_reporting_certification() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='DELETE' then raise exception 'Reporting certifications cannot be deleted';end if;
 if not public.has_capability('admin') or current_setting('app.revoke_certification',true) is distinct from old.id::text or old.revoked_at is not null then raise exception 'An approved certification revocation is required';end if;
 if (to_jsonb(new)-array['revoked_at','revoked_by','revocation_reason']) is distinct from (to_jsonb(old)-array['revoked_at','revoked_by','revocation_reason']) then raise exception 'Original certification is immutable';end if;
 if new.revoked_at is null or new.revoked_by is distinct from auth.uid() or length(trim(coalesce(new.revocation_reason,''))) not between 5 and 500 then raise exception 'Complete revocation metadata required';end if;
 return new;
end $$;
create trigger protect_reporting_certification before update or delete on public.reporting_certifications for each row execute function public.protect_reporting_certification();
create function public.audit_reporting_certification() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.audit_events(owner_id,actor_id,entity_type,entity_id,action,reason,source_table,source_id,before_data,after_data)
 values(new.owner_id,auth.uid(),'Report Coverage',new.id,case when tg_op='INSERT' then 'period_certified' else 'certification_revoked' end,case when tg_op='INSERT' then new.reason else new.revocation_reason end,'reporting_certifications',new.id,case when tg_op='UPDATE' then to_jsonb(old) else null end,to_jsonb(new));return new;
end $$;
create trigger certification_audit after insert or update on public.reporting_certifications for each row execute function public.audit_reporting_certification();
create function public.certify_reporting_period(p_from date,p_to date,p_currency text,p_reason text,p_expenses_complete boolean,p_losses_complete boolean,p_expected_event_count bigint,p_request_id uuid,p_confirm boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;v_id uuid;v_count bigint;
begin
 perform public.require_capability('admin');
 if p_confirm is distinct from true or p_expenses_complete is distinct from true or p_losses_complete is distinct from true then raise exception 'Explicit approval of complete expenses and recognized losses is required';end if;
 if p_from is null or p_to is null or p_from<'1900-01-01' or p_to<p_from or p_to>(statement_timestamp() at time zone 'Africa/Lusaka')::date or p_currency is distinct from 'ZMW' then raise exception 'Choose a completed real reporting period and supported currency';end if;
 if length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'A certification reason of 5–500 characters is required';end if;
 v_payload:=jsonb_build_object('from',p_from,'to',p_to,'currency',p_currency,'reason',trim(p_reason),'expected_event_count',p_expected_event_count);
 v_result:=public.begin_financial_operation(p_request_id,'certify_reporting_period',v_payload);if v_result is not null then return v_result;end if;
 select count(*) into v_count from public.audit_events where owner_id=public.current_ledger_id() and entity_type in ('Loan','Repayment','Expense');
 if p_expected_event_count is distinct from v_count then raise exception 'Financial history changed. Refresh and review the report before certifying coverage.';end if;
 insert into public.reporting_certifications(owner_id,from_date,to_date,currency,ledger_event_count,reason,created_by,request_id)
 values(public.current_ledger_id(),p_from,p_to,p_currency,v_count,trim(p_reason),auth.uid(),p_request_id) returning id into v_id;
 return public.finish_financial_operation(p_request_id,'certify_reporting_period',v_payload,jsonb_build_object('certification_id',v_id));
end $$;
create function public.revoke_reporting_certification(p_id uuid,p_reason text,p_request_id uuid,p_confirm boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;c public.reporting_certifications;
begin
 perform public.require_capability('admin');
 if p_confirm is distinct from true or length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'Confirm revocation with a reason';end if;
 v_payload:=jsonb_build_object('id',p_id,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'revoke_reporting_certification',v_payload);if v_result is not null then return v_result;end if;
 select * into c from public.reporting_certifications where id=p_id and owner_id=public.current_ledger_id() for update;
 if not found or c.revoked_at is not null then raise exception 'Certification not found or already revoked';end if;
 perform set_config('app.revoke_certification',p_id::text,true);
 update public.reporting_certifications set revoked_at=clock_timestamp(),revoked_by=auth.uid(),revocation_reason=trim(p_reason) where id=p_id;
 return public.finish_financial_operation(p_request_id,'revoke_reporting_certification',v_payload,jsonb_build_object('certification_id',p_id));
end $$;
revoke all on function public.protect_reporting_certification(),public.audit_reporting_certification() from public,anon,authenticated;
revoke all on function public.certify_reporting_period(date,date,text,text,boolean,boolean,bigint,uuid,boolean),public.revoke_reporting_certification(uuid,text,uuid,boolean) from public,anon;
grant execute on function public.certify_reporting_period(date,date,text,text,boolean,boolean,bigint,uuid,boolean),public.revoke_reporting_certification(uuid,text,uuid,boolean) to authenticated;

-- Only the version counter is exposed; audit contents remain Administrator-only.
create function public.reporting_revision() returns bigint language sql stable security definer set search_path='' as $$
 select case when auth.uid() is not null and public.has_capability('read') then (select count(*) from public.audit_events where owner_id=public.current_ledger_id() and entity_type in ('Loan','Repayment','Expense')) else null end;
$$;
revoke all on function public.reporting_revision() from public,anon;
grant execute on function public.reporting_revision() to authenticated;

-- Bounded, server-filtered history. Status remains an effective-date calculation
-- in the exact-integer report engine, rather than filtering today's status.
create function public.report_source_filtered(p_filters jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare v_ids uuid[];v_count integer;v_from date;v_to date;v_asof date;v_currency text;
begin
 if auth.uid() is null then raise exception 'Authentication required';end if;
 if jsonb_typeof(p_filters) is distinct from 'object' or octet_length(p_filters::text)>5000 then raise exception 'Invalid report filters';end if;
 v_from:=(p_filters->>'from')::date;v_to:=(p_filters->>'to')::date;v_asof:=(p_filters->>'asOf')::date;v_currency:=p_filters->>'currency';
 if v_from is null or v_to is null or v_asof is null or v_from<'1900-01-01' or v_from>v_to or v_to>v_asof or v_asof>(statement_timestamp() at time zone 'Africa/Lusaka')::date or v_currency is null or v_currency !~ '^[A-Z]{3}$' then raise exception 'Choose valid report dates and one currency';end if;
 select array_agg(id),count(*) into v_ids,v_count from (
  select l.id from public.loans l join public.clients c on c.id=l.client_id and c.owner_id=l.owner_id
  where l.owner_id=public.current_ledger_id() and l.currency=v_currency and l.disbursement_date<=v_asof
   and (coalesce(p_filters->>'search','')='' or strpos(lower(c.name),lower(trim(p_filters->>'search')))>0 or strpos(lower(c.man_number),lower(trim(p_filters->>'search')))>0 or strpos(lower(l.loan_reference),lower(trim(p_filters->>'search')))>0)
   and (coalesce(p_filters->>'department','')='' or c.department=p_filters->>'department')
   and (coalesce(p_filters->>'designation','')='' or c.designation=p_filters->>'designation')
   and (coalesce(p_filters->>'disbursedFrom','')='' or l.disbursement_date>=(p_filters->>'disbursedFrom')::date)
   and (coalesce(p_filters->>'disbursedTo','')='' or l.disbursement_date<=(p_filters->>'disbursedTo')::date)
  order by l.id limit 10001
 ) selected;
 if v_count>10000 then raise exception 'More than 10000 matching loans. Narrow the report Client, department or disbursement dates; no truncated report is shown.' using errcode='54000';end if;
 if (select count(*) from (select r.id from public.repayments r where r.loan_id=any(v_ids) limit 100001) r)>100000 then raise exception 'More than 100000 matching receipts. Narrow the report selection; no truncated report is shown.' using errcode='54000';end if;
 return jsonb_build_object(
  'generated_at',statement_timestamp(),'timezone','Africa/Lusaka',
  'ledger_event_count',public.reporting_revision(),
  'certifications',coalesce((select jsonb_agg(to_jsonb(c) order by c.created_at desc,c.id) from public.reporting_certifications c where c.owner_id=public.current_ledger_id() and c.from_date=v_from and c.to_date=v_to and c.currency=v_currency),'[]'::jsonb),
  'filter_options',jsonb_build_object('department',(select coalesce(jsonb_agg(d order by d),'[]'::jsonb) from (select distinct department d from public.clients where owner_id=public.current_ledger_id() and department is not null) o),'designation',(select coalesce(jsonb_agg(d order by d),'[]'::jsonb) from (select distinct designation d from public.clients where owner_id=public.current_ledger_id() and designation is not null) o)),
  'clients',coalesce((select jsonb_agg(to_jsonb(c) order by c.id) from public.clients c where c.owner_id=public.current_ledger_id() and exists(select 1 from public.loans l where l.id=any(v_ids) and l.client_id=c.id)),'[]'::jsonb),
  'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.id) from public.loans l where l.id=any(v_ids)),'[]'::jsonb),
  'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence) from public.repayments r where r.loan_id=any(v_ids)),'[]'::jsonb),
  'terms_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_terms_audit a where a.loan_id=any(v_ids)),'[]'::jsonb),
  'status_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_status_audit a where a.loan_id=any(v_ids)),'[]'::jsonb),
  'repayment_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.repayment_audit a join public.repayments r on r.id=a.repayment_id where r.loan_id=any(v_ids)),'[]'::jsonb),
  'expenses',coalesce((select jsonb_agg(to_jsonb(e) order by e.expense_date,e.id) from public.expenses e where e.owner_id=public.current_ledger_id() and e.currency=v_currency),'[]'::jsonb)
 );
end $$;
revoke all on function public.report_source_filtered(jsonb) from public,anon;
grant execute on function public.report_source_filtered(jsonb) to authenticated;
create or replace function public.report_source() returns jsonb language plpgsql stable security invoker set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 return (select jsonb_build_object(
  'generated_at',statement_timestamp(), 'timezone','Africa/Lusaka',
  'ledger_event_count',public.reporting_revision(),
  'certifications',coalesce((select jsonb_agg(to_jsonb(c) order by c.created_at desc,c.id) from public.reporting_certifications c where c.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'expenses',coalesce((select jsonb_agg(to_jsonb(e) order by e.expense_date,e.id) from public.expenses e where e.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'clients',coalesce((select jsonb_agg(to_jsonb(c) order by c.id) from public.clients c where c.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.id) from public.loans l where l.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence) from public.repayments r where r.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'terms_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_terms_audit a where a.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'status_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_status_audit a where a.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'repayment_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.repayment_audit a where a.owner_id=public.current_ledger_id()),'[]'::jsonb)));
end $$;

commit;
