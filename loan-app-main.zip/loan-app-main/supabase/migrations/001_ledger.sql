-- Single-owner ledgers. All monetary amounts are integer ngwee (ZMW cents).
create table public.clients (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null default auth.uid() references auth.users(id),
 name text not null check (length(trim(name)) between 2 and 120),
 email text check (email is null or (length(email) <= 254 and email ~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$')),
 phone text check (length(phone) <= 30),
 created_at timestamptz not null default now(),
 unique (id, owner_id)
);
create table public.loans (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references auth.users(id),
 client_id uuid not null,
 principal_cents bigint not null check (principal_cents between 1 and 99999999999),
 interest_cents bigint not null check (interest_cents between 0 and 99999999999),
 balance_cents bigint not null check (balance_cents >= 0 and balance_cents <= principal_cents + interest_cents),
 due_date date not null,
 created_at timestamptz not null default now(),
 foreign key (client_id, owner_id) references public.clients(id, owner_id),
 unique (id, owner_id)
);
create table public.repayments (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references auth.users(id),
 loan_id uuid not null,
 amount_cents bigint not null check (amount_cents between 1 and 199999999998),
 request_id uuid not null,
 created_at timestamptz not null default now(),
 foreign key (loan_id, owner_id) references public.loans(id, owner_id),
 unique (owner_id, request_id)
);
create index clients_owner on public.clients(owner_id);
create index loans_owner_due on public.loans(owner_id, due_date);
create index repayments_owner_loan on public.repayments(owner_id, loan_id);
alter table public.clients enable row level security;
alter table public.loans enable row level security;
alter table public.repayments enable row level security;
create policy clients_read on public.clients for select to authenticated using (owner_id = (select auth.uid()));
create policy clients_create on public.clients for insert to authenticated with check (owner_id = (select auth.uid()));
create policy loans_read on public.loans for select to authenticated using (owner_id = (select auth.uid()));
create policy repayments_read on public.repayments for select to authenticated using (owner_id = (select auth.uid()));
revoke all on public.clients, public.loans, public.repayments from anon, authenticated;
grant select, insert on public.clients to authenticated;
grant select on public.loans, public.repayments to authenticated;

create function public.create_loan(p_client_id uuid, p_principal_cents bigint, p_interest_cents bigint, p_due_date date)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_id uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if not exists (select 1 from public.clients where id = p_client_id and owner_id = auth.uid()) then raise exception 'Client not found'; end if;
 if p_principal_cents is null or p_principal_cents not between 1 and 99999999999 or p_interest_cents is null or p_interest_cents not between 0 and 99999999999 then raise exception 'Invalid loan amounts'; end if;
 if p_due_date is null or p_due_date < (now() at time zone 'Africa/Lusaka')::date or p_due_date > (now() at time zone 'Africa/Lusaka')::date + 36500 then raise exception 'Invalid due date'; end if;
 insert into public.loans(owner_id, client_id, principal_cents, interest_cents, balance_cents, due_date)
 values (auth.uid(), p_client_id, p_principal_cents, p_interest_cents, p_principal_cents + p_interest_cents, p_due_date) returning id into v_id;
 return v_id;
end $$;

create function public.record_repayment(p_loan_id uuid, p_amount_cents bigint, p_request_id uuid)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_loan public.loans; v_existing public.repayments; v_id uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 -- Serialize repeated requests even when they target different loans.
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text || p_request_id::text, 0));
 select * into v_existing from public.repayments where owner_id = auth.uid() and request_id = p_request_id;
 if found then
   if v_existing.loan_id <> p_loan_id or v_existing.amount_cents <> p_amount_cents then raise exception 'Request already used for another repayment'; end if;
   return v_existing.id;
 end if;
 select * into v_loan from public.loans where id = p_loan_id and owner_id = auth.uid() for update;
 if not found then raise exception 'Loan not found'; end if;
 if p_amount_cents is null or p_amount_cents <= 0 or p_amount_cents > v_loan.balance_cents then raise exception 'Amount must be positive and no greater than the outstanding balance'; end if;
 insert into public.repayments(owner_id, loan_id, amount_cents, request_id) values (auth.uid(), p_loan_id, p_amount_cents, p_request_id) returning id into v_id;
 update public.loans set balance_cents = balance_cents - p_amount_cents where id = p_loan_id;
 return v_id;
end $$;

create function public.import_clients(p_rows jsonb)
returns integer language plpgsql security definer set search_path = '' as $$
declare v_count integer;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if jsonb_typeof(p_rows) <> 'array' or p_rows is null then raise exception 'Expected Client rows'; end if;
 v_count := jsonb_array_length(p_rows);
 if v_count not between 1 and 500 then raise exception 'Import 1–500 Clients at a time'; end if;
 insert into public.clients(owner_id, name, email, phone)
 select auth.uid(), trim(r.name), nullif(trim(r.email), ''), nullif(trim(r.phone), '')
 from jsonb_to_recordset(p_rows) as r(name text, email text, phone text);
 return v_count;
end $$;
revoke all on function public.create_loan(uuid,bigint,bigint,date) from public, anon;
revoke all on function public.record_repayment(uuid,bigint,uuid) from public, anon;
revoke all on function public.import_clients(jsonb) from public, anon;
grant execute on function public.create_loan(uuid,bigint,bigint,date) to authenticated;
grant execute on function public.record_repayment(uuid,bigint,uuid) to authenticated;
grant execute on function public.import_clients(jsonb) to authenticated;
