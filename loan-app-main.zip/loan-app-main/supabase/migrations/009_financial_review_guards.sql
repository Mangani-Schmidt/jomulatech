begin;

-- Preserve legacy rows for audited correction; reject ambiguous identifiers on
-- every new/updated record, including writes made directly through the API.
alter table public.clients add constraint clients_man_no_controls
 check(man_number is null or man_number !~ '[[:cntrl:]]') not valid;

-- Keep the implementation and old loan payload snapshots intact, but close its
-- API grant. The new entry point binds confirmation to the reviewed Client.
alter function public.originate_loan(jsonb,uuid,boolean) rename to originate_loan_v8;
revoke all on function public.originate_loan_v8(jsonb,uuid,boolean) from public,anon,authenticated;
create function public.originate_loan(p_details jsonb,p_request_id uuid,p_confirm boolean)
returns uuid language plpgsql security definer set search_path='' as $$
declare c public.clients; l public.loans; v_details jsonb;
begin
 perform public.require_capability('originate');
 if p_confirm is distinct from true or p_request_id is null then raise exception 'Explicit confirmation and request ID required';end if;
 if jsonb_typeof(p_details) is distinct from 'object' then raise exception 'Invalid loan details';end if;
 v_details:=p_details-'expected_client_revision';
 perform pg_advisory_xact_lock(hashtextextended('loan_request:'||public.current_ledger_id()::text||p_request_id::text,0));
 select * into l from public.loans where owner_id=public.current_ledger_id() and origin_request_id=p_request_id;
 if found then
  if l.origination_payload is distinct from v_details then raise exception 'Request ID already used for different loan terms';end if;
  return l.id;
 end if;
 if coalesce(p_details->>'expected_client_revision','') !~ '^[0-9]{1,9}$' then raise exception 'Review the current Client details before confirming this loan';end if;
 select * into c from public.clients where id=(p_details->>'client_id')::uuid and owner_id=public.current_ledger_id() for share;
 if not found or c.revision<>(p_details->>'expected_client_revision')::integer then raise exception 'Client details changed. Reload and select the Client again before confirming.';end if;
 return public.originate_loan_v8(v_details,p_request_id,p_confirm);
end $$;
revoke all on function public.originate_loan(jsonb,uuid,boolean) from public,anon;
grant execute on function public.originate_loan(jsonb,uuid,boolean) to authenticated;

-- Check every effective event boundary, not only today's balance. This keeps
-- valid backdating, while rejecting an allocation exceeding the terms in force
-- on any date. Loan/request locks in posting RPCs serialize competing changes.
create function public.validate_effective_allocations(p_loan_id uuid) returns void
language plpgsql security definer set search_path='' as $$
declare l public.loans; v_floor date; v_bad date;
begin
 select * into l from public.loans where id=p_loan_id;
 if not found then return;end if;
 select max(d) into v_floor from (
  select (a.created_at at time zone l.business_timezone)::date d from public.loan_terms_audit a where a.loan_id=l.id and a.action='baseline'
  union all
  select (a.created_at at time zone l.business_timezone)::date from public.repayment_audit a join public.repayments r on r.id=a.repayment_id where r.loan_id=l.id and a.action='baseline'
 ) floors;
 with receipts as (
  select r.*,case when r.replaces_repayment_id is not null then (r.created_at at time zone l.business_timezone)::date else r.payment_date end effective_date,
   (r.reversed_at at time zone l.business_timezone)::date reversal_date
  from public.repayments r where r.loan_id=l.id
 ), boundaries as (
  select effective_date d from receipts union select reversal_date from receipts where reversal_date is not null
  union select (a.created_at at time zone l.business_timezone)::date from public.loan_terms_audit a where a.loan_id=l.id and a.action in ('adjust','baseline')
 ), positions as (
  select b.d,
   coalesce((select (a.after_data->>'interest_cents')::numeric from public.loan_terms_audit a where a.loan_id=l.id and a.action='adjust' and (a.created_at at time zone l.business_timezone)::date<=b.d order by a.created_at desc,(a.after_data->>'terms_revision')::integer desc limit 1),
    (select (a.after_data->>'interest_cents')::numeric from public.loan_terms_audit a where a.loan_id=l.id and a.action in ('originate','baseline') order by a.created_at limit 1),l.interest_cents) charge,
   coalesce(sum(r.interest_allocation_cents),0) interest_paid,coalesce(sum(r.principal_allocation_cents),0) principal_paid
  from boundaries b left join receipts r on r.effective_date<=b.d and (r.reversal_date is null or r.reversal_date>b.d)
  where b.d>=coalesce(v_floor,l.disbursement_date) group by b.d
 ) select d into v_bad from positions where interest_paid>charge or principal_paid>l.principal_cents order by d limit 1;
 if v_bad is not null then raise exception 'Payment would invalidate historical principal/interest allocations on %. Review the payment date and effective loan terms before posting.',v_bad;end if;
end $$;
create function public.check_effective_allocations() returns trigger
language plpgsql security definer set search_path='' as $$
begin perform public.validate_effective_allocations(new.loan_id);return new;end $$;
create trigger receipt_effective_allocations after insert or update on public.repayments
 for each row execute function public.check_effective_allocations();
create trigger terms_effective_allocations after insert on public.loan_terms_audit
 for each row execute function public.check_effective_allocations();
revoke all on function public.validate_effective_allocations(uuid),public.check_effective_allocations() from public,anon,authenticated;

-- No payload/audit disclosure. The request advisory lock waits for an in-flight
-- operation; clients can recover its result instead of inventing another key.
create function public.posting_request_status(p_request_id uuid,p_operation text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare f public.financial_operations; l public.loans;
begin
 if p_request_id is null then raise exception 'Request ID required';end if;
 if p_operation='originate_loan' then
  perform public.require_capability('originate');
  perform pg_advisory_xact_lock(hashtextextended('loan_request:'||public.current_ledger_id()::text||p_request_id::text,0));
  select * into l from public.loans where owner_id=public.current_ledger_id() and origin_request_id=p_request_id;
  if found then return jsonb_build_object('loan_id',l.id);end if;
 elsif p_operation in ('post_repayment','correct_repayment','post_expense') then
  perform public.require_capability(case p_operation when 'post_repayment' then 'repayments' when 'post_expense' then 'expenses' else 'admin' end);
  perform pg_advisory_xact_lock(hashtextextended('finance_request:'||public.current_ledger_id()::text||p_request_id::text,0));
  select * into f from public.financial_operations where owner_id=public.current_ledger_id() and request_id=p_request_id;
  if found then
   if f.operation<>p_operation then raise exception 'Request belongs to a different operation';end if;
   return f.result;
  end if;
 else raise exception 'Unsupported posting operation';end if;
 return null;
end $$;
revoke all on function public.posting_request_status(uuid,text) from public,anon;
grant execute on function public.posting_request_status(uuid,text) to authenticated;

-- A single invoker/RLS statement snapshot for all current ledger positions.
create function public.ledger_snapshot() returns jsonb language plpgsql stable security invoker set search_path='' as $$
begin
 if (select count(*) from (select id from public.clients where owner_id=public.current_ledger_id() limit 20001) c)>20000 or (select count(*) from (select id from public.loans where owner_id=public.current_ledger_id() limit 20001) l)>20000 or (select count(*) from (select id from public.repayments where owner_id=public.current_ledger_id() limit 100001) r)>100000 then raise exception 'The interactive ledger exceeds its supported capacity. Use filtered Reports and contact your Administrator to plan server pagination; no partial ledger is shown.' using errcode='54000';end if;
 return (select jsonb_build_object('generated_at',statement_timestamp(),
  'clients',coalesce((select jsonb_agg(to_jsonb(c) order by c.created_at desc,c.id) from public.clients c where c.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.created_at desc,l.id) from public.loan_register l where l.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence desc) from public.repayment_register r where r.owner_id=public.current_ledger_id()),'[]'::jsonb)));
end $$;
revoke all on function public.ledger_snapshot() from public,anon;
grant execute on function public.ledger_snapshot() to authenticated;
commit;
