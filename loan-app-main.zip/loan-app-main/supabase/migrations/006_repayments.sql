begin;
create sequence public.payment_reference_sequence;
create sequence public.receipt_posting_sequence;
revoke all on sequence public.receipt_posting_sequence from public,anon,authenticated;
revoke all on sequence public.payment_reference_sequence from public,anon,authenticated;
create function public.next_payment_reference() returns text language plpgsql security definer set search_path='' as $$
declare v text;
begin v:=nextval('public.payment_reference_sequence')::text;return 'PAY-'||lpad(v,greatest(8,length(v)),'0');end $$;
revoke all on function public.next_payment_reference() from public,anon,authenticated;
alter table public.repayments
 add column posting_sequence bigint,add column payment_reference text,add column payment_date date,add column interest_allocation_cents bigint,add column principal_allocation_cents bigint,
 add column payment_method text,add column external_reference text,add column created_by uuid references auth.users(id),add column updated_at timestamptz,
 add column allocation_policy text not null default 'interest_first',add column metadata_inferred boolean not null default false,
 add column receipt_snapshot jsonb,add column terms_revision_at_posting integer,
 add column reversed_at timestamptz,add column reversed_by uuid references auth.users(id),add column reversal_reason text,add column reversal_request_id uuid,
 add column replaces_repayment_id uuid,
 add column posting_status text generated always as(case when reversed_at is null then 'posted' else 'reversed' end) stored,
 add unique(id,owner_id),add unique(payment_reference),add unique(owner_id,reversal_request_id),add unique(replaces_repayment_id),
 add foreign key(replaces_repayment_id,owner_id) references public.repayments(id,owner_id);
with ordered as(select id,row_number() over(order by created_at,id) as seq from public.repayments) update public.repayments r set posting_sequence=o.seq from ordered o where o.id=r.id;
select setval('public.receipt_posting_sequence',coalesce(max(posting_sequence),1),count(*)>0) from public.repayments;
alter table public.repayments alter column posting_sequence set not null;
alter table public.repayments add unique(posting_sequence);
-- Historic allocation was not recorded. Reconstruct explicitly against the current
-- obligation, in original posting order, without changing receipts or balances.
with allocation as (
 select r.id,least(r.amount_cents,greatest(l.interest_cents-coalesce(sum(r.amount_cents) over(partition by r.loan_id order by r.created_at,r.id rows between unbounded preceding and 1 preceding),0),0))::bigint as interest
 from public.repayments r join public.loans l on l.id=r.loan_id
)
update public.repayments r set interest_allocation_cents=a.interest,principal_allocation_cents=r.amount_cents-a.interest,
 payment_reference=public.next_payment_reference(),payment_date=(r.created_at at time zone 'Africa/Lusaka')::date,payment_method='not_recorded',created_by=r.owner_id,updated_at=r.created_at,metadata_inferred=true
 from allocation a where r.id=a.id;
update public.repayments r set receipt_snapshot=jsonb_build_object('client',jsonb_build_object('id',c.id,'name',c.name,'man_number',c.man_number),'loan_reference',l.loan_reference,'currency',l.currency,'allocation_inferred',true,'historic_note','Historic allocations reconstructed against current obligation; payment date/creator inferred from posting; Client details captured at migration; payment method was not recorded.') from public.loans l join public.clients c on c.id=l.client_id where r.loan_id=l.id;
alter table public.repayments alter column payment_reference set not null;
alter table public.repayments alter column payment_date set not null;
alter table public.repayments alter column interest_allocation_cents set not null;
alter table public.repayments alter column principal_allocation_cents set not null;
alter table public.repayments alter column payment_method set not null;
alter table public.repayments alter column created_by set not null;
alter table public.repayments alter column updated_at set not null;
alter table public.repayments alter column receipt_snapshot set not null;
alter table public.repayments add constraint repayment_allocations check(interest_allocation_cents>=0 and principal_allocation_cents>=0 and interest_allocation_cents+principal_allocation_cents=amount_cents and allocation_policy='interest_first');
alter table public.repayments add constraint payment_method_supported check(payment_method in ('cash','bank_transfer','mobile_money','card','other','not_recorded'));
alter table public.repayments add constraint payment_external_reference_length check(length(external_reference)<=120);
alter table public.repayments add constraint repayment_reversal_complete check(
 (reversed_at is null and reversed_by is null and reversal_reason is null and reversal_request_id is null) or
 (reversed_at is not null and reversed_by is not null and reversal_reason is not null and length(trim(reversal_reason)) between 5 and 500 and reversal_request_id is not null));
create unique index repayment_external_reference_unique on public.repayments(owner_id,payment_method,lower(external_reference)) where external_reference is not null and reversed_at is null;
create index repayment_active_allocations on public.repayments(owner_id,loan_id) where reversed_at is null;
create table public.financial_operations (
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users(id),request_id uuid not null,
 operation text not null,payload jsonb not null,result jsonb not null,created_by uuid not null references auth.users(id),created_at timestamptz not null default clock_timestamp(),unique(owner_id,request_id)
);
create table public.repayment_audit (
 id uuid primary key default gen_random_uuid(),owner_id uuid not null,repayment_id uuid not null,actor_id uuid references auth.users(id),action text not null check(action in ('baseline','post','reverse')),
 reason text not null,before_data jsonb,after_data jsonb not null,request_id uuid,created_at timestamptz not null default clock_timestamp(),foreign key(repayment_id,owner_id) references public.repayments(id,owner_id)
);
create index repayment_audit_lookup on public.repayment_audit(owner_id,repayment_id,created_at);
alter table public.financial_operations enable row level security;
alter table public.repayment_audit enable row level security;
create policy financial_operations_read on public.financial_operations for select to authenticated using(owner_id=(select auth.uid()));
create policy repayment_audit_read on public.repayment_audit for select to authenticated using(owner_id=(select auth.uid()));
revoke all on public.financial_operations,public.repayment_audit from public,anon,authenticated;
grant select on public.financial_operations,public.repayment_audit to authenticated;
insert into public.repayment_audit(owner_id,repayment_id,action,reason,after_data) select owner_id,id,'baseline','Repayment migration: original amounts preserved; allocation/date/method provenance explicitly marked inferred.',to_jsonb(r) from public.repayments r;
-- Preserve old write-off request identities even after their decisions are reversed.
insert into public.financial_operations(owner_id,request_id,operation,payload,result,created_by)
 select owner_id,request_id,'write_off',jsonb_build_object('loan_id',loan_id,'balance',(after_data->>'written_off_cents')::bigint,'revision',(after_data->>'terms_revision')::integer,'reason',reason),jsonb_build_object('loan_id',loan_id),actor_id
 from public.loan_status_audit where action='write_off' and request_id is not null;

create function public.begin_financial_operation(p_request_id uuid,p_operation text,p_payload jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare v public.financial_operations;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_request_id is null then raise exception 'Financial request ID required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('finance_request:'||auth.uid()::text||p_request_id::text,0));
 select * into v from public.financial_operations where owner_id=auth.uid() and request_id=p_request_id;
 if found then
   if v.operation<>p_operation or v.payload is distinct from p_payload then raise exception 'Request ID already used for a different financial operation';end if;
   return v.result;
 end if;
 return null;
end $$;
create function public.finish_financial_operation(p_request_id uuid,p_operation text,p_payload jsonb,p_result jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
begin insert into public.financial_operations(owner_id,request_id,operation,payload,result,created_by) values(auth.uid(),p_request_id,p_operation,p_payload,p_result,auth.uid());return p_result;end $$;

create function public.protect_repayment() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='DELETE' then raise exception 'Posted financial transactions cannot be deleted'; end if;
 if not public.is_ledger_admin() or auth.uid()<>old.owner_id or current_setting('app.receipt_reversal',true) is distinct from old.id::text then raise exception 'An authorized audited reversal is required';end if;
 if old.reversed_at is not null then raise exception 'Reversed receipts are immutable';end if;
 if (to_jsonb(new)-array['reversed_at','reversed_by','reversal_reason','reversal_request_id','updated_at','posting_status']) is distinct from (to_jsonb(old)-array['reversed_at','reversed_by','reversal_reason','reversal_request_id','updated_at','posting_status']) then raise exception 'Posted receipt details and allocations are immutable';end if;
 if new.reversed_at is null or new.reversed_by is distinct from auth.uid() or length(trim(coalesce(new.reversal_reason,''))) not between 5 and 500 or new.reversal_request_id is null then raise exception 'Complete reversal metadata required';end if;
 new.updated_at:=clock_timestamp();return new;
end $$;
create trigger protect_repayment before update or delete on public.repayments for each row execute function public.protect_repayment();
create function public.audit_repayment() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.repayment_audit(owner_id,repayment_id,actor_id,action,reason,before_data,after_data,request_id)
 values(new.owner_id,new.id,auth.uid(),case when tg_op='INSERT' then 'post' else 'reverse' end,case when tg_op='INSERT' then coalesce(nullif(current_setting('app.receipt_correction_reason',true),''),'Repayment Received posted using interest-first allocation') else new.reversal_reason end,case when tg_op='UPDATE' then to_jsonb(old) else null end,to_jsonb(new),case when tg_op='INSERT' then new.request_id else new.reversal_request_id end);
 return new;
end $$;
create trigger audit_repayment after insert or update on public.repayments for each row execute function public.audit_repayment();

create function public.post_receipt_internal(p_details jsonb,p_request_id uuid,p_replaces_id uuid default null) returns uuid language plpgsql security definer set search_path='' as $$
declare l public.loans;c public.clients;v_amount bigint;v_interest_paid bigint;v_principal_paid bigint;v_interest bigint;v_date date;v_method text;v_external text;v_id uuid:=gen_random_uuid();v_reference text;v_stamp timestamptz;
begin
 if auth.uid() is null then raise exception 'Authentication required';end if;
 if p_details is null or jsonb_typeof(p_details)<>'object' or octet_length(p_details::text)>5000 then raise exception 'Invalid payment details';end if;
 if exists(select 1 from jsonb_object_keys(p_details) k where k not in ('loan_id','amount_cents','payment_date','payment_method','external_reference','expected_balance_cents','expected_terms_revision','expected_interest_outstanding_cents','expected_principal_outstanding_cents')) then raise exception 'Unexpected payment field';end if;
 if coalesce(p_details->>'amount_cents','') !~ '^[0-9]{1,12}$' then raise exception 'Repayment Received must be a positive amount with up to two decimal places';end if;
 v_amount:=(p_details->>'amount_cents')::bigint;if v_amount<=0 or v_amount>199999999998 then raise exception 'Repayment Received must be positive and within supported limits';end if;
 select * into l from public.loans where id=(p_details->>'loan_id')::uuid and owner_id=auth.uid() for update;
 if not found then raise exception 'Loan not found';end if;
 if l.lifecycle_status='written_off' then raise exception 'Reverse the write-off before posting a payment';end if;
 if coalesce(p_details->>'payment_date','') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then raise exception 'Payment date required';end if;
 v_date:=(p_details->>'payment_date')::date;
 if v_date<l.disbursement_date or v_date>(statement_timestamp() at time zone l.business_timezone)::date then raise exception 'Payment date must be between disbursement and the current business date';end if;
 v_method:=p_details->>'payment_method';if v_method is null or v_method not in ('cash','bank_transfer','mobile_money','card','other') then raise exception 'Choose a supported payment method';end if;
 v_external:=nullif(trim(p_details->>'external_reference'),'');if length(v_external)>120 then raise exception 'External reference must be at most 120 characters';end if;
 if v_external is not null and exists(select 1 from public.repayments where owner_id=auth.uid() and payment_method=v_method and lower(external_reference)=lower(v_external) and reversed_at is null) then raise exception 'External reference already belongs to a posted payment with this method';end if;
 if v_amount>l.balance_cents then raise exception 'Overpayment: Repayment Received % ZMW exceeds the outstanding balance of % ZMW. Reduce the amount or review the loan.',to_char(v_amount::numeric/100,'FM9999999990.00'),to_char(l.balance_cents::numeric/100,'FM9999999990.00');end if;
 if coalesce(p_details->>'expected_balance_cents','') !~ '^[0-9]{1,12}$' or coalesce(p_details->>'expected_terms_revision','') !~ '^[0-9]{1,9}$' or (p_details->>'expected_balance_cents')::bigint<>l.balance_cents or (p_details->>'expected_terms_revision')::integer<>l.terms_revision then raise exception 'Loan balance or terms changed. Reload and review the allocation before posting.';end if;
 select coalesce(sum(interest_allocation_cents),0),coalesce(sum(principal_allocation_cents),0) into v_interest_paid,v_principal_paid from public.repayments where loan_id=l.id and owner_id=auth.uid() and reversed_at is null;
 if v_interest_paid>l.interest_cents or v_principal_paid>l.principal_cents or l.balance_cents<>l.principal_cents+l.interest_cents-v_interest_paid-v_principal_paid then raise exception 'Loan allocation totals require review before posting';end if;
 if coalesce(p_details->>'expected_interest_outstanding_cents','') !~ '^[0-9]{1,12}$' or coalesce(p_details->>'expected_principal_outstanding_cents','') !~ '^[0-9]{1,12}$' or (p_details->>'expected_interest_outstanding_cents')::bigint<>l.interest_cents-v_interest_paid or (p_details->>'expected_principal_outstanding_cents')::bigint<>l.principal_cents-v_principal_paid then raise exception 'Loan allocations changed. Reload and review before posting.';end if;
 v_interest:=least(v_amount,l.interest_cents-v_interest_paid);
 select * into c from public.clients where id=l.client_id and owner_id=auth.uid();v_reference:=public.next_payment_reference();v_stamp:=clock_timestamp();
 insert into public.repayments(id,posting_sequence,owner_id,loan_id,amount_cents,request_id,payment_reference,payment_date,interest_allocation_cents,principal_allocation_cents,payment_method,external_reference,created_by,created_at,updated_at,terms_revision_at_posting,replaces_repayment_id,receipt_snapshot)
 values(v_id,nextval('public.receipt_posting_sequence'),auth.uid(),l.id,v_amount,p_request_id,v_reference,v_date,v_interest,v_amount-v_interest,v_method,v_external,auth.uid(),v_stamp,v_stamp,l.terms_revision,p_replaces_id,
 jsonb_build_object('client',jsonb_build_object('id',c.id,'name',c.name,'man_number',c.man_number),'loan_reference',l.loan_reference,'currency',l.currency,'balance_after_cents',l.balance_cents-v_amount,'principal_cents',l.principal_cents,'interest_charge_cents',l.interest_cents,'total_obligation_cents',l.total_obligation_cents,'terms_revision',l.terms_revision));
 perform set_config('app.receipt_request_id',p_request_id::text,true);perform set_config('app.receipt_action','post',true);
 update public.loans set balance_cents=balance_cents-v_amount where id=l.id;
 return v_id;
end $$;
create function public.reverse_receipt_internal(p_id uuid,p_reason text,p_request_id uuid) returns void language plpgsql security definer set search_path='' as $$
declare r public.repayments;l public.loans;
begin
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'A reversal reason of 5–500 characters is required';end if;
 select * into r from public.repayments where id=p_id and owner_id=auth.uid();if not found then raise exception 'Payment not found';end if;
 -- All operations acquire the loan lock before the receipt row lock.
 select * into l from public.loans where id=r.loan_id and owner_id=auth.uid() for update;
 select * into r from public.repayments where id=p_id and owner_id=auth.uid() for update;
 if l.lifecycle_status='written_off' then raise exception 'Reverse the write-off before reversing this receipt';end if;
 if r.reversed_at is not null then raise exception 'Payment is already reversed; no further financial effect is allowed';end if;
 perform set_config('app.receipt_reversal',r.id::text,true);perform set_config('app.receipt_reason',trim(p_reason),true);perform set_config('app.receipt_action','reverse',true);perform set_config('app.receipt_request_id',p_request_id::text,true);
 update public.repayments set reversed_at=clock_timestamp(),reversed_by=auth.uid(),reversal_reason=trim(p_reason),reversal_request_id=p_request_id where id=r.id;
 update public.loans set balance_cents=balance_cents+r.amount_cents where id=l.id;
end $$;
create function public.post_repayment(p_details jsonb,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_result jsonb;v_id uuid;
begin
 if p_confirm is distinct from true then raise exception 'Explicit payment confirmation required';end if;
 v_result:=public.begin_financial_operation(p_request_id,'post_repayment',p_details);if v_result is not null then return v_result;end if;
 v_id:=public.post_receipt_internal(p_details,p_request_id);
 return public.finish_financial_operation(p_request_id,'post_repayment',p_details,jsonb_build_object('repayment_id',v_id));
exception when unique_violation then raise exception 'Duplicate payment request or external reference. Review existing posted payments before retrying.';
end $$;
create function public.reverse_repayment(p_repayment_id uuid,p_reason text,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;
begin
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if p_confirm is distinct from true then raise exception 'Explicit reversal confirmation required';end if;
 v_payload:=jsonb_build_object('repayment_id',p_repayment_id,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'reverse_repayment',v_payload);if v_result is not null then return v_result;end if;
 perform public.reverse_receipt_internal(p_repayment_id,p_reason,p_request_id);
 return public.finish_financial_operation(p_request_id,'reverse_repayment',v_payload,jsonb_build_object('repayment_id',p_repayment_id));
end $$;
create function public.correct_repayment(p_repayment_id uuid,p_details jsonb,p_reason text,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;r public.repayments;l public.loans;v_id uuid;v_details jsonb;
begin
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if p_confirm is distinct from true then raise exception 'Explicit adjustment confirmation required';end if;
 v_payload:=jsonb_build_object('repayment_id',p_repayment_id,'details',p_details,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'correct_repayment',v_payload);if v_result is not null then return v_result;end if;
 select * into r from public.repayments where id=p_repayment_id and owner_id=auth.uid();if not found then raise exception 'Payment not found';end if;
 select * into l from public.loans where id=r.loan_id and owner_id=auth.uid() for update;
 if (p_details->>'loan_id')::uuid is distinct from l.id or (p_details->>'expected_balance_cents')::bigint is distinct from l.balance_cents or (p_details->>'expected_terms_revision')::integer is distinct from l.terms_revision then raise exception 'Loan changed or replacement targets another loan. Reload before adjusting.';end if;
 perform public.reverse_receipt_internal(p_repayment_id,p_reason,p_request_id);
 perform set_config('app.receipt_correction_reason','Authorized replacement: '||trim(p_reason),true);
 v_details:=p_details||jsonb_build_object('expected_balance_cents',l.balance_cents+r.amount_cents,'expected_interest_outstanding_cents',(p_details->>'expected_interest_outstanding_cents')::bigint+r.interest_allocation_cents,'expected_principal_outstanding_cents',(p_details->>'expected_principal_outstanding_cents')::bigint+r.principal_allocation_cents);
 v_id:=public.post_receipt_internal(v_details,p_request_id,r.id);
 return public.finish_financial_operation(p_request_id,'correct_repayment',v_payload,jsonb_build_object('reversed_repayment_id',r.id,'repayment_id',v_id));
exception when unique_violation then raise exception 'Duplicate replacement or external reference. No adjustment was saved.';
end $$;
-- The old interface now permits only safe retries of already-posted receipts.
create or replace function public.record_repayment(p_loan_id uuid,p_amount_cents bigint,p_request_id uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare r public.repayments;
begin
 if auth.uid() is null then raise exception 'Authentication required';end if;
 select * into r from public.repayments where owner_id=auth.uid() and request_id=p_request_id;
 if found and r.loan_id=p_loan_id and r.amount_cents=p_amount_cents then return r.id;end if;
 raise exception 'Use post_repayment with payment date, method, allocation review, and confirmation';
end $$;

alter table public.loan_status_audit drop constraint loan_status_audit_action_check;
alter table public.loan_status_audit add check(action in ('baseline','originate','settle','reopen','write_off','reverse_write_off'));
create or replace function public.maintain_loan_lifecycle() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or new.owner_id<>auth.uid() then raise exception 'Loan authorization required'; end if;
 if tg_op='INSERT' then
   if new.loan_reference is not null or new.lifecycle_status='written_off' or new.written_off_at is not null or new.written_off_request_id is not null or new.written_off_cents is not null or new.written_off_reason is not null or new.written_off_by is not null then raise exception 'Loan reference and initial status are system assigned'; end if;
   if new.principal_cents<=0 or new.disbursement_date>(now() at time zone new.business_timezone)::date or new.due_date<=new.disbursement_date then raise exception 'Invalid Amount Disbursed or inconsistent dates'; end if;
   if new.balance_cents<>new.principal_cents+new.interest_cents then raise exception 'A new loan must start at its total repayment obligation'; end if;
   new.loan_reference:=public.next_loan_reference();new.created_by:=auth.uid();new.creator_inferred:=false;
   new.created_at:=clock_timestamp();new.updated_at:=new.created_at;
 else
   if new.loan_reference<>old.loan_reference or new.created_by<>old.created_by or new.created_at<>old.created_at or new.creator_inferred<>old.creator_inferred then raise exception 'Loan reference and creator metadata are immutable'; end if;
   if old.lifecycle_status='written_off' then
     if not public.is_ledger_admin() or current_setting('app.reverse_write_off',true) is distinct from old.id::text or length(trim(coalesce(current_setting('app.writeoff_reversal_reason',true),''))) not between 5 and 500 then raise exception 'Reverse the write-off before receipts or adjustments';end if;
     if new.balance_cents<>old.balance_cents or new.terms_revision<>old.terms_revision or new.lifecycle_status='written_off' then raise exception 'Write-off reversal must preserve the obligation and unpaid balance';end if;
   end if;
   if new.lifecycle_status='written_off' then
     if not public.is_ledger_admin() or current_setting('app.loan_write_off',true) is distinct from new.written_off_request_id::text then raise exception 'An administrator must explicitly authorize a write-off'; end if;
     if new.balance_cents<>old.balance_cents or new.balance_cents<=0 or new.written_off_cents<>old.balance_cents or new.written_off_by<>auth.uid() then raise exception 'Write-off must preserve the unpaid balance'; end if;
     new.updated_at:=clock_timestamp();new.updated_by:=auth.uid();return new;
   end if;
   if new.written_off_cents is not null or new.written_off_at is not null or new.written_off_by is not null or new.written_off_reason is not null or new.written_off_request_id is not null then raise exception 'Invalid write-off metadata'; end if;
   new.updated_at:=clock_timestamp();
 end if;
 new.lifecycle_status:=case when new.balance_cents=0 then 'settled' else 'active' end;
 new.updated_by:=auth.uid();
 return new;
end $$;

create or replace function public.audit_loan_lifecycle() returns trigger language plpgsql security definer set search_path='' as $$
declare v_action text;v_reason text;v_before text;
begin
 if tg_op='UPDATE' and new.lifecycle_status=old.lifecycle_status then return new; end if;
 if tg_op='INSERT' then v_action:='originate';v_reason:='Amount Disbursed recorded';
 else
   v_before:=public.loan_effective_status(old.balance_cents,old.due_date,old.lifecycle_status,old.business_timezone);
   if old.lifecycle_status='written_off' and new.lifecycle_status<>'written_off' then v_action:='reverse_write_off';v_reason:='Write-off reversed: '||current_setting('app.writeoff_reversal_reason',true);
   elsif new.lifecycle_status='written_off' then v_action:='write_off';v_reason:=new.written_off_reason;
   elsif new.lifecycle_status='settled' then v_action:='settle';v_reason:=case when new.terms_revision<>old.terms_revision then 'Authorized terms adjustment: '||current_setting('app.loan_adjustment_reason',true) else 'Repayment Received covered the total obligation' end;
   else v_action:='reopen';v_reason:=case when current_setting('app.receipt_action',true)='reverse' then 'Repayment reversal: '||current_setting('app.receipt_reason',true) else 'Authorized terms adjustment: '||current_setting('app.loan_adjustment_reason',true) end;end if;
 end if;
 insert into public.loan_status_audit(loan_id,owner_id,actor_id,action,before_status,after_status,reason,before_data,after_data,request_id)
 values(new.id,new.owner_id,auth.uid(),v_action,v_before,public.loan_effective_status(new.balance_cents,new.due_date,new.lifecycle_status,new.business_timezone),v_reason,case when tg_op='UPDATE' then to_jsonb(old) else null end,to_jsonb(new),case when new.lifecycle_status='written_off' then new.written_off_request_id when v_action='reverse_write_off' then nullif(current_setting('app.writeoff_reversal_request',true),'')::uuid else nullif(current_setting('app.receipt_request_id',true),'')::uuid end);
 return new;
end $$;

create or replace function public.adjust_loan_terms(p_loan_id uuid,p_rate_bps integer,p_term_days integer,p_expected_revision integer,p_reason text,p_request_id uuid,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_loan public.loans; v_existing public.loan_terms_audit; v_paid bigint; v_interest bigint;
begin
 if not public.is_ledger_admin() then raise exception 'Administrator permission required'; end if;
 if p_confirm is distinct from true or p_request_id is null then raise exception 'Explicit adjustment confirmation and request ID required'; end if;
 if p_reason is null or length(trim(p_reason)) not between 5 and 500 then raise exception 'An adjustment reason of 5–500 characters is required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('loan_request:'||auth.uid()::text||p_request_id::text,0));
 select * into v_existing from public.loan_terms_audit where owner_id=auth.uid() and request_id=p_request_id;
 if found then
   if v_existing.action<>'adjust' or v_existing.loan_id<>p_loan_id or (v_existing.after_data->>'interest_rate_bps')::integer is distinct from p_rate_bps or (v_existing.after_data->>'term_days')::integer is distinct from p_term_days or v_existing.reason<>trim(p_reason) then raise exception 'Request ID already used for different adjustment'; end if;
   return p_loan_id;
 end if;
 select * into v_loan from public.loans where id=p_loan_id and owner_id=auth.uid() for update;
 if not found then raise exception 'Loan not found'; end if;
 if p_expected_revision is distinct from v_loan.terms_revision then raise exception 'Loan terms changed. Reload the loan before adjusting.'; end if;
 if p_term_days is null or p_term_days not between 1 and 3650 then raise exception 'Term must be 1–3650 days'; end if;
 v_interest:=public.flat_interest_cents(v_loan.principal_cents,p_rate_bps,'one_time_flat','entire_term');
 select coalesce(sum(amount_cents),0) into v_paid from public.repayments where loan_id=v_loan.id and owner_id=auth.uid() and reversed_at is null;
 if v_interest<(select coalesce(sum(interest_allocation_cents),0) from public.repayments where loan_id=v_loan.id and owner_id=auth.uid() and reversed_at is null) then raise exception 'Interest cannot be reduced below posted interest allocations. Reverse or correct affected receipts first.';end if;
 if v_loan.principal_cents+v_interest<v_paid then raise exception 'Adjusted obligation cannot be less than payments already received'; end if;
 perform set_config('app.loan_adjustment_reason',trim(p_reason),true);perform set_config('app.loan_request_id',p_request_id::text,true);
 update public.loans set interest_rate_bps=p_rate_bps,calculation_method='one_time_flat',rate_basis='entire_term',interest_cents=v_interest,term_days=p_term_days,due_date=disbursement_date+p_term_days,balance_cents=principal_cents+v_interest-v_paid,terms_revision=terms_revision+1 where id=v_loan.id;
 return v_loan.id;
end $$;
alter function public.write_off_loan(uuid,bigint,integer,text,uuid,boolean) rename to write_off_loan_v5;
revoke all on function public.write_off_loan_v5(uuid,bigint,integer,text,uuid,boolean) from public,anon,authenticated;
create function public.write_off_loan(p_loan_id uuid,p_expected_balance_cents bigint,p_expected_terms_revision integer,p_reason text,p_request_id uuid,p_confirm boolean) returns uuid language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;v_id uuid;
begin
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if p_confirm is distinct from true then raise exception 'Explicit write-off confirmation required';end if;
 v_payload:=jsonb_build_object('loan_id',p_loan_id,'balance',p_expected_balance_cents,'revision',p_expected_terms_revision,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'write_off',v_payload);if v_result is not null then return (v_result->>'loan_id')::uuid;end if;
 v_id:=public.write_off_loan_v5(p_loan_id,p_expected_balance_cents,p_expected_terms_revision,p_reason,p_request_id,p_confirm);
 perform public.finish_financial_operation(p_request_id,'write_off',v_payload,jsonb_build_object('loan_id',v_id));return v_id;
end $$;
create function public.reverse_write_off(p_loan_id uuid,p_original_write_off_request_id uuid,p_reason text,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare v_payload jsonb;v_result jsonb;l public.loans;
begin
 if not public.is_ledger_admin() then raise exception 'Administrator permission required';end if;
 if p_confirm is distinct from true or length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'Explicit confirmation and a write-off reversal reason of 5–500 characters are required';end if;
 v_payload:=jsonb_build_object('loan_id',p_loan_id,'original_write_off_request_id',p_original_write_off_request_id,'reason',trim(p_reason));v_result:=public.begin_financial_operation(p_request_id,'reverse_write_off',v_payload);if v_result is not null then return v_result;end if;
 select * into l from public.loans where id=p_loan_id and owner_id=auth.uid() for update;if not found then raise exception 'Loan not found';end if;
 if l.lifecycle_status<>'written_off' or p_original_write_off_request_id is null or p_original_write_off_request_id is distinct from l.written_off_request_id then raise exception 'Write-off changed or was already reversed. Reload the loan.';end if;
 perform set_config('app.reverse_write_off',l.id::text,true);perform set_config('app.writeoff_reversal_reason',trim(p_reason),true);perform set_config('app.writeoff_reversal_request',p_request_id::text,true);
 update public.loans set lifecycle_status='active',written_off_cents=null,written_off_at=null,written_off_by=null,written_off_reason=null,written_off_request_id=null where id=l.id;
 return public.finish_financial_operation(p_request_id,'reverse_write_off',v_payload,jsonb_build_object('loan_id',l.id));
end $$;

create or replace view public.loan_register with(security_invoker=true) as
 select l.*,l.principal_cents as amount_disbursed_cents,public.loan_effective_status(l.balance_cents,l.due_date,l.lifecycle_status,l.business_timezone) as status,
 coalesce(a.interest,0)::bigint as interest_repaid_cents,coalesce(a.principal,0)::bigint as principal_repaid_cents,
 (l.interest_cents-coalesce(a.interest,0))::bigint as interest_outstanding_cents,(l.principal_cents-coalesce(a.principal,0))::bigint as principal_outstanding_cents
 from public.loans l left join lateral(select sum(interest_allocation_cents) as interest,sum(principal_allocation_cents) as principal from public.repayments r where r.loan_id=l.id and r.owner_id=l.owner_id and r.reversed_at is null) a on true;
create view public.repayment_register with(security_invoker=true) as select r.*,l.loan_reference,l.client_id,(select payment_reference from public.repayments p where p.replaces_repayment_id=r.id) as replaced_by_reference from public.repayments r join public.loans l on l.id=r.loan_id and l.owner_id=r.owner_id;
revoke all on public.repayment_register from public,anon,authenticated;
grant select on public.repayment_register to authenticated;
create function public.receipt_document(p_repayment_id uuid) returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('generated_at',statement_timestamp(),'receipt',to_jsonb(r),'audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.repayment_audit a where a.repayment_id=r.id),'[]'::jsonb)) from public.repayment_register r where r.id=p_repayment_id and r.owner_id=auth.uid();
$$;
create function public.client_statement(p_client_id uuid) returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('client',to_jsonb(c),'generated_at',statement_timestamp(),'timezone','Africa/Lusaka','allocation_policy','Interest first, then principal, in posting order; reversals restore original allocations without rewriting later receipts.',
 'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.created_at,l.id) from public.loan_register l where l.client_id=c.id),'[]'::jsonb),
 'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence) from public.repayment_register r where r.client_id=c.id),'[]'::jsonb),
 'repayment_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.repayment_audit a join public.loans l on l.id=(a.after_data->>'loan_id')::uuid where l.client_id=c.id),'[]'::jsonb),
 'terms_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.loan_terms_audit a join public.loans l on l.id=a.loan_id where l.client_id=c.id),'[]'::jsonb),
 'status_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.loan_status_audit a join public.loans l on l.id=a.loan_id where l.client_id=c.id),'[]'::jsonb)) from public.clients c where c.id=p_client_id and c.owner_id=auth.uid();
$$;
-- Refuse to silently repair an inconsistent imported legacy balance.
do $$begin
 if exists(select 1 from public.loans l where l.balance_cents<>l.principal_cents+l.interest_cents-(select coalesce(sum(amount_cents),0) from public.repayments r where r.loan_id=l.id and r.reversed_at is null)) then raise exception 'Existing balances do not match receipt totals. Reconcile before applying migration.';end if;
end $$;
revoke all on function public.begin_financial_operation(uuid,text,jsonb),public.finish_financial_operation(uuid,text,jsonb,jsonb),public.protect_repayment(),public.audit_repayment(),public.post_receipt_internal(jsonb,uuid,uuid),public.reverse_receipt_internal(uuid,text,uuid) from public,anon,authenticated;
revoke all on function public.post_repayment(jsonb,uuid,boolean),public.reverse_repayment(uuid,text,uuid,boolean),public.correct_repayment(uuid,jsonb,text,uuid,boolean),public.reverse_write_off(uuid,uuid,text,uuid,boolean),public.write_off_loan(uuid,bigint,integer,text,uuid,boolean),public.receipt_document(uuid),public.client_statement(uuid) from public,anon;
grant execute on function public.post_repayment(jsonb,uuid,boolean),public.reverse_repayment(uuid,text,uuid,boolean),public.correct_repayment(uuid,jsonb,text,uuid,boolean),public.reverse_write_off(uuid,uuid,text,uuid,boolean),public.write_off_loan(uuid,bigint,integer,text,uuid,boolean),public.receipt_document(uuid),public.client_statement(uuid) to authenticated;
commit;
