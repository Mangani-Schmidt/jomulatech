begin;
-- Preserve existing grants. New destructive access requires explicit approval.
alter function public.role_permissions(text) rename to role_permissions_v14;
create function public.role_permissions(p_role text) returns jsonb language sql immutable set search_path='' as $$select public.role_permissions_v14(p_role)||jsonb_build_object('delete_clients',false);$$;
revoke all on function public.role_permissions(text) from public,anon;
grant execute on function public.role_permissions(text) to authenticated;
select set_config('app.role_reason','Migration 015: retain grants; deletion requires explicit approval',true);
update public.user_roles set permissions=permissions||'{"delete_clients":false}';
do $$begin execute replace(pg_get_functiondef('public.has_capability(text)'::regprocedure),'FUNCTION public.has_capability(','FUNCTION public.has_capability_v14(');end $$;
revoke all on function public.has_capability_v14(text) from public,anon,authenticated;
create or replace function public.has_capability(p_action text) returns boolean language sql stable security definer set search_path='' as $$
 select case when p_action in ('imports','delete_clients') then coalesce((select
 public.app_session_active() and (r.permissions->>p_action)::boolean and (r.permissions->>'view_clients')::boolean
 and (p_action<>'imports' or (r.permissions->>'view_imports')::boolean)
 and (r.role<>'administrator' or not b.admin_mfa_required or public.recent_admin_assurance())
 from public.user_roles r join public.businesses b on b.id=r.owner_id where r.user_id=auth.uid() and r.is_active),false)
 else public.has_capability_v14(p_action) end;
$$;
revoke all on function public.has_capability(text) from public,anon;
grant execute on function public.has_capability(text) to authenticated;
do $$declare d text;begin
 d:=pg_get_functiondef('public.manage_user_access(uuid,text,boolean,jsonb,integer,text,uuid,boolean)'::regprocedure);
 d:=replace(d,'v_key not like ''view_%'' and','v_key not like ''view_%'' and v_key not in (''imports'',''delete_clients'') and');execute d;
 d:=pg_get_functiondef('public.loan_defaults()'::regprocedure);
 d:=replace(d,'''can_delete_clients'',false','''can_delete_clients'',public.has_capability(''delete_clients'')');execute d;
 d:=pg_get_functiondef('public.audit_client_change()'::regprocedure);
 d:=replace(d,'perform public.require_capability(''clients'');','if current_setting(''app.import_clients'',true)=''approved'' then perform public.require_capability(''imports''); else perform public.require_capability(''clients'');end if;');execute d;
end $$;
-- Loan imports continue to require origination; Client imports confer no manual
-- registration/loan permission. The internal flag is never caller supplied.
alter function public.preview_import(text,text,text,jsonb,jsonb) rename to preview_import_v14;
alter function public.commit_import(uuid,integer,boolean) rename to commit_import_v14;
revoke all on function public.preview_import_v14(text,text,text,jsonb,jsonb),public.commit_import_v14(uuid,integer,boolean) from public,anon,authenticated;
create function public.preview_import(p_filename text,p_file_sha256 text,p_mode text,p_terms jsonb,p_rows jsonb) returns uuid language plpgsql security definer set search_path='' as $$
begin
 perform public.require_capability('imports');
 if p_mode='loans' then perform public.require_capability('originate');end if;
 return public.preview_import_v14(p_filename,p_file_sha256,p_mode,p_terms,p_rows);
end $$;
create function public.commit_import(p_batch_id uuid,p_preview_version integer,p_confirm boolean) returns uuid language plpgsql security definer set search_path='' as $$
declare v_result uuid;v_previous text:=current_setting('app.import_clients',true);
begin
 perform public.require_capability('imports');
 if exists(select 1 from public.import_batches where id=p_batch_id and owner_id=public.current_ledger_id() and mode='loans') then perform public.require_capability('originate');end if;
 perform set_config('app.import_clients','approved',true);
 v_result:=public.commit_import_v14(p_batch_id,p_preview_version,p_confirm);
 perform set_config('app.import_clients',coalesce(v_previous,''),true);
 return v_result;
end $$;
revoke all on function public.preview_import(text,text,text,jsonb,jsonb),public.commit_import(uuid,integer,boolean) from public,anon;
grant execute on function public.preview_import(text,text,text,jsonb,jsonb),public.commit_import(uuid,integer,boolean) to authenticated;
-- Retain stable identities and every immutable audit row after register deletion.
create table public.client_identities(id uuid primary key,owner_id uuid not null references public.businesses(id),retention_reason text,unique(id,owner_id));
alter table public.client_identities enable row level security;
revoke all on public.client_identities from public,anon,authenticated;
insert into public.client_identities(id,owner_id) select id,owner_id from public.clients;
alter table public.client_audit drop constraint client_audit_client_id_owner_id_fkey;
alter table public.client_audit add foreign key(client_id,owner_id) references public.client_identities(id,owner_id);
alter table public.client_audit drop constraint client_audit_action_check;
alter table public.client_audit add check(action in ('baseline','create','correct','delete'));
create function public.register_client_identity() returns trigger language plpgsql security definer set search_path='' as $$begin
 insert into public.client_identities(id,owner_id) values(new.id,new.owner_id);return new;end $$;
create trigger z_client_identity before insert on public.clients for each row execute function public.register_client_identity();
revoke all on function public.register_client_identity() from public,anon,authenticated;
create function public.client_deletion_status(p_client_id uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare c public.clients;reason text;
begin
 if not(public.has_capability('delete_clients') or public.has_capability('clients')) then raise exception 'Client lifecycle permission required' using errcode='42501';end if;
 select * into c from public.clients where id=p_client_id and owner_id=public.current_ledger_id();if not found then raise exception 'Client not found';end if;
 select retention_reason into reason from public.client_identities where id=c.id;
 if exists(select 1 from public.loans where client_id=c.id) then reason:='Loan and repayment history must be retained. Archive/Deactivate instead.';
 elsif exists(select 1 from public.import_rows where client_id=c.id or matched_client_id=c.id) then reason:='Import history references this Client. Archive/Deactivate instead.';end if;
 return jsonb_build_object('can_delete',reason is null and public.has_capability('delete_clients'),'reason',coalesce(reason,case when not public.has_capability('delete_clients') then 'Delete Client permission is required.' end),'revision',c.revision);
end $$;
create function public.delete_client(p_client_id uuid,p_expected_revision integer,p_reason text,p_request_id uuid,p_confirm boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare c public.clients;v_payload jsonb;v_result jsonb;v_status jsonb;
begin
 perform public.require_capability('delete_clients');
 if p_confirm is distinct from true or length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'Confirm deletion with a reason of 5–500 characters';end if;
 v_payload:=jsonb_build_object('client_id',p_client_id,'revision',p_expected_revision,'reason',trim(p_reason));
 v_result:=public.begin_financial_operation(p_request_id,'delete_client',v_payload);if v_result is not null then return v_result;end if;
 select * into c from public.clients where id=p_client_id and owner_id=public.current_ledger_id() for update;
 if not found then raise exception 'Client not found';end if;
 perform 1 from public.client_identities where id=c.id for update;
 if c.revision is distinct from p_expected_revision then raise exception 'Client changed. Reload and review.';end if;
 v_status:=public.client_deletion_status(c.id);
 if not (v_status->>'can_delete')::boolean then raise exception '%',v_status->>'reason';end if;
 insert into public.client_audit(client_id,owner_id,actor_id,action,reason,before_data,after_data) values(c.id,c.owner_id,auth.uid(),'delete',trim(p_reason),to_jsonb(c),jsonb_build_object('id',c.id,'deleted',true));
 delete from public.clients where id=c.id;
 return public.finish_financial_operation(p_request_id,'delete_client',v_payload,jsonb_build_object('client_id',c.id,'deleted',true));
end $$;
revoke all on function public.client_deletion_status(uuid),public.delete_client(uuid,integer,text,uuid,boolean) from public,anon;
grant execute on function public.client_deletion_status(uuid),public.delete_client(uuid,integer,text,uuid,boolean) to authenticated;
commit;
