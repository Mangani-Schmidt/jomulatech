begin;
-- Exact text lookup uses the existing case-insensitive unique index. No
-- wildcard interpretation, new identity, or financial/Client write is involved.
create function public.find_client_by_man(p_man_number text) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare v_man text:=trim(p_man_number);v_client jsonb;
begin
 if not public.has_capability('read') then
  raise exception 'Permission denied for this role: read' using errcode='42501';
 end if;
 if v_man is null or length(v_man) not between 1 and 50 or v_man ~ '[[:cntrl:]]' then
  raise exception 'Enter a Man# of 1–50 text characters without control characters' using errcode='22023';
 end if;
 -- SECURITY INVOKER retains clients RLS; explicit business scope also binds
 -- the indexed owner_id/lower(man_number) lookup to the signed-in membership.
 select to_jsonb(c) into v_client from public.clients c
 where c.owner_id=public.current_ledger_id() and lower(c.man_number)=lower(v_man);
 return v_client;
end $$;
revoke all on function public.find_client_by_man(text) from public,anon,authenticated;
grant execute on function public.find_client_by_man(text) to authenticated;
comment on function public.find_client_by_man(text) is 'Read-only exact case-insensitive text Man# lookup within the active business; Client RLS applies.';
commit;
