begin;
-- Loan references identify loans, never Clients or receipt requests. Gaps are allowed.
create sequence public.loan_reference_sequence;
revoke all on sequence public.loan_reference_sequence from public,anon,authenticated;
create function public.next_loan_reference() returns text language plpgsql security definer set search_path='' as $$
declare v_number text;
begin
 v_number:=nextval('public.loan_reference_sequence')::text;
 return 'LN-'||lpad(v_number,greatest(8,length(v_number)),'0');
end $$;
revoke all on function public.next_loan_reference() from public,anon,authenticated;
-- Backfill metadata in one locked migration without changing financial amounts.
drop trigger enforce_loan_terms on public.loans;
drop trigger audit_loan_terms on public.loans;
alter table public.loans
 add column loan_reference text,
 add column created_by uuid references auth.users(id),
 add column creator_inferred boolean not null default false,
 add column updated_at timestamptz,
 add column updated_by uuid references auth.users(id),
 add column lifecycle_status text,
 add column written_off_cents bigint,
 add column written_off_at timestamptz,
 add column written_off_by uuid references auth.users(id),
 add column written_off_reason text,
 add column written_off_request_id uuid;
update public.loans l set loan_reference=public.next_loan_reference(),
 created_by=coalesce((select a.actor_id from public.loan_terms_audit a where a.loan_id=l.id and a.action='originate' order by a.created_at limit 1),(select uploaded_by from public.import_batches b where b.id=l.import_batch_id),l.owner_id),
 creator_inferred=not exists(select 1 from public.loan_terms_audit a where a.loan_id=l.id and a.action='originate' and a.actor_id is not null) and not exists(select 1 from public.import_batches b where b.id=l.import_batch_id and b.uploaded_by is not null),
 updated_at=greatest(l.created_at,(select max(created_at) from public.repayments r where r.loan_id=l.id),(select max(created_at) from public.loan_terms_audit a where a.loan_id=l.id and a.action='adjust')),
 updated_by=l.owner_id,lifecycle_status=case when balance_cents=0 then 'settled' else 'active' end;
alter table public.loans alter column loan_reference set not null;
alter table public.loans alter column created_by set not null;
alter table public.loans alter column updated_at set not null;
alter table public.loans alter column lifecycle_status set not null;
alter table public.loans add unique(loan_reference);
alter table public.loans add unique(owner_id,written_off_request_id);
alter table public.loans add constraint loan_reference_format check(loan_reference ~ '^LN-[0-9]{8,}$');
alter table public.loans add constraint loan_date_consistency check(disbursement_date>=date '1900-01-01' and due_date>=disbursement_date);
alter table public.loans add constraint loan_lifecycle_consistency check(
 (lifecycle_status='active' and balance_cents>0 and written_off_at is null and written_off_cents is null and written_off_by is null and written_off_reason is null and written_off_request_id is null) or
 (lifecycle_status='settled' and balance_cents=0 and written_off_at is null and written_off_cents is null and written_off_by is null and written_off_reason is null and written_off_request_id is null) or
 (lifecycle_status='written_off' and balance_cents>0 and written_off_cents is not null and written_off_cents=balance_cents and written_off_at is not null and written_off_by is not null and written_off_reason is not null and length(trim(written_off_reason)) between 5 and 500 and written_off_request_id is not null)
);
comment on column public.loans.principal_cents is 'Amount Disbursed: principal actually given to the Client, in ngwee; not an approved limit or repayment.';
comment on column public.repayments.amount_cents is 'Repayment Received from the Client, in ngwee; never a disbursement or write-off.';
comment on column public.loans.lifecycle_status is 'Stored lifecycle: active, settled, written_off. Current overdue status is calculated by loan_register on every read.';

create function public.loan_effective_status(p_balance bigint,p_due_date date,p_lifecycle text,p_timezone text,p_as_of date default null) returns text
language plpgsql stable set search_path='' as $$
begin
 if p_balance is null or p_balance<0 or p_due_date is null or p_lifecycle is null or p_lifecycle not in ('active','settled','written_off') or p_timezone is distinct from 'Africa/Lusaka' then raise exception 'Invalid loan status inputs'; end if;
 return case when p_lifecycle='written_off' then 'written_off' when p_balance=0 then 'settled' when p_due_date<coalesce(p_as_of,(statement_timestamp() at time zone p_timezone)::date) then 'overdue' else 'active' end;
end $$;
revoke all on function public.loan_effective_status(bigint,date,text,text,date) from public,anon;
grant execute on function public.loan_effective_status(bigint,date,text,text,date) to authenticated;
-- Invoker security preserves the loans table's RLS, including when queried directly.
create view public.loan_register with(security_invoker=true) as select l.*,l.principal_cents as amount_disbursed_cents,public.loan_effective_status(l.balance_cents,l.due_date,l.lifecycle_status,l.business_timezone) as status from public.loans l;
revoke all on public.loan_register from public,anon,authenticated;
grant select on public.loan_register to authenticated;

create table public.loan_status_audit (
 id uuid primary key default gen_random_uuid(),loan_id uuid not null,owner_id uuid not null,
 actor_id uuid references auth.users(id),action text not null check(action in ('baseline','originate','settle','reopen','write_off')),
 before_status text check(before_status in ('active','overdue','settled','written_off')),after_status text not null check(after_status in ('active','overdue','settled','written_off')),
 reason text not null,before_data jsonb,after_data jsonb not null,request_id uuid,created_at timestamptz not null default clock_timestamp(),
 foreign key(loan_id,owner_id) references public.loans(id,owner_id)
);
create index loan_status_audit_lookup on public.loan_status_audit(owner_id,loan_id,created_at desc);
alter table public.loan_status_audit enable row level security;
create policy loan_status_audit_read on public.loan_status_audit for select to authenticated using(owner_id=(select auth.uid()));
revoke all on public.loan_status_audit from public,anon,authenticated;
grant select on public.loan_status_audit to authenticated;
insert into public.loan_status_audit(loan_id,owner_id,action,after_status,reason,after_data)
 select id,owner_id,'baseline',public.loan_effective_status(balance_cents,due_date,lifecycle_status,business_timezone),'Loan-register migration: references/metadata assigned; financial history preserved.',to_jsonb(l) from public.loans l;

create or replace function public.enforce_loan_terms() returns trigger language plpgsql security definer set search_path='' as $$
declare v_batch public.import_batches; v_settings public.ledger_settings; v_terms jsonb;
begin
 if tg_op='UPDATE' then
   if (to_jsonb(new)-array['balance_cents','total_obligation_cents','updated_at','updated_by','lifecycle_status','written_off_cents','written_off_at','written_off_by','written_off_reason','written_off_request_id'])=(to_jsonb(old)-array['balance_cents','total_obligation_cents','updated_at','updated_by','lifecycle_status','written_off_cents','written_off_at','written_off_by','written_off_reason','written_off_request_id']) then return new; end if;
   if not public.is_ledger_admin() or new.owner_id<>auth.uid() or length(coalesce(current_setting('app.loan_adjustment_reason',true),''))<5 then raise exception 'Loan terms require an authorized audited adjustment'; end if;
   if (to_jsonb(new)-array['interest_cents','interest_rate_bps','calculation_method','rate_basis','term_days','due_date','terms_revision','total_obligation_cents','balance_cents','updated_at','updated_by','lifecycle_status','written_off_cents','written_off_at','written_off_by','written_off_reason','written_off_request_id'])<>(to_jsonb(old)-array['interest_cents','interest_rate_bps','calculation_method','rate_basis','term_days','due_date','terms_revision','total_obligation_cents','balance_cents','updated_at','updated_by','lifecycle_status','written_off_cents','written_off_at','written_off_by','written_off_reason','written_off_request_id']) then raise exception 'Loan identity, principal, and original snapshot are immutable'; end if;
 else
   if auth.uid() is null or new.owner_id<>auth.uid() then raise exception 'Authentication required'; end if;
   if new.import_batch_id is not null then
     select * into v_batch from public.import_batches where id=new.import_batch_id and owner_id=auth.uid() and status='preview';
     if not found or v_batch.mode<>'loans' then raise exception 'Invalid disbursement batch'; end if;
     v_terms:=v_batch.terms||jsonb_build_object('rate_bps',((v_batch.terms->>'interest_value')::numeric*100)::integer);
     if v_batch.terms->>'interest_type' is distinct from 'flat_percent' then raise exception 'Unsupported import interest method'; end if;
     v_settings:=public.checked_loan_terms(v_terms);
     new.interest_rate_bps:=(v_terms->>'rate_bps')::integer;new.term_days:=(v_terms->>'term_days')::integer;
     new.calculation_method:='one_time_flat';new.rate_basis:='entire_term';new.settings_revision:=v_settings.revision;
     new.default_rate_bps_at_origination:=v_settings.default_rate_bps;new.rate_override_reason:=nullif(trim(v_terms->>'override_reason'),'');
     new.origin_request_id:=gen_random_uuid();
   end if;
   if new.settings_revision is null or new.default_rate_bps_at_origination is null then raise exception 'A current settings snapshot is required'; end if;
 end if;
 if new.interest_cents<>public.flat_interest_cents(new.principal_cents,new.interest_rate_bps,new.calculation_method,new.rate_basis) or new.term_days is null or new.due_date<>new.disbursement_date+new.term_days then raise exception 'Loan amounts or dates do not match the actual terms'; end if;
 return new;
end $$;
-- Run metadata after the terms guard, so routine balance updates do not look like term edits.
create function public.maintain_loan_lifecycle() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or new.owner_id<>auth.uid() then raise exception 'Loan authorization required'; end if;
 if tg_op='INSERT' then
   if new.loan_reference is not null or new.lifecycle_status='written_off' or new.written_off_at is not null or new.written_off_request_id is not null or new.written_off_cents is not null or new.written_off_reason is not null or new.written_off_by is not null then raise exception 'Loan reference and initial status are system assigned'; end if;
   if new.principal_cents<=0 or new.disbursement_date>(now() at time zone new.business_timezone)::date or new.due_date<=new.disbursement_date then raise exception 'Invalid Amount Disbursed or inconsistent dates'; end if;
   if new.balance_cents<>new.principal_cents+new.interest_cents then raise exception 'A new loan must start at its total repayment obligation'; end if;
   new.loan_reference:=public.next_loan_reference();new.created_by:=auth.uid();new.creator_inferred:=false;
   new.created_at:=clock_timestamp();new.updated_at:=new.created_at;
 else
   if new.loan_reference<>old.loan_reference or new.created_by<>old.created_by or new.created_at<>old.created_at or new.creator_inferred<>old.creator_inferred then raise exception 'Loan reference and creator metadata are immutable'; end if;
   if old.lifecycle_status='written_off' then raise exception 'Written-off loans are closed to receipts and term adjustments'; end if;
   if new.lifecycle_status='written_off' then
     if not public.is_ledger_admin() or current_setting('app.loan_write_off',true) is distinct from new.written_off_request_id::text then raise exception 'An administrator must explicitly authorize a write-off'; end if;
     if new.balance_cents<>old.balance_cents or new.balance_cents<=0 or new.written_off_cents<>old.balance_cents or new.written_off_by<>auth.uid() then raise exception 'Write-off must preserve the unpaid balance'; end if;
     new.updated_at:=clock_timestamp();new.updated_by:=auth.uid();return new;
   end if;
   if new.written_off_cents is not null or new.written_off_at is not null or new.written_off_by is not null or new.written_off_reason is not null or new.written_off_request_id is not null then raise exception 'Invalid write-off metadata'; end if;
   new.updated_at:=clock_timestamp();
 end if;
 new.lifecycle_status:=case when new.balance_cents=0 then 'settled' else 'active' end;
 new.updated_by:=auth.uid();
 return new;
end $$;
create trigger enforce_loan_terms before insert or update on public.loans for each row execute function public.enforce_loan_terms();
create trigger zz_loan_lifecycle before insert or update on public.loans for each row execute function public.maintain_loan_lifecycle();
create trigger audit_loan_terms after insert or update on public.loans for each row execute function public.audit_loan_terms();
create function public.audit_loan_lifecycle() returns trigger language plpgsql security definer set search_path='' as $$
declare v_action text;v_reason text;v_before text;
begin
 if tg_op='UPDATE' and new.lifecycle_status=old.lifecycle_status then return new; end if;
 if tg_op='INSERT' then v_action:='originate';v_reason:='Amount Disbursed recorded';
 else
   v_before:=public.loan_effective_status(old.balance_cents,old.due_date,old.lifecycle_status,old.business_timezone);
   if new.lifecycle_status='written_off' then v_action:='write_off';v_reason:=new.written_off_reason;
   elsif new.lifecycle_status='settled' then v_action:='settle';v_reason:=case when new.terms_revision<>old.terms_revision then 'Authorized terms adjustment: '||current_setting('app.loan_adjustment_reason',true) else 'Repayment Received covered the total obligation' end;
   else v_action:='reopen';v_reason:='Authorized terms adjustment: '||current_setting('app.loan_adjustment_reason',true);end if;
 end if;
 insert into public.loan_status_audit(loan_id,owner_id,actor_id,action,before_status,after_status,reason,before_data,after_data,request_id)
 values(new.id,new.owner_id,auth.uid(),v_action,v_before,public.loan_effective_status(new.balance_cents,new.due_date,new.lifecycle_status,new.business_timezone),v_reason,case when tg_op='UPDATE' then to_jsonb(old) else null end,to_jsonb(new),case when new.lifecycle_status='written_off' then new.written_off_request_id else null end);
 return new;
end $$;
create trigger audit_loan_lifecycle after insert or update on public.loans for each row execute function public.audit_loan_lifecycle();
revoke all on function public.maintain_loan_lifecycle(),public.audit_loan_lifecycle() from public,anon,authenticated;

create function public.write_off_loan(p_loan_id uuid,p_expected_balance_cents bigint,p_expected_terms_revision integer,p_reason text,p_request_id uuid,p_confirm boolean) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_loan public.loans;
begin
 if not public.is_ledger_admin() then raise exception 'Administrator permission required'; end if;
 if p_confirm is distinct from true or p_request_id is null then raise exception 'Explicit write-off confirmation and request ID required'; end if;
 if p_reason is null or length(trim(p_reason)) not between 5 and 500 then raise exception 'A write-off reason of 5–500 characters is required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('loan_write_off:'||auth.uid()::text||p_request_id::text,0));
 select * into v_loan from public.loans where owner_id=auth.uid() and written_off_request_id=p_request_id;
 if found then
   if v_loan.id<>p_loan_id or v_loan.written_off_cents is distinct from p_expected_balance_cents or v_loan.terms_revision is distinct from p_expected_terms_revision or v_loan.written_off_reason<>trim(p_reason) then raise exception 'Request ID already used for another write-off'; end if;
   return v_loan.id;
 end if;
 select * into v_loan from public.loans where id=p_loan_id and owner_id=auth.uid() for update;
 if not found then raise exception 'Loan not found'; end if;
 if v_loan.lifecycle_status='written_off' then raise exception 'Loan is already written off'; end if;
 if v_loan.balance_cents=0 then raise exception 'Settled loans have no unpaid balance to write off'; end if;
 if p_expected_balance_cents is distinct from v_loan.balance_cents or p_expected_terms_revision is distinct from v_loan.terms_revision then raise exception 'Loan balance or terms changed. Reload and confirm the current balance.'; end if;
 perform set_config('app.loan_write_off',p_request_id::text,true);
 update public.loans set lifecycle_status='written_off',written_off_cents=balance_cents,written_off_at=clock_timestamp(),written_off_by=auth.uid(),written_off_reason=trim(p_reason),written_off_request_id=p_request_id where id=v_loan.id;
 return v_loan.id;
end $$;
revoke all on function public.write_off_loan(uuid,bigint,integer,text,uuid,boolean) from public,anon;
grant execute on function public.write_off_loan(uuid,bigint,integer,text,uuid,boolean) to authenticated;

-- Keep the existing receipt ledger/idempotency, but disallow new receipts on closed write-offs.
alter function public.record_repayment(uuid,bigint,uuid) rename to record_repayment_v1;
revoke all on function public.record_repayment_v1(uuid,bigint,uuid) from public,anon,authenticated;
create function public.record_repayment(p_loan_id uuid,p_amount_cents bigint,p_request_id uuid) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_existing public.repayments;v_loan public.loans;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_request_id is null then raise exception 'Receipt request ID required'; end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text||p_request_id::text,0));
 select * into v_existing from public.repayments where owner_id=auth.uid() and request_id=p_request_id;
 if found then
   if v_existing.loan_id is distinct from p_loan_id or v_existing.amount_cents is distinct from p_amount_cents then raise exception 'Request already used for another Repayment Received'; end if;
   return v_existing.id;
 end if;
 select * into v_loan from public.loans where id=p_loan_id and owner_id=auth.uid() for update;
 if not found then raise exception 'Loan not found'; end if;
 if v_loan.lifecycle_status='written_off' then raise exception 'Written-off loans are closed to new Repayment Received entries'; end if;
 return public.record_repayment_v1(p_loan_id,p_amount_cents,p_request_id);
end $$;
revoke all on function public.record_repayment(uuid,bigint,uuid) from public,anon;
grant execute on function public.record_repayment(uuid,bigint,uuid) to authenticated;

create or replace function public.import_report(p_batch_id uuid) returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('batch',to_jsonb(b)-'payload','rows',coalesce((select jsonb_agg(to_jsonb(r)||jsonb_build_object('loan_reference',(select loan_reference from public.loans l where l.id=r.loan_id)) order by r.excel_row) from public.import_rows r where r.batch_id=b.id),'[]'::jsonb)) from public.import_batches b where b.id=p_batch_id and b.owner_id=auth.uid();
$$;
commit;
