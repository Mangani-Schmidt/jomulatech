begin;
-- Add explicit grants without rewriting Client IDs, financial data or terms.
create function public.role_permissions(p_role text) returns jsonb
language sql immutable set search_path='' as $$
 select jsonb_build_object(
  'view_dashboard',true,'view_clients',true,'view_loans',true,'view_repayments',true,
  'view_reports',true,'view_expenses',true,'view_imports',p_role='administrator',
  'view_settings',p_role='administrator','view_users',p_role='administrator','view_audit',p_role='administrator',
  'clients',p_role in ('administrator','loan_officer'),'originate',p_role in ('administrator','loan_officer'),
  'repayments',p_role in ('administrator','cashier'),'imports',p_role='administrator',
  'expenses',p_role='administrator','settings',p_role='administrator','adjustments',p_role='administrator',
  'users',p_role='administrator','override_rate',p_role='administrator','security',p_role='administrator','export_reports',true);
$$;
revoke all on function public.role_permissions(text) from public,anon;
grant execute on function public.role_permissions(text) to authenticated;
alter table public.user_roles add column permissions jsonb;
select set_config('app.role_reason','Migration 013: preserve existing role access as explicit permissions',true);
update public.user_roles set permissions=public.role_permissions(role);
alter table public.user_roles alter column permissions set not null;
create function public.initialize_user_permissions() returns trigger language plpgsql set search_path='' as $$
begin
 if new.permissions is null then new.permissions:=public.role_permissions(new.role);end if;
 if jsonb_typeof(new.permissions) is distinct from 'object' or exists(
  select 1 from jsonb_each(new.permissions) e where jsonb_typeof(e.value)<>'boolean' or not(public.role_permissions(new.role)?e.key)
 ) or (select count(*) from jsonb_object_keys(new.permissions))<>(select count(*) from jsonb_object_keys(public.role_permissions(new.role))) then
  raise exception 'Supply the complete supported boolean permission set';
 end if;
 return new;
end $$;
create trigger initialize_user_permissions before insert or update on public.user_roles for each row execute function public.initialize_user_permissions();
revoke all on function public.initialize_user_permissions() from public,anon,authenticated;
create or replace function public.has_capability(p_action text) returns boolean
language sql stable security definer set search_path='' as $$
 select coalesce((select case
  when p_action='read' then true
  when p_action='admin' then r.role='administrator' and (not b.admin_mfa_required or public.recent_admin_assurance())
  when p_action='data_clients' then (r.permissions->>'view_clients')::boolean or (r.permissions->>'view_loans')::boolean or (r.permissions->>'view_repayments')::boolean or (r.permissions->>'view_reports')::boolean
  when p_action='data_finance' then (r.permissions->>'view_loans')::boolean or (r.permissions->>'view_repayments')::boolean or (r.permissions->>'view_reports')::boolean
  when p_action='data_expenses' then (r.permissions->>'view_expenses')::boolean or (r.permissions->>'view_reports')::boolean
  when p_action='reporting' then (r.permissions->>'view_reports')::boolean or ((r.permissions->>'view_dashboard')::boolean and ((r.permissions->>'view_loans')::boolean or (r.permissions->>'view_repayments')::boolean))
  when p_action like 'view_%' then coalesce((r.permissions->>p_action)::boolean,false) and (r.role<>'administrator' or p_action not in ('view_settings','view_users','view_audit','view_imports') or not b.admin_mfa_required or public.recent_admin_assurance())
  when p_action in ('clients','originate','repayments') then coalesce((r.permissions->>p_action)::boolean,false)
   and coalesce((public.role_permissions(r.role)->>p_action)::boolean,false)
   and coalesce((r.permissions->>case p_action when 'clients' then 'view_clients' when 'originate' then 'view_loans' else 'view_repayments' end)::boolean,false)
  when p_action='export_reports' then coalesce((r.permissions->>'export_reports')::boolean,false)
  when p_action in ('imports','expenses','settings','adjustments','users','override_rate','security') then
   r.role='administrator' and coalesce((r.permissions->>p_action)::boolean,false)
   and (not b.admin_mfa_required or public.recent_admin_assurance())
   and case p_action when 'imports' then (r.permissions->>'view_imports')::boolean and (r.permissions->>'clients')::boolean and (r.permissions->>'view_clients')::boolean
    when 'expenses' then (r.permissions->>'view_expenses')::boolean
    when 'settings' then (r.permissions->>'view_settings')::boolean
    when 'users' then (r.permissions->>'view_users')::boolean else true end
  else false end
  from public.user_roles r join public.businesses b on b.id=r.owner_id
  where r.user_id=auth.uid() and r.is_active),false);
$$;
create or replace function public.require_capability(p_action text) returns void language plpgsql security definer set search_path='' as $$
declare r public.user_roles;v_required boolean;
begin
 select * into r from public.user_roles where user_id=auth.uid() and is_active for share;
 if not found then raise exception 'Permission denied for this role: %',p_action using errcode='42501';end if;
 select admin_mfa_required into v_required from public.businesses where id=r.owner_id;
 if r.role='administrator' and p_action in ('admin','imports','expenses','settings','adjustments','users','override_rate','security') and v_required and not public.recent_admin_assurance() then
  raise exception 'Additional authentication required. Verify your authenticator in Account security before this action.' using errcode='28000';
 end if;
 if not public.has_capability(p_action) then raise exception 'Permission denied for this role: %',p_action using errcode='42501';end if;
end $$;
create or replace function public.can_override_loan_rate() returns boolean language sql stable security definer set search_path='' as $$select public.has_capability('override_rate');$$;
create or replace function public.loan_defaults() returns jsonb language plpgsql security definer set search_path='' as $$
declare v_settings public.ledger_settings;v_caps jsonb;v_key text;v_map jsonb:=
 '{"can_view_dashboard":"view_dashboard","can_view_clients":"view_clients","can_view_loans":"view_loans","can_view_repayments":"view_repayments","can_view_imports":"view_imports","can_view_reports":"view_reports","can_view_expenses":"view_expenses","can_view_settings":"view_settings","can_view_users":"view_users","can_view_audit":"view_audit","can_register_clients":"clients","can_originate":"originate","can_post_repayments":"repayments","can_import":"imports","can_manage_expenses":"expenses","can_manage_settings":"settings","can_approve_adjustments":"adjustments","can_manage_users":"users","can_override_rate":"override_rate","can_manage_security":"security","can_export_reports":"export_reports"}';
begin
 perform public.require_capability('read');
 select * into v_settings from public.ledger_settings where owner_id=public.current_ledger_id();
 if not found then raise exception 'Business settings are not initialized. Contact an Administrator.';end if;
 v_caps:=jsonb_build_object('can_read',true,'is_admin',public.has_capability('admin'),'can_delete_clients',false,'role',(select role from public.user_roles where user_id=auth.uid()));
 for v_key in select jsonb_object_keys(v_map) loop v_caps:=v_caps||jsonb_build_object(v_key,public.has_capability(v_map->>v_key));end loop;
 return jsonb_build_object('settings',to_jsonb(v_settings),'capabilities',v_caps);
end $$;

-- Full permission updates are versioned, explicitly approved and idempotent.
create function public.manage_user_access(p_user_id uuid,p_role text,p_is_active boolean,p_permissions jsonb,p_expected_revision integer,p_reason text,p_request_id uuid,p_confirm boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare v_old public.user_roles;v_new public.user_roles;v_payload jsonb;v_result jsonb;v_key text;
begin
 perform public.require_capability('users');
 if p_confirm is distinct from true or p_user_id is null or p_role is null or p_role not in ('administrator','loan_officer','cashier','viewer') or p_is_active is null then raise exception 'Approve an existing Auth user, supported role and active status';end if;
 if length(trim(coalesce(p_reason,''))) not between 5 and 500 then raise exception 'A permission change reason of 5–500 characters is required';end if;
 if jsonb_typeof(p_permissions) is distinct from 'object' or (select count(*) from jsonb_object_keys(p_permissions))<>(select count(*) from jsonb_object_keys(public.role_permissions(p_role))) then raise exception 'Supply every supported permission explicitly';end if;
 for v_key in select jsonb_object_keys(p_permissions) loop
  if not(public.role_permissions(p_role)?v_key) or jsonb_typeof(p_permissions->v_key)<>'boolean' then raise exception 'Unsupported permission or non-boolean grant';end if;
  if v_key not like 'view_%' and p_permissions->>v_key='true' and public.role_permissions(p_role)->>v_key<>'true' then raise exception 'This action requires an eligible business role: %',v_key;end if;
 end loop;
 if p_user_id=auth.uid() and (p_role<>'administrator' or not p_is_active or p_permissions->>'users'<>'true' or p_permissions->>'view_users'<>'true') then raise exception 'You cannot remove your own Administrator user-management access';end if;
 v_payload:=jsonb_build_object('user_id',p_user_id,'role',p_role,'active',p_is_active,'permissions',p_permissions,'revision',p_expected_revision,'reason',trim(p_reason));
 v_result:=public.begin_financial_operation(p_request_id,'manage_user_access',v_payload);if v_result is not null then return v_result;end if;
 perform 1 from public.businesses where id=public.current_ledger_id() for update;
 if not exists(select 1 from auth.users where id=p_user_id) then raise exception 'Auth user not found. Invite/register the user through Supabase Auth first.';end if;
 select * into v_old from public.user_roles where user_id=p_user_id for update;
 if found and v_old.owner_id<>public.current_ledger_id() then raise exception 'User is already assigned to another business';end if;
 if coalesce(v_old.revision,0) is distinct from p_expected_revision then raise exception 'Permissions changed. Reload and review the existing user.';end if;
 perform set_config('app.role_reason',trim(p_reason),true);
 if v_old.user_id is null then
  insert into public.user_roles(user_id,owner_id,role,is_active,permissions,assigned_by) values(p_user_id,public.current_ledger_id(),p_role,p_is_active,p_permissions,auth.uid()) returning * into v_new;
 else
  update public.user_roles set role=p_role,is_active=p_is_active,permissions=p_permissions,revision=revision+1,assigned_by=auth.uid(),updated_at=clock_timestamp() where user_id=p_user_id returning * into v_new;
 end if;
 return public.finish_financial_operation(p_request_id,'manage_user_access',v_payload,to_jsonb(v_new));
end $$;
revoke all on function public.manage_user_access(uuid,text,boolean,jsonb,integer,text,uuid,boolean) from public,anon;
grant execute on function public.manage_user_access(uuid,text,boolean,jsonb,integer,text,uuid,boolean) to authenticated;
-- Keep old callers compatible; a role-only change never overwrites explicit grants.
create or replace function public.manage_user_role(p_user_id uuid,p_role text,p_is_active boolean,p_expected_revision integer,p_reason text,p_request_id uuid,p_confirm boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare v_permissions jsonb;
begin
 perform public.require_capability('users');
 select permissions into v_permissions from public.user_roles where user_id=p_user_id and owner_id=public.current_ledger_id();
 return public.manage_user_access(p_user_id,p_role,p_is_active,coalesce(v_permissions,public.role_permissions(p_role)),p_expected_revision,p_reason,p_request_id,p_confirm);
end $$;

-- Source data is shared by permitted workflows (e.g. loan balances need receipt
-- allocations). Module RPCs still require the corresponding module/view grant.
drop policy roles_read on public.user_roles;
create policy roles_read on public.user_roles for select to authenticated using(public.has_capability('read') and (user_id=auth.uid() or (owner_id=public.current_ledger_id() and public.has_capability('view_users'))));
do $$declare t text;v_cap text;v_policy record;begin
 foreach t in array array['clients','loans','repayments','client_audit','loan_terms_audit','loan_status_audit','repayment_audit','ledger_settings','settings_audit','import_batches','import_rows','financial_operations','audit_events','expenses','reporting_certifications'] loop
  case when t in ('clients','client_audit') then v_cap:='data_clients';
   when t in ('loans','repayments','loan_terms_audit','loan_status_audit','repayment_audit','reporting_certifications') then v_cap:='data_finance';
   when t='ledger_settings' then v_cap:='view_settings'; when t='settings_audit' then v_cap:='view_audit';
   when t in ('import_batches','import_rows') then v_cap:='view_imports';
   when t='financial_operations' then v_cap:='adjustments';when t='audit_events' then v_cap:='view_audit';
   else v_cap:='data_expenses';end case;
  for v_policy in select policyname from pg_policies where schemaname='public' and tablename=t and cmd='SELECT' loop
   execute format('drop policy %I on public.%I',v_policy.policyname,t);
  end loop;
  execute format('create policy business_read on public.%I for select to authenticated using(owner_id=(select public.current_ledger_id()) and (select public.has_capability(%L)))',t,v_cap);
 end loop;
end $$;

-- Only authorization guards change in these reviewed financial implementations.
-- Fixed signatures and expected-text assertions make schema drift fail closed.
do $migration$declare v_sig text;v_def text;v_guard text;begin
 for v_sig,v_guard in select * from (values
 ('public.save_interest_settings(jsonb,integer,text)','perform public.require_capability(''settings'');'),
 ('public.adjust_loan_terms(uuid,integer,integer,integer,text,uuid,boolean)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_loans'');'),
 ('public.write_off_loan(uuid,bigint,integer,text,uuid,boolean)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_loans'');'),
 ('public.write_off_loan_v5(uuid,bigint,integer,text,uuid,boolean)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_loans'');'),
 ('public.reverse_write_off(uuid,uuid,text,uuid,boolean)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_loans'');'),
 ('public.reverse_repayment(uuid,text,uuid,boolean)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_repayments'');'),
 ('public.correct_repayment(uuid,jsonb,text,uuid,boolean)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_repayments'');'),
 ('public.reverse_receipt_internal(uuid,text,uuid)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_repayments'');'),
 ('public.reverse_expense(uuid,text,uuid,boolean)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_expenses'');'),
 ('public.certify_reporting_period(date,date,text,text,boolean,boolean,bigint,uuid,boolean)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_reports'');'),
 ('public.revoke_reporting_certification(uuid,text,uuid,boolean)','perform public.require_capability(''adjustments''); perform public.require_capability(''view_reports'');'),
 ('public.set_admin_mfa_policy(boolean,text,uuid,boolean)','perform public.require_capability(''security'');')
 ) patches(signature,guard) loop
  v_def:=pg_get_functiondef(v_sig::regprocedure);
  if strpos(v_def,'perform public.require_capability(''admin'');')=0 then raise exception 'Expected authorization guard missing: %',v_sig;end if;
  execute replace(v_def,'perform public.require_capability(''admin'');',v_guard);
 end loop;
end $migration$;

-- Recovery exposes only result IDs, and still needs the original action grant.
create or replace function public.posting_request_status(p_request_id uuid,p_operation text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare f public.financial_operations; l public.loans;
begin
 if p_request_id is null then raise exception 'Request ID required';end if;
 if p_operation='originate_loan' then
  perform public.require_capability('originate');
  perform pg_advisory_xact_lock(hashtextextended('loan_request:'||public.current_ledger_id()::text||p_request_id::text,0));
  select * into l from public.loans where owner_id=public.current_ledger_id() and origin_request_id=p_request_id;
  if found then return jsonb_build_object('loan_id',l.id);end if;
 elsif p_operation in ('post_repayment','correct_repayment','post_expense') then
  perform public.require_capability(case p_operation when 'post_repayment' then 'repayments' when 'post_expense' then 'expenses' else 'adjustments' end);
  if p_operation='correct_repayment' then perform public.require_capability('view_repayments');end if;
  perform pg_advisory_xact_lock(hashtextextended('finance_request:'||public.current_ledger_id()::text||p_request_id::text,0));
  select * into f from public.financial_operations where owner_id=public.current_ledger_id() and request_id=p_request_id;
  if found then
   if f.operation<>p_operation then raise exception 'Request belongs to a different operation';end if;
   return f.result;
  end if;
 else raise exception 'Unsupported posting operation';end if;
 return null;
end $$;
create or replace function public.reporting_revision() returns bigint language sql stable security definer set search_path='' as $$
 select case when auth.uid() is not null and public.has_capability('reporting') then (select count(*) from public.audit_events where owner_id=public.current_ledger_id() and entity_type in ('Loan','Repayment','Expense')) else null end;
$$;

create or replace function public.receipt_document(p_repayment_id uuid) returns jsonb language plpgsql stable security invoker set search_path='' as $$
begin
 if not (public.has_capability('view_repayments') or public.has_capability('view_reports')) then raise exception 'Permission denied for this record history' using errcode='42501';end if;
 return (select jsonb_build_object('generated_at',statement_timestamp(),'receipt',to_jsonb(r),'audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.repayment_audit a where a.repayment_id=r.id),'[]'::jsonb)) from public.repayment_register r where r.id=p_repayment_id and r.owner_id=public.current_ledger_id());
end $$;

create or replace function public.client_statement(p_client_id uuid) returns jsonb language plpgsql stable security invoker set search_path='' as $$
begin
 if not (public.has_capability('view_loans') or public.has_capability('view_reports')) then raise exception 'Permission denied for this record history' using errcode='42501';end if;
 return (select jsonb_build_object('client',to_jsonb(c),'generated_at',statement_timestamp(),'timezone','Africa/Lusaka','allocation_policy','Interest first, then principal, in posting order; reversals restore original allocations without rewriting later receipts.',
 'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.created_at,l.id) from public.loan_register l where l.client_id=c.id),'[]'::jsonb),
 'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence) from public.repayment_register r where r.client_id=c.id),'[]'::jsonb),
 'repayment_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.repayment_audit a join public.loans l on l.id=(a.after_data->>'loan_id')::uuid where l.client_id=c.id),'[]'::jsonb),
 'terms_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.loan_terms_audit a join public.loans l on l.id=a.loan_id where l.client_id=c.id),'[]'::jsonb),
 'status_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at) from public.loan_status_audit a join public.loans l on l.id=a.loan_id where l.client_id=c.id),'[]'::jsonb)) from public.clients c where c.id=p_client_id and c.owner_id=public.current_ledger_id());
end $$;

create or replace function public.report_source() returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare v_result jsonb;
begin
 if not public.has_capability('reporting') then raise exception 'Reporting access required' using errcode='42501';end if;
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 v_result:=(select jsonb_build_object(
  'generated_at',statement_timestamp(), 'timezone','Africa/Lusaka',
  'ledger_event_count',public.reporting_revision(),
  'certifications',coalesce((select jsonb_agg(to_jsonb(c) order by c.created_at desc,c.id) from public.reporting_certifications c where c.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'expenses',coalesce((select jsonb_agg(to_jsonb(e) order by e.expense_date,e.id) from public.expenses e where e.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'clients',coalesce((select jsonb_agg(to_jsonb(c) order by c.id) from public.clients c where c.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.id) from public.loans l where l.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence) from public.repayments r where r.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'terms_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_terms_audit a where a.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'status_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_status_audit a where a.owner_id=public.current_ledger_id()),'[]'::jsonb),
  'repayment_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.repayment_audit a where a.owner_id=public.current_ledger_id()),'[]'::jsonb)));
if not public.has_capability('data_expenses') then v_result:=v_result||jsonb_build_object('expenses',null,'certifications','[]'::jsonb);end if;
 return v_result;
end;
$$;

create or replace function public.report_source_filtered(p_filters jsonb) returns jsonb
language plpgsql stable security invoker set search_path='' as $$
declare v_result jsonb;v_ids uuid[];v_count integer;v_from date;v_to date;v_asof date;v_currency text;
begin
 if not public.has_capability('reporting') then raise exception 'Reporting access required' using errcode='42501';end if;
 if auth.uid() is null then raise exception 'Authentication required';end if;
 if jsonb_typeof(p_filters) is distinct from 'object' or octet_length(p_filters::text)>5000 then raise exception 'Invalid report filters';end if;
 v_from:=(p_filters->>'from')::date;v_to:=(p_filters->>'to')::date;v_asof:=(p_filters->>'asOf')::date;v_currency:=p_filters->>'currency';
 if v_from is null or v_to is null or v_asof is null or v_from<'1900-01-01' or v_from>v_to or v_to>v_asof or v_asof>(statement_timestamp() at time zone 'Africa/Lusaka')::date or v_currency is null or v_currency !~ '^[A-Z]{3}$' then raise exception 'Choose valid report dates and one currency';end if;
 select array_agg(id),count(*) into v_ids,v_count from (
  select l.id from public.loans l join public.clients c on c.id=l.client_id and c.owner_id=l.owner_id
  where l.owner_id=public.current_ledger_id() and l.currency=v_currency and l.disbursement_date<=v_asof
   and (coalesce(p_filters->>'search','')='' or strpos(lower(c.name),lower(trim(p_filters->>'search')))>0 or strpos(lower(c.man_number),lower(trim(p_filters->>'search')))>0 or strpos(lower(l.loan_reference),lower(trim(p_filters->>'search')))>0)
   and (coalesce(p_filters->>'department','')='' or c.department=p_filters->>'department')
   and (coalesce(p_filters->>'designation','')='' or c.designation=p_filters->>'designation')
   and (coalesce(p_filters->>'disbursedFrom','')='' or l.disbursement_date>=(p_filters->>'disbursedFrom')::date)
   and (coalesce(p_filters->>'disbursedTo','')='' or l.disbursement_date<=(p_filters->>'disbursedTo')::date)
  order by l.id limit 10001
 ) selected;
 if v_count>10000 then raise exception 'More than 10000 matching loans. Narrow the report Client, department or disbursement dates; no truncated report is shown.' using errcode='54000';end if;
 if (select count(*) from (select r.id from public.repayments r where r.loan_id=any(v_ids) limit 100001) r)>100000 then raise exception 'More than 100000 matching receipts. Narrow the report selection; no truncated report is shown.' using errcode='54000';end if;
 v_result:=jsonb_build_object(
  'generated_at',statement_timestamp(),'timezone','Africa/Lusaka',
  'ledger_event_count',public.reporting_revision(),
  'certifications',coalesce((select jsonb_agg(to_jsonb(c) order by c.created_at desc,c.id) from public.reporting_certifications c where c.owner_id=public.current_ledger_id() and c.from_date=v_from and c.to_date=v_to and c.currency=v_currency),'[]'::jsonb),
  'filter_options',jsonb_build_object('department',(select coalesce(jsonb_agg(d order by d),'[]'::jsonb) from (select distinct department d from public.clients where owner_id=public.current_ledger_id() and department is not null) o),'designation',(select coalesce(jsonb_agg(d order by d),'[]'::jsonb) from (select distinct designation d from public.clients where owner_id=public.current_ledger_id() and designation is not null) o)),
  'clients',coalesce((select jsonb_agg(to_jsonb(c) order by c.id) from public.clients c where c.owner_id=public.current_ledger_id() and exists(select 1 from public.loans l where l.id=any(v_ids) and l.client_id=c.id)),'[]'::jsonb),
  'loans',coalesce((select jsonb_agg(to_jsonb(l) order by l.id) from public.loans l where l.id=any(v_ids)),'[]'::jsonb),
  'repayments',coalesce((select jsonb_agg(to_jsonb(r) order by r.posting_sequence) from public.repayments r where r.loan_id=any(v_ids)),'[]'::jsonb),
  'terms_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_terms_audit a where a.loan_id=any(v_ids)),'[]'::jsonb),
  'status_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.loan_status_audit a where a.loan_id=any(v_ids)),'[]'::jsonb),
  'repayment_audit',coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at,a.id) from public.repayment_audit a join public.repayments r on r.id=a.repayment_id where r.loan_id=any(v_ids)),'[]'::jsonb),
  'expenses',coalesce((select jsonb_agg(to_jsonb(e) order by e.expense_date,e.id) from public.expenses e where e.owner_id=public.current_ledger_id() and e.currency=v_currency),'[]'::jsonb)
 );
if not public.has_capability('data_expenses') then v_result:=v_result||jsonb_build_object('expenses',null,'certifications','[]'::jsonb);end if;
 return v_result;
end;
$$;

commit;
