-- Repair the newly registered session response without relaxing expiry or RLS.
-- Previously touch_app_session() called the STABLE app_session_status()
-- inside its own modifying statement. That status read can use the statement's
-- earlier snapshot, reporting a newly inserted/updated session as inactive.
-- The browser then revoked it immediately.
begin;
create or replace function public.touch_app_session()
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  s public.app_sessions;
  v_id uuid := public.current_app_session_id();
  v_now timestamptz;
begin
  if auth.uid() is null or v_id is null then
    raise exception 'A verified Supabase Auth session is required' using errcode='28000';
  end if;

  insert into public.app_sessions(session_id,user_id)
  values(v_id,auth.uid())
  on conflict(session_id) do nothing;

  select * into s
  from public.app_sessions
  where session_id=v_id and user_id=auth.uid()
  for update;
  if not found then
    raise exception 'Session identity mismatch' using errcode='28000';
  end if;

  if s.revoked_at is not null
     or s.last_activity_at <= clock_timestamp()-interval '15 minutes' then
    update public.app_sessions
    set revoked_at=coalesce(revoked_at,clock_timestamp()),
        revocation_reason=coalesce(revocation_reason,'inactive')
    where session_id=v_id;
    return jsonb_build_object(
      'active',false,'registered',true,
      'server_now',clock_timestamp(),'last_activity_at',s.last_activity_at
    );
  end if;

  update public.app_sessions
  set last_activity_at=clock_timestamp()
  where session_id=v_id
  returning last_activity_at into v_now;

  -- Return the committed row value directly. Do NOT call a STABLE status
  -- function within this modifying statement: it may see a stale snapshot.
  return jsonb_build_object(
    'active',true,'registered',true,
    'server_now',v_now,'last_activity_at',v_now
  );
end $$;
commit;
