-- Read-only checks for a migrated/restored ledger. Run as a trusted database
-- administrator; RLS-restricted application sessions cannot inspect all rows.
-- This is not a migration, seed, repair, or authorization to access live data.
begin isolation level repeatable read read only;
do $$
declare
 v_table text;
 v_role text;
begin
 foreach v_table in array array[
  'clients','loans','repayments','client_audit','import_batches','import_rows',
  'account_permissions','ledger_settings','settings_audit','loan_terms_audit',
  'loan_status_audit','financial_operations','repayment_audit','businesses',
  'user_roles','audit_events','expenses','reporting_certifications','app_sessions','client_identities'
 ] loop
  if not exists (
   select 1 from pg_class c join pg_namespace n on n.oid=c.relnamespace
   where n.nspname='public' and c.relname=v_table and c.relkind='r' and c.relrowsecurity
  ) then
   raise exception 'Missing table or disabled RLS: %',v_table;
  end if;
  if v_table <> 'clients' then
   foreach v_role in array array['anon','authenticated'] loop
    if has_table_privilege(v_role,'public.'||v_table,'INSERT,UPDATE,DELETE,TRUNCATE') then
     raise exception 'Unexpected direct mutation grant: % on %',v_role,v_table;
    end if;
   end loop;
  end if;
 end loop;
 if exists (
  select 1 from public.clients where man_number ~ '[[:cntrl:]]'
 ) then
  raise exception 'Legacy Man# control characters require audited correction';
 end if;
 perform public.validate_effective_allocations(l.id) from public.loans l;
 if exists (
  select 1 from public.repayments
  where interest_allocation_cents+principal_allocation_cents<>amount_cents
   or interest_allocation_cents<0 or principal_allocation_cents<0
 ) then
  raise exception 'Repayment allocations do not reconcile';
 end if;
 if exists (
  select 1 from public.loans l
  where l.balance_cents<>l.principal_cents+l.interest_cents-(
   select coalesce(sum(r.amount_cents),0) from public.repayments r
   where r.loan_id=l.id and r.owner_id=l.owner_id and r.reversed_at is null
  )
 ) then
  raise exception 'Loan balances do not reconcile with posted receipts';
 end if;
 if exists (
  select 1 from public.loan_register
  where interest_outstanding_cents<0 or principal_outstanding_cents<0
   or balance_cents<>interest_outstanding_cents+principal_outstanding_cents
 ) then
  raise exception 'Outstanding principal/interest do not reconcile';
 end if;
end $$;

-- Aggregate evidence only; distinguish written-off contractual balances from
-- collectible balances. These are current balances, not period cash activity.
select currency,status,count(*) as loans,
 sum(principal_outstanding_cents)/100 as outstanding_principal,
 sum(interest_outstanding_cents)/100 as unpaid_interest,
 sum(balance_cents)/100 as contractual_balance
from public.loan_register
group by currency,status order by currency,status;
rollback;
