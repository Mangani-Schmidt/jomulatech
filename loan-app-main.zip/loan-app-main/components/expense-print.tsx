"use client";
import { formatBusinessTimestamp } from "@/lib/business-time";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { ExpenseReport } from "@/lib/expense-report";
import { businessDate } from "@/lib/domain";
export function ExpensePrint({
  report,
  onClose,
  verify,
}: {
  report: ExpenseReport;
  onClose: () => void;
  verify: () => Promise<void>;
}) {
  const ref = useRef<HTMLDialogElement>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    ref.current?.showModal();
  }, []);
  const fmt = (n: number) =>
    new Intl.NumberFormat("en-ZM", {
      style: "currency",
      currency: report.filters.currency,
    }).format(n / 100);
  return createPortal(
    <dialog
      className="report-document expense-document"
      ref={ref}
      aria-label="Expense print preview"
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
    >
      <div className="print-actions">
        <button
          className="button primary"
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            setError("");
            try {
              await verify();
              window.print();
            } catch (e) {
              setError((e as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          Print Expenses
        </button>
        <button className="button secondary" disabled={busy} onClick={onClose}>
          Close expense preview
        </button>
      </div>
      {error && <p role="alert">{error}</p>}
      <article className="print-area">
        <header className="document-header">
          <h1>LendTrack · Expense report</h1>
          <p>
            Activity {report.filters.from} to {report.filters.to} (inclusive) ·{" "}
            {report.filters.currency} · Africa/Lusaka
          </p>
          <p>
            Search: {report.filters.search || "All"} · Category:{" "}
            {report.filters.category || "All"} · Current status:{" "}
            {report.filters.status || "All"}
          </p>
          <p>
            Generated {formatBusinessTimestamp(report.generated_at)}{" "}
            Africa/Lusaka · All {report.items.length} filtered expenses
          </p>
        </header>
        <table>
          <thead>
            <tr>
              {[
                "Reference / payment date",
                "Category / payee / description",
                "Reversal date",
                "Paid in period",
                "Reversed in period",
                "Net in period",
              ].map((h) => (
                <th key={h}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {report.items.map(({ expense: e, paid, reversed, net }) => (
              <tr key={e.id}>
                <td>
                  {e.expense_reference}
                  <br />
                  {e.expense_date}
                </td>
                <td>
                  {e.category} · {e.payee ?? "—"}
                  <br />
                  {e.description}
                  <br />
                  {e.reversed_at ? "Reversed" : "Posted"}
                </td>
                <td>{e.reversed_at ? businessDate(e.reversed_at) : "—"}</td>
                <td>{fmt(paid)}</td>
                <td>{fmt(reversed)}</td>
                <td>{fmt(net)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <th colSpan={3}>TOTAL</th>
              <td>{fmt(report.paid)}</td>
              <td>{fmt(report.reversed)}</td>
              <td>{fmt(report.net)}</td>
            </tr>
          </tfoot>
        </table>
        <p>
          Payments minus reversals effective in the period; shared business
          expenses are not allocated to Clients. This report does not calculate
          Net Profit.
        </p>
      </article>
    </dialog>,
    document.body,
  );
}
