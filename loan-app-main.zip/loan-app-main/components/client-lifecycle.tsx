"use client";
import { RequiredMark } from "./form-controls";
import { useEffect, useRef, useState } from "react";
import { useSupabase } from "@/lib/workspace-context";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import { hasCapability } from "@/lib/access";
import type { Client } from "@/lib/domain";
export function ClientLifecycle({
  client,
  onSaved,
  onBusy,
}: {
  client: Client;
  onSaved: () => Promise<void>;
  onBusy: (busy: boolean) => void;
}) {
  const db = useSupabase(),
    defaults = useLoanDefaults();
  const canDelete = hasCapability(
      defaults.value?.capabilities,
      "can_delete_clients",
    ),
    canArchive = hasCapability(
      defaults.value?.capabilities,
      "can_register_clients",
    );
  const [status, setStatus] = useState<{
      can_delete: boolean;
      reason: string | null;
    } | null>(null),
    [error, setError] = useState(""),
    [reason, setReason] = useState(""),
    [confirmed, setConfirmed] = useState(false),
    [busy, setBusy] = useState(false);
  const request = useRef<{ payload: string; id: string } | null>(null);
  useEffect(() => {
    let live = true;
    setStatus(null);
    if (db && (canDelete || canArchive))
      void db
        .rpc("client_deletion_status", { p_client_id: client.id })
        .then((r) => {
          if (!live) return;
          if (r.error)
            setError(
              "Could not verify deletion eligibility. Try reopening Client Details.",
            );
          else setStatus(r.data);
        });
    return () => {
      live = false;
    };
  }, [db, client.id, client.revision, canDelete, canArchive]);
  if (!db || (!canDelete && !canArchive)) return null;
  async function act(remove: boolean) {
    if (busy || !confirmed || reason.trim().length < 5) return;
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      const body = {
        p_client_id: client.id,
        p_expected_revision: client.revision,
        p_reason: reason.trim(),
      };
      let result;
      if (remove) {
        const payload = JSON.stringify(body);
        if (request.current?.payload !== payload)
          request.current = { payload, id: crypto.randomUUID() };
        result = await db!.rpc("delete_client", {
          ...body,
          p_confirm: true,
          p_request_id: request.current.id,
        });
      } else
        result = await db!.rpc("correct_client", {
          ...body,
          p_details: Object.fromEntries(
            [
              "man_number",
              "name",
              "department",
              "designation",
              "phone",
              "email",
              "address",
            ]
              .map((key) => [key, client[key as keyof Client] ?? null])
              .concat([["is_active", false]]),
          ),
        });
      if (result.error) throw result.error;
      await onSaved();
    } catch (e) {
      setError(
        (e as { message?: string }).message ??
          "Could not complete Client action.",
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  return (
    <section className="panel" aria-label="Client deletion and archival">
      <h3>Delete or Archive Client</h3>
      <p>
        Archiving keeps the Client and all history, and prevents new loans.
        Unsubmitted edits above are not saved by these actions. The marked
        reason and confirmation are required only for Delete or Archive.
      </p>
      {!status ? (
        <p role="status">Checking retention and linked records…</p>
      ) : (
        <p>
          {status.reason ??
            "No linked financial/import records or retention hold prevents deletion. The permanent audit identity and history will remain."}
        </p>
      )}
      <label>
        <span className="field-label">
          Deletion / archival reason <RequiredMark />
        </span>
        <input
          value={reason}
          maxLength={500}
          onChange={(e) => {
            setReason(e.target.value);
            setConfirmed(false);
          }}
        />
      </label>
      <label className="checkbox-label">
        <input
          type="checkbox"
          checked={confirmed}
          onChange={(e) => setConfirmed(e.target.checked)}
        />
        <RequiredMark /> I confirm the selected Client action and retention of
        audit history.
      </label>
      <div className="modal-actions">
        {canArchive && client.is_active && (
          <button
            type="button"
            className="button secondary"
            disabled={busy || !confirmed || reason.trim().length < 5}
            onClick={() => void act(false)}
          >
            Archive/Deactivate
          </button>
        )}
        {canDelete && (
          <button
            type="button"
            className="button secondary"
            disabled={
              busy ||
              !status?.can_delete ||
              !confirmed ||
              reason.trim().length < 5
            }
            onClick={() => void act(true)}
          >
            Delete Client permanently
          </button>
        )}
      </div>
      {error && (
        <p role="alert" className="notice error">
          {error}
        </p>
      )}
    </section>
  );
}
