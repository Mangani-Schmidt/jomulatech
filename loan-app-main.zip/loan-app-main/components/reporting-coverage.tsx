"use client";
import { Form, RequiredMark } from "./form-controls";
import { hasCapability } from "@/lib/access";
import { useRef, useState } from "react";
import { useSupabase } from "@/lib/workspace-context";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import {
  type ReportFilters,
  type ReportingCertification,
} from "@/lib/reporting";
export function ReportingCoverage({
  filters,
  eventCount,
  certification,
  onChanged,
}: {
  filters: ReportFilters;
  eventCount?: number;
  certification: ReportingCertification | null;
  onChanged: () => void;
}) {
  const supabase = useSupabase();
  const defaults = useLoanDefaults();
  const [reason, setReason] = useState(""),
    [expenses, setExpenses] = useState(false),
    [losses, setLosses] = useState(false),
    [approve, setApprove] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const request = useRef<{ payload: string; id: string } | null>(null);
  const businessScope = ![
    filters.search.trim(),
    filters.department,
    filters.designation,
    filters.status,
    filters.disbursedFrom,
    filters.disbursedTo,
  ].some(Boolean);
  if (
    !supabase ||
    !hasCapability(defaults.value?.capabilities, "can_approve_adjustments")
  )
    return null;
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const body = certification
        ? {
            p_id: certification.id,
            p_reason: reason.trim(),
            p_confirm: approve,
          }
        : {
            p_from: filters.from,
            p_to: filters.to,
            p_currency: filters.currency,
            p_reason: reason.trim(),
            p_expenses_complete: expenses,
            p_losses_complete: losses,
            p_expected_event_count: eventCount,
            p_confirm: approve,
          };
      const payload = JSON.stringify(body);
      if (request.current?.payload !== payload)
        request.current = { payload, id: crypto.randomUUID() };
      const r = await supabase!.rpc(
        certification
          ? "revoke_reporting_certification"
          : "certify_reporting_period",
        { ...body, p_request_id: request.current.id },
      );
      if (r.error) throw r.error;
      setReason("");
      setExpenses(false);
      setLosses(false);
      setApprove(false);
      request.current = null;
      onChanged();
    } catch (e) {
      setError(
        (e as { message?: string }).message ??
          "Could not save coverage approval.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <details className="panel settings-panel">
      <summary>Reporting coverage approval</summary>
      <p>
        Business scope only. Certify that all paid expenses and recognized
        losses for {filters.from} to {filters.to}, {filters.currency}, are
        complete under the cash-interest policy. This is an Administrator
        attestation, not an automatic accounting certification. Any later
        financial event invalidates it until reviewed again.
      </p>
      {!businessScope ? (
        <p role="status">
          Clear Client and loan filters to approve business-wide coverage.
        </p>
      ) : (
        <Form onSubmit={submit}>
          <fieldset disabled={busy}>
            <label>
              <span className="field-label">
                <RequiredMark />
                Coverage approval or revocation reason
              </span>
              <textarea
                required
                minLength={5}
                maxLength={500}
                value={reason}
                onChange={(e) => {
                  setReason(e.target.value);
                  setApprove(false);
                }}
              />
            </label>
            {!certification && (
              <>
                <label className="checkbox-label">
                  <RequiredMark />
                  <input
                    type="checkbox"
                    required
                    checked={expenses}
                    onChange={(e) => {
                      setExpenses(e.target.checked);
                      setApprove(false);
                    }}
                  />
                  All paid business expenses for this period are recorded,
                  including an explicitly reviewed zero-expense period.
                </label>
                <label className="checkbox-label">
                  <RequiredMark />
                  <input
                    type="checkbox"
                    required
                    checked={losses}
                    onChange={(e) => {
                      setLosses(e.target.checked);
                      setApprove(false);
                    }}
                  />
                  All recognized principal losses and their reversals for this
                  period are recorded.
                </label>
              </>
            )}
            <label className="checkbox-label">
              <RequiredMark />
              <input
                type="checkbox"
                required
                checked={approve}
                onChange={(e) => setApprove(e.target.checked)}
              />
              I approve{" "}
              {certification
                ? "revoking this coverage certification"
                : "this period and snapshot for business Net Profit reporting"}
              .
            </label>
            <button
              className="button primary"
              disabled={
                busy ||
                !approve ||
                (!certification &&
                  (!expenses || !losses || eventCount === undefined))
              }
            >
              {busy
                ? "Saving…"
                : certification
                  ? "Revoke coverage approval"
                  : "Approve reporting coverage"}
            </button>
          </fieldset>
        </Form>
      )}
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
    </details>
  );
}
