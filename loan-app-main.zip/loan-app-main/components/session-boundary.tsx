"use client";
import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { usePathname } from "next/navigation";
import type { Session } from "@supabase/supabase-js";
import { getSupabase } from "@/lib/supabase";
import {
  activityKey,
  INACTIVITY_MS,
  inactivityRemaining,
  readActivity,
  saveActivity,
  sessionIdentity,
  sessionReadyForRead,
  setSessionBinding,
  SESSION_CHANNEL,
  SESSION_EXPIRED_EVENT,
  SESSION_RESUMED_EVENT,
  SESSION_REVALIDATING_EVENT,
  SESSION_READY_EVENT,
  WARNING_MS,
  type ActivityRecord,
  validActivity,
} from "@/lib/session-activity";
import { clearPostingMemory, redactPostingStorage } from "@/lib/posting-intent";
type State =
  "checking" | "anonymous" | "active" | "unconfigured" | "error" | "expired";
const SessionContext = createContext<{
  state: State;
  start: (session: Session) => Promise<void>;
  logout: () => Promise<void>;
}>({ state: "checking", start: async () => {}, logout: async () => {} });
export const useSessionSafety = () => useContext(SessionContext);
export function SessionBoundary({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const demo = pathname === "/demo" || pathname.startsWith("/demo/");
  const [state, setState] = useState<State>("checking"),
    [remaining, setRemaining] = useState(INACTIVITY_MS),
    [working, setWorking] = useState(false);
  const action = useRef<{
    start: (s: Session) => Promise<void>;
    stay: () => Promise<void>;
    logout: () => Promise<void>;
    retry: () => void;
  }>({
    start: async () => {},
    stay: async () => {},
    logout: async () => {},
    retry: () => {},
  });
  const dialog = useRef<HTMLDialogElement>(null),
    generation = useRef(0);
  useEffect(() => {
    if (demo) {
      setState("unconfigured");
      return;
    }
    const db = getSupabase();
    if (!db) {
      setState("unconfigured");
      return;
    }
    let disposed = false,
      session: Session | null = null,
      id = "",
      last = 0,
      lastMono = 0,
      lastSent = 0,
      dirty = false,
      ending = false,
      channel: BroadcastChannel | null = null,
      checking = false;
    const mine = ++generation.current;
    const live = () => !disposed && mine === generation.current;
    const leftNow = () =>
      Math.max(
        0,
        INACTIVITY_MS -
          Math.max(Date.now() - last, performance.now() - lastMono),
      );
    function mergeActivity(at: number) {
      if (at > last) {
        last = at;
        lastMono = performance.now() - Math.max(0, Date.now() - at);
      }
    }

    try {
      channel = new BroadcastChannel(SESSION_CHANNEL);
    } catch {}
    const publish = (record: ActivityRecord) => {
      saveActivity(record);
      channel?.postMessage(record);
    };
    const unlock = () => {
      if (!live() || ending || !id) return;
      setSessionBinding({ session: id, at: last, blocked: false });
      document.documentElement.removeAttribute("data-session-locked");
      setState("active");
      setRemaining(leftNow());
    };
    async function expire(
      reason: "inactive" | "signed-out" = "inactive",
      broadcast = true,
    ) {
      if (ending || !live()) return;
      ending = true;
      setSessionBinding({ session: id, at: last, blocked: true });
      document.documentElement.setAttribute("data-session-locked", "true");
      clearPostingMemory();
      redactPostingStorage();
      setState("expired");
      if (id && broadcast)
        publish({ session: id, at: Date.now(), ended: true });
      // A local route change happens regardless of network availability. The
      // server clock still denies data after expiry if revocation cannot arrive.
      const stop = Promise.resolve(
        db!.rpc("end_app_session", { p_reason: reason }),
      )
        .then(() => db!.auth.signOut({ scope: "local" }))
        .catch(() => db!.auth.signOut({ scope: "local" }));
      await Promise.race([
        stop,
        new Promise((resolve) => window.setTimeout(resolve, 1500)),
      ]);
      if (!live()) return;
      // Supported local sign-out normally removes SDK credentials. Explicitly
      // remove only this project's cached Auth record if its network call failed.
      const project = new URL(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
      ).hostname.split(".")[0];
      try {
        localStorage.removeItem(`sb-${project}-auth-token`);
      } catch {}
      window.location.replace(`/login?reason=${reason}`);
    }
    async function activate(next: Session) {
      const candidate = sessionIdentity(next);
      session = next;
      if (candidate === id && last) {
        if (leftNow() === 0) await expire();
        return;
      }
      if (id && id !== candidate) {
        clearPostingMemory();
        redactPostingStorage();
      }
      id = candidate;
      last = 0;
      ending = false;
      setState("checking");
      setSessionBinding({ session: id, at: 0, blocked: true });
      const stored = readActivity(id);
      if (stored?.ended || (stored && inactivityRemaining(stored.at) === 0)) {
        last = stored.at;
        await expire();
        return;
      }
      const status = await db!.rpc("app_session_status");
      if (!live() || ending || id !== candidate) return;
      if (status.error) throw new Error("Could not check the current session.");
      let data = status.data;
      if (!data?.registered) {
        const fresh = await db!.rpc("touch_app_session");
        if (fresh.error)
          throw new Error("Could not start the application session.");
        data = fresh.data;
      }
      if (!live() || ending || id !== candidate) return;
      if (!data?.active) {
        last = stored?.at ?? Date.now() - INACTIVITY_MS;
        await expire();
        return;
      }
      const elapsed = Math.max(
        0,
        Date.parse(data.server_now) - Date.parse(data.last_activity_at),
      );
      const serverAt = Number.isFinite(elapsed)
        ? Date.now() - elapsed
        : Date.now();
      last = Math.max(stored?.at ?? 0, serverAt);
      lastMono = performance.now() - Math.max(0, Date.now() - last);
      lastSent = Date.now();
      saveActivity({ session: id, at: last });
      unlock();
      window.dispatchEvent(new Event(SESSION_READY_EVENT));
    }
    async function touch() {
      if (!id || ending || checking) return;
      checking = true;
      dirty = false;
      const captured = id;
      try {
        const result = await db!.rpc("touch_app_session");
        if (!live() || ending || id !== captured) return;
        if (result.error) throw result.error;
        if (!result.data?.active) {
          await expire();
          return;
        }
        lastSent = Date.now();
        unlock();
      } catch {
        if (live() && !ending) {
          setState("error");
          setSessionBinding({ session: id, at: last, blocked: true });
        }
      } finally {
        checking = false;
      }
    }
    function activity(event?: Event) {
      if (!id || !last || ending || (event && !event.isTrusted)) return;
      if (
        event instanceof KeyboardEvent &&
        ["Shift", "Control", "Alt", "Meta"].includes(event.key)
      )
        return;
      if (dialog.current?.open && event) return;
      const stored = readActivity(id);
      if (stored) mergeActivity(stored.at);
      if (stored?.ended || leftNow() === 0) {
        void expire();
        return;
      }
      last = Date.now();
      lastMono = performance.now();
      dirty = true;
      publish({ session: id, at: last });
      setSessionBinding({ session: id, at: last, blocked: false });
      setRemaining(INACTIVITY_MS);
      if (event && Date.now() - lastSent >= 5000) void touch();
    }
    function receive(record: unknown) {
      if (!id || ending || !validActivity(record, id)) return;
      if (record.ended) {
        void expire("inactive", false);
        return;
      }
      mergeActivity(record.at);
      setSessionBinding({ session: id, at: last, blocked: false });
      setRemaining(leftNow());
    }
    const stored = (event: StorageEvent) => {
      if (event.key === activityKey(id) && event.newValue) {
        try {
          receive(JSON.parse(event.newValue));
        } catch {}
      }
    };
    const incoming = (event: MessageEvent) => receive(event.data);
    let resuming: Promise<void> | null = null;
    async function resume() {
      // A new sign-in has no verified timestamp until activation finishes.
      // Initialization is not inactivity; keep protected content locked.
      if (document.visibilityState === "hidden" || !id || !last || ending)
        return;
      const shared = readActivity(id);
      if (shared) mergeActivity(shared.at);
      if (shared?.ended || leftNow() === 0) {
        await expire();
        return;
      }
      // Paired visibility/focus events share one in-flight server check. Neither
      // event is activity; local expiry is checked above even during that request.
      if (resuming) return resuming;
      const captured = id,
        startedAt = Date.now();
      // This is an already verified local session, checked above for elapsed
      // inactivity. Business RPCs may refresh in parallel: each still enforces
      // the database session clock, JWT, capabilities and RLS independently.
      if (sessionReadyForRead(id))
        window.dispatchEvent(
          new CustomEvent(SESSION_REVALIDATING_EVENT, {
            detail: { startedAt },
          }),
        );
      resuming = (async () => {
        const status = await db!.rpc("app_session_status");
        if (!live() || ending || id !== captured) return;
        if (status.error) {
          setState("error");
          setSessionBinding({ session: id, at: last, blocked: true });
        } else if (!status.data?.active) await expire();
        else
          window.dispatchEvent(
            new CustomEvent(SESSION_RESUMED_EVENT, { detail: { startedAt } }),
          );
      })()
        .catch(() => {
          if (live() && !ending && id === captured) {
            setState("error");
            setSessionBinding({ session: id, at: last, blocked: true });
          }
        })
        .finally(() => {
          resuming = null;
        });
      return resuming;
    }
    const expired = () => {
      if (id) void expire();
    };
    const events = [
      "pointerdown",
      "keydown",
      "wheel",
      "touchstart",
      "input",
    ] as const;
    events.forEach((name) =>
      window.addEventListener(name, activity, { passive: true }),
    );
    window.addEventListener("storage", stored);
    channel?.addEventListener("message", incoming);
    window.addEventListener("focus", resume);
    document.addEventListener("visibilitychange", resume);
    window.addEventListener(SESSION_EXPIRED_EVENT, expired);
    const timer = window.setInterval(() => {
      // Never treat a pending first status/touch request as an expired session.
      if (!id || !last || ending) return;
      const shared = readActivity(id);
      if (shared?.ended) {
        void expire("inactive", false);
        return;
      }
      if (shared) mergeActivity(shared.at);
      const left = leftNow();
      setRemaining(left);
      if (!left) {
        void expire();
        return;
      }
      if (dirty && Date.now() - lastSent >= 5000) {
        if (Date.now() - last <= 5000) void touch();
        else dirty = false;
      }
    }, 1000);
    action.current = {
      start: activate,
      stay: async () => {
        if (!id) return;
        activity();
        await touch();
      },
      logout: () => expire("signed-out"),
      retry: () => {
        if (!session) return;
        if (!last) {
          void activate(session).catch(() => setState("error"));
          return;
        }
        void resume().then(() => {
          if (!ending) void touch();
        });
      },
    };
    const changed = (_event: string, next: Session | null) => {
      if (!live()) return;
      if (!next) {
        if (ending) return;
        const ended = id ? readActivity(id)?.ended : false;
        if (ended) {
          void expire("inactive", false);
          return;
        }
        const hadSession = !!id;
        id = "";
        last = 0;
        setSessionBinding(null);
        clearPostingMemory();
        redactPostingStorage();
        setState("anonymous");
        if (
          hadSession &&
          !["/", "/login", "/signup", "/forgot-password"].includes(
            window.location.pathname,
          )
        ) {
          document.documentElement.setAttribute("data-session-locked", "true");
          window.location.replace("/login?reason=signed-out");
        } else document.documentElement.removeAttribute("data-session-locked");
        return;
      }
      if (sessionIdentity(next) === id && last) {
        session = next;
        return;
      } // refresh/polling is not activity
      queueMicrotask(() => {
        if (live())
          void activate(next).catch(() => {
            if (live()) setState("error");
          });
      });
    };
    const {
      data: { subscription },
    } = db.auth.onAuthStateChange(changed);
    return () => {
      disposed = true;
      generation.current++;
      subscription.unsubscribe();
      window.clearInterval(timer);
      events.forEach((name) => window.removeEventListener(name, activity));
      window.removeEventListener("storage", stored);
      window.removeEventListener("focus", resume);
      document.removeEventListener("visibilitychange", resume);
      window.removeEventListener(SESSION_EXPIRED_EVENT, expired);
      channel?.close();
    };
  }, [demo]);
  const warning =
    state === "active" && remaining > 0 && remaining <= WARNING_MS;
  useEffect(() => {
    if (warning && !dialog.current?.open) dialog.current?.showModal();
    else if (!warning) dialog.current?.close();
  }, [warning]);
  const publicRoute =
    demo || ["/", "/login", "/signup", "/forgot-password"].includes(pathname);
  const usable =
    publicRoute ||
    state === "active" ||
    state === "unconfigured" ||
    state === "anonymous";
  const contextValue = useMemo(
    () => ({
      state,
      start: (session: Session) => action.current.start(session),
      logout: () => action.current.logout(),
    }),
    [state],
  );
  return (
    <SessionContext.Provider value={contextValue}>
      {state === "expired" ? (
        <main className="auth-card">
          <h1>Session ended</h1>
          <p role="status">Clearing this workspace and returning to Log In…</p>
        </main>
      ) : (
        <>
          <div data-session-content hidden={!usable} inert={!usable}>
            {children}
          </div>
          {!usable && (
            <main className="auth-card">
              <h1>
                {state === "error"
                  ? "Session check unavailable"
                  : "Checking your session…"}
              </h1>
              <p role="status">
                {state === "error"
                  ? "Your workspace is hidden until the session can be verified."
                  : "Please wait."}
              </p>
              {state === "error" && (
                <>
                  <button
                    type="button"
                    className="button primary"
                    onClick={() => action.current.retry()}
                  >
                    Retry session check
                  </button>
                  <button
                    type="button"
                    className="button secondary"
                    onClick={() => void action.current.logout()}
                  >
                    Log Out
                  </button>
                </>
              )}
            </main>
          )}
          <dialog
            ref={dialog}
            aria-labelledby="inactivity-title"
            className="inactivity-warning"
            onCancel={(event) => event.preventDefault()}
          >
            <h2 id="inactivity-title">Are you still there?</h2>
            <p>
              Your session ends after 15 minutes without interaction. You will
              be logged out in {Math.ceil(remaining / 1000)} seconds.
            </p>
            <div className="modal-actions">
              <button
                type="button"
                className="button secondary"
                disabled={working}
                onClick={() => void action.current.logout()}
              >
                Log Out
              </button>
              <button
                type="button"
                className="button primary"
                disabled={working}
                autoFocus
                onClick={async () => {
                  setWorking(true);
                  try {
                    await action.current.stay();
                  } finally {
                    setWorking(false);
                  }
                }}
              >
                Stay Signed In
              </button>
            </div>
          </dialog>
        </>
      )}
    </SessionContext.Provider>
  );
}
