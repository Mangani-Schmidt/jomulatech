"use client";
import { WorkspaceNavigation } from "./workspace-navigation";
import { AuditHistory } from "./audit-history";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
export function AuditLogs() {
  const defaults = useLoanDefaults();
  return (
    <main
      className="settings-page standalone-page"
      id="workspace-content"
      tabIndex={-1}
    >
      <WorkspaceNavigation
        current="Audit Logs"
        capabilities={defaults.value?.capabilities}
        standalone
      />
      <div className="page-heading">
        <div>
          <div className="eyebrow">ACCOUNTABILITY</div>
          <h1>Audit Logs</h1>
          <p>Immutable user, permission, Client and financial history.</p>
        </div>
      </div>
      <AuditHistory source="audit_events" title="Business audit history" />
    </main>
  );
}
