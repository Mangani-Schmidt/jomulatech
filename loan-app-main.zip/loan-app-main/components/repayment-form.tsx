"use client";
import { Form, RequiredMark, DateInput } from "./form-controls";
import { useRef, useState } from "react";
import {
  type Loan,
  type Client,
  type Repayment,
  isCollectible,
  money,
  today,
} from "@/lib/domain";
import {
  paymentMethods,
  receivedCents,
  repaymentAllocation,
  outstandingParts,
} from "@/lib/repayments";
import { FinancialReview } from "./financial-review";
import { useSupabase } from "@/lib/workspace-context";
import { usePostingIntent } from "@/lib/use-posting-intent";
import { PostingRecovery } from "./posting-recovery";
export function RepaymentForm({
  loans,
  clients,
  selectedId = "",
  original,
  onSaved,
  onCancel,
  onBusy,
}: {
  loans: Loan[];
  clients: Client[];
  selectedId?: string;
  original?: Repayment;
  onSaved: (id: string) => Promise<void>;
  onCancel?: () => void;
  onBusy: (busy: boolean) => void;
}) {
  const supabase = useSupabase();
  const [loanId, setLoanId] = useState(original?.loan_id ?? selectedId);
  const [amount, setAmount] = useState(
    original ? String(original.amount_cents / 100) : "",
  );
  const [date, setDate] = useState(original?.payment_date ?? today());
  const [method, setMethod] = useState(
    original?.payment_method && original.payment_method !== "not_recorded"
      ? original.payment_method
      : "",
  );
  const [external, setExternal] = useState(original?.external_reference ?? "");
  const [reason, setReason] = useState("");
  const [reviewing, setReviewing] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const form = useRef<HTMLFormElement>(null);
  const intent = usePostingIntent();
  const blocked = intent.checking || !!intent.pending || !!intent.storageError;
  const [freshLoan, setFreshLoan] = useState<Loan | null>(null);
  const loan =
    freshLoan?.id === loanId ? freshLoan : loans.find((l) => l.id === loanId);
  let allocation: ReturnType<typeof repaymentAllocation> | null = null;
  let validation = "";
  try {
    if (loan && amount)
      allocation = repaymentAllocation(loan, receivedCents(amount), original);
  } catch (e) {
    validation = e instanceof Error ? e.message : "Invalid amount.";
  }
  function edit() {
    setConfirm(false);
    setReviewing(false);
    setError("");
  }
  async function reload() {
    if (!supabase || !loan) return;
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      const { data, error } = await supabase
        .from("loan_register")
        .select("*")
        .eq("id", loan.id)
        .single();
      if (error) throw error;
      setFreshLoan(data as Loan);
      setConfirm(false);
      setReviewing(false);
    } catch {
      setError("Could not reload the loan.");
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (blocked) return;
    if (!loan || !allocation) return;
    if (!reviewing) {
      setReviewing(true);
      setConfirm(false);
      return;
    }
    if (!confirm) return;
    setBusy(true);
    onBusy(true);
    setError("");
    let posted = false;
    try {
      if (!supabase)
        throw new Error("Connect Supabase and sign in to post a payment.");
      const parts = outstandingParts(loan);
      const details = {
        loan_id: loan.id,
        amount_cents: receivedCents(amount),
        payment_date: date,
        payment_method: method,
        external_reference: external.trim() || null,
        expected_balance_cents: loan.balance_cents,
        expected_terms_revision: loan.terms_revision,
        expected_interest_outstanding_cents: parts.interest,
        expected_principal_outstanding_cents: parts.principal,
      };
      const body = original
        ? {
            p_repayment_id: original.id,
            p_details: details,
            p_reason: reason.trim(),
            p_confirm: confirm,
          }
        : { p_details: details, p_confirm: confirm };
      const data = await intent.post(
        original ? "correct_repayment" : "post_repayment",
        body,
      );
      posted = true;
      await onSaved(data.repayment_id);
      await intent.complete();
    } catch (e) {
      setError(
        posted
          ? "Payment saved. Reload the ledger before further action."
          : e instanceof Error
            ? e.message
            : ((e as { message?: string }).message ??
              "Could not save payment."),
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  async function recover() {
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      const saved = await intent.recover();
      if (
        saved.operation === "post_repayment" ||
        saved.operation === "correct_repayment"
      )
        await onSaved(saved.result.repayment_id);
      await intent.complete();
      if (saved.operation === "originate_loan")
        window.location.assign("/dashboard/#loan-history");
      if (saved.operation === "post_expense")
        window.location.assign("/expenses");
    } catch (e) {
      setError(
        (e as { message?: string }).message ??
          "Recovery could not be completed. Keep the original request reference and retry recovery.",
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  return (
    <Form ref={form} onSubmit={submit} aria-busy={busy}>
      <PostingRecovery
        intent={intent}
        busy={busy}
        onRecover={() => void recover()}
      />
      <fieldset disabled={busy || reviewing || blocked} hidden={reviewing}>
        <p className="mode-explanation">
          Interest-first allocation: Repayment Received pays outstanding
          interest, then principal, in posting order. Payment dates do not
          reorder posted allocations.
        </p>
        <label>
          <span className="field-label">
            <RequiredMark />
            Loan
          </span>
          <select
            required
            value={loanId}
            disabled={!!original || busy}
            onChange={(e) => {
              edit();
              setLoanId(e.target.value);
              setFreshLoan(null);
            }}
          >
            <option value="">Select a loan</option>
            {loans
              .filter((l) => isCollectible(l) || l.id === original?.loan_id)
              .map((l) => (
                <option key={l.id} value={l.id}>
                  {clients.find((c) => c.id === l.client_id)?.name ?? "Client"}{" "}
                  · {l.loan_reference ?? l.id} · {money(l.balance_cents)}{" "}
                  outstanding
                </option>
              ))}
          </select>
        </label>
        <label>
          <span className="field-label">
            <RequiredMark />
            Payment date
          </span>
          <DateInput
            required
            min={loan?.disbursement_date ?? "1900-01-01"}
            max={today()}
            value={date}
            onChange={(e) => {
              edit();
              setDate(e.target.value);
            }}
          />
        </label>
        <label>
          <span className="field-label">
            <RequiredMark />
            Repayment Received (ZMW)
          </span>
          <input
            required
            name="amount"
            inputMode="decimal"
            value={amount}
            onChange={(e) => {
              edit();
              setAmount(e.target.value);
            }}
            placeholder="0.00"
          />
        </label>
        <label>
          <span className="field-label">
            <RequiredMark />
            Payment method
          </span>
          <select
            required
            aria-label="Payment method"
            value={method}
            onChange={(e) => {
              edit();
              setMethod(e.target.value);
            }}
          >
            <option value="">Choose method</option>
            {Object.entries(paymentMethods).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label>
          External reference
          <input
            maxLength={120}
            value={external}
            onChange={(e) => {
              edit();
              setExternal(e.target.value);
            }}
          />
        </label>
        {original && (
          <>
            <p className="form-hint">
              This adjustment reverses{" "}
              {original.payment_reference ?? original.id} and posts a linked
              replacement on the same loan in one transaction. The original
              stays visible. No physical refund or new disbursement is made.
            </p>
            <label>
              <span className="field-label">
                <RequiredMark />
                Adjustment reason
              </span>
              <input
                required
                minLength={5}
                maxLength={500}
                value={reason}
                onChange={(e) => {
                  edit();
                  setReason(e.target.value);
                }}
              />
            </label>
          </>
        )}
        {loan && (
          <button
            className="text-button"
            type="button"
            disabled={busy || !supabase}
            onClick={reload}
          >
            Reload current balance and allocations
          </button>
        )}
      </fieldset>
      {!reviewing && (
        <>
          {allocation && (
            <section
              className="loan-summary"
              aria-label="Repayment allocation preview"
            >
              <dl>
                <div>
                  <dt>Interest allocation</dt>
                  <dd>{money(allocation.interest)}</dd>
                </div>
                <div>
                  <dt>Principal allocation</dt>
                  <dd>{money(allocation.principal)}</dd>
                </div>
                <div>
                  <dt>Outstanding after posting</dt>
                  <dd>{money(allocation.balanceAfter)}</dd>
                </div>
              </dl>
            </section>
          )}
          <div className="modal-actions">
            {onCancel && (
              <button
                type="button"
                className="button secondary"
                onClick={onCancel}
                disabled={busy}
              >
                Cancel
              </button>
            )}
            <button
              className="button primary"
              disabled={
                busy ||
                blocked ||
                !loan ||
                !allocation ||
                !method ||
                (!!original && reason.trim().length < 5)
              }
            >
              Review Repayment
            </button>
          </div>
        </>
      )}
      {reviewing && loan && allocation && (
        <FinancialReview
          title={
            original
              ? "Confirm Repayment Adjustment"
              : "Confirm Repayment Received"
          }
        >
          <dl className="review-details">
            <div>
              <dt>Client</dt>
              <dd>
                {clients.find((c) => c.id === loan.client_id)?.name ?? "Client"}{" "}
                · Man#{" "}
                {clients.find((c) => c.id === loan.client_id)?.man_number ??
                  "Not recorded"}
              </dd>
            </div>
            <div>
              <dt>Loan reference</dt>
              <dd>{loan.loan_reference ?? loan.id}</dd>
            </div>
            <div>
              <dt>Payment date</dt>
              <dd>{date}</dd>
            </div>
            <div>
              <dt>Repayment Received</dt>
              <dd>{money(receivedCents(amount))}</dd>
            </div>
            <div>
              <dt>Payment method</dt>
              <dd>{paymentMethods[method as keyof typeof paymentMethods]}</dd>
            </div>
            {external && (
              <div>
                <dt>External reference</dt>
                <dd>{external}</dd>
              </div>
            )}
            {original && (
              <div>
                <dt>Adjustment reason</dt>
                <dd>{reason}</dd>
              </div>
            )}
          </dl>
          {allocation && (
            <section
              className="loan-summary"
              aria-label="Repayment allocation preview"
            >
              <dl>
                <div>
                  <dt>Interest allocation</dt>
                  <dd>{money(allocation.interest)}</dd>
                </div>
                <div>
                  <dt>Principal allocation</dt>
                  <dd>{money(allocation.principal)}</dd>
                </div>
                <div>
                  <dt>Outstanding after posting</dt>
                  <dd>{money(allocation.balanceAfter)}</dd>
                </div>
              </dl>
            </section>
          )}
          <label className="checkbox-label">
            <RequiredMark />
            <input
              type="checkbox"
              required
              checked={confirm}
              disabled={busy || !allocation}
              onChange={(e) => setConfirm(e.target.checked)}
            />
            I confirm the payment date, amount, method, and interest-first
            allocation.
          </label>
          <div className="modal-actions">
            <button
              type="button"
              className="button secondary"
              disabled={busy}
              onClick={() => {
                setReviewing(false);
                setConfirm(false);
                requestAnimationFrame(() =>
                  form.current
                    ?.querySelector<HTMLInputElement>("input[name=amount]")
                    ?.focus(),
                );
              }}
            >
              Back to Repayment Details
            </button>
            <button
              className="button primary"
              disabled={busy || blocked || !confirm}
            >
              {busy
                ? "Posting Repayment…"
                : original
                  ? "Save audited payment adjustment"
                  : "Confirm Repayment Received"}
            </button>
          </div>
        </FinancialReview>
      )}
      {busy && (
        <p role="status">Posting the confirmed repayment. Please wait…</p>
      )}
      {(error || validation) && (
        <p className="form-error" role="alert">
          {error || validation}
        </p>
      )}
    </Form>
  );
}
