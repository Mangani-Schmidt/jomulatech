"use client";
import { Form, RequiredMark, DateInput } from "./form-controls";
import { useEffect, useId, useRef, useState } from "react";
import { hasCapability } from "@/lib/access";
import { loanRateTerms } from "@/lib/loan-rate";
import { FinancialReview } from "./financial-review";
import { ClientLookup } from "./client-lookup";
import { useSupabase } from "@/lib/workspace-context";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import { cents, money, today, type Client } from "@/lib/domain";
import { flatInterest, rateBps, dueDate } from "@/lib/interest";
import { usePostingIntent } from "@/lib/use-posting-intent";
import { PostingRecovery } from "./posting-recovery";
export function LoanOrigination({
  clients,
  authorized,
  onAdd,
  onCancel,
  onSaved,
  onBusy,
}: {
  clients: Client[];
  authorized: boolean;
  onAdd?: (query: string) => void;
  onCancel: () => void;
  onSaved: () => Promise<void>;
  onBusy: (value: boolean) => void;
}) {
  const supabase = useSupabase();
  const defaults = useLoanDefaults();
  const [client, setClient] = useState<Client | null>(null);
  const [principal, setPrincipal] = useState("");
  const [resetVersion, setResetVersion] = useState(0);
  const [rate, setRate] = useState(() =>
    defaults.value
      ? String(defaults.value.settings.default_rate_bps / 100)
      : "",
  );
  const [days, setDays] = useState(() =>
    defaults.value ? String(defaults.value.settings.default_term_days) : "",
  );
  const [date, setDate] = useState(today());
  const [reason, setReason] = useState("");
  const [reviewing, setReviewing] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const form = useRef<HTMLFormElement>(null);
  const intent = usePostingIntent();
  const blocked = intent.checking || !!intent.pending || !!intent.storageError;
  useEffect(() => {
    if (defaults.value) {
      setRate(String(defaults.value.settings.default_rate_bps / 100));
      setDays(String(defaults.value.settings.default_term_days));
      setReason("");
      setConfirmed(false);
      setReviewing(false);
    }
  }, [
    defaults.value?.settings.owner_id,
    defaults.value?.settings.revision,
    defaults.value?.capabilities.can_override_rate,
    resetVersion,
  ]);
  const rateHelp = useId();
  const errorId = useId();
  const canOverride = hasCapability(
    defaults.value?.capabilities,
    "can_override_rate",
  );
  const defaultRate = defaults.value
    ? String(defaults.value.settings.default_rate_bps / 100)
    : "";
  let selectedBps: number | null = null;
  let rateError = "";
  try {
    selectedBps = rateBps(rate);
  } catch (failure) {
    if (defaults.value)
      rateError =
        failure instanceof Error
          ? failure.message
          : "Enter a valid interest rate.";
  }
  const override =
    selectedBps !== null &&
    !!defaults.value &&
    selectedBps !== defaults.value.settings.default_rate_bps;
  let reviewedRate: ReturnType<typeof loanRateTerms> | null = null;
  let rateIssue = "";
  if (defaults.value) {
    try {
      reviewedRate = loanRateTerms(rate, defaults.value, reason);
    } catch (failure) {
      rateIssue =
        failure instanceof Error ? failure.message : "Review the loan rate.";
    }
  }
  let summary: {
    principal: number;
    interest: number;
    total: number;
    due: string;
    bps: number;
  } | null = null;
  let validation = "";
  try {
    const p = cents(principal);
    if (!defaults.value)
      throw new Error(
        "Load the current interest defaults before reviewing a loan.",
      );
    const bps = rateBps(rate);
    const settings = defaults.value.settings;
    const interest = flatInterest(
      p,
      bps,
      settings.calculation_method,
      settings.rate_basis,
    );
    summary = {
      principal: p,
      interest,
      total: p + interest,
      due: dueDate(date, Number(days)),
      bps,
    };
  } catch (e) {
    if (principal && defaults.value)
      validation =
        e instanceof Error
          ? e.message
          : "Review the amount and interest terms.";
  }
  function invalidate() {
    setConfirmed(false);
    setReviewing(false);
    setError("");
  }
  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (blocked || defaults.loading) return;
    if (!summary || !client || !defaults.value) return;
    if (!reviewedRate) {
      setError(rateIssue || "Review the loan rate and override reason.");
      return;
    }
    if (!reviewing) {
      setReviewing(true);
      setConfirmed(false);
      return;
    }
    if (!confirmed) return;
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      if (!supabase || !authorized)
        throw new Error(
          "Connect Supabase and sign in with an Administrator or Loan Officer role to post a loan.",
        );
      const settings = defaults.value.settings;
      const details = {
        client_id: client.id,
        expected_client_revision: client.revision,
        principal_cents: summary.principal,
        rate_bps: reviewedRate.bps,
        term_days: Number(days),
        disbursement_date: date,
        calculation_method: settings.calculation_method,
        rate_basis: settings.rate_basis,
        settings_revision: settings.revision,
        override_reason: reviewedRate.overrideReason,
      };
      await intent.post("originate_loan", {
        p_details: details,
        p_confirm: confirmed,
      });
      await onSaved();
      await intent.complete();
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : ((e as { message?: string }).message ??
              "Could not create the loan."),
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  async function recover() {
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      const saved = await intent.recover();
      if (saved.operation === "originate_loan") await onSaved();
      await intent.complete();
      if (saved.operation !== "originate_loan")
        window.location.assign(
          saved.operation === "post_expense"
            ? "/expenses"
            : "/dashboard/#repayments",
        );
    } catch (e) {
      setError(
        (e as { message?: string }).message ??
          "Could not recover the original transaction.",
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  return (
    <Form ref={form} onSubmit={submit} aria-busy={busy}>
      <PostingRecovery
        intent={intent}
        busy={busy}
        onRecover={() => void recover()}
      />
      <fieldset disabled={busy || reviewing || blocked} hidden={reviewing}>
        <p className="mode-explanation">
          Calculation method: one-time flat interest. Rate basis: the entire
          loan term. Interest = principal × rate ÷ 100. Total obligation =
          Amount Disbursed + interest.
        </p>
        {defaults.loading && <p role="status">Loading current defaults…</p>}
        {defaults.error && (
          <p className="form-error" role="alert">
            {defaults.error}
          </p>
        )}
        <ClientLookup
          clients={clients}
          onSelect={(c) => {
            invalidate();
            setClient(c);
          }}
          onAdd={onAdd}
        />
        <label>
          <span className="field-label">
            <RequiredMark />
            Amount Disbursed (ZMW)
          </span>
          <input
            name="principal"
            inputMode="decimal"
            required
            value={principal}
            onChange={(e) => {
              invalidate();
              setPrincipal(e.target.value);
            }}
            placeholder="0.00"
          />
        </label>
        <div className="form-row">
          <label>
            <span className="field-label">
              <RequiredMark />
              Interest rate for entire term (%)
            </span>
            <input
              name="rate"
              inputMode="decimal"
              required
              readOnly={!canOverride || defaults.loading}
              aria-describedby={rateHelp + (rateError ? " " + errorId : "")}
              aria-invalid={!!rateError || undefined}
              value={rate}
              onChange={(e) => {
                if (!canOverride) return;
                invalidate();
                setRate(e.target.value);
              }}
            />
          </label>
          <label>
            <span className="field-label">
              <RequiredMark />
              Loan term (days)
            </span>
            <input
              type="number"
              min={1}
              max={3650}
              step={1}
              required
              value={days}
              onChange={(e) => {
                invalidate();
                setDays(e.target.value);
              }}
            />
          </label>
        </div>
        <p className="form-hint" id={rateHelp}>
          {defaults.value && (
            <>
              Current Settings default: {defaultRate}% for the entire loan
              term.{" "}
            </>
          )}
          Supported rates: 0–100%, with up to two decimal places.
          {canOverride
            ? " You may edit this rate for this loan only. An override requires a recorded reason and leaves Settings unchanged."
            : " Your permissions allow the default rate; a loan-rate override permission is required to edit it."}
        </p>
        {canOverride && rate !== defaultRate && (
          <button
            type="button"
            className="text-button"
            onClick={() => {
              invalidate();
              setRate(defaultRate);
              setReason("");
            }}
          >
            Use default rate
          </button>
        )}
        <label>
          <span className="field-label">
            <RequiredMark />
            Disbursement date
          </span>
          <DateInput
            min="1900-01-01"
            max={today()}
            required
            value={date}
            onChange={(e) => {
              invalidate();
              setDate(e.target.value);
            }}
          />
        </label>
        {override && canOverride && (
          <label>
            <span className="field-label">
              <RequiredMark />
              Rate override reason
            </span>
            <input
              required
              minLength={5}
              maxLength={500}
              value={reason}
              onChange={(e) => {
                invalidate();
                setReason(e.target.value);
              }}
            />
          </label>
        )}
        {defaults.value && (
          <p className="form-hint">
            Defaults revision {defaults.value.settings.revision} · ZMW · round
            half up to 2 decimal places · Africa/Lusaka. Rate overrides require
            permission and a recorded reason.
          </p>
        )}
        <button
          type="button"
          className="text-button"
          disabled={busy}
          onClick={async () => {
            await defaults.reload();
            setResetVersion((v) => v + 1);
          }}
        >
          Reload current defaults (resets rate and term)
        </button>
      </fieldset>
      {!reviewing && (
        <>
          {summary && (
            <section
              className="loan-summary"
              aria-label="Loan obligation preview"
            >
              <dl>
                <div>
                  <dt>Amount Disbursed</dt>
                  <dd>{money(summary.principal)}</dd>
                </div>
                <div>
                  <dt>One-time interest charge</dt>
                  <dd>{money(summary.interest)}</dd>
                </div>
                <div>
                  <dt>Total obligation</dt>
                  <dd>{money(summary.total)}</dd>
                </div>
                <div>
                  <dt>Due date</dt>
                  <dd>{summary.due}</dd>
                </div>
              </dl>
            </section>
          )}
          <div className="modal-actions">
            <button
              type="button"
              className="button secondary"
              onClick={onCancel}
              disabled={busy}
            >
              Cancel
            </button>
            <button
              className="button primary"
              disabled={
                busy ||
                blocked ||
                !client ||
                !summary ||
                defaults.loading ||
                !defaults.value ||
                !reviewedRate ||
                (!authorized && !!supabase)
              }
            >
              Review Loan
            </button>
          </div>
        </>
      )}
      {reviewing && summary && client && (
        <FinancialReview title="Confirm New Loan">
          <dl className="review-details">
            <div>
              <dt>Client</dt>
              <dd>
                {client.name} · Man# {client.man_number}
              </dd>
            </div>
            <div>
              <dt>Disbursement date</dt>
              <dd>{date}</dd>
            </div>
            <div>
              <dt>Loan interest rate</dt>
              <dd>
                {rate}%
                {override ? " · override for this loan" : " · current default"}
              </dd>
            </div>
            <div>
              <dt>Calculation method</dt>
              <dd>One-time flat interest</dd>
            </div>
            <div>
              <dt>Rate basis</dt>
              <dd>The entire {days}-day loan term · one charge</dd>
            </div>
            {override && (
              <div>
                <dt>Settings default at review</dt>
                <dd>{defaultRate}%</dd>
              </div>
            )}
            {override && canOverride && (
              <div>
                <dt>Rate override reason</dt>
                <dd>{reason}</dd>
              </div>
            )}
          </dl>
          {summary && (
            <section
              className="loan-summary"
              aria-label="Loan obligation preview"
            >
              <dl>
                <div>
                  <dt>Amount Disbursed</dt>
                  <dd>{money(summary.principal)}</dd>
                </div>
                <div>
                  <dt>One-time interest charge</dt>
                  <dd>{money(summary.interest)}</dd>
                </div>
                <div>
                  <dt>Total obligation</dt>
                  <dd>{money(summary.total)}</dd>
                </div>
                <div>
                  <dt>Due date</dt>
                  <dd>{summary.due}</dd>
                </div>
              </dl>
            </section>
          )}
          <label className="checkbox-label">
            <RequiredMark />
            <input
              type="checkbox"
              required
              checked={confirmed}
              disabled={!summary || busy}
              onChange={(e) => setConfirmed(e.target.checked)}
            />
            I confirm the Client, Amount Disbursed, one-time interest charge,
            total obligation, and due date.
          </label>
          <div className="modal-actions">
            <button
              type="button"
              className="button secondary"
              disabled={busy}
              onClick={() => {
                setReviewing(false);
                setConfirmed(false);
                requestAnimationFrame(() =>
                  form.current
                    ?.querySelector<HTMLInputElement>("input[name=principal]")
                    ?.focus(),
                );
              }}
            >
              Back to Loan Details
            </button>
            <button
              className="button primary"
              disabled={
                busy ||
                blocked ||
                defaults.loading ||
                !reviewedRate ||
                !confirmed
              }
            >
              {busy ? "Posting Loan…" : "Confirm Loan"}
            </button>
          </div>
        </FinancialReview>
      )}
      {busy && <p role="status">Posting the confirmed loan. Please wait…</p>}
      {(error ||
        rateError ||
        validation ||
        (override && reason.trim() && rateIssue)) && (
        <p className="form-error" role="alert" id={errorId}>
          {error || rateError || validation || rateIssue}
        </p>
      )}
    </Form>
  );
}
