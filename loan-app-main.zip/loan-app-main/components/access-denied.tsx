import { firstAccessiblePath, type Capabilities } from "@/lib/access";
export function AccessDenied({
  standalone = false,
  capabilities,
}: {
  standalone?: boolean;
  capabilities?: Capabilities | null;
}) {
  const path = firstAccessiblePath(capabilities);
  return (
    <section
      className={standalone ? "auth-card access-card" : "panel settings-panel"}
      aria-label="Access denied"
    >
      <h1>Access denied</h1>
      <p role="alert">
        Your current business permissions do not allow this page or action. Ask
        an Administrator to review your access.
      </p>
      <p>
        If additional authentication is required, verify your authenticator in
        Account security.
      </p>
      <a className="button secondary" href={path}>
        {path === "/security" ? "Account security" : "Open permitted module"}
      </a>
      {path !== "/security" && (
        <a className="text-button" href="/security">
          Account security
        </a>
      )}
    </section>
  );
}
