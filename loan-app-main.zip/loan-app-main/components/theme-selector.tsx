"use client";
import {
  useCallback,
  useEffect,
  useId,
  useRef,
  useState,
  type KeyboardEvent,
} from "react";
import { Sun, Moon, Monitor, SunMoon, Check } from "lucide-react";
import { useTheme } from "./theme-provider";
const options = [
  { value: "light", label: "Light", Icon: Sun },
  { value: "dark", label: "Dark", Icon: Moon },
  { value: "system", label: "System", Icon: Monitor },
] as const;
export function ThemeSelector() {
  const { preference, ready, storageError, choose } = useTheme();
  const id = useId();
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const menu = useRef<HTMLDivElement>(null);
  const initialFocus = useRef(0);
  const tabClose = useRef<number | undefined>(undefined);
  const current = options.find((option) => option.value === preference)!;
  const close = useCallback((restoreFocus = false) => {
    setOpen(false);
    if (restoreFocus) trigger.current?.focus();
  }, []);
  useEffect(() => {
    if (!open) return;
    const items = menu.current!.querySelectorAll<HTMLButtonElement>(
      "[role=menuitemradio]",
    );
    items[initialFocus.current]?.focus();
    function outside(event: Event) {
      if (event.target instanceof Node && !root.current?.contains(event.target))
        close();
    }
    function escape(event: globalThis.KeyboardEvent) {
      if (event.key !== "Escape") return;
      event.preventDefault();
      event.stopPropagation();
      close(true);
    }
    document.addEventListener("pointerdown", outside);
    document.addEventListener("focusin", outside);
    document.addEventListener("keydown", escape);
    return () => {
      document.removeEventListener("pointerdown", outside);
      document.removeEventListener("focusin", outside);
      document.removeEventListener("keydown", escape);
      window.clearTimeout(tabClose.current);
    };
  }, [open, close]);
  function keys(event: KeyboardEvent<HTMLDivElement>) {
    const items = Array.from(
      menu.current!.querySelectorAll<HTMLButtonElement>("[role=menuitemradio]"),
    );
    const index = items.indexOf(document.activeElement as HTMLButtonElement);
    let next: number;
    switch (event.key) {
      case "ArrowDown":
        next = (index + 1) % items.length;
        break;
      case "ArrowUp":
        next = (index - 1 + items.length) % items.length;
        break;
      case "Home":
        next = 0;
        break;
      case "End":
        next = items.length - 1;
        break;
      case "Escape":
        event.preventDefault();
        event.stopPropagation();
        close(true);
        return;
      case "Tab":
        // Let the browser move focus in its native order before removing the
        // menu. Shift+Tab can return to the trigger without leaving it open.
        tabClose.current = window.setTimeout(() => close(), 0);
        return;
      default:
        return;
    }
    event.preventDefault();
    items[next]?.focus();
  }
  return (
    <div className="theme-selection" ref={root}>
      <button
        ref={trigger}
        type="button"
        className="theme-trigger"
        disabled={!ready}
        aria-label="Choose color theme"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-controls={id + "-menu"}
        aria-describedby={id + "-current"}
        title={`Color theme: ${current.label}`}
        onClick={() => {
          initialFocus.current = options.findIndex(
            (option) => option.value === preference,
          );
          setOpen((value) => !value);
        }}
        onKeyDown={(event) => {
          if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
          event.preventDefault();
          initialFocus.current =
            event.key === "ArrowUp" ? options.length - 1 : 0;
          setOpen(true);
        }}
      >
        <SunMoon size={20} aria-hidden="true" />
      </button>
      <span id={id + "-current"} className="theme-current">
        Current theme: {current.label}.
      </span>
      <div
        ref={menu}
        id={id + "-menu"}
        className="theme-menu"
        role="menu"
        aria-label="Color theme"
        hidden={!open}
        onKeyDown={keys}
      >
        <p className="theme-menu-heading" role="presentation">
          Color theme
        </p>
        {options.map(({ value, label, Icon }) => (
          <button
            type="button"
            role="menuitemradio"
            aria-checked={preference === value}
            className="theme-option"
            key={value}
            data-choice={value}
            tabIndex={-1}
            onClick={() => {
              choose(value);
              close(true);
            }}
          >
            <Icon size={17} aria-hidden="true" />
            <span>{label}</span>
            {preference === value && (
              <Check className="theme-check" size={16} aria-hidden="true" />
            )}
          </button>
        ))}
        <p className="theme-menu-note">System follows your device.</p>
        {storageError && <p className="theme-save-note">{storageError}</p>}
      </div>
      {storageError && !open && (
        <p className="theme-save-note theme-save-toast" role="status">
          {storageError}
        </p>
      )}
    </div>
  );
}
