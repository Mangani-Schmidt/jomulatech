"use client";
export function Pagination({
  page,
  total,
  size = 20,
  onPage,
  label,
}: {
  page: number;
  total: number;
  size?: number;
  onPage: (page: number) => void;
  label: string;
}) {
  const pages = Math.max(1, Math.ceil(total / size));
  return (
    <div className="report-pagination" aria-label={label + " pagination"}>
      <button
        type="button"
        className="button secondary"
        disabled={page <= 1}
        onClick={() => onPage(page - 1)}
      >
        Previous {label}
      </button>
      <span role="status">
        {total ? Math.min((page - 1) * size + 1, total) : 0}–
        {Math.min(page * size, total)} of {total}
      </span>
      <button
        type="button"
        className="button secondary"
        disabled={page >= pages}
        onClick={() => onPage(page + 1)}
      >
        Next {label}
      </button>
    </div>
  );
}
