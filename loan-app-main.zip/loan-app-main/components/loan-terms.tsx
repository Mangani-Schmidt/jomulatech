"use client";
import { formatBusinessTimestamp } from "@/lib/business-time";
import { Form, RequiredMark } from "./form-controls";
import { hasCapability } from "@/lib/access";
import { useRef, useState } from "react";
import { type Loan, money, status, today } from "@/lib/domain";
import { flatInterest, rateBps, dueDate } from "@/lib/interest";
import { AuditHistory } from "./audit-history";
import { useSupabase } from "@/lib/workspace-context";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
export function LoanTerms({
  loan: initialLoan,
  onSaved,
  onBusy,
}: {
  loan: Loan;
  onSaved: (message?: string) => Promise<void>;
  onBusy: (value: boolean) => void;
}) {
  const supabase = useSupabase();
  const [loan, setLoan] = useState(initialLoan);
  const [reverseWriteReason, setReverseWriteReason] = useState("");
  const [reverseWriteConfirm, setReverseWriteConfirm] = useState(false);
  const reverseWriteRequest = useRef<{ payload: string; id: string } | null>(
    null,
  );
  const [writeReason, setWriteReason] = useState("");
  const [writeConfirmed, setWriteConfirmed] = useState(false);
  const writeRequest = useRef<{ payload: string; id: string } | null>(null);
  const closed = status(loan, today()) === "Written off";
  const defaults = useLoanDefaults();
  const [rate, setRate] = useState(
    loan.interest_rate_bps == null ? "" : String(loan.interest_rate_bps / 100),
  );
  const [days, setDays] = useState(
    loan.term_days == null ? "" : String(loan.term_days),
  );
  const [reason, setReason] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const request = useRef<{ payload: string; id: string } | null>(null);
  let preview: {
    interest: number;
    total: number;
    balance: number;
    due: string;
    bps: number;
  } | null = null;
  try {
    const bps = rateBps(rate);
    const interest = flatInterest(loan.principal_cents, bps);
    const paid =
      loan.principal_cents + loan.interest_cents - loan.balance_cents;
    preview = {
      interest,
      total: loan.principal_cents + interest,
      balance: loan.principal_cents + interest - paid,
      due: dueDate(
        loan.disbursement_date ?? loan.created_at.slice(0, 10),
        Number(days),
      ),
      bps,
    };
  } catch {}
  async function save(event: React.FormEvent) {
    event.preventDefault();
    if (!supabase || !preview) return;
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      const payload = JSON.stringify([
        loan.id,
        preview.bps,
        Number(days),
        loan.terms_revision,
        reason.trim(),
      ]);
      if (request.current?.payload !== payload)
        request.current = { payload, id: crypto.randomUUID() };
      const { error } = await supabase.rpc("adjust_loan_terms", {
        p_loan_id: loan.id,
        p_rate_bps: preview.bps,
        p_term_days: Number(days),
        p_expected_revision: loan.terms_revision,
        p_reason: reason.trim(),
        p_request_id: request.current.id,
        p_confirm: confirmed,
      });
      if (error) throw error;
      await onSaved();
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : ((e as { message?: string }).message ??
              "Could not adjust loan terms."),
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  async function reload() {
    if (!supabase) return;
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      const { data, error } = await supabase
        .from("loan_register")
        .select("*")
        .eq("id", loan.id)
        .single();
      if (error) throw error;
      setLoan(data as Loan);
      setRate(
        data.interest_rate_bps == null
          ? ""
          : String(data.interest_rate_bps / 100),
      );
      setDays(data.term_days == null ? "" : String(data.term_days));
      setConfirmed(false);
      setWriteConfirmed(false);
      setReason("");
      setWriteReason("");
    } catch {
      setError("Could not reload this loan.");
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  async function writeOff(event: React.FormEvent) {
    event.preventDefault();
    if (!supabase) return;
    setBusy(true);
    onBusy(true);
    setError("");
    let saved = false;
    try {
      const payload = JSON.stringify([
        loan.id,
        loan.balance_cents,
        loan.terms_revision,
        writeReason.trim(),
      ]);
      if (writeRequest.current?.payload !== payload)
        writeRequest.current = { payload, id: crypto.randomUUID() };
      const { error } = await supabase.rpc("write_off_loan", {
        p_loan_id: loan.id,
        p_expected_balance_cents: loan.balance_cents,
        p_expected_terms_revision: loan.terms_revision,
        p_reason: writeReason.trim(),
        p_request_id: writeRequest.current.id,
        p_confirm: writeConfirmed,
      });
      if (error) throw error;
      saved = true;
      await onSaved(
        "Loan written off and audited. No Repayment Received was recorded.",
      );
    } catch (e) {
      setError(
        saved
          ? "Write-off saved. Reload the ledger before further action."
          : e instanceof Error
            ? e.message
            : ((e as { message?: string }).message ??
              "Could not write off this loan."),
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  async function reverseWriteOff(event: React.FormEvent) {
    event.preventDefault();
    if (!supabase) return;
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      const body = {
        p_loan_id: loan.id,
        p_original_write_off_request_id: loan.written_off_request_id,
        p_reason: reverseWriteReason.trim(),
        p_confirm: reverseWriteConfirm,
      };
      const payload = JSON.stringify(body);
      if (reverseWriteRequest.current?.payload !== payload)
        reverseWriteRequest.current = { payload, id: crypto.randomUUID() };
      const { error } = await supabase.rpc("reverse_write_off", {
        ...body,
        p_request_id: reverseWriteRequest.current.id,
      });
      if (error) throw error;
      await onSaved(
        "Write-off reversed and audited. No Repayment Received was created.",
      );
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : ((e as { message?: string }).message ??
              "Could not reverse the write-off."),
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  return (
    <div>
      <p className="form-hint">
        Loan {loan.loan_reference ?? loan.id} · Terms revision{" "}
        {loan.terms_revision ?? 1}
      </p>
      <button
        className="text-button"
        type="button"
        disabled={busy || !supabase}
        onClick={reload}
      >
        Reload latest loan (discards edits)
      </button>
      <p className="mode-explanation">
        {loan.calculation_method === "one_time_flat"
          ? "One-time flat interest for the entire loan term."
          : "Historical fixed charge: no reliable percentage was recorded. Actual charges are retained."}
      </p>
      <section className="loan-summary">
        <dl>
          <div>
            <dt>Status</dt>
            <dd>{status(loan, today())}</dd>
          </div>
          <div>
            <dt>Internal loan ID / Client ID</dt>
            <dd>
              {loan.id} / {loan.client_id}
            </dd>
          </div>
          <div>
            <dt>Disbursement date</dt>
            <dd>{loan.disbursement_date ?? loan.created_at.slice(0, 10)}</dd>
          </div>
          <div>
            <dt>Creator</dt>
            <dd>
              {loan.created_by ?? "Not recorded"}
              {loan.creator_inferred ? " (inferred ledger owner)" : ""}
            </dd>
          </div>
          <div>
            <dt>Recorded / updated (business time)</dt>
            <dd>
              {formatBusinessTimestamp(loan.created_at)} /{" "}
              {formatBusinessTimestamp(loan.updated_at)}
            </dd>
          </div>
          <div>
            <dt>Amount Disbursed</dt>
            <dd>{money(loan.principal_cents)}</dd>
          </div>
          <div>
            <dt>Interest charge</dt>
            <dd>{money(loan.interest_cents)}</dd>
          </div>
          <div>
            <dt>Total obligation</dt>
            <dd>{money(loan.principal_cents + loan.interest_cents)}</dd>
          </div>
          <div>
            <dt>Outstanding</dt>
            <dd>{money(loan.balance_cents)}</dd>
          </div>
          <div>
            <dt>Actual rate / basis</dt>
            <dd>
              {loan.interest_rate_bps == null
                ? "Not recorded"
                : `${loan.interest_rate_bps / 100}% for entire term`}
            </dd>
          </div>
          <div>
            <dt>Term / due date</dt>
            <dd>
              {loan.term_days ?? "Not recorded"} days · {loan.due_date}
            </dd>
          </div>
          <div>
            <dt>Currency / rounding / timezone</dt>
            <dd>
              {loan.currency ?? "ZMW"} · half up to 2 decimals ·{" "}
              {loan.business_timezone ?? "Africa/Lusaka"}
            </dd>
          </div>
          <div>
            <dt>Original defaults snapshot</dt>
            <dd>
              Revision {loan.settings_revision ?? "Not recorded"} ·{" "}
              {loan.default_rate_bps_at_origination == null
                ? "rate not recorded"
                : `${loan.default_rate_bps_at_origination / 100}%`}
            </dd>
          </div>
        </dl>
        {loan.rate_override_reason && (
          <p className="form-hint">
            Original rate override: {loan.rate_override_reason}
          </p>
        )}
      </section>
      {hasCapability(defaults.value?.capabilities, "can_approve_adjustments") &&
        !closed && (
          <Form onSubmit={save}>
            <h3>Authorized adjustment</h3>
            <p className="form-hint">
              An explicit adjustment changes only this loan’s rate and term,
              retains all repayments, and writes before/after audit records.
              Amount Disbursed and original defaults remain unchanged.
            </p>
            <div className="form-row">
              <label>
                <span className="field-label">
                  <RequiredMark />
                  Adjusted rate for entire term (%)
                </span>
                <input
                  required
                  inputMode="decimal"
                  value={rate}
                  onChange={(e) => {
                    setRate(e.target.value);
                    setConfirmed(false);
                  }}
                />
              </label>
              <label>
                <span className="field-label">
                  <RequiredMark />
                  Adjusted term (days)
                </span>
                <input
                  type="number"
                  min={1}
                  max={3650}
                  required
                  value={days}
                  onChange={(e) => {
                    setDays(e.target.value);
                    setConfirmed(false);
                  }}
                />
              </label>
            </div>
            <label>
              <span className="field-label">
                <RequiredMark />
                Adjustment reason
              </span>
              <input
                required
                minLength={5}
                maxLength={500}
                value={reason}
                onChange={(e) => {
                  setReason(e.target.value);
                  setConfirmed(false);
                }}
              />
            </label>
            {preview && (
              <div className="mode-explanation">
                New one-time interest: {money(preview.interest)} · Total
                obligation: {money(preview.total)} · Outstanding:{" "}
                {money(preview.balance)} · Due: {preview.due}
              </div>
            )}
            <label className="checkbox-label">
              <RequiredMark />
              <input
                type="checkbox"
                required
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
              />
              I authorize and confirm this audited loan adjustment.
            </label>
            <button
              className="button primary"
              disabled={
                busy ||
                !preview ||
                preview.balance < 0 ||
                !confirmed ||
                reason.trim().length < 5
              }
            >
              {busy ? "Saving…" : "Save audited loan adjustment"}
            </button>
          </Form>
        )}
      {closed && (
        <div className="mode-explanation">
          <b>
            Written off: {money(loan.written_off_cents ?? loan.balance_cents)}
          </b>
          <p>{loan.written_off_reason}</p>
          <p>
            By {loan.written_off_by ?? "Not recorded"} ·{" "}
            {loan.written_off_at
              ? formatBusinessTimestamp(loan.written_off_at)
              : "Not recorded"}
          </p>
          <p>
            The unpaid balance and original obligation are preserved. This loan
            is closed to new Repayment Received entries and term adjustments.
          </p>
        </div>
      )}
      {hasCapability(defaults.value?.capabilities, "can_approve_adjustments") &&
        !closed &&
        loan.balance_cents > 0 && (
          <Form className="write-off-form" onSubmit={writeOff}>
            <h3>Write off loan</h3>
            <p className="form-hint">
              Write off the unpaid {money(loan.balance_cents)}. This does not
              record money received, change Amount Disbursed, or erase the
              obligation or receipt history. The loan will close to further
              receipts and adjustments. An administrator must reverse a mistaken
              write-off before further receipts or adjustments.
            </p>
            <label>
              <span className="field-label">
                <RequiredMark />
                Write-off reason
              </span>
              <input
                required
                minLength={5}
                maxLength={500}
                value={writeReason}
                onChange={(e) => {
                  setWriteReason(e.target.value);
                  setWriteConfirmed(false);
                }}
              />
            </label>
            <label className="checkbox-label">
              <RequiredMark />
              <input
                type="checkbox"
                required
                checked={writeConfirmed}
                onChange={(e) => setWriteConfirmed(e.target.checked)}
              />
              I confirm the unpaid balance and authorize this write-off.
            </label>
            <button
              className="button danger"
              disabled={
                busy || !writeConfirmed || writeReason.trim().length < 5
              }
            >
              {busy ? "Saving…" : "Confirm write-off"}
            </button>
          </Form>
        )}
      {closed &&
        hasCapability(
          defaults.value?.capabilities,
          "can_approve_adjustments",
        ) && (
          <Form className="write-off-form" onSubmit={reverseWriteOff}>
            <h3>Reverse write-off</h3>
            <p className="form-hint">
              Reopen this unpaid loan without changing its balance or creating
              money received. The original write-off stays in status history.
            </p>
            <label>
              <span className="field-label">
                <RequiredMark />
                Write-off reversal reason
              </span>
              <input
                required
                minLength={5}
                maxLength={500}
                value={reverseWriteReason}
                onChange={(e) => {
                  setReverseWriteReason(e.target.value);
                  setReverseWriteConfirm(false);
                }}
              />
            </label>
            <label className="checkbox-label">
              <RequiredMark />
              <input
                type="checkbox"
                required
                checked={reverseWriteConfirm}
                onChange={(e) => setReverseWriteConfirm(e.target.checked)}
              />
              I authorize reversal of this write-off.
            </label>
            <button
              className="button danger"
              disabled={
                busy ||
                !reverseWriteConfirm ||
                reverseWriteReason.trim().length < 5
              }
            >
              Confirm write-off reversal
            </button>
          </Form>
        )}
      <AuditHistory
        source="loan_status_audit"
        recordId={loan.id}
        title="Loan status history"
        revision={loan.updated_at}
      />
      <AuditHistory
        source="loan_terms_audit"
        recordId={loan.id}
        title="Loan terms audit trail"
        revision={loan.updated_at}
      />
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
