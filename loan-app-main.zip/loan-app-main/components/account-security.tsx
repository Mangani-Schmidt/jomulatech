"use client";
import { Form, RequiredMark } from "./form-controls";
import { hasCapability } from "@/lib/access";
import { useEffect, useRef, useState } from "react";
import { useSupabase } from "@/lib/workspace-context";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import { WorkspaceNavigation } from "./workspace-navigation";
import { brand } from "@/lib/brand";
import { PasswordField } from "./password-field";
import { passwordUpdateSchema } from "@/lib/auth";
type Security = {
  role: string;
  admin_mfa_required: boolean;
  recent_assurance: boolean;
};
export function AccountSecurity() {
  const supabase = useSupabase();
  const defaults = useLoanDefaults();
  const [security, setSecurity] = useState<Security | null>(null),
    [signedIn, setSignedIn] = useState(false),
    [loading, setLoading] = useState(true),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [message, setMessage] = useState("");
  const [factors, setFactors] = useState<
      { id: string; friendly_name?: string; status: string }[]
    >([]),
    [factor, setFactor] = useState(""),
    [code, setCode] = useState(""),
    [enrollment, setEnrollment] = useState<{
      id: string;
      qr: string;
      secret: string;
    } | null>(null);
  const [required, setRequired] = useState(false),
    [reason, setReason] = useState(""),
    [approve, setApprove] = useState(false);
  const request = useRef<{ payload: string; id: string } | null>(null);
  async function load() {
    if (!supabase) {
      setLoading(false);
      return;
    }
    const session = await supabase.auth.getSession();
    setSignedIn(!!session.data.session);
    if (!session.data.session) {
      setSecurity(null);
      setFactors([]);
      setLoading(false);
      return;
    }
    const list = await supabase.auth.mfa.listFactors();
    if (list.error) throw list.error;
    setFactors(list.data.totp);
    setFactor(list.data.totp.find((f) => f.status === "verified")?.id ?? "");
    const s = await supabase.rpc("account_security");
    if (s.error) throw s.error;
    setSecurity(s.data);
    setRequired(s.data?.admin_mfa_required ?? false);
    setLoading(false);
  }
  useEffect(() => {
    void load().catch((e) => {
      setError(e.message);
      setLoading(false);
    });
    return () => {
      setEnrollment(null);
    };
  }, []);
  async function run(action: () => Promise<void>) {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      await action();
    } catch (e) {
      setError(
        (e as { message?: string }).message ??
          "Could not complete the security action.",
      );
    } finally {
      setBusy(false);
    }
  }
  async function enroll() {
    await run(async () => {
      const r = await supabase!.auth.mfa.enroll({
        factorType: "totp",
        friendlyName: brand.name + " " + new Date().toISOString(),
      });
      if (r.error) throw r.error;
      const qr = r.data.totp.qr_code;
      setEnrollment({
        id: r.data.id,
        qr: qr.startsWith("data:")
          ? qr
          : "data:image/svg+xml;charset=utf-8," + encodeURIComponent(qr),
        secret: r.data.totp.secret,
      });
      setCode("");
    });
  }
  async function verify(e: React.FormEvent) {
    e.preventDefault();
    await run(async () => {
      const id = enrollment?.id ?? factor;
      if (!id) throw new Error("Choose or enroll an authenticator.");
      const r = await supabase!.auth.mfa.challengeAndVerify({
        factorId: id,
        code,
      });
      if (r.error) throw r.error;
      setEnrollment(null);
      setCode("");
      await load();
      await defaults.reload();
      setMessage(
        "Authenticator verified. Protected Administrator actions are available for 15 minutes when the business policy requires verification.",
      );
    });
  }
  async function policy(e: React.FormEvent) {
    e.preventDefault();
    await run(async () => {
      const body = {
        p_required: required,
        p_reason: reason.trim(),
        p_confirm: approve,
      };
      const payload = JSON.stringify(body);
      if (request.current?.payload !== payload)
        request.current = { payload, id: crypto.randomUUID() };
      const r = await supabase!.rpc("set_admin_mfa_policy", {
        ...body,
        p_request_id: request.current.id,
      });
      if (r.error) throw r.error;
      request.current = null;
      setReason("");
      setApprove(false);
      await load();
      await defaults.reload();
      setMessage("Business authentication policy saved and audited.");
    });
  }
  async function password(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const f = new FormData(form);
    const value = String(f.get("password") ?? "");
    const validation = passwordUpdateSchema.safeParse({
      password: value,
      repeat: String(f.get("repeat") ?? ""),
    });
    if (!validation.success) {
      setError(validation.error.issues[0].message);
      return;
    }
    await run(async () => {
      const r = await supabase!.auth.updateUser({ password: value });
      if (r.error) throw r.error;
      form.reset();
      setMessage(
        "Password updated. Store it securely and sign in again on other devices as needed.",
      );
    });
  }
  return (
    <main
      className="settings-page standalone-page"
      id="workspace-content"
      tabIndex={-1}
    >
      <WorkspaceNavigation
        current="Account security"
        capabilities={defaults.value?.capabilities}
        demo={!supabase}
        standalone
        pending={busy}
      />
      {hasCapability(defaults.value?.capabilities, "can_view_dashboard") && (
        <a className="text-button" href="/dashboard">
          ← Back to workspace
        </a>
      )}
      <div className="page-heading">
        <h1>Account security</h1>
      </div>
      {loading ? (
        <p role="status">Checking account security…</p>
      ) : !supabase || !signedIn ? (
        <p>
          Sign in from the workspace to manage your password and authenticator.
        </p>
      ) : (
        <>
          <section className="panel settings-panel">
            <h2>Authenticator verification</h2>
            <p>
              Use a TOTP authenticator app. Enrollment secrets are shown only
              during setup and are cleared after verification; they are never
              added to application logs.
            </p>
            {security && (
              <p>
                Business policy:{" "}
                {security.admin_mfa_required
                  ? "Recent authenticator verification required for protected Administrator actions"
                  : "Optional authenticator verification"}
                .{" "}
                {security.recent_assurance
                  ? "Verified within the last 15 minutes."
                  : "Verify again before protected actions."}
              </p>
            )}
            <fieldset disabled={busy}>
              {!enrollment && (
                <button
                  type="button"
                  className="button secondary"
                  onClick={() => void enroll()}
                >
                  Set up an authenticator
                </button>
              )}
              {enrollment && (
                <div className="authenticator-setup">
                  <img
                    src={enrollment.qr}
                    alt="Scan this QR code with your authenticator app"
                    width={220}
                    height={220}
                  />
                  <label>
                    Manual authenticator setup key
                    <input
                      readOnly
                      value={enrollment.secret}
                      autoComplete="off"
                    />
                  </label>
                  <button
                    type="button"
                    className="text-button"
                    onClick={() =>
                      void run(async () => {
                        const r = await supabase!.auth.mfa.unenroll({
                          factorId: enrollment.id,
                        });
                        if (r.error) throw r.error;
                        setEnrollment(null);
                        setCode("");
                      })
                    }
                  >
                    Cancel authenticator setup
                  </button>
                </div>
              )}
              {(enrollment || factors.some((f) => f.status === "verified")) && (
                <Form onSubmit={verify}>
                  {!enrollment && (
                    <label>
                      Authenticator
                      <select
                        value={factor}
                        onChange={(e) => setFactor(e.target.value)}
                      >
                        {factors
                          .filter((f) => f.status === "verified")
                          .map((f) => (
                            <option key={f.id} value={f.id}>
                              {f.friendly_name ?? "Authenticator"}
                            </option>
                          ))}
                      </select>
                    </label>
                  )}
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Six-digit authenticator code
                    </span>
                    <input
                      required
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      pattern="[0-9]{6}"
                      maxLength={6}
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                    />
                  </label>
                  <button
                    className="button primary"
                    disabled={busy || code.length !== 6}
                  >
                    Verify authenticator
                  </button>
                </Form>
              )}
            </fieldset>
          </section>
          {hasCapability(
            defaults.value?.capabilities,
            "can_manage_security",
          ) && (
            <section className="panel settings-panel">
              <h2>Business Administrator authentication policy</h2>
              <p>
                Requires recent TOTP verification for users/roles, settings,
                rate overrides, imports, expenses, reporting coverage approvals,
                reversals, term adjustments and write-offs. Enable only after
                your Administrators have working authenticators and a trusted
                account-recovery procedure.
              </p>
              <Form onSubmit={policy}>
                <fieldset disabled={busy}>
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={required}
                      onChange={(e) => {
                        setRequired(e.target.checked);
                        setApprove(false);
                      }}
                    />
                    Require recent authenticator verification for protected
                    Administrator actions
                  </label>
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Policy change reason
                    </span>
                    <textarea
                      required
                      minLength={5}
                      maxLength={500}
                      value={reason}
                      onChange={(e) => {
                        setReason(e.target.value);
                        setApprove(false);
                      }}
                    />
                  </label>
                  <label className="checkbox-label">
                    <RequiredMark />
                    <input
                      type="checkbox"
                      required
                      checked={approve}
                      onChange={(e) => setApprove(e.target.checked)}
                    />
                    I approve this business policy and have verified recovery
                    arrangements.
                  </label>
                  <button
                    className="button primary"
                    disabled={busy || !approve || !security?.recent_assurance}
                  >
                    Save authentication policy
                  </button>
                </fieldset>
              </Form>
            </section>
          )}
          <section className="panel settings-panel">
            <h2>Update password</h2>
            <Form onSubmit={password} noValidate>
              <fieldset disabled={busy}>
                <PasswordField
                  label="New password"
                  name="password"
                  required
                  autoComplete="new-password"
                />
                <PasswordField
                  label="Repeat new password"
                  name="repeat"
                  required
                  autoComplete="new-password"
                />
                <p className="form-hint">
                  Use at least 6 characters and matching passwords.
                </p>
                <button className="button primary" disabled={busy}>
                  Update password
                </button>
              </fieldset>
            </Form>
          </section>
        </>
      )}
      {error && (
        <p role="alert" className="notice error">
          {error}
        </p>
      )}
      {message && (
        <p role="status" className="notice success">
          {message}
        </p>
      )}
    </main>
  );
}
