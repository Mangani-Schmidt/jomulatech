"use client";
import { ArrowRight, ShieldCheck, Files, UsersRound } from "lucide-react";
import { PublicShell } from "./public-shell";
export function LandingPage() {
  return (
    <PublicShell>
      <section className="landing-hero">
        <div className="landing-copy">
          <span className="eyebrow">
            PURPOSE-BUILT FOR YOUR LENDING BUSINESS
          </span>
          <h1>Keep your lending business on track.</h1>
          <p>
            Manage Client records, loans and repayments in one organized
            workspace. Clear records and controlled team access help you focus
            on the people behind your business.
          </p>
          <div className="landing-actions">
            <a className="button primary" href="/signup">
              Sign Up <ArrowRight size={17} aria-hidden="true" />
            </a>
            <a className="button secondary" href="/login">
              Log In
            </a>
          </div>
          <p className="landing-assurance">
            <ShieldCheck size={17} aria-hidden="true" />
            Business access is assigned by an Administrator.
          </p>
        </div>
        <aside className="landing-overview" aria-label="About LendTrack">
          <div className="landing-symbol">
            <Files size={38} aria-hidden="true" />
          </div>
          <span className="eyebrow">CLARITY AT EVERY STEP</span>
          <h2>One place for your lending records.</h2>
          <p>
            From Client registration to repayment receipts, keep your team's
            work connected and easy to follow.
          </p>
          <div className="landing-steps">
            <span>Organize</span>
            <ArrowRight size={16} aria-hidden="true" />
            <span>Record</span>
            <ArrowRight size={16} aria-hidden="true" />
            <span>Review</span>
          </div>
        </aside>
      </section>
      <section className="landing-features" aria-label="Application benefits">
        {[
          {
            Icon: UsersRound,
            title: "Organized Client records",
            text: "Keep Client identities and lending history together.",
          },
          {
            Icon: Files,
            title: "Clear loan terms",
            text: "Review the details before confirming a transaction.",
          },
          {
            Icon: ShieldCheck,
            title: "Controlled team access",
            text: "Give each staff member the access their role requires.",
          },
        ].map(({ Icon, title, text }) => (
          <article key={title}>
            <Icon size={23} aria-hidden="true" />
            <h2>{title}</h2>
            <p>{text}</p>
          </article>
        ))}
      </section>
    </PublicShell>
  );
}
