"use client";
import { hasCapability, postingCapability } from "@/lib/access";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import type { usePostingIntent } from "@/lib/use-posting-intent";
export function PostingRecovery({
  intent,
  busy,
  onRecover,
}: {
  intent: ReturnType<typeof usePostingIntent>;
  busy: boolean;
  onRecover: () => void;
}) {
  const defaults = useLoanDefaults();
  const allowed =
    !!intent.pending &&
    !defaults.loading &&
    hasCapability(
      defaults.value?.capabilities,
      postingCapability[intent.pending.operation],
    );
  if (!intent.pending && !intent.storageError) return null;
  return (
    <section className="notice error" role="alert">
      <p>
        {intent.storageError ||
          "An earlier transaction needs confirmation. Editing and new posting are paused so the same money cannot be recorded twice."}
      </p>
      {intent.pending && (
        <>
          <p>
            Request reference: {intent.pending.id}. Recovery checks its saved
            result. In-memory retries reuse the original request. After a
            reload, unposted requests require reviewed re-entry with the same
            reference.
          </p>
          {!allowed && (
            <p>
              Your current permissions do not allow retrying this transaction.
              Ask an Administrator to reconcile the original request. Its
              reference is retained.
            </p>
          )}
          {allowed && (
            <button
              type="button"
              className="button secondary"
              disabled={busy || !!intent.storageError}
              onClick={onRecover}
            >
              Recover pending transaction
            </button>
          )}
        </>
      )}
    </section>
  );
}
