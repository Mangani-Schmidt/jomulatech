"use client";
import { formatBusinessTimestamp } from "@/lib/business-time";
import { Form, RequiredMark, DateInput } from "./form-controls";
import { useEffect, useState } from "react";
import { ArrowDownToLine, FileSpreadsheet, LoaderCircle } from "lucide-react";
import { useSupabase } from "@/lib/workspace-context";
import { hasCapability } from "@/lib/access";
import { assertActiveSession } from "@/lib/session-activity";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import { rateBps } from "@/lib/interest";
import { today, money } from "@/lib/domain";
import {
  importFields,
  importLabels,
  type ColumnMapping,
  type ImportMode,
  type ImportReport,
  type ImportBatch,
  type WorkbookInspection,
} from "@/lib/import";
import { previewSampleImport, sampleInspection } from "@/lib/import-demo";
export function ImportWorkspace({
  authorized,
  onSaved,
  onBusy,
}: {
  authorized: boolean;
  onSaved: () => Promise<void>;
  onBusy: (value: boolean) => void;
}) {
  const supabase = useSupabase();
  const defaults = useLoanDefaults();
  const [sampleActive, setSampleActive] = useState(false);
  const canPreview = authorized || sampleActive;
  const readable =
    !!supabase &&
    hasCapability(defaults.value?.capabilities, "can_view_imports");
  const [overrideReason, setOverrideReason] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [inspection, setInspection] = useState<WorkbookInspection | null>(null);
  const [mapping, setMapping] = useState<ColumnMapping | null>(null);
  const [mode, setMode] = useState<ImportMode | "">("");
  const [date, setDate] = useState("");
  const [interestType, setInterestType] = useState("");
  const [interest, setInterest] = useState("");
  const [days, setDays] = useState("");
  const [dueRule, setDueRule] = useState("");
  const [report, setReport] = useState<ImportReport | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [history, setHistory] = useState<ImportBatch[]>([]);
  const [page, setPage] = useState(0);
  const [historyError, setHistoryError] = useState("");
  useEffect(() => {
    if (defaults.value) {
      setInterestType("flat_percent");
      setInterest(String(defaults.value.settings.default_rate_bps / 100));
      setDays(String(defaults.value.settings.default_term_days));
      setDate(today());
      setDueRule("days_after_disbursement");
      setOverrideReason("");
      setReport(null);
      setConfirmed(false);
    }
  }, [
    defaults.value?.settings.owner_id,
    defaults.value?.settings.revision,
    defaults.value?.capabilities.can_override_rate,
  ]);
  let overriding = false;
  try {
    overriding =
      !!defaults.value &&
      rateBps(interest) !== defaults.value.settings.default_rate_bps;
  } catch {}
  async function api(path: string, init?: RequestInit) {
    assertActiveSession();
    const session = await supabase?.auth.getSession();
    const token = session?.data.session?.access_token;
    if (!token) throw new Error("Sign in to use imports.");
    const response = await fetch(`/api/imports/${path}`, {
      ...init,
      headers: { ...init?.headers, Authorization: `Bearer ${token}` },
      cache: "no-store",
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error ?? "Import request failed.");
    return data;
  }
  async function loadHistory(index = page) {
    try {
      setHistory(await api(`history?page=${index}`));
      setHistoryError("");
    } catch (e) {
      setHistoryError(
        e instanceof Error ? e.message : "Could not load history.",
      );
    }
  }
  useEffect(() => {
    if (readable) void loadHistory(page);
  }, [readable, page]);
  function working(value: boolean) {
    setBusy(value);
    onBusy(value);
  }
  function invalidate() {
    setReport(null);
    setConfirmed(false);
    setError("");
  }
  async function inspect(file: File) {
    working(true);
    invalidate();
    setFile(file);
    setInspection(null);
    setMapping(null);
    try {
      const form = new FormData();
      form.set("file", file);
      const result: WorkbookInspection = await api("inspect", {
        method: "POST",
        body: form,
      });
      setInspection(result);
      setMapping(result.mapping);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not inspect workbook.");
    } finally {
      working(false);
    }
  }
  async function preview(event: React.FormEvent) {
    event.preventDefault();
    if (busy) return;
    if ((!file && !sampleActive) || !mapping) return;
    working(true);
    setError("");
    setConfirmed(false);
    try {
      if (sampleActive) {
        setReport(
          previewSampleImport(mode, mapping, {
            calculation_method: "one_time_flat",
            rate_basis: "entire_term",
            disbursement_date: date,
            interest_type: interestType as "flat_percent",
            interest_value: interest,
            due_rule: dueRule as "days_after_disbursement",
            term_days: Number(days),
          }),
        );
        return;
      }
      if (!file) throw new Error("Choose a workbook.");
      const form = new FormData();
      form.set("file", file);
      form.set("mapping", JSON.stringify(mapping));
      form.set("mode", mode);
      form.set(
        "terms",
        JSON.stringify(
          mode === "loans"
            ? {
                calculation_method: "one_time_flat",
                rate_basis: "entire_term",
                settings_revision: defaults.value?.settings.revision,
                override_reason: overriding ? overrideReason.trim() : "",
                disbursement_date: date,
                interest_type: interestType,
                interest_value: interest,
                due_rule: dueRule,
                term_days: Number(days),
              }
            : {},
        ),
      );
      setReport(await api("preview", { method: "POST", body: form }));
      await loadHistory();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Preview failed.");
    } finally {
      working(false);
    }
  }
  async function commit() {
    if (!report || busy || !confirmed) return;
    working(true);
    setError("");
    try {
      if (sampleActive) {
        if (!confirmed)
          throw new Error("Review and confirm the demo preview first.");
        setReport({
          ...report,
          batch: {
            ...report.batch,
            status: "completed",
            completed_at: new Date().toISOString(),
          },
        });
        setConfirmed(false);
        return;
      }
      const result = await api("commit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          batch_id: report.batch.id,
          preview_version: report.batch.preview_version,
          confirm: confirmed,
        }),
      });
      setReport(result);
      setConfirmed(false);
      await loadHistory();
      try {
        await onSaved();
      } catch {
        setError(
          "Import saved, but the ledger could not refresh. Reload the page before making another entry.",
        );
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Confirmation failed.");
    } finally {
      working(false);
    }
  }
  async function downloadErrors() {
    if (!report || busy) return;
    working(true);
    setError("");
    try {
      const { Workbook } = await import("exceljs");
      const wb = new Workbook();
      const sheet = wb.addWorksheet("Validation report");
      sheet.addRow([
        "Excel row",
        "no#",
        "name",
        "man#",
        "department",
        "designation",
        "amount",
        "Interest charge (ZMW)",
        "Total obligation (ZMW)",
        "Outcome",
        "Errors",
        "Warnings",
        "Client ID",
        "Loan reference",
        "Loan ID",
      ]);
      for (const row of report.rows)
        sheet.addRow([
          row.excel_row,
          row.source_no,
          row.data.name,
          row.data.man_number,
          row.data.department,
          row.data.designation,
          row.data.amount,
          row.data.interest_cents == null ? "" : row.data.interest_cents / 100,
          row.data.total_obligation_cents == null
            ? ""
            : row.data.total_obligation_cents / 100,
          row.outcome,
          row.errors.join("; "),
          row.warnings.join("; "),
          row.client_id ?? "",
          row.loan_reference ?? "",
          row.loan_id ?? "",
        ]);
      sheet.getRow(1).font = { bold: true };
      sheet.columns.forEach((c) => {
        c.width = 24;
      });
      const url = URL.createObjectURL(
        new Blob([await wb.xlsx.writeBuffer()], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        }),
      );
      const a = document.createElement("a");
      a.href = url;
      a.download = `import-errors-${report.batch.id}.xlsx`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      setError("Could not download the validation report.");
    } finally {
      working(false);
    }
  }
  return (
    <div className="import-workspace">
      <p aria-label="Import steps">
        1. Upload → 2. Validate and Preview → 3. Confirm → 4. Import Summary
      </p>
      <div hidden={!!supabase && !authorized}>
        <p className="form-hint">
          First worksheet only. .xlsx · maximum 2 MB, 500 data rows and 30
          source columns. The <b>no#</b> column is the source row number, never
          the Client identifier. Verify numeric Man# warnings before confirming.
        </p>
        <div className="import-downloads">
          <a className="button secondary" href="/api/imports/template" download>
            <ArrowDownToLine size={15} /> Download Import Template
          </a>
          {!supabase && (
            <button
              className="button secondary"
              type="button"
              disabled={busy}
              onClick={() => {
                invalidate();
                setSampleActive(true);
                setFile(null);
                setInspection(sampleInspection);
                setMapping(sampleInspection.mapping);
              }}
            >
              Try sample import
            </button>
          )}
        </div>
        {sampleActive && (
          <p className="notice" role="status">
            Demo import: choose a mode, review the bundled fictional rows and
            practice confirmation. No upload or database write occurs. Refresh
            to reset.
          </p>
        )}
        {!authorized && (
          <p className="form-hint">
            Connect Supabase and sign in to upload, preview, and save imports.
          </p>
        )}
        <Form onSubmit={preview}>
          <fieldset disabled={busy || !canPreview} className="import-fields">
            <label>
              <span className="field-label">
                <RequiredMark />
                Import mode
              </span>
              <select
                required
                value={mode}
                onChange={(e) => {
                  invalidate();
                  setMode(e.target.value as ImportMode);
                }}
              >
                <option value="">Select a mode explicitly</option>
                <option value="clients">Client Register Import</option>
                <option
                  value="loans"
                  disabled={
                    !!supabase &&
                    !hasCapability(
                      defaults.value?.capabilities,
                      "can_originate",
                    )
                  }
                >
                  Loan Disbursement Import
                </option>
              </select>
            </label>
            {mode && (
              <p className="mode-explanation">
                {mode === "clients"
                  ? "Import Client details only. amount is ignored. No loans, repayments, or balances are created."
                  : "Import or match Client details and create new loans from amount after confirmation. Existing loans are never modified."}
              </p>
            )}
            {mode === "loans" && (
              <div className="loan-import-terms">
                <h3>Loan disbursement terms</h3>
                <div className="form-row">
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Disbursement date
                    </span>
                    <DateInput
                      required
                      min="1900-01-01"
                      max={today()}
                      value={date}
                      onChange={(e) => {
                        invalidate();
                        setDate(e.target.value);
                      }}
                    />
                  </label>
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Interest terms
                    </span>
                    <select
                      required
                      value={interestType}
                      onChange={(e) => {
                        invalidate();
                        setInterestType(e.target.value);
                      }}
                    >
                      <option value="flat_percent">
                        One-time flat interest for entire loan term
                      </option>
                    </select>
                  </label>
                </div>
                <label>
                  <span className="field-label">
                    <RequiredMark />
                    Flat interest (%)
                  </span>
                  <input
                    required
                    inputMode="decimal"
                    pattern="[0-9]+(\.[0-9]{1,2})?"
                    value={interest}
                    readOnly={!defaults.value?.capabilities.can_override_rate}
                    onChange={(e) => {
                      invalidate();
                      setInterest(e.target.value);
                    }}
                    placeholder="Enter 0 explicitly for no interest"
                  />
                </label>
                <div className="form-row">
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Due-date rule
                    </span>
                    <select
                      value={dueRule}
                      required
                      onChange={(e) => {
                        invalidate();
                        setDueRule(e.target.value);
                      }}
                    >
                      <option value="">Choose a rule</option>
                      <option value="days_after_disbursement">
                        Days after disbursement
                      </option>
                    </select>
                  </label>
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Term in days
                    </span>
                    <input
                      type="number"
                      min="1"
                      max="3650"
                      step="1"
                      required
                      value={days}
                      onChange={(e) => {
                        invalidate();
                        setDays(e.target.value);
                      }}
                    />
                  </label>
                </div>
                {overriding && (
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Rate override reason
                    </span>
                    <input
                      required
                      minLength={5}
                      maxLength={500}
                      value={overrideReason}
                      onChange={(e) => {
                        invalidate();
                        setOverrideReason(e.target.value);
                      }}
                    />
                  </label>
                )}
                <button
                  type="button"
                  className="text-button"
                  onClick={() => void defaults.reload()}
                >
                  Reload current defaults
                </button>
                {defaults.error && (
                  <p className="form-error" role="alert">
                    {defaults.error}
                  </p>
                )}
                <p className="form-hint">
                  Defaults revision{" "}
                  {defaults.value?.settings.revision ?? "loading"} · One-time
                  flat interest for the entire loan term.
                </p>
                <p className="form-hint">
                  ZMW. Interest is added once, rounded to the nearest ngwee. No
                  compounding. Due date = disbursement date + term days.
                </p>
              </div>
            )}
            <label>
              Excel workbook
              <input
                type="file"
                accept=".xlsx"
                disabled={!authorized}
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void inspect(file);
                }}
              />
            </label>
            {inspection && mapping && (
              <>
                <p className="form-hint">
                  {inspection.rowCount} source rows. Match each required field
                  to a different column. Standard headers are matched without
                  regard to letter case.
                </p>
                <div className="mapping-grid">
                  {importFields.map((field) => (
                    <label key={field}>
                      <span className="field-label">
                        <RequiredMark />
                        Map {importLabels[field]}
                      </span>
                      <select
                        value={mapping[field]}
                        required
                        onChange={(e) => {
                          invalidate();
                          setMapping({
                            ...mapping,
                            [field]: Number(e.target.value),
                          });
                        }}
                      >
                        <option value={0}>Choose a source column</option>
                        {inspection.columns.map((column) => (
                          <option key={column.index} value={column.index}>
                            {column.index}: {column.label || "(blank header)"}
                          </option>
                        ))}
                      </select>
                    </label>
                  ))}
                </div>
                <button
                  className="button primary"
                  disabled={
                    !mode ||
                    Object.values(mapping).some((v) => !v) ||
                    (mode === "loans" &&
                      (!defaults.value ||
                        (overriding &&
                          (!defaults.value.capabilities.can_override_rate ||
                            overrideReason.trim().length < 5))))
                  }
                >
                  <FileSpreadsheet size={15} />
                  Validate and preview
                </button>
              </>
            )}
          </fieldset>
        </Form>
        {busy && (
          <p className="import-progress" role="status">
            <LoaderCircle size={16} className="spin" />
            Processing import…
          </p>
        )}
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
      </div>
      {supabase && !authorized && (
        <p className="notice">
          Read-only import history. Importing requires a separately approved
          action permission.
        </p>
      )}
      {report && (
        <section className="import-results">
          <h3>
            {sampleActive && report.batch.status === "completed"
              ? "Demo confirmation complete"
              : report.batch.status === "completed"
                ? "Import Summary"
                : "Preview — nothing has been saved to the ledger"}
          </h3>
          <p className="form-hint">
            {report.batch.filename} ·{" "}
            {report.batch.mode === "clients"
              ? "Client Register Import"
              : "Loan Disbursement Import"}{" "}
            · Preview revision {report.batch.preview_version}
          </p>
          {report.batch.mode === "loans" && (
            <p className="mode-explanation">
              Disbursed {report.batch.terms.disbursement_date} ·{" "}
              {report.batch.terms.interest_value}
              {report.batch.terms.interest_type === "flat_percent"
                ? "% flat"
                : " ZMW fixed interest per loan"}{" "}
              · Due {report.batch.terms.term_days} days after disbursement.
            </p>
          )}
          <div className="import-counts">
            <span>
              <b>{report.batch.accepted}</b> accepted
            </span>
            <span>
              <b>{report.batch.rejected}</b> rejected
            </span>
            <span>
              <b>{report.batch.unchanged}</b> unchanged
            </span>
          </div>
          <button
            className="text-button"
            onClick={downloadErrors}
            disabled={busy}
          >
            <ArrowDownToLine size={14} />
            Download error / validation report
          </button>
          <div
            className="table-scroll import-preview-table"
            tabIndex={0}
            aria-label="Import preview rows"
          >
            <table>
              <thead>
                <tr>
                  <th>Excel row / no#</th>
                  <th>Client / Man#</th>
                  <th>Department / designation</th>
                  <th>
                    {report.batch.mode === "loans"
                      ? "Amount Disbursed"
                      : "amount (ignored)"}
                  </th>
                  <th>Interest charge</th>
                  <th>Total obligation</th>
                  <th>Outcome</th>
                  <th>Errors / warnings</th>
                </tr>
              </thead>
              <tbody>
                {report.rows.map((row) => (
                  <tr key={row.id}>
                    <td>
                      {row.excel_row} / {row.source_no}
                    </td>
                    <td>
                      {row.data.name}
                      <small className="register-subtitle">
                        {row.data.man_number}
                      </small>
                    </td>
                    <td>
                      {row.data.department}
                      <small className="register-subtitle">
                        {row.data.designation}
                      </small>
                    </td>
                    <td>{row.data.amount}</td>
                    <td>
                      {row.data.interest_cents == null
                        ? "—"
                        : money(row.data.interest_cents)}
                    </td>
                    <td>
                      {row.data.total_obligation_cents == null
                        ? "—"
                        : money(row.data.total_obligation_cents)}
                    </td>
                    <td>{row.outcome}</td>
                    <td className="import-row-notes">
                      {row.errors.map((text, i) => (
                        <p key={`e${i}`} className="import-row-error">
                          {text}
                        </p>
                      ))}
                      {row.warnings.map((text, i) => (
                        <p key={`w${i}`}>{text}</p>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {report.batch.status === "preview" ? (
            canPreview ? (
              <>
                <p className="form-hint">
                  Only accepted rows will be saved. Rejected rows are skipped;
                  unchanged rows do not create or update Clients. No conflicting
                  Client details are overwritten.
                </p>
                <label className="import-confirm">
                  <RequiredMark />
                  <input
                    type="checkbox"
                    required
                    checked={confirmed}
                    disabled={busy}
                    onChange={(e) => setConfirmed(e.target.checked)}
                  />
                  I reviewed all rows and warnings
                  {report.batch.mode === "loans"
                    ? " and confirm the disbursement date, interest, and due-date rule"
                    : ""}
                  .
                </label>
                <button
                  className="button primary"
                  type="button"
                  disabled={
                    busy ||
                    !confirmed ||
                    !canPreview ||
                    (report.batch.accepted === 0 && report.batch.rejected > 0)
                  }
                  onClick={commit}
                >
                  Confirm {report.batch.accepted} accepted rows
                </button>
              </>
            ) : (
              <p>
                Saved preview. Your access is read-only; an authorized importer
                must confirm it.
              </p>
            )
          ) : (
            <p className="import-saved" role="status">
              {sampleActive
                ? "Demo confirmation complete. No Client, loan or financial records were saved. Your business workspace is unchanged."
                : "Import completed. Repeated submissions return this result without creating duplicate records."}
            </p>
          )}
        </section>
      )}
      <section className="import-history">
        <h3>Import history</h3>
        <p className="form-hint">
          {sampleActive
            ? "Demo previews stay on this screen only and do not enter business import history."
            : "Includes staged previews and completed imports. Uploader is the Supabase Auth user ID. Times use Africa/Lusaka."}
        </p>
        {historyError && (
          <p role="alert" className="form-error">
            {historyError}
          </p>
        )}
        {!history.length && (
          <p className="form-hint">No import history on this page.</p>
        )}
        {history.map((batch) => (
          <article key={batch.id}>
            <div>
              <strong>{batch.filename}</strong>
              <p>
                {batch.mode === "clients"
                  ? "Client register"
                  : "Loan disbursement"}{" "}
                · {batch.status} · {batch.accepted} accepted / {batch.rejected}{" "}
                rejected / {batch.unchanged} unchanged
              </p>
              <small>
                Uploaded {formatBusinessTimestamp(batch.created_at)} by{" "}
                {batch.uploaded_by}
                {batch.completed_at
                  ? ` · Completed ${formatBusinessTimestamp(batch.completed_at)}`
                  : ""}
              </small>
            </div>
            <button
              className="text-button"
              disabled={busy}
              onClick={async () => {
                working(true);
                setError("");
                setConfirmed(false);
                try {
                  setReport(await api(`report?id=${batch.id}`));
                } catch (e) {
                  setError(
                    e instanceof Error ? e.message : "Could not load report.",
                  );
                } finally {
                  working(false);
                }
              }}
            >
              View result
            </button>
          </article>
        ))}
        {readable && (
          <div className="history-pagination">
            <button
              className="button secondary"
              disabled={busy || page === 0}
              onClick={() => setPage((p) => p - 1)}
            >
              Previous
            </button>
            <span>Page {page + 1}</span>
            <button
              className="button secondary"
              disabled={busy || history.length < 20}
              onClick={() => setPage((p) => p + 1)}
            >
              Next
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
