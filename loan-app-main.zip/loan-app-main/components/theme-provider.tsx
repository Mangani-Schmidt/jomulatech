"use client";
import {
  createContext,
  useContext,
  useLayoutEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  themeStorageKey,
  themePreference,
  resolvedTheme,
  type ThemePreference,
} from "@/lib/theme";
const ThemeContext = createContext<{
  preference: ThemePreference;
  ready: boolean;
  storageError: string;
  choose: (preference: ThemePreference) => void;
} | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  // Identical server/client markup. The head script styles the page before
  // hydration; layout effect restores attributes during Strict Mode remounts.
  const [preference, setPreference] = useState<ThemePreference>("system");
  const [ready, setReady] = useState(false),
    [storageError, setStorageError] = useState("");
  const applyRef = useRef<(value: ThemePreference) => void>(() => {});
  useLayoutEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    let current: ThemePreference = "system";
    function apply(next: ThemePreference) {
      current = next;
      const theme = resolvedTheme(next, media.matches);
      document.documentElement.dataset.theme = theme;
      document.documentElement.dataset.themePreference = next;
      document.documentElement.style.colorScheme = theme;
      setPreference(next);
    }
    try {
      current = themePreference(localStorage.getItem(themeStorageKey));
    } catch {
      current = themePreference(
        document.documentElement.dataset.themePreference,
      );
      setStorageError(
        "Your browser cannot save the theme. It will apply for this visit.",
      );
    }
    apply(current);
    applyRef.current = apply;
    setReady(true);
    const systemChanged = () => {
      if (current === "system") apply(current);
    };
    const storedChanged = (event: StorageEvent) => {
      if (event.key !== themeStorageKey && event.key !== null) return;
      if (event.storageArea) {
        try {
          if (event.storageArea !== localStorage) return;
        } catch {
          return;
        }
      }
      apply(themePreference(event.newValue));
    };
    media.addEventListener("change", systemChanged);
    window.addEventListener("storage", storedChanged);
    return () => {
      media.removeEventListener("change", systemChanged);
      window.removeEventListener("storage", storedChanged);
    };
  }, []);
  function choose(value: ThemePreference) {
    const next = themePreference(value);
    applyRef.current(next);
    try {
      localStorage.setItem(themeStorageKey, next);
      setStorageError("");
    } catch {
      setStorageError(
        "Your browser cannot save the theme. It will apply for this visit.",
      );
    }
  }
  return (
    <ThemeContext.Provider value={{ preference, ready, storageError, choose }}>
      {children}
    </ThemeContext.Provider>
  );
}
export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context)
    throw new Error("Theme controls require the application ThemeProvider.");
  return context;
}
