import { PublicShell } from "./public-shell";
import { AuthForm, type AuthMode } from "./auth-form";
export function AuthPage({ mode }: { mode: AuthMode }) {
  return (
    <PublicShell>
      <section className="auth-card">
        <span className="eyebrow">LENDTRACK</span>
        <h1>
          {mode === "login"
            ? "Log In"
            : mode === "signup"
              ? "Create your account"
              : "Reset your password"}
        </h1>
        <p>
          {mode === "signup"
            ? "Create an account, confirm your email if required, then ask an Administrator to assign your business access."
            : mode === "forgot"
              ? "Enter your account email and we'll request a recovery link."
              : "Log in to your approved business workspace."}
        </p>
        <AuthForm mode={mode} />
      </section>
    </PublicShell>
  );
}
