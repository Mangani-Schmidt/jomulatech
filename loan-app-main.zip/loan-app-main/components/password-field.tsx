"use client";
import { RequiredMark } from "./form-controls";
import { useId, useState, type InputHTMLAttributes } from "react";
import { Eye, EyeOff } from "lucide-react";
import { MIN_PASSWORD_LENGTH } from "@/lib/auth";
export function PasswordField({
  label = "Password",
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label?: string }) {
  const id = useId(),
    [visible, setVisible] = useState(false);
  return (
    <div className="password-field">
      <label htmlFor={id}>
        <span className="field-label">
          {label}
          {props.required && <RequiredMark />}
        </span>
      </label>
      <div className="password-input-wrap">
        <input
          {...props}
          id={id}
          type={visible ? "text" : "password"}
          minLength={MIN_PASSWORD_LENGTH}
        />
        <button
          type="button"
          className="password-toggle"
          aria-label={`${visible ? "Hide" : "Show"} ${label.toLowerCase()}`}
          aria-pressed={visible}
          onClick={() => setVisible((v) => !v)}
          disabled={props.disabled}
        >
          {visible ? (
            <EyeOff size={18} aria-hidden="true" />
          ) : (
            <Eye size={18} aria-hidden="true" />
          )}
        </button>
      </div>
    </div>
  );
}
