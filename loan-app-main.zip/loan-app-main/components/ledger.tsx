"use client";
import { useReadScope } from "@/lib/use-read-scope";
import { ScopedSnapshotCache } from "@/lib/scoped-snapshot";
import type { ReportSource } from "@/lib/reporting";
import { sessionIdentity } from "@/lib/session-activity";
import { formatBusinessTimestamp } from "@/lib/business-time";
import { DateInput, Form, RequiredMark } from "./form-controls";

import { useEffect, useRef, useState, useMemo, type FormEvent } from "react";
import {
  ArrowDownLeft,
  ArrowDownToLine,
  ArrowRight,
  Bell,
  BookOpen,
  Check,
  ChevronRight,
  CircleHelp,
  FileSpreadsheet,
  LayoutDashboard,
  Leaf,
  LoaderCircle,
  LogOut,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Users,
  Wallet,
  X,
} from "lucide-react";
import type { Session } from "@supabase/supabase-js";
import { useSupabase, useWorkspaceBase } from "@/lib/workspace-context";
import {
  businessDate,
  isCollectible,
  isPosted,
  cents,
  clientSchema,
  money,
  status,
  today,
  findClients,
  type Client,
  type Loan,
  type Repayment,
} from "@/lib/domain";
import { LoanOrigination } from "@/components/loan-origination";
import { LoanTerms } from "@/components/loan-terms";
import { useBusinessDate } from "@/lib/use-business-date";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import { AuditHistory } from "./audit-history";
import { Pagination } from "./pagination";
import {
  findRegisteredMan,
  localManConflict,
  sameManNumber,
} from "@/lib/client-register";
import {
  periodRange,
  repaymentPeriod,
  exactSum,
  type PeriodPreset,
} from "@/lib/report-period";
import { ClientLifecycle } from "./client-lifecycle";
import { ClientManConflict } from "./client-man-conflict";
import { ClientFields } from "@/components/client-fields";
import { RepaymentForm } from "@/components/repayment-form";
import { ReportingWorkspace } from "@/components/reporting-workspace";
import { FinancialDocument } from "@/components/financial-document";
import {
  ClientFinancialSummary,
  ClientBalance,
} from "@/components/client-financial-summary";
import { WorkspaceNavigation } from "@/components/workspace-navigation";
import { clientLabels, viewHashes, type WorkspaceView } from "@/lib/ui-labels";
import { ImportWorkspace } from "@/components/import-workspace";
import { useLedgerSnapshot } from "@/lib/use-ledger-snapshot";
import { brand } from "@/lib/brand";
import { useSessionSafety } from "./session-boundary";
import { ThemeSelector } from "./theme-selector";
import { ReadAccessError, requireReadAccess } from "@/lib/read-access";
import { AccessDenied } from "./access-denied";
import {
  firstAccessiblePath,
  hasCapability,
  viewCapability,
} from "@/lib/access";
import { AuthForm } from "./auth-form";

type Tab = WorkspaceView;
type Modal =
  | "receipt"
  | "statement"
  | "terms"
  | "client"
  | "edit"
  | "loan"
  | "repayment"
  | "auth"
  | "import"
  | "help"
  | null;
const fmtDate = (value: string) =>
  new Date(businessDate(value) + "T12:00:00Z").toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

export function Ledger() {
  const sessionSafety = useSessionSafety();
  const supabase = useSupabase();
  const workspaceBase = useWorkspaceBase();
  const demo = !supabase;
  const businessDay = useBusinessDate();
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(demo);
  const defaults = useLoanDefaults();
  const dataScope = JSON.stringify([
    session ? sessionIdentity(session) : "signed-out",
    defaults.value?.settings.owner_id,
    Object.entries(defaults.value?.capabilities ?? {}).sort(([a], [b]) =>
      a.localeCompare(b),
    ),
  ]);
  const verifyDataScope = useReadScope(dataScope);
  const reportCache = useRef(new ScopedSnapshotCache<ReportSource>()).current;
  reportCache.setScope(dataScope);
  useEffect(() => () => reportCache.clear(), [reportCache]);
  const ledger = useLedgerSnapshot(session?.user.id ?? null, dataScope);
  const {
    clients,
    loans,
    repayments,
    refresh,
    revision: ledgerRevision,
    reportRevision,
    loading: ledgerLoading,
  } = ledger;
  const ledgerReady = demo || (ledgerRevision > 0 && !ledger.error);
  const [tab, setTab] = useState<Tab>("Dashboard");
  const [search, setSearch] = useState("");
  const [repayPreset, setRepayPreset] = useState<PeriodPreset>("This Month");
  const [repayCustom, setRepayCustom] = useState({
    from: businessDay,
    to: businessDay,
  });
  const [repayCurrency, setRepayCurrency] = useState("ZMW");
  const repayRange =
    repayPreset === "Custom Date Range"
      ? repayCustom
      : periodRange(repayPreset, businessDay);
  useEffect(() => setPage(1), [repayRange.from, repayRange.to, repayCurrency]);
  const [historyClientId, setHistoryClientId] = useState<string | null>(null);
  const heading = useRef<HTMLHeadingElement>(null);
  const previousTab = useRef<Tab>("Dashboard");
  const [page, setPage] = useState(1);
  useEffect(() => setPage(1), [tab, search, historyClientId]);
  const [filter, setFilter] = useState("All loans");
  const [modal, setModal] = useState<Modal>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [termsLoan, setTermsLoan] = useState<Loan | null>(null);
  const [newManNumber, setNewManNumber] = useState("");
  const [enteredMan, setEnteredMan] = useState("");
  const [manConflict, setManConflict] = useState<{
    man: string;
    client: Client;
  } | null>(null);
  useEffect(() => {
    setEnteredMan(
      modal === "edit" ? (editingClient?.man_number ?? "") : newManNumber,
    );
    setManConflict(null);
  }, [modal, editingClient?.id, editingClient?.revision, newManNumber]);
  const [documentId, setDocumentId] = useState("");
  const [selectedLoan, setSelectedLoan] = useState("");
  const dialog = useRef<HTMLDialogElement>(null);
  const permissionClosedDialog = useRef(false);
  useEffect(() => {
    if (!supabase) return;
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      setReady(true);
      if (!next) {
        setModal(null);
        ledger.clear();
      }
    });
    return () => subscription.unsubscribe();
  }, []);
  useEffect(() => {
    if (ledger.error) setError(ledger.error);
  }, [ledger.error]);
  useEffect(() => {
    if (modal && (!defaults.loading || defaults.value))
      dialog.current?.showModal();
    else {
      if (defaults.loading && dialog.current?.open)
        permissionClosedDialog.current = true;
      dialog.current?.close();
    }
  }, [modal, defaults.loading]);
  async function navigate(next: Tab, clientId: string | null = null) {
    if (!demo) await defaults.reload();
    ledger.refreshIfStale();
    setPage(1);
    setTab(next);
    setSearch("");
    setFilter("All loans");
    setHistoryClientId(clientId);
    const fragment =
      viewHashes[next] +
      (clientId ? `?client_id=${encodeURIComponent(clientId)}` : "");
    window.history.pushState(null, "", `${workspaceBase}/#${fragment}`);
  }
  useEffect(() => {
    function restore() {
      setPage(1);
      const [key, query] = window.location.hash.slice(1).split("?");
      const view =
        (Object.keys(viewHashes) as Tab[]).find((v) => viewHashes[v] === key) ??
        "Dashboard";
      setTab(view);
      setSearch("");
      setFilter("All loans");
      setHistoryClientId(
        view === "Loans" ? new URLSearchParams(query).get("client_id") : null,
      );
    }
    restore();
    const historyChanged = () => {
      if (demo) restore();
      else void defaults.reload().then(restore);
    };
    window.addEventListener("popstate", historyChanged);
    window.addEventListener("hashchange", historyChanged);
    return () => {
      window.removeEventListener("popstate", historyChanged);
      window.removeEventListener("hashchange", historyChanged);
    };
  }, []);
  useEffect(() => {
    if (previousTab.current !== tab) {
      heading.current?.focus();
      previousTab.current = tab;
    }
  }, [tab]);
  async function open(next: Modal) {
    if (
      (next === "client" && !canRegister) ||
      (next === "loan" && !canOriginate) ||
      (next === "repayment" && !canRepay) ||
      (next === "import" && !canImport) ||
      (next === "edit" && !canViewClients) ||
      (next === "terms" && !canViewLoans) ||
      (next === "receipt" && !canViewRepayments && !canViewReports) ||
      (next === "statement" && !canViewLoans && !canViewReports)
    )
      return;
    setError("");
    setMessage("");
    setNewManNumber("");
    if (!demo && ["client", "loan", "repayment", "import"].includes(next ?? ""))
      await defaults.reload();
    setModal(next);
  }
  async function accountAction() {
    if (busy) return;
    if (session) {
      await sessionSafety.logout();
    } else open("auth");
  }
  function close() {
    if (!busy) {
      setModal(null);
      setError("");
    }
  }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if ((modal === "client" || modal === "edit") && !canRegister) return;
    setBusy(true);
    setError("");
    const fields = new FormData(event.currentTarget);
    const str = (key: string) => String(fields.get(key) ?? "");
    try {
      if (!supabase)
        throw new Error(
          "Connect your Supabase project to add real data. See the setup instructions in README.md.",
        );
      if (!session) throw new Error("Sign in to manage your ledger.");
      if (modal === "client" || modal === "edit") {
        const data = clientSchema.parse({
          man_number: str("man_number"),
          department: str("department"),
          designation: str("designation"),
          address: str("address"),
          is_active: str("is_active") === "on",
          name: str("name"),
          email: str("email"),
          phone: str("phone"),
        });
        if (
          modal === "client" ||
          !sameManNumber(editingClient?.man_number ?? null, data.man_number)
        ) {
          const existing = await findRegisteredMan(supabase, data.man_number);
          if (
            existing &&
            (modal !== "edit" || existing.id !== editingClient?.id)
          ) {
            setManConflict({ man: data.man_number, client: existing });
            setError("This Man# is already registered. No Client was saved.");
            return;
          }
        }
        const { error } =
          modal === "edit" && editingClient
            ? await supabase.rpc("correct_client", {
                p_client_id: editingClient.id,
                p_details: data,
                p_reason: str("reason"),
                p_expected_revision: editingClient.revision,
              })
            : await supabase.from("clients").insert(data);
        if (error) throw error;
      }
      setMessage(
        modal === "edit"
          ? "Client correction saved and audited."
          : `${modal === "client" ? "Client" : "Loan"} created.`,
      );
      try {
        await refresh();
      } catch {
        setError(
          "Saved successfully, but the ledger could not refresh. Reload before making another entry.",
        );
      }
      setModal(null);
    } catch (e) {
      if ((e as { code?: string }).code === "23505" && supabase) {
        try {
          const existing = await findRegisteredMan(supabase, str("man_number"));
          if (
            existing &&
            (modal !== "edit" || existing.id !== editingClient?.id)
          )
            setManConflict({ man: str("man_number"), client: existing });
          setError(
            existing
              ? "This Man# is already registered. No Client was saved."
              : "The register reported a duplicate. No Client was saved. Refresh Client Register or try again.",
          );
        } catch {
          setError(
            "The register reported a duplicate, but its current record could not be loaded. No Client was saved. Check your connection and try again.",
          );
        }
      } else {
        setError(
          e && typeof e === "object" && "issues" in e
            ? ((e as { issues: { message: string }[] }).issues[0]?.message ??
                "Check the Client details.")
            : e instanceof Error
              ? e.message
              : (e as { message?: string }).message ||
                "Something went wrong. Please try again.",
        );
      }
    } finally {
      setBusy(false);
    }
  }
  async function exportReport() {
    if (!canExport || !canViewLoans || !ledgerReady || ledgerLoading) return;
    setBusy(true);
    setError("");
    try {
      if (supabase) await requireReadAccess(supabase);
      if (supabase) await requireReadAccess(supabase, "view_loans");
      const { reportWorkbook, saveWorkbook, generatedTime, workbookMoney } =
        await import("@/lib/workbook");
      const data: (string | number)[][] = [];
      const sheet = { addRow: (row: (string | number)[]) => data.push(row) };
      sheet.addRow([
        "Client",
        "Man#",
        "Department",
        "Designation",
        "Loan reference",
        "Loan ID",
        "Client ID",
        "Amount Disbursed (ZMW)",
        "Interest (ZMW)",
        "Total obligation (ZMW)",
        "Rate for entire term (%)",
        "Calculation method",
        "Rate basis",
        "Loan term (days)",
        "Currency",
        "Rounding rule",
        "Business timezone",
        "Original default rate (%)",
        "Original settings revision",
        "Rate override reason",
        "Terms revision",
        "Repayment Received (ZMW)",
        "Outstanding (ZMW)",
        "Balance written off (ZMW)",
        "Creator",
        "Creator inferred",
        "Created at",
        "Updated at",
        "Disbursement date",
        "Due date",
        "Status",
      ]);
      for (const loan of visibleLoans)
        sheet.addRow([
          clientIndex.get(loan.client_id)?.name ?? "Client",
          clientIndex.get(loan.client_id)?.man_number ?? "",
          clientIndex.get(loan.client_id)?.department ?? "",
          clientIndex.get(loan.client_id)?.designation ?? "",
          loan.loan_reference ?? loan.id,
          loan.id,
          loan.client_id,
          loan.principal_cents / 100,
          loan.interest_cents / 100,
          (loan.principal_cents + loan.interest_cents) / 100,
          loan.interest_rate_bps == null
            ? "Not recorded"
            : loan.interest_rate_bps / 100,
          loan.calculation_method ?? "Legacy fixed charge",
          loan.rate_basis ?? "Not recorded",
          loan.term_days ?? "Not recorded",
          loan.currency ?? "ZMW",
          loan.rounding_rule ?? "half_up_2",
          loan.business_timezone ?? "Africa/Lusaka",
          loan.default_rate_bps_at_origination == null
            ? "Not recorded"
            : loan.default_rate_bps_at_origination / 100,
          loan.settings_revision ?? "Not recorded",
          loan.rate_override_reason ?? "",
          loan.terms_revision ?? 1,
          repayments
            .filter((r) => r.loan_id === loan.id && isPosted(r))
            .reduce((sum, r) => sum + r.amount_cents, 0) / 100,
          loan.balance_cents / 100,
          (loan.written_off_cents ?? 0) / 100,
          loan.created_by ?? "Not recorded",
          loan.creator_inferred ? "Yes" : "No",
          loan.created_at,
          loan.updated_at ?? "Not recorded",
          loan.disbursement_date ?? businessDate(loan.created_at),
          loan.due_date,
          status(loan, businessDay),
        ]);
      const headers = data[0],
        currencyIndex = headers.indexOf("Currency");
      const currencies = [
        ...new Set(data.slice(1).map((row) => String(row[currencyIndex]))),
      ];
      const wb = reportWorkbook(
        "Client loan history",
        [
          [
            "Scope",
            "All matching issued loans; current balances, not a dated accounting-period report.",
          ],
          ["Search", search || "All"],
          ["Status", filter],
          [
            "Clients Receiving Loans (all matching disbursements)",
            new Set(visibleLoans.map((l) => l.client_id)).size,
          ],
          ["Loans issued (all matching disbursements)", visibleLoans.length],
          ["Client ID", historyClientId || "All"],
          ["Generated at", generatedTime(new Date().toISOString())],
          ["Currencies", "Separate worksheets and totals per currency"],
        ],
        currencies.map((currency) => {
          const rows = data
            .slice(1)
            .filter((row) => row[currencyIndex] === currency);
          return {
            name: "Loans " + currency,
            currency,
            columns: headers.map((h) => ({
              label: String(h).replaceAll("(ZMW)", "(" + currency + ")"),
              kind: String(h).includes("(ZMW)")
                ? ("money" as const)
                : String(h).includes("date")
                  ? ("date" as const)
                  : String(h).includes("(%)")
                    ? ("number" as const)
                    : /revision|\(days\)/i.test(String(h))
                      ? ("integer" as const)
                      : ("text" as const),
            })),
            rows,
            totals: headers.map((h, i) =>
              i === 0
                ? "TOTAL"
                : String(h).includes("(ZMW)")
                  ? workbookMoney(
                      exactSum(
                        rows.map((row) => Math.round(Number(row[i]) * 100)),
                      ),
                    )
                  : "",
            ),
          };
        }),
      );
      if (supabase) {
        await requireReadAccess(supabase);
        await requireReadAccess(supabase, "view_loans");
      }
      await saveWorkbook(wb, `client-loan-report-${today()}.xlsx`, async () => {
        if (supabase) {
          await requireReadAccess(supabase);
          await requireReadAccess(supabase, "view_loans");
        }
        verifyDataScope();
      });
      setMessage("Client loan report exported.");
    } catch (failure) {
      if (failure instanceof ReadAccessError && failure.denied)
        void defaults.reload();
      setError(
        failure instanceof ReadAccessError
          ? failure.message
          : "Report export failed. Please try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  const active = loans.filter(isCollectible);
  const overdue = active.filter((l) => status(l, businessDay) === "Overdue");
  const clientIndex = useMemo(
    () => new Map(clients.map((c) => [c.id, c])),
    [clients],
  );
  const loanIndex = useMemo(
    () => new Map(loans.map((l) => [l.id, l])),
    [loans],
  );
  const matchingClients = useMemo(
    () => findClients(clients, search),
    [clients, search],
  );
  const matchingClientIds = useMemo(
    () => new Set(matchingClients.map((c) => c.id)),
    [matchingClients],
  );
  const clientName = (id: string) => clientIndex.get(id)?.name ?? "Client";
  const visibleLoans = loans.filter(
    (l) =>
      (!historyClientId || l.client_id === historyClientId) &&
      (matchingClientIds.has(l.client_id) ||
        (l.loan_reference ?? l.id)
          .toLowerCase()
          .includes(search.trim().toLowerCase())) &&
      (filter === "All loans" || status(l, businessDay) === filter),
  );
  const searchedRepayments = repayments.filter(
    (r) =>
      !search ||
      matchingClientIds.has(loanIndex.get(r.loan_id)?.client_id ?? "") ||
      (r.payment_reference ?? "").toLowerCase().includes(search.toLowerCase()),
  );
  const paymentResult = useMemo(() => {
    try {
      return {
        value: repaymentPeriod(
          searchedRepayments.filter(
            (r) =>
              (loanIndex.get(r.loan_id)?.currency ??
                r.receipt_snapshot?.currency ??
                "ZMW") === repayCurrency,
          ),
          repayRange.from,
          repayRange.to,
        ),
        error: "",
      };
    } catch (e) {
      return { value: null, error: (e as Error).message };
    }
  }, [
    repayments,
    search,
    clients,
    loans,
    repayCurrency,
    repayRange.from,
    repayRange.to,
  ]);
  const matchingRepayments = paymentResult.value?.rows ?? [];
  const receiptMoney = (n: number) =>
    new Intl.NumberFormat("en-ZM", {
      style: "currency",
      currency: repayCurrency,
    }).format(n / 100);
  async function exportRepayments() {
    if (
      !canExport ||
      !canViewRepayments ||
      !paymentResult.value ||
      !ledgerReady ||
      ledgerLoading
    )
      return;
    setBusy(true);
    setError("");
    setMessage("");
    try {
      if (supabase) {
        await requireReadAccess(supabase);
        await requireReadAccess(supabase, "view_repayments");
      }
      const { reportWorkbook, saveWorkbook, generatedTime, workbookMoney } =
        await import("@/lib/workbook");
      const p = paymentResult.value;
      const wb = reportWorkbook(
        "Repayment history",
        [
          ["Payment date from", repayRange.from],
          ["Payment date to (inclusive)", repayRange.to],
          ["Currency", repayCurrency],
          ["Search", search || "All"],
          ["Generated at", generatedTime(new Date().toISOString())],
          [
            "Policy",
            "Receipt history by payment date. Totals include currently posted receipts; reversed rows remain visible with zero current effect. Accounting-period reversals/corrections use Reports. Principal received is not profit.",
          ],
        ],
        [
          {
            name: "Filtered repayments",
            currency: repayCurrency,
            columns: [
              { label: "Payment reference" },
              { label: "Payment date", kind: "date" },
              { label: "Client" },
              { label: "Man#" },
              { label: "Loan reference" },
              { label: "Status" },
              { label: "Method" },
              { label: "External reference" },
              { label: "Repayment Received", kind: "money" },
              { label: "Principal allocation", kind: "money" },
              { label: "Interest allocation", kind: "money" },
              { label: "Current net receipt", kind: "money" },
            ],
            rows: p.rows.map((r) => {
              const l = loanIndex.get(r.loan_id),
                c = l ? clientIndex.get(l.client_id) : undefined;
              return [
                r.payment_reference ?? r.id,
                r.payment_date ?? businessDate(r.created_at),
                c?.name ?? "Client",
                c?.man_number ?? "",
                l?.loan_reference ?? r.loan_id,
                isPosted(r) ? "Posted" : "Reversed",
                r.payment_method ?? "Not recorded",
                r.external_reference ?? "",
                r.amount_cents / 100,
                r.principal_allocation_cents == null
                  ? "Not recorded"
                  : r.principal_allocation_cents / 100,
                r.interest_allocation_cents == null
                  ? "Not recorded"
                  : r.interest_allocation_cents / 100,
                isPosted(r) ? r.amount_cents / 100 : 0,
              ];
            }),
            totals: [
              "TOTAL (posted only)",
              ...Array(8).fill(""),
              p.principal == null ? "Not recorded" : workbookMoney(p.principal),
              p.interest == null ? "Not recorded" : workbookMoney(p.interest),
              workbookMoney(p.received),
            ],
          },
        ],
      );
      if (supabase) {
        await requireReadAccess(supabase);
        await requireReadAccess(supabase, "view_repayments");
      }
      await saveWorkbook(
        wb,
        `repayments-${repayRange.from}-${repayRange.to}-${repayCurrency}.xlsx`,
        async () => {
          if (supabase) {
            await requireReadAccess(supabase);
            await requireReadAccess(supabase, "view_repayments");
          }
          verifyDataScope();
        },
      );
      setMessage("Filtered repayment workbook downloaded.");
    } catch (e) {
      setError((e as Error).message ?? "Repayment export failed.");
      if (e instanceof ReadAccessError && e.denied) void defaults.reload();
    } finally {
      setBusy(false);
    }
  }
  const requiresAuth = !!supabase && !session;
  const capabilities = defaults.value?.capabilities;
  const canRead =
    demo || (!!session && hasCapability(capabilities, "can_read"));
  const canRegister =
    demo || (!!session && hasCapability(capabilities, "can_register_clients"));
  const canOriginate =
    demo || (!!session && hasCapability(capabilities, "can_originate"));
  const canRepay =
    demo || (!!session && hasCapability(capabilities, "can_post_repayments"));
  const canImport =
    demo || (!!session && hasCapability(capabilities, "can_import"));
  const canViewClients =
    demo || hasCapability(capabilities, "can_view_clients");
  const canViewLoans = demo || hasCapability(capabilities, "can_view_loans");
  const canViewRepayments =
    demo || hasCapability(capabilities, "can_view_repayments");
  const canViewReports =
    demo || hasCapability(capabilities, "can_view_reports");
  const canExport = demo || hasCapability(capabilities, "can_export_reports");
  const viewAllowed =
    demo || (!!session && hasCapability(capabilities, viewCapability[tab]));
  const modalAllowed =
    modal === "client"
      ? canRegister
      : modal === "loan"
        ? canOriginate
        : modal === "repayment"
          ? canRepay
          : modal === "import"
            ? canImport
            : ["edit", "terms", "receipt", "statement"].includes(modal ?? "")
              ? modal === "edit"
                ? canViewClients
                : modal === "terms"
                  ? canViewLoans
                  : modal === "receipt"
                    ? canViewRepayments || canViewReports
                    : canViewLoans || canViewReports
              : true;
  const duplicateClient =
    modal === "client" || modal === "edit"
      ? manConflict && sameManNumber(manConflict.man, enteredMan)
        ? manConflict.client
        : localManConflict(
            clients,
            enteredMan,
            modal === "edit" ? editingClient?.id : undefined,
          )
      : null;
  const headingAction =
    tab === "Clients"
      ? canRegister
      : tab === "Repayments"
        ? canRepay
        : canOriginate;
  return (
    <div className="app-shell">
      <a
        href="#workspace-content"
        className="skip-link"
        onClick={(e) => {
          e.preventDefault();
          document.getElementById("workspace-content")?.focus();
        }}
      >
        Skip to main content
      </a>
      <WorkspaceNavigation
        current={tab}
        capabilities={capabilities}
        demo={demo}
        onNavigate={navigate}
        pending={busy}
      >
        <div className="sidebar-bottom">
          <button className="nav-item" onClick={() => open("help")}>
            <CircleHelp size={19} />
            Help & getting started
          </button>
          <div className="profile">
            <span className="avatar">
              {session?.user.email?.slice(0, 2).toUpperCase() || brand.initials}
            </span>
            <div>
              <strong>
                {session ? "My workspace" : `${brand.name} workspace`}
              </strong>
              <small>
                {demo
                  ? "Preview account"
                  : session
                    ? "Business ledger"
                    : "Sign in to continue"}
              </small>
            </div>
            {!session && (
              <button
                aria-label="Sign in"
                disabled={busy}
                onClick={accountAction}
              >
                <LogOut size={17} />
              </button>
            )}
          </div>
        </div>
      </WorkspaceNavigation>
      <main id="workspace-content" tabIndex={-1} aria-busy={ledgerLoading}>
        <header className="topbar">
          <div className="breadcrumb">
            Workspace <ChevronRight size={13} />
            <span>
              {viewAllowed
                ? tab === "Loans"
                  ? clientLabels.history
                  : tab
                : defaults.loading || !ready
                  ? "Checking access…"
                  : "Access denied"}
            </span>
          </div>
          <div className="top-actions">
            {demo && (
              <a className="text-button demo-entry" href="/">
                Exit demo
              </a>
            )}
            <span className="secure">
              <span /> {demo ? "Demo workspace" : "Business workspace"}
            </span>
            {canViewLoans && (
              <button
                className="icon-button"
                disabled={busy}
                aria-label="View overdue loans"
                onClick={() => {
                  navigate("Loans");
                  setFilter("Overdue");
                }}
              >
                <Bell size={19} />
                {overdue.length > 0 && <i />}
              </button>
            )}
            {!session && (
              <button
                className="icon-button mobile-account-action"
                aria-label="Sign in"
                disabled={busy}
                onClick={accountAction}
              >
                <LogOut size={18} />
              </button>
            )}
            {session && hasCapability(capabilities, "can_view_settings") ? (
              <a
                className="avatar small"
                href="/settings"
                aria-label="Settings"
              >
                <Settings size={17} />
              </a>
            ) : (
              <span className="avatar small">
                {session?.user.email?.slice(0, 2).toUpperCase() ||
                  brand.initials}
              </span>
            )}
          </div>
          <ThemeSelector />
        </header>
        <div className="page-content">
          {viewAllowed && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">YOUR BUSINESS AT A GLANCE</div>
                  <h1 ref={heading} tabIndex={-1}>
                    {tab === "Dashboard"
                      ? "Dashboard"
                      : tab === "Clients"
                        ? clientLabels.register
                        : tab === "Loans"
                          ? clientLabels.history
                          : tab === "Repayments"
                            ? "Every payment accounted for."
                            : tab === "New Loan"
                              ? "New Loan"
                              : tab === "Excel Imports"
                                ? "Excel Imports"
                                : "Reports"}
                  </h1>
                  <p>
                    {tab === "Dashboard"
                      ? "Your lending business at a glance."
                      : tab === "Clients"
                        ? "Build lasting relationships. Keep every Client within reach."
                        : tab === "Loans"
                          ? "Track balances, due dates, and the next step for every loan."
                          : tab === "Repayments"
                            ? "An immutable record of money received, down to the ngwee."
                            : tab === "New Loan"
                              ? "Select a Client, enter the disbursement, and review the obligation."
                              : tab === "Excel Imports"
                                ? "Choose an import mode, preview every row, and confirm before saving."
                                : "See what came in, what went out and what you earned."}
                  </p>
                </div>
                {tab !== "Dashboard" &&
                  tab !== "New Loan" &&
                  tab !== "Excel Imports" &&
                  headingAction && (
                    <button
                      className="button primary"
                      disabled={
                        busy ||
                        (tab === "Clients"
                          ? !canRegister
                          : tab === "Repayments"
                            ? !canRepay
                            : !canOriginate)
                      }
                      onClick={() =>
                        open(
                          tab === "Clients"
                            ? "client"
                            : tab === "Repayments"
                              ? "repayment"
                              : "loan",
                        )
                      }
                    >
                      <Plus size={17} />
                      {tab === "Clients"
                        ? "Add Client"
                        : tab === "Repayments"
                          ? "Record Repayment Received"
                          : "New Loan"}
                    </button>
                  )}
              </div>
            </>
          )}
          {demo && (
            <div className="demo-note">
              <span>
                <BookOpen size={15} />
                <strong>You’re exploring a demo.</strong> Sample data gives you
                a feel for your workspace.
              </span>
              <button onClick={() => open("help")}>
                Set up your ledger <ArrowRight size={14} />
              </button>
            </div>
          )}
          {session && (
            <div className="form-hint">
              Role:{" "}
              {capabilities?.role
                ?.replaceAll("_", " ")
                .replace(/(^|\s)\S/g, (c) => c.toUpperCase()) ??
                "Unassigned"}{" "}
              {tab !== "Dashboard" && <>· Auth user ID: {session.user.id}</>}
            </div>
          )}
          {session && defaults.error && (
            <p className="notice error" role="alert">
              {defaults.error}
              <button
                type="button"
                className="text-button"
                onClick={() => void defaults.reload()}
              >
                Retry business access
              </button>
            </p>
          )}
          {!ready && (
            <div className="notice">
              <LoaderCircle size={17} className="spin" />
              Checking your session…
            </div>
          )}
          {ledgerLoading && (
            <p className="notice" role="status">
              Loading Client records, loans, and repayments…
            </p>
          )}
          {session && ledger.error && (
            <button
              type="button"
              className="button secondary"
              disabled={ledgerLoading}
              onClick={() => {
                setError("");
                void refresh().catch(() => {});
              }}
            >
              Retry ledger snapshot
            </button>
          )}
          {requiresAuth && ready && (
            <div className="notice">
              Sign in with an assigned business role to access the Client
              ledger.
              <button className="button primary" onClick={() => open("auth")}>
                Sign in
              </button>
            </div>
          )}
          {message && (
            <div className="notice success" role="status">
              <Check size={17} />
              {message}
              <button
                aria-label="Dismiss notification"
                onClick={() => setMessage("")}
              >
                <X size={16} />
              </button>
            </div>
          )}
          {error && !modal && (
            <div className="notice error" role="alert">
              {error}
            </div>
          )}
          {!defaults.loading && ready && !viewAllowed && (
            <AccessDenied capabilities={capabilities} />
          )}
          {(defaults.loading || !ready) && (
            <p role="status">Checking business permissions…</p>
          )}
          {viewAllowed && (
            <>
              {tab === "New Loan" && (
                <section className="panel workspace-form" aria-label="New Loan">
                  {!ready || (!defaults.value && defaults.loading) ? (
                    <p role="status">Loading loan access and defaults…</p>
                  ) : !canOriginate ? (
                    <p role="alert">
                      An Administrator or Loan Officer role is required to
                      create a loan.
                    </p>
                  ) : (
                    <LoanOrigination
                      key={session?.user.id ?? "demo"}
                      clients={clients}
                      authorized={!!session && !!canOriginate}
                      onAdd={
                        canRegister && session
                          ? (query) => {
                              open("client");
                              setNewManNumber(query);
                            }
                          : undefined
                      }
                      onCancel={() => navigate("Dashboard")}
                      onBusy={setBusy}
                      onSaved={async () => {
                        await refresh();
                        navigate("Loans");
                        setMessage("Loan created with actual terms saved.");
                      }}
                    />
                  )}
                </section>
              )}
              {tab === "Excel Imports" && (
                <section
                  className="panel workspace-form"
                  aria-label="Excel Imports"
                >
                  {!ready || (!defaults.value && defaults.loading) ? (
                    <p role="status">Checking Excel Imports access…</p>
                  ) : (
                    <ImportWorkspace
                      authorized={!!session && !!canImport}
                      onSaved={refresh}
                      onBusy={setBusy}
                    />
                  )}
                </section>
              )}
              {(tab === "Reports" ||
                (tab === "Dashboard" &&
                  (canViewLoans || canViewRepayments))) && (
                <ReportingWorkspace
                  key={session?.user.id ?? "demo"}
                  account={session?.user.id ?? null}
                  cache={reportCache}
                  scope={dataScope}
                  revision={reportRevision}
                  detailed={tab === "Reports"}
                  onStatement={(id) => {
                    setDocumentId(id);
                    open("statement");
                  }}
                />
              )}
              {tab === "Dashboard" && !canViewLoans && !canViewRepayments && (
                <p className="notice">
                  No financial summary is included in your current module
                  access.
                </p>
              )}
              {tab === "Dashboard" && (
                <section
                  className="panel dashboard-actions"
                  aria-label="Quick actions"
                >
                  <h2>Quick actions</h2>
                  <div className="dashboard-action-buttons">
                    {canOriginate && (
                      <button
                        className="button primary"
                        disabled={busy || !ready || defaults.loading}
                        onClick={() => open("loan")}
                      >
                        <Plus size={17} aria-hidden="true" />
                        New Loan
                      </button>
                    )}
                    {canRepay && (
                      <button
                        className="button secondary"
                        disabled={busy || !ready || defaults.loading}
                        onClick={() => open("repayment")}
                      >
                        Record Repayment Received
                      </button>
                    )}
                    {canRegister && (
                      <button
                        className="button secondary"
                        disabled={busy || !ready || defaults.loading}
                        onClick={() => open("client")}
                      >
                        Add Client
                      </button>
                    )}
                    {canViewReports && (
                      <button
                        className="text-button"
                        disabled={busy}
                        onClick={() => navigate("Reports")}
                      >
                        View detailed reports{" "}
                        <ArrowRight size={15} aria-hidden="true" />
                      </button>
                    )}
                    {canViewLoans && (
                      <button
                        className="text-button"
                        disabled={busy}
                        onClick={() => navigate("Loans")}
                      >
                        View all loans{" "}
                        <ArrowRight size={15} aria-hidden="true" />
                      </button>
                    )}
                  </div>
                </section>
              )}
              {tab === "Loans" && (
                <section className="panel table-panel">
                  <div className="panel-heading">
                    <div>
                      <h2>
                        All loans{" "}
                        <span className="count">
                          {historyClientId ? visibleLoans.length : loans.length}
                        </span>
                      </h2>
                      <p>
                        {historyClientId
                          ? `Loans for ${clientName(historyClientId)}`
                          : "Every loan, one clear view"}
                      </p>
                      {historyClientId && (
                        <button
                          className="text-button"
                          onClick={() => navigate("Clients")}
                        >
                          Back to Client Register
                        </button>
                      )}
                    </div>
                    {canExport && (
                      <button
                        className="text-button"
                        onClick={exportReport}
                        disabled={busy || ledgerLoading || !ledgerReady}
                      >
                        Export report <ArrowDownToLine size={15} />
                      </button>
                    )}
                  </div>
                  <div className="table-toolbar">
                    <div className="filter-tabs">
                      {[
                        "All loans",
                        "Active",
                        "Overdue",
                        "Settled",
                        "Written off",
                      ].map((f) => (
                        <button
                          key={f}
                          className={filter === f ? "active" : ""}
                          onClick={() => {
                            setFilter(f);
                            setPage(1);
                          }}
                        >
                          {f}
                        </button>
                      ))}
                    </div>
                    <label className="search">
                      <Search size={16} />
                      <input
                        placeholder={clientLabels.search}
                        aria-label={clientLabels.search}
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                      />
                      <kbd>⌕</kbd>
                    </label>
                  </div>
                  <details className="status-rules">
                    <summary>Loan status rules</summary>
                    <p>
                      Active: an unpaid balance, due today or later. Overdue: an
                      unpaid balance after the due date. Settled: no outstanding
                      balance. Written off: an administrator has explicitly
                      closed an unpaid balance; no further receipts or
                      adjustments are allowed. Write-offs never record Repayment
                      Received. Dates use Africa/Lusaka.
                    </p>
                  </details>
                  <div
                    className="table-scroll"
                    tabIndex={0}
                    aria-label="Scrollable records"
                  >
                    <table>
                      <thead>
                        <tr>
                          <th>Loan reference</th>
                          <th>Client</th>
                          <th>Amount Disbursed</th>
                          <th>
                            {clientLabels.outstanding}
                            <small className="register-subtitle">
                              All unpaid obligations
                            </small>
                          </th>
                          <th>Due date</th>
                          <th>Status</th>
                          <th>
                            <span className="sr-only">Actions</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {visibleLoans
                          .slice((page - 1) * 20, page * 20)
                          .map((l) => (
                            <tr key={l.id}>
                              <td className="reference">
                                {l.loan_reference ?? l.id}
                              </td>
                              <td>
                                <div className="client-cell">
                                  <span
                                    className={`client-avatar tone-${clients.findIndex((c) => c.id === l.client_id) % 4}`}
                                  >
                                    {clientName(l.client_id)
                                      .split(" ")
                                      .map((n) => n[0])
                                      .slice(0, 2)
                                      .join("")}
                                  </span>
                                  <div>
                                    <strong>{clientName(l.client_id)}</strong>
                                    <small>
                                      {clients.find((c) => c.id === l.client_id)
                                        ?.email || "No email on file"}
                                    </small>
                                  </div>
                                </div>
                              </td>
                              <td>{money(l.principal_cents)}</td>
                              <td className="balance">
                                {money(l.balance_cents)}
                              </td>
                              <td>{fmtDate(l.due_date)}</td>
                              <td>
                                <span
                                  className={`badge ${status(l, businessDay).toLowerCase().replaceAll(" ", "-")}`}
                                >
                                  <span />
                                  {status(l, businessDay)}
                                </span>
                              </td>
                              <td>
                                <button
                                  className="text-button"
                                  aria-label={`View loan terms for ${clientName(l.client_id)} · ${l.loan_reference ?? l.id}`}
                                  onClick={() => {
                                    setTermsLoan(l);
                                    open("terms");
                                  }}
                                >
                                  Terms & audit
                                </button>
                                {canRepay && (
                                  <button
                                    className="row-action"
                                    disabled={!isCollectible(l)}
                                    aria-label={`Record Repayment Received for ${clientName(l.client_id)} · ${l.loan_reference ?? l.id}`}
                                    onClick={() => {
                                      setSelectedLoan(l.id);
                                      open("repayment");
                                    }}
                                  >
                                    <ArrowDownLeft size={17} />
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                    {!visibleLoans.length && (
                      <div className="empty">
                        <Wallet size={25} />
                        <h3>No loans to show</h3>
                        <p>
                          {loans.length
                            ? "Try another search or filter."
                            : "Add a Client, then create your first loan."}
                        </p>
                      </div>
                    )}
                  </div>
                  <div className="table-footer">
                    Showing{" "}
                    {Math.min(
                      visibleLoans.length,
                      Math.max(0, visibleLoans.length - (page - 1) * 20),
                      20,
                    )}{" "}
                    of {visibleLoans.length} loans<span>Amounts in ZMW</span>
                  </div>
                </section>
              )}
              {tab === "Clients" && (
                <section className="panel table-panel">
                  <div className="panel-heading">
                    <div>
                      <h2>
                        {clientLabels.register}{" "}
                        <span className="count">{clients.length}</span>
                      </h2>
                      <p>The people at the heart of your business</p>
                    </div>
                    {canImport && (
                      <button
                        className="button secondary"
                        onClick={() => open("import")}
                        disabled={busy}
                      >
                        <FileSpreadsheet size={16} />
                        Import .xlsx
                      </button>
                    )}
                  </div>
                  <div className="table-toolbar">
                    <label className="search">
                      <Search size={16} />
                      <input
                        placeholder={clientLabels.search}
                        aria-label={clientLabels.search}
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                      />
                    </label>
                  </div>
                  <div
                    className="table-scroll"
                    tabIndex={0}
                    aria-label="Scrollable records"
                  >
                    <table>
                      <thead>
                        <tr>
                          <th>Client</th>
                          <th>Man#</th>
                          <th>Department / designation</th>
                          <th>Status</th>
                          <th>Phone</th>
                          <th>Loans</th>
                          <th>
                            {clientLabels.outstanding}
                            <small className="register-subtitle">
                              All unpaid obligations
                            </small>
                          </th>
                          <th>Joined</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {matchingClients
                          .slice((page - 1) * 20, page * 20)
                          .map((c) => (
                            <tr key={c.id}>
                              <td>
                                <div className="client-cell">
                                  <span className="client-avatar">
                                    {c.name.slice(0, 2).toUpperCase()}
                                  </span>
                                  <div>
                                    <strong>{c.name}</strong>
                                    <small>
                                      {c.email || "No email on file"}
                                    </small>
                                  </div>
                                </div>
                              </td>
                              <td>{c.man_number ?? "Needs Man#"}</td>
                              <td>
                                {c.department ?? "Needs department"}
                                <small className="register-subtitle">
                                  {c.designation ?? "Needs designation"}
                                </small>
                              </td>
                              <td>
                                <span
                                  className={`badge ${c.is_active ? "active" : "paid"}`}
                                >
                                  {c.is_active ? "Active" : "Inactive"}
                                </span>
                                {!c.man_number && (
                                  <small className="register-subtitle">
                                    Complete register details
                                  </small>
                                )}
                              </td>
                              <td>{c.phone || "—"}</td>
                              <td>
                                {
                                  loans.filter((l) => l.client_id === c.id)
                                    .length
                                }
                              </td>
                              <td>
                                <ClientBalance clientId={c.id} loans={loans} />
                              </td>
                              <td>{formatBusinessTimestamp(c.created_at)}</td>
                              <td>
                                <button
                                  className="text-button"
                                  disabled={requiresAuth}
                                  aria-label={`${clientLabels.details} for ${c.name}`}
                                  onClick={() => {
                                    setEditingClient(c);
                                    open("edit");
                                  }}
                                >
                                  {clientLabels.details}
                                </button>
                                {(canViewLoans || canViewReports) && (
                                  <button
                                    className="text-button"
                                    aria-label={`${clientLabels.statement} for ${c.name}`}
                                    onClick={() => {
                                      setDocumentId(c.id);
                                      open("statement");
                                    }}
                                  >
                                    {clientLabels.statement}
                                  </button>
                                )}
                                {canViewLoans && (
                                  <button
                                    className="text-button"
                                    aria-label={`${clientLabels.history} for ${c.name}`}
                                    onClick={() => navigate("Loans", c.id)}
                                  >
                                    {clientLabels.history}
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                    {!findClients(clients, search).length && (
                      <div className="empty">
                        <Users />
                        <h3>Your next relationship starts here.</h3>
                        <p>
                          Add your first Client or import an existing workbook.
                        </p>
                      </div>
                    )}
                  </div>
                </section>
              )}
              {tab === "Clients" && (
                <Pagination
                  page={page}
                  total={matchingClients.length}
                  onPage={setPage}
                  label="Clients"
                />
              )}
              {tab === "Loans" && (
                <Pagination
                  page={page}
                  total={visibleLoans.length}
                  onPage={setPage}
                  label="loans"
                />
              )}
              {tab === "Repayments" && ledgerReady && (
                <section className="panel table-panel">
                  <div className="panel-heading">
                    <div>
                      <h2>Repayment history</h2>
                      <p>
                        Posted and reversed payments remain visible; totals
                        exclude reversals
                      </p>
                    </div>
                    <span className="period">
                      {matchingRepayments.length} matching entries
                    </span>
                  </div>
                  {repayPreset === "Custom Date Range" && (
                    <p className="required-legend">
                      <span aria-hidden="true">*</span> Required
                    </p>
                  )}
                  <fieldset className="report-filters" disabled={busy}>
                    <label>
                      Repayment period
                      <select
                        value={repayPreset}
                        onChange={(e) =>
                          setRepayPreset(e.target.value as PeriodPreset)
                        }
                      >
                        {(
                          [
                            "Today",
                            "This Week",
                            "This Month",
                            "Custom Date Range",
                          ] as const
                        ).map((p) => (
                          <option key={p}>{p}</option>
                        ))}
                      </select>
                    </label>
                    {repayPreset === "Custom Date Range" && (
                      <>
                        <label>
                          <span className="field-label">
                            Payment date from <RequiredMark />
                          </span>
                          <DateInput
                            required
                            value={repayCustom.from}
                            onChange={(e) =>
                              setRepayCustom({
                                ...repayCustom,
                                from: e.target.value,
                              })
                            }
                          />
                        </label>
                        <label>
                          <span className="field-label">
                            Payment date to <RequiredMark />
                          </span>
                          <DateInput
                            required
                            value={repayCustom.to}
                            onChange={(e) =>
                              setRepayCustom({
                                ...repayCustom,
                                to: e.target.value,
                              })
                            }
                          />
                        </label>
                      </>
                    )}
                    <label>
                      Repayment currency
                      <select
                        value={repayCurrency}
                        onChange={(e) => setRepayCurrency(e.target.value)}
                      >
                        {[
                          ...new Set([
                            "ZMW",
                            ...loans.map((l) => l.currency ?? "ZMW"),
                            ...repayments.map(
                              (r) => r.receipt_snapshot?.currency ?? "ZMW",
                            ),
                          ]),
                        ]
                          .sort()
                          .map((c) => (
                            <option key={c}>{c}</option>
                          ))}
                      </select>
                    </label>
                  </fieldset>
                  <p>
                    Payment dates {repayRange.from} to {repayRange.to},
                    inclusive · Africa/Lusaka · {repayCurrency}. This Week
                    begins Monday.
                  </p>
                  {paymentResult.error ? (
                    <p role="alert">{paymentResult.error}</p>
                  ) : (
                    <p aria-label="Filtered repayment totals">
                      Currently posted receipts:{" "}
                      {receiptMoney(paymentResult.value?.received ?? 0)} ·
                      Principal:{" "}
                      {paymentResult.value?.principal == null
                        ? "Not recorded"
                        : receiptMoney(paymentResult.value.principal)}{" "}
                      · Interest:{" "}
                      {paymentResult.value?.interest == null
                        ? "Not recorded"
                        : receiptMoney(paymentResult.value.interest)}
                      . Reversed rows have zero current effect. Use Reports for
                      accounting-period reversal and correction activity.
                    </p>
                  )}
                  {canExport && canViewRepayments && (
                    <button
                      className="button secondary"
                      disabled={busy || ledgerLoading || !paymentResult.value}
                      onClick={() => void exportRepayments()}
                    >
                      Export Repayments to Excel
                    </button>
                  )}
                  <label className="register-search">
                    Search by Man# or Client Name
                    <input
                      type="search"
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                    />
                  </label>
                  <div
                    className="table-scroll"
                    tabIndex={0}
                    aria-label="Scrollable records"
                  >
                    <table>
                      <thead>
                        <tr>
                          <th>Client</th>
                          <th>Loan reference</th>
                          <th>Repayment Received</th>
                          <th>Payment date</th>
                          <th>Interest allocation</th>
                          <th>Principal allocation</th>
                          <th>Method / external reference</th>
                          <th>Status</th>
                          <th>Payment reference</th>
                          <th>Receipt</th>
                        </tr>
                      </thead>
                      <tbody>
                        {matchingRepayments
                          .slice((page - 1) * 20, page * 20)
                          .map((r) => (
                            <tr key={r.id}>
                              <td>
                                <strong>
                                  {clientName(
                                    loanIndex.get(r.loan_id)?.client_id || "",
                                  )}
                                </strong>
                              </td>
                              <td className="reference">
                                {loanIndex.get(r.loan_id)?.loan_reference ??
                                  r.loan_id}
                              </td>
                              <td className="payment-amount">
                                + {receiptMoney(r.amount_cents)}
                              </td>
                              <td>
                                {fmtDate(r.payment_date ?? r.created_at)}
                                <small className="recorded-time">
                                  Recorded:{" "}
                                  {formatBusinessTimestamp(r.created_at)}
                                </small>
                              </td>
                              <td>
                                {r.interest_allocation_cents == null
                                  ? "Not recorded"
                                  : receiptMoney(r.interest_allocation_cents)}
                              </td>
                              <td>
                                {r.principal_allocation_cents == null
                                  ? "Not recorded"
                                  : receiptMoney(r.principal_allocation_cents)}
                              </td>
                              <td>
                                {r.payment_method?.replaceAll("_", " ") ??
                                  "Not recorded"}
                                <small className="register-subtitle">
                                  {r.external_reference ??
                                    "No external reference"}
                                </small>
                              </td>
                              <td>
                                <span
                                  className={`badge ${isPosted(r) ? "active" : "written-off"}`}
                                >
                                  {isPosted(r) ? "Posted" : "Reversed"}
                                </span>
                                {!isPosted(r) && (
                                  <small className="register-subtitle">
                                    Net effect {receiptMoney(0)}
                                  </small>
                                )}
                              </td>
                              <td className="reference">
                                {r.payment_reference ?? r.id}
                              </td>
                              <td>
                                <button
                                  className="text-button"
                                  aria-label={`View receipt ${r.payment_reference ?? r.id}`}
                                  onClick={() => {
                                    setDocumentId(r.id);
                                    open("receipt");
                                  }}
                                >
                                  Receipt & audit
                                </button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                    {!matchingRepayments.length && (
                      <div className="empty">
                        <ArrowDownLeft />
                        <h3>
                          {search
                            ? "No repayments match this search."
                            : "A fresh start."}
                        </h3>
                        <p>Recorded repayments will appear here.</p>
                      </div>
                    )}
                  </div>
                </section>
              )}
              {tab === "Repayments" && ledgerReady && (
                <Pagination
                  page={page}
                  total={matchingRepayments.length}
                  onPage={setPage}
                  label="repayments"
                />
              )}
            </>
          )}
          <footer className="page-footer">
            <span>
              <Leaf size={14} />
              Made for a business that moves people forward.
            </span>
            <span>
              <ShieldCheck size={14} />
              {demo ? "Sample data · ZMW" : "Business Client ledger · ZMW"}
            </span>
          </footer>
        </div>
      </main>
      <dialog
        inert={defaults.loading}
        className={
          modal === "import" || modal === "receipt" || modal === "statement"
            ? "wide-dialog"
            : undefined
        }
        aria-labelledby="dialog-title"
        ref={dialog}
        onCancel={(e) => {
          e.preventDefault();
          close();
        }}
        onClose={() => {
          if (permissionClosedDialog.current) {
            permissionClosedDialog.current = false;
            return;
          }
          if (!busy) setModal(null);
        }}
      >
        <div className="modal-heading">
          <div>
            <span className="eyebrow">
              {brand.name.toUpperCase()} WORKSPACE
            </span>
            <h2 id="dialog-title">
              {!modalAllowed
                ? "Access denied"
                : modal === "receipt"
                  ? "Receipt & audit"
                  : modal === "statement"
                    ? clientLabels.statement
                    : modal === "client"
                      ? clientLabels.add
                      : modal === "terms"
                        ? "Loan terms & audit"
                        : modal === "edit"
                          ? clientLabels.details
                          : modal === "loan"
                            ? "New Loan"
                            : modal === "repayment"
                              ? "Record Repayment Received"
                              : modal === "auth"
                                ? "Log In"
                                : modal === "import"
                                  ? "Excel Imports"
                                  : "A good place to start."}
            </h2>
          </div>
          <button
            className="icon-button"
            type="button"
            aria-label="Close dialog"
            onClick={close}
            disabled={busy}
          >
            <X size={20} />
          </button>
        </div>
        {!modalAllowed ? (
          <AccessDenied capabilities={capabilities} />
        ) : modal === "help" ? (
          <div className="help-content">
            <p>
              {brand.name} keeps Client records, loans, and repayments in one
              business workspace.
            </p>
            <ol>
              <li>
                Connect a Supabase project using the setup guide in{" "}
                <code>README.md</code> and apply the included migrations.
              </li>
              <li>
                Confirm your Auth account and have an Administrator assign your
                business role.
              </li>
              <li>
                Add Clients individually or import a workbook with{" "}
                <code>no#, name, man#, department, designation, amount</code>{" "}
                columns.
              </li>
              <li>
                Create loans in ZMW with a one-time flat rate, then record
                repayments as they arrive.
              </li>
            </ol>
            <p>
              Financial records are permanent. Staff roles control access to the
              business ledger. Reports include Client information; share
              exported workbooks carefully.
            </p>
            <button className="button primary" onClick={() => open("auth")}>
              Continue to sign in <ArrowRight size={16} />
            </button>
          </div>
        ) : modal === "repayment" ? (
          <RepaymentForm
            loans={loans}
            clients={clients}
            selectedId={selectedLoan}
            onCancel={close}
            onBusy={setBusy}
            onSaved={async (id) => {
              await refresh();
              setDocumentId(id);
              setModal("receipt");
              setMessage(
                "Repayment Received posted with interest-first allocation.",
              );
            }}
          />
        ) : modal === "receipt" || modal === "statement" ? (
          <FinancialDocument
            key={`${modal}-${documentId}`}
            kind={modal}
            id={documentId}
            clients={clients}
            loans={loans}
            repayments={repayments}
            onBusy={setBusy}
            onSaved={async (id) => {
              await refresh();
              setDocumentId(id);
              setModal("receipt");
              setMessage("Financial operation saved and audited.");
            }}
          />
        ) : modal === "loan" ? (
          <LoanOrigination
            onCancel={close}
            clients={clients}
            authorized={!!session && !!canOriginate}
            onAdd={
              canRegister && session
                ? (query) => {
                    open("client");
                    setNewManNumber(query);
                  }
                : undefined
            }
            onBusy={setBusy}
            onSaved={async () => {
              await refresh();
              setModal(null);
              setMessage("Loan created with actual terms saved.");
            }}
          />
        ) : modal === "terms" && termsLoan ? (
          <LoanTerms
            loan={termsLoan}
            onBusy={setBusy}
            onSaved={async (message = "Loan adjustment saved and audited.") => {
              await refresh();
              setModal(null);
              setMessage(message);
            }}
          />
        ) : modal === "import" ? (
          <ImportWorkspace
            authorized={!!session && !!canImport}
            onSaved={refresh}
            onBusy={setBusy}
          />
        ) : modal === "auth" ? (
          <>
            <AuthForm mode="login" />
            <div className="modal-actions">
              <button className="button secondary" onClick={close}>
                Cancel
              </button>
            </div>
          </>
        ) : (
          <Form
            key={`${modal}-${editingClient?.id}-${editingClient?.revision}`}
            onSubmit={submit}
          >
            {demo && (
              <div className="form-hint">
                Preview mode: connect Supabase to save real records.
              </div>
            )}
            {(modal === "client" || modal === "edit") && (
              <>
                {modal === "edit" &&
                  editingClient &&
                  (canViewLoans || canViewReports) && (
                    <ClientFinancialSummary
                      unavailable={!demo && (!ledgerRevision || !!ledger.error)}
                      refreshing={ledgerLoading}
                      onRetry={() => {
                        setError("");
                        void refresh().catch(() => {});
                      }}
                      clientId={editingClient.id}
                      loans={loans}
                      repayments={repayments}
                    />
                  )}
                <fieldset className="client-register-fields" disabled={busy}>
                  <ClientFields
                    onManNumberChange={(value) => {
                      setEnteredMan(value);
                      setManConflict(null);
                      setError("");
                    }}
                    client={modal === "edit" ? editingClient : null}
                    readOnly={modal === "edit" && !canRegister}
                    manNumber={newManNumber}
                  />
                  {duplicateClient && (
                    <ClientManConflict
                      client={duplicateClient}
                      busy={busy}
                      onOpen={
                        canRead
                          ? () => {
                              setEditingClient(duplicateClient);
                              void open("edit");
                            }
                          : undefined
                      }
                    />
                  )}
                  {modal === "edit" && editingClient && (
                    <>
                      <button
                        type="button"
                        className="text-button"
                        disabled={busy || !session}
                        onClick={async () => {
                          if (!supabase) return;
                          setBusy(true);
                          setError("");
                          const { data, error } = await supabase
                            .from("clients")
                            .select("*")
                            .eq("id", editingClient.id)
                            .single();
                          setBusy(false);
                          if (error) setError("Could not reload this Client.");
                          else setEditingClient(data as Client);
                        }}
                      >
                        Reload latest details (discards edits)
                      </button>
                      <div className="register-metadata">
                        <p>Internal Client ID: {editingClient.id}</p>
                        <p>Created by: {editingClient.created_by}</p>
                        <p>
                          Created:{" "}
                          {formatBusinessTimestamp(editingClient.created_at)} ·
                          Updated:{" "}
                          {formatBusinessTimestamp(editingClient.updated_at)}
                        </p>
                        <p>
                          Revision: {editingClient.revision}. Loan history stays
                          linked to this Client ID.
                        </p>
                      </div>
                      {canRegister && (
                        <label>
                          <span className="field-label">
                            <RequiredMark />
                            Correction reason
                          </span>
                          <input
                            name="reason"
                            required
                            minLength={5}
                            maxLength={500}
                            placeholder="Explain what changed and why"
                          />
                        </label>
                      )}
                      <ClientLifecycle
                        client={editingClient}
                        onBusy={setBusy}
                        onSaved={async () => {
                          await refresh();
                          setModal(null);
                          setMessage("Client action saved and audited.");
                        }}
                      />
                      <AuditHistory
                        source="client_audit"
                        recordId={editingClient.id}
                        title="Client audit trail"
                        revision={editingClient.revision}
                      />
                    </>
                  )}
                </fieldset>
              </>
            )}
            {error && (
              <p className="form-error" role="alert">
                {error}
              </p>
            )}
            <div className="modal-actions">
              <button
                className="button secondary"
                type="button"
                onClick={close}
                disabled={busy}
              >
                Cancel
              </button>
              {!(modal === "edit" && !canRegister) && (
                <button
                  className="button primary"
                  disabled={
                    busy ||
                    (modal === "edit" &&
                      (!session || !editingClient || !canRegister)) ||
                    (!!supabase && !session) ||
                    ((modal === "client" || modal === "edit") &&
                      !canRegister) ||
                    false
                  }
                >
                  {busy ? (
                    <>
                      <LoaderCircle className="spin" size={16} />
                      Working…
                    </>
                  ) : modal === "edit" ? (
                    "Save audited correction"
                  ) : modal === "client" ? (
                    "Save Client"
                  ) : (
                    "Confirm Repayment Received"
                  )}
                </button>
              )}
            </div>
          </Form>
        )}
      </dialog>
    </div>
  );
}
