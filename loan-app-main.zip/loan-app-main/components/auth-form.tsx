"use client";
import { Form, RequiredMark } from "./form-controls";
import { useEffect, useId, useState, type FormEvent } from "react";
import { LoaderCircle } from "lucide-react";
import { useSupabase } from "@/lib/workspace-context";
import {
  authSchema,
  emailSchema,
  authError,
  safeReturnPath,
  MIN_PASSWORD_LENGTH,
} from "@/lib/auth";
import { permittedReturnPath } from "@/lib/access";
import { useSessionSafety } from "./session-boundary";
import { PasswordField } from "./password-field";
export type AuthMode = "login" | "signup" | "forgot";
export function AuthForm({ mode = "login" }: { mode?: AuthMode }) {
  const supabase = useSupabase();
  const safety = useSessionSafety();
  const errorId = useId();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [message, setMessage] = useState("");
  const [invalid, setInvalid] = useState<string[]>([]);
  useEffect(() => {
    const query = new URLSearchParams(window.location.search);
    if (query.get("reason") === "inactive")
      setMessage(
        "You were logged out after 15 minutes of inactivity. Log in again to continue.",
      );
    if (query.get("reason") === "signed-out")
      setMessage("You have been logged out. Log in to continue.");
    const returnUrl = new URL(
      safeReturnPath(query.get("next")),
      window.location.origin,
    );
    const parameters = [
      query,
      new URLSearchParams(window.location.hash.slice(1)),
      new URLSearchParams(returnUrl.hash.slice(1)),
    ];
    if (parameters.some((p) => p.has("error") || p.has("error_code")))
      setError(
        "This authentication link is invalid or expired. Log in or request a new password recovery link.",
      );
  }, []);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    const form = new FormData(event.currentTarget),
      email = String(form.get("email") ?? ""),
      password = String(form.get("password") ?? "");
    const validation =
      mode === "forgot"
        ? emailSchema.safeParse(email)
        : authSchema.safeParse({ email, password });
    if (!validation.success) {
      setError(validation.error.issues[0].message);
      setInvalid(
        validation.error.issues.map((i) => String(i.path[0] ?? "email")),
      );
      return;
    }
    setInvalid([]);
    setError("");
    setMessage("");
    setBusy(true);
    try {
      if (!supabase) {
        setError(
          "Business authentication is not configured. Ask your Administrator to configure Supabase, or explore the demo.",
        );
        return;
      }
      if (mode === "forgot") {
        const result = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: window.location.origin + "/security",
        });
        if (result.error) throw result.error;
        setMessage(
          "If an account exists for this email, a password recovery link has been requested. Check your email.",
        );
      } else if (mode === "signup") {
        const result = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { emailRedirectTo: window.location.origin + "/login" },
        });
        if (result.error) throw result.error;
        setMessage(
          "Account requested. Check your email if confirmation is required. An Administrator must assign an active business role before you can access Client records. You can then log in.",
        );
      } else {
        const result = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (result.error) throw result.error;
        if (result.data.session) await safety.start(result.data.session);
        const current = await supabase.rpc("loan_defaults");
        const requested = safeReturnPath(
          new URLSearchParams(window.location.search).get("next"),
        );
        window.location.assign(
          current.error
            ? "/security"
            : permittedReturnPath(current.data?.capabilities, requested),
        );
      }
    } catch (e) {
      setError(authError(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <Form className="auth-form" onSubmit={submit} noValidate aria-busy={busy}>
      <fieldset disabled={busy}>
        <label>
          <span className="field-label">
            <RequiredMark />
            Email
          </span>
          <input
            name="email"
            type="email"
            required
            autoComplete="email"
            maxLength={254}
            aria-invalid={invalid.includes("email") || undefined}
            aria-describedby={invalid.includes("email") ? errorId : undefined}
          />
        </label>
        {mode !== "forgot" && (
          <>
            <PasswordField
              name="password"
              required
              autoComplete={
                mode === "login" ? "current-password" : "new-password"
              }
              aria-invalid={invalid.includes("password") || undefined}
              aria-describedby={
                invalid.includes("password") ? errorId : undefined
              }
            />
            <p className="form-hint">
              Use at least {MIN_PASSWORD_LENGTH} characters.
            </p>
          </>
        )}
        {error && (
          <p className="form-error" role="alert" id={errorId}>
            {error}
          </p>
        )}
        {message && (
          <p className="notice success" role="status">
            {message}
          </p>
        )}
        <button className="button primary auth-submit" disabled={busy}>
          {busy ? (
            <>
              <LoaderCircle size={17} className="spin" aria-hidden="true" />
              {mode === "login"
                ? "Logging in…"
                : mode === "signup"
                  ? "Creating account…"
                  : "Sending recovery link…"}
            </>
          ) : mode === "login" ? (
            "Log In"
          ) : mode === "signup" ? (
            "Sign Up"
          ) : (
            "Send recovery link"
          )}
        </button>
        {mode === "login" && (
          <a className="text-button" href="/forgot-password">
            Forgot password?
          </a>
        )}
      </fieldset>
      <p className="auth-switch">
        {mode === "signup" ? (
          <>
            Already have an account? <a href="/login">Log In</a>
          </>
        ) : mode === "login" ? (
          <>
            New to LendTrack? <a href="/signup">Sign Up</a>
          </>
        ) : (
          <a href="/login">Back to Log In</a>
        )}
      </p>
    </Form>
  );
}
