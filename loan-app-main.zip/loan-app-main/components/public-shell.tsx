"use client";
import { ChartNoAxesCombined } from "lucide-react";
import { useSessionSafety } from "./session-boundary";
import { ThemeSelector } from "./theme-selector";
import { brand } from "@/lib/brand";
import type { ReactNode } from "react";
export function PublicShell({
  children,
  authenticated = false,
}: {
  children: ReactNode;
  authenticated?: boolean;
}) {
  const session = useSessionSafety();
  return (
    <div className="public-site">
      <a className="skip-link" href="#public-content">
        Skip to content
      </a>
      <header className="public-header">
        <a
          className="brand public-brand"
          href="/"
          aria-label={`${brand.name} home`}
        >
          <span className="brand-icon">
            <ChartNoAxesCombined size={23} aria-hidden="true" />
          </span>
          {brand.name}
          <span className="brand-dot">.</span>
        </a>
        <nav aria-label="Public navigation" className="public-actions">
          <a className="text-button" href="/login">
            Log In
          </a>
          <a className="button secondary" href="/signup">
            Sign Up
          </a>
        </nav>
        <ThemeSelector />
      </header>
      <main id="public-content" className="public-content" tabIndex={-1}>
        {children}
      </main>
      <footer className="public-footer">
        <span>{brand.name} · Client lending, clearly managed.</span>
        {!authenticated &&
          (session.state === "anonymous" ||
            session.state === "unconfigured") && (
            <a className="text-button" href="/demo">
              Explore demo
            </a>
          )}
      </footer>
    </div>
  );
}
