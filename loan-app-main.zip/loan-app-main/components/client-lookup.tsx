"use client";
import { RequiredMark } from "./form-controls";
import { useId, useState } from "react";
import type { Client } from "@/lib/domain";
import { clientLabels } from "@/lib/ui-labels";
import { findClients } from "@/lib/domain";

export function ClientLookup({
  clients,
  onSelect,
  onAdd,
}: {
  clients: Client[];
  onSelect: (client: Client | null) => void;
  onAdd?: (query: string) => void;
}) {
  const id = useId();
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Client | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const matches = query.trim() ? findClients(clients, query).slice(0, 20) : [];
  const eligible = (client: Client) =>
    !!(
      client.is_active &&
      client.man_number &&
      client.department &&
      client.designation
    );
  function choose(client: Client) {
    if (!eligible(client)) return;
    setSelected(client);
    setQuery(client.man_number ?? "");
    setExpanded(false);
    onSelect(client);
  }
  return (
    <div
      className="client-lookup"
      onBlur={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node | null))
          setExpanded(false);
      }}
    >
      <label htmlFor={id}>
        <span className="field-label">
          {clientLabels.search}
          <RequiredMark />
        </span>
      </label>
      <input
        id={id}
        role="combobox"
        aria-autocomplete="list"
        aria-expanded={expanded && !!query.trim()}
        aria-controls={`${id}-results`}
        aria-activedescendant={
          expanded && matches[highlight] ? `${id}-${highlight}` : undefined
        }
        required
        autoComplete="off"
        value={query}
        placeholder={clientLabels.search}
        onFocus={() => setExpanded(true)}
        onChange={(e) => {
          setQuery(e.target.value);
          setSelected(null);
          onSelect(null);
          setExpanded(true);
          setHighlight(0);
        }}
        onKeyDown={(e) => {
          if (e.key === "ArrowDown") {
            e.preventDefault();
            setExpanded(true);
            setHighlight((i) =>
              Math.max(0, Math.min(i + 1, matches.length - 1)),
            );
          } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setHighlight((i) => Math.max(0, i - 1));
          } else if (e.key === "Enter" && expanded) {
            e.preventDefault();
            if (matches[highlight]) choose(matches[highlight]);
          } else if (e.key === "Escape" && expanded) {
            e.preventDefault();
            e.stopPropagation();
            setExpanded(false);
          }
        }}
      />
      {expanded && !!query.trim() && (
        <>
          <ul
            id={`${id}-results`}
            role="listbox"
            aria-label="Matching Clients"
            className="client-matches"
          >
            {matches.map((client, index) => (
              <li
                key={client.id}
                id={`${id}-${index}`}
                role="option"
                aria-disabled={!eligible(client)}
                aria-selected={index === highlight}
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => choose(client)}
              >
                <div className="client-option">
                  <strong>
                    {client.man_number} · {client.name}
                  </strong>
                  <small>
                    {client.department} · {client.designation}
                    {!eligible(client) &&
                      (client.is_active
                        ? " · Complete register details first"
                        : " · Inactive Client")}
                  </small>
                </div>
              </li>
            ))}
          </ul>
          {!matches.length && (
            <div className="lookup-empty" role="status">
              <p>No client found</p>
              {onAdd && (
                <button
                  type="button"
                  className="text-button"
                  onClick={() => onAdd(query)}
                >
                  Add Client
                </button>
              )}
            </div>
          )}
          {matches.length === 20 && (
            <p className="form-hint">
              Showing the first 20 matches. Keep typing to narrow your search.
            </p>
          )}
        </>
      )}
      <input type="hidden" name="client_id" value={selected?.id ?? ""} />
      <div className="lookup-details" aria-live="polite">
        <label>
          Client name
          <input readOnly value={selected?.name ?? ""} />
        </label>
        <label>
          Department
          <input readOnly value={selected?.department ?? ""} />
        </label>
        <label>
          Designation
          <input readOnly value={selected?.designation ?? ""} />
        </label>
      </div>
    </div>
  );
}
