"use client";
import type { ComponentPropsWithRef, InputHTMLAttributes } from "react";
export function RequiredMark() {
  return <span className="required-mark" aria-hidden="true" />;
}
export function Form({ children, ...props }: ComponentPropsWithRef<"form">) {
  return (
    <form {...props}>
      <p className="required-legend">
        <span aria-hidden="true">*</span> Required
      </p>
      {children}
    </form>
  );
}
/** Keep native editing/mobile behavior; showPicker must be invoked from a user gesture. */
export function DateInput({
  onClick,
  ...props
}: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      type="date"
      onClick={(event) => {
        onClick?.(event);
        if (
          event.defaultPrevented ||
          event.currentTarget.disabled ||
          event.currentTarget.readOnly
        )
          return;
        try {
          event.currentTarget.showPicker?.();
        } catch {
          /* Browser keeps its native date control when unavailable. */
        }
      }}
    />
  );
}
