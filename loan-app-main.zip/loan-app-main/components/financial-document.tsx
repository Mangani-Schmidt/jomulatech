"use client";
import { formatBusinessTimestamp } from "@/lib/business-time";
import { Form, RequiredMark } from "./form-controls";
import { requireReadAccess } from "@/lib/read-access";
import { hasCapability } from "@/lib/access";
import { useEffect, useRef, useState } from "react";
import {
  type Client,
  type Loan,
  type Repayment,
  money,
  isPosted,
  isCollectible,
  status,
  businessDate,
} from "@/lib/domain";
import { paymentMethods, netReceived } from "@/lib/repayments";
import { useSupabase } from "@/lib/workspace-context";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import { RepaymentForm } from "./repayment-form";
import { brand } from "@/lib/brand";
type Audit = {
  id: string;
  action: string;
  reason: string;
  actor_id?: string | null;
  created_at: string;
};
type Document = {
  generated_at?: string;
  receipt?: Repayment;
  audit?: Audit[];
  client?: Client;
  loans?: Loan[];
  repayments?: Repayment[];
  repayment_audit?: Audit[];
  terms_audit?: Audit[];
  status_audit?: Audit[];
};
const timestamp = (value?: string | null) => formatBusinessTimestamp(value);
export function FinancialDocument({
  kind,
  id,
  clients,
  loans,
  repayments,
  onSaved,
  onBusy,
}: {
  kind: "receipt" | "statement";
  id: string;
  clients: Client[];
  loans: Loan[];
  repayments: Repayment[];
  onSaved: (id: string) => Promise<void>;
  onBusy: (busy: boolean) => void;
}) {
  const supabase = useSupabase();
  const defaults = useLoanDefaults();
  const permissionsLoading = useRef(defaults.loading);
  permissionsLoading.current = defaults.loading;
  const [document, setDocument] = useState<Document | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [reason, setReason] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [correction, setCorrection] = useState(false);
  const request = useRef<{ payload: string; id: string } | null>(null);
  async function load() {
    if (!supabase) {
      if (kind === "receipt") {
        const r = repayments.find((r) => r.id === id);
        if (!r) throw new Error("Receipt not found.");
        const l = loans.find((l) => l.id === r.loan_id);
        const c = clients.find((c) => c.id === l?.client_id);
        return {
          generated_at: new Date().toISOString(),
          receipt: {
            ...r,
            payment_reference: r.payment_reference ?? `PAY-DEMO-${r.id}`,
            receipt_snapshot: r.receipt_snapshot ?? {
              client: {
                id: c?.id ?? "",
                name: c?.name ?? "Client",
                man_number: c?.man_number ?? null,
              },
              loan_reference: l?.loan_reference ?? r.loan_id,
              currency: "ZMW",
              historic_note: "Sample receipt. No real transaction was posted.",
            },
          },
          audit: [],
        } as Document;
      }
      return {
        generated_at: new Date().toISOString(),
        client: clients.find((c) => c.id === id),
        loans: loans.filter((l) => l.client_id === id),
        repayments: repayments.filter((r) =>
          loans.some((l) => l.id === r.loan_id && l.client_id === id),
        ),
        repayment_audit: [],
        terms_audit: [],
        status_audit: [],
      } as Document;
    }
    const { data, error } = await supabase.rpc(
      kind === "receipt" ? "receipt_document" : "client_statement",
      kind === "receipt" ? { p_repayment_id: id } : { p_client_id: id },
    );
    if (error) throw error;
    if (!data) throw new Error("Document not found or access denied.");
    return data as Document;
  }
  useEffect(() => {
    let active = true;
    setDocument(null);
    setError("");
    load()
      .then((data) => {
        if (active) setDocument(data);
      })
      .catch((e) => {
        if (active) setError(e.message ?? "Could not load document.");
      });
    return () => {
      active = false;
    };
  }, [kind, id]);
  async function print() {
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      if (supabase) await requireReadAccess(supabase);
      setDocument(await load());
      await new Promise((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(resolve)),
      );
      if (permissionsLoading.current)
        throw new Error(
          "Access is being rechecked. Wait for verification, then print again.",
        );
      window.print();
    } catch (e) {
      if ((e as { code?: string } | null)?.code === "42501") {
        setDocument(null);
        void defaults.reload();
      }
      setError(
        e instanceof Error
          ? e.message
          : "Could not refresh the document for printing.",
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  async function reverse(event: React.FormEvent) {
    event.preventDefault();
    if (!supabase || !document?.receipt) return;
    setBusy(true);
    onBusy(true);
    setError("");
    try {
      const body = {
        p_repayment_id: document.receipt.id,
        p_reason: reason.trim(),
        p_confirm: confirm,
      };
      const payload = JSON.stringify(body);
      if (request.current?.payload !== payload)
        request.current = { payload, id: crypto.randomUUID() };
      const { error } = await supabase.rpc("reverse_repayment", {
        ...body,
        p_request_id: request.current.id,
      });
      if (error) throw error;
      await onSaved(document.receipt.id);
      setDocument(await load());
      setConfirm(false);
      setReason("");
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : ((e as { message?: string }).message ??
              "Could not reverse receipt."),
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  const receipt = document?.receipt;
  const statementLoans = document?.loans ?? [];
  const statementPayments = document?.repayments ?? [];
  const asOf = businessDate(document?.generated_at ?? new Date().toISOString());
  return (
    <div>
      <div className="print-actions">
        {(!supabase ||
          hasCapability(
            defaults.value?.capabilities,
            "can_export_reports",
          )) && (
          <button
            className="button primary"
            type="button"
            disabled={busy || !document}
            onClick={print}
          >
            Print {kind === "receipt" ? "receipt" : "Client Statement"}
          </button>
        )}
        <p className="form-hint">
          Print or save as PDF using your browser. The document is refreshed
          before printing.
        </p>
      </div>
      {error && (
        <p role="alert" className="form-error">
          {error}
        </p>
      )}
      {!document && !error && <p role="status">Loading financial document…</p>}
      {document && (
        <article className="print-area">
          <header className="document-header">
            <strong>{brand.name}</strong>
            <h2>
              {kind === "receipt"
                ? "Repayment Received receipt"
                : "Client Statement"}
            </h2>
            <p>All amounts in ZMW · Africa/Lusaka</p>
            {!supabase && (
              <p className="document-watermark">DEMO — sample document</p>
            )}
          </header>
          {receipt && (
            <>
              <p
                className={`document-watermark ${isPosted(receipt) ? "" : "reversed-text"}`}
              >
                {isPosted(receipt)
                  ? "POSTED"
                  : "REVERSED — financial effect excluded"}
              </p>
              <dl className="document-details">
                <div>
                  <dt>Payment reference</dt>
                  <dd>{receipt.payment_reference ?? receipt.id}</dd>
                </div>
                <div>
                  <dt>Client / Man#</dt>
                  <dd>
                    {receipt.receipt_snapshot?.client.name} ·{" "}
                    {receipt.receipt_snapshot?.client.man_number ??
                      "Not recorded"}
                  </dd>
                </div>
                <div>
                  <dt>Loan reference</dt>
                  <dd>
                    {receipt.receipt_snapshot?.loan_reference ??
                      receipt.loan_reference ??
                      receipt.loan_id}
                  </dd>
                </div>
                <div>
                  <dt>Payment date</dt>
                  <dd>
                    {receipt.payment_date ?? businessDate(receipt.created_at)}
                  </dd>
                </div>
                <div>
                  <dt>Repayment Received</dt>
                  <dd>{money(receipt.amount_cents)}</dd>
                </div>
                <div>
                  <dt>Interest allocation</dt>
                  <dd>
                    {receipt.interest_allocation_cents == null
                      ? "Not recorded"
                      : money(receipt.interest_allocation_cents)}
                  </dd>
                </div>
                <div>
                  <dt>Principal allocation</dt>
                  <dd>
                    {receipt.principal_allocation_cents == null
                      ? "Not recorded"
                      : money(receipt.principal_allocation_cents)}
                  </dd>
                </div>
                <div>
                  <dt>Net financial effect</dt>
                  <dd>{money(isPosted(receipt) ? receipt.amount_cents : 0)}</dd>
                </div>
                <div>
                  <dt>Payment method</dt>
                  <dd>
                    {paymentMethods[
                      receipt.payment_method as keyof typeof paymentMethods
                    ] ?? "Not recorded"}
                  </dd>
                </div>
                <div>
                  <dt>External reference</dt>
                  <dd>{receipt.external_reference ?? "None"}</dd>
                </div>
                <div>
                  <dt>Creator / posted at</dt>
                  <dd>
                    {receipt.created_by ?? "Not recorded"} ·{" "}
                    {timestamp(receipt.created_at)}
                  </dd>
                </div>
                <div>
                  <dt>Last updated</dt>
                  <dd>{timestamp(receipt.updated_at)}</dd>
                </div>
                <div>
                  <dt>Outstanding immediately after original posting</dt>
                  <dd>
                    {receipt.receipt_snapshot?.balance_after_cents == null
                      ? "Not recorded"
                      : money(receipt.receipt_snapshot.balance_after_cents)}
                  </dd>
                </div>
              </dl>
              <p className="document-note">
                Allocation policy: interest first, then principal, at posting
                time. Later reversals do not rewrite this receipt’s original
                allocations.
              </p>
              {receipt.receipt_snapshot?.historic_note && (
                <p className="document-note">
                  {receipt.receipt_snapshot.historic_note}
                </p>
              )}
              {!isPosted(receipt) && (
                <div className="document-reversal">
                  <h3>Reversal</h3>
                  <p>{receipt.reversal_reason}</p>
                  <p>
                    {receipt.reversed_by} ·{" "}
                    {receipt.reversed_at ? timestamp(receipt.reversed_at) : ""}
                  </p>
                  {receipt.replaced_by_reference && (
                    <p>Replacement: {receipt.replaced_by_reference}</p>
                  )}
                </div>
              )}
              {receipt.replaces_repayment_id && (
                <p className="document-note">
                  This is a replacement for reversed receipt ID{" "}
                  {receipt.replaces_repayment_id}.
                </p>
              )}
              <section className="audit-trail">
                <h3>Receipt audit history</h3>
                {document.audit?.map((entry) => (
                  <p key={entry.id}>
                    {entry.action}: {entry.reason} ·{" "}
                    {entry.actor_id ?? "Migration"} ·{" "}
                    {timestamp(entry.created_at)}
                  </p>
                ))}
              </section>
            </>
          )}
          {kind === "statement" && (
            <>
              <h3>
                {document.client?.name} · Man#{" "}
                {document.client?.man_number ?? "Not recorded"}
              </h3>
              <p className="document-note">
                As at {timestamp(document.generated_at!)}. Includes all Client
                loans, posted and reversed receipts, and audit history.
              </p>
              <div className="document-totals">
                <p>
                  Net Repayment Received:{" "}
                  <b>{money(netReceived(statementPayments))}</b>
                </p>
                <p>
                  Collectible outstanding:{" "}
                  <b>
                    {money(
                      statementLoans
                        .filter(isCollectible)
                        .reduce((sum, l) => sum + l.balance_cents, 0),
                    )}
                  </b>
                </p>
                <p>
                  Written-off balance:{" "}
                  <b>
                    {money(
                      statementLoans
                        .filter((l) => status(l, asOf) === "Written off")
                        .reduce((sum, l) => sum + l.balance_cents, 0),
                    )}
                  </b>
                </p>
              </div>
              <h3>Loan positions</h3>
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>Loan reference</th>
                      <th>Amount Disbursed</th>
                      <th>Interest charge</th>
                      <th>Total obligation</th>
                      <th>Outstanding</th>
                      <th>Status / due date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statementLoans.map((l) => (
                      <tr key={l.id}>
                        <td>{l.loan_reference ?? l.id}</td>
                        <td>{money(l.principal_cents)}</td>
                        <td>{money(l.interest_cents)}</td>
                        <td>{money(l.principal_cents + l.interest_cents)}</td>
                        <td>{money(l.balance_cents)}</td>
                        <td>
                          {status(l, asOf)} · {l.due_date}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {statementPayments.some((r) => r.metadata_inferred) && (
                <p className="document-note">
                  Legacy receipt dates, creator details, and allocations were
                  inferred at migration. Their payment method may be unrecorded.
                  See the original receipt’s history note.
                </p>
              )}
              <h3>Repayment history (posting order)</h3>
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>Payment / loan reference</th>
                      <th>Payment / posting date</th>
                      <th>Original amount</th>
                      <th>Interest / principal</th>
                      <th>Status / net effect</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statementPayments.map((r) => (
                      <tr key={r.id}>
                        <td>
                          {r.payment_reference ?? r.id}
                          <small className="register-subtitle">
                            {r.loan_reference ?? r.loan_id}
                          </small>
                        </td>
                        <td>
                          {r.payment_date ?? businessDate(r.created_at)}
                          <small className="register-subtitle">
                            {timestamp(r.created_at)}
                          </small>
                        </td>
                        <td>{money(r.amount_cents)}</td>
                        <td>
                          {r.interest_allocation_cents == null
                            ? "Not recorded"
                            : money(r.interest_allocation_cents)}{" "}
                          /{" "}
                          {r.principal_allocation_cents == null
                            ? "Not recorded"
                            : money(r.principal_allocation_cents)}
                        </td>
                        <td>
                          {isPosted(r) ? "Posted" : "Reversed"} ·{" "}
                          {money(isPosted(r) ? r.amount_cents : 0)}
                          {r.reversal_reason && (
                            <small className="register-subtitle">
                              {r.reversal_reason}
                            </small>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <section className="audit-trail">
                <h3>Reversals, adjustments, and write-off history</h3>
                {[
                  ...(document.repayment_audit ?? []),
                  ...(document.terms_audit ?? []),
                  ...(document.status_audit ?? []),
                ]
                  .sort((a, b) => a.created_at.localeCompare(b.created_at))
                  .map((entry) => (
                    <p key={entry.id}>
                      {entry.reason} · {entry.actor_id ?? "Migration"} ·{" "}
                      {timestamp(entry.created_at)}
                    </p>
                  ))}
              </section>
              <p className="document-note">
                Interest-first allocation uses posting order, not backdated
                payment order. Reversed receipts remain visible with zero
                financial effect. Loan positions reflect current audited terms;
                this statement does not invent historical running balances for
                legacy records.
              </p>
            </>
          )}
        </article>
      )}
      {receipt &&
        isPosted(receipt) &&
        hasCapability(defaults.value?.capabilities, "can_view_repayments") &&
        hasCapability(
          defaults.value?.capabilities,
          "can_approve_adjustments",
        ) && (
          <section className="receipt-controls">
            <Form onSubmit={reverse}>
              <h3>Authorized reversal</h3>
              <p className="form-hint">
                Reverse this entire posted receipt, restore its
                interest/principal allocations, and retain the original. This is
                a ledger correction, not a cash refund.
              </p>
              <label>
                <span className="field-label">
                  <RequiredMark />
                  Reversal reason
                </span>
                <input
                  required
                  minLength={5}
                  maxLength={500}
                  value={reason}
                  onChange={(e) => {
                    setReason(e.target.value);
                    setConfirm(false);
                  }}
                />
              </label>
              <label className="checkbox-label">
                <RequiredMark />
                <input
                  type="checkbox"
                  required
                  checked={confirm}
                  onChange={(e) => setConfirm(e.target.checked)}
                />
                I authorize reversal of this Repayment Received entry.
              </label>
              <button
                className="button danger"
                disabled={busy || !confirm || reason.trim().length < 5}
              >
                Reverse posted payment
              </button>
            </Form>
            {hasCapability(
              defaults.value?.capabilities,
              "can_post_repayments",
            ) && (
              <button
                className="button secondary"
                type="button"
                disabled={busy}
                onClick={() => setCorrection((v) => !v)}
              >
                {correction ? "Hide adjustment" : "Correct posted payment"}
              </button>
            )}
            {correction &&
              hasCapability(
                defaults.value?.capabilities,
                "can_post_repayments",
              ) && (
                <RepaymentForm
                  loans={loans}
                  clients={clients}
                  original={receipt}
                  onSaved={onSaved}
                  onBusy={(value) => {
                    setBusy(value);
                    onBusy(value);
                  }}
                />
              )}
          </section>
        )}
    </div>
  );
}
