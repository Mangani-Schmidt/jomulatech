"use client";
import { useReadScope } from "@/lib/use-read-scope";
import type { ScopedSnapshotCache } from "@/lib/scoped-snapshot";
import { formatBusinessTimestamp } from "@/lib/business-time";
import { Form, DateInput, RequiredMark } from "./form-controls";
import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { hasCapability } from "@/lib/access";
import { ReadAccessError, requireReadAccess } from "@/lib/read-access";
import { clientLabels } from "@/lib/ui-labels";
import { serviceError } from "@/lib/errors";
import { BusinessPerformance } from "./business-performance";
import { ReportingCoverage } from "./reporting-coverage";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import { useSupabase } from "@/lib/workspace-context";
import { demoReportSource } from "@/lib/demo";
import { businessDate, today } from "@/lib/domain";
import { brand } from "@/lib/brand";
import {
  buildReport,
  repaymentEffectiveDate,
  defaultReportFilters,
  reportCSV,
  reportMoney,
  reportAmountLabels,
  type ReportSource,
  type ReportFilters,
  type FinancialReport,
  type LoanReport,
  type ReportAmounts,
} from "@/lib/reporting";
export function ReportingWorkspace({
  account,
  cache,
  scope,
  revision,
  detailed,
  onStatement,
}: {
  account: string | null;
  cache: ScopedSnapshotCache<ReportSource>;
  scope: string;
  revision: number;
  detailed: boolean;
  onStatement: (id: string) => void;
}) {
  const supabase = useSupabase();
  const defaults = useLoanDefaults();
  const verifyScope = useReadScope(scope);
  const canExport =
    !supabase ||
    hasCapability(defaults.value?.capabilities, "can_export_reports");
  const canLoans =
    !supabase || hasCapability(defaults.value?.capabilities, "can_view_loans");
  const canRepayments =
    !supabase ||
    hasCapability(defaults.value?.capabilities, "can_view_repayments");
  const canExpenses =
    !supabase ||
    hasCapability(defaults.value?.capabilities, "can_view_expenses") ||
    hasCapability(defaults.value?.capabilities, "can_view_reports");
  const [showOverdue, setShowOverdue] = useState(false);
  const [sourceKey, setSourceKey] = useState("");
  const [rawSource, setSource] = useState<ReportSource | null>(null);
  const [sourceScope, setSourceScope] = useState(scope);
  const source = sourceScope === scope ? rawSource : null;
  const [draft, setDraft] = useState(() => defaultReportFilters(today()));
  const [filters, setFilters] = useState(draft);
  const [reload, setReload] = useState(0);
  const [loading, setLoading] = useState(true),
    [error, setError] = useState("");
  const [kind, setKind] = useState<"clients" | "loans">("clients"),
    [page, setPage] = useState(1);
  const [history, setHistory] = useState<string | null>(null);
  const [printReport, setPrintReport] = useState<FinancialReport | null>(null);
  const [exporting, setExporting] = useState(false);
  const [downloadMessage, setDownloadMessage] = useState("");
  useEffect(() => {
    let cancelled = false;
    setSourceScope(scope);
    if (!supabase) {
      setSource({
        ...demoReportSource,
        generated_at: new Date().toISOString(),
      });
      setLoading(false);
      return;
    }
    const cached = cache.read(scope, JSON.stringify(filters));
    setSource(cached);
    setSourceKey(cached ? JSON.stringify(filters) : "");
    setError("");
    setPage(1);
    setHistory(null);
    if (!account) {
      setLoading(false);
      return;
    }
    setLoading(true);
    Promise.resolve(
      supabase.rpc("report_source_filtered", { p_filters: filters }),
    )
      .then(({ data, error }) => {
        if (cancelled) return;
        setLoading(false);
        if (
          error ||
          !data ||
          ![
            "loans",
            "clients",
            "repayments",
            "terms_audit",
            "status_audit",
            "repayment_audit",
          ].every((key) => Array.isArray(data[key])) ||
          typeof data.generated_at !== "string"
        ) {
          setSource(null);
          setError(
            error
              ? serviceError(error, "reporting history")
              : "The reporting response was incomplete. Retry the snapshot; no report or export is available until a complete response is received.",
          );
        } else {
          cache.write(scope, JSON.stringify(filters), data as ReportSource);
          setSource(data as ReportSource);
          setSourceKey(JSON.stringify(filters));
        }
      })
      .catch((failure: unknown) => {
        if (cancelled) return;
        setSource(null);
        setError(serviceError(failure, "reporting history"));
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [account, scope, cache, revision, reload, filters]);
  const result = useMemo(() => {
    if (!source || (supabase && sourceKey !== JSON.stringify(filters)))
      return { report: null, error: "" };
    try {
      return { report: buildReport(source, filters), error: "" };
    } catch (e) {
      return {
        report: null,
        error:
          e instanceof Error ? e.message : "Report could not be calculated.",
      };
    }
  }, [source, filters, sourceKey]);
  const report = result.report;
  const currencies = [
    ...new Set([
      "ZMW",
      ...(source?.loans.map((l) => l.currency ?? "ZMW") ?? []),
    ]),
  ].sort();
  const options = (field: "department" | "designation") =>
    source?.filter_options?.[field] ??
    [
      ...new Set(
        source?.clients.map((c) => c[field] ?? "").filter(Boolean) ?? [],
      ),
    ].sort();
  const rows = report?.[kind] ?? [];
  const pageCount = Math.max(1, Math.ceil(rows.length / 10));
  const visible = rows.slice((page - 1) * 10, page * 10);
  const changed = JSON.stringify(draft) !== JSON.stringify(filters);
  const fmt = (n: number) => reportMoney(n, filters.currency);
  function edit(key: keyof ReportFilters, value: string) {
    setDraft((d) => ({ ...d, [key]: value }));
  }
  async function readAction(action: () => void) {
    if (loading || error) return;
    setExporting(true);
    setError("");
    try {
      if (supabase) await requireReadAccess(supabase);
      if (supabase)
        await requireReadAccess(
          supabase,
          detailed ? "view_reports" : "reporting",
        );
      verifyScope();
      action();
    } catch (failure) {
      if (failure instanceof ReadAccessError && failure.denied) {
        setSource(null);
        setPrintReport(null);
        void defaults.reload();
      }
      setError(
        failure instanceof Error
          ? failure.message
          : "Read access could not be verified.",
      );
    } finally {
      setExporting(false);
    }
  }
  function download(text: string, type: string, filename: string) {
    const url = URL.createObjectURL(new Blob([text], { type }));
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setDownloadMessage("CSV report downloaded with all filtered rows.");
  }
  async function excel() {
    if (!report || loading || error) return;
    setExporting(true);
    setError("");
    setDownloadMessage("");
    try {
      if (supabase) await requireReadAccess(supabase);
      if (supabase)
        await requireReadAccess(
          supabase,
          detailed ? "view_reports" : "reporting",
        );
      const { financialWorkbook } = await import("@/lib/report-exports");
      const { saveWorkbook } = await import("@/lib/workbook");
      verifyScope();
      const wb = financialWorkbook(report);
      if (supabase) {
        await requireReadAccess(supabase);
        await requireReadAccess(
          supabase,
          detailed ? "view_reports" : "reporting",
        );
      }
      await saveWorkbook(
        wb,
        `client-loan-report-${filters.asOf}.xlsx`,
        async () => {
          if (supabase) {
            await requireReadAccess(supabase);
            await requireReadAccess(
              supabase,
              detailed ? "view_reports" : "reporting",
            );
          }
          verifyScope();
        },
      );
      setDownloadMessage("Excel report downloaded with all filtered rows.");
    } catch (failure) {
      if (failure instanceof ReadAccessError && failure.denied) {
        setSource(null);
        setPrintReport(null);
        void defaults.reload();
      }
      setError(
        failure instanceof ReadAccessError
          ? failure.message
          : "Export failed. Please retry.",
      );
    } finally {
      setExporting(false);
    }
  }
  return (
    <section
      className={`report-workspace ${detailed ? "" : "dashboard-summary"}`}
      aria-label="Financial reporting"
    >
      <details className="panel report-filter-panel">
        <summary>
          {detailed ? "Report filters" : "Change dates and filters"}
        </summary>
        <h2>{detailed ? "Dashboard and reports" : "Reporting period"}</h2>
        <p>
          Disbursements and receipts use the activity period. Outstanding
          balances use the end of the selected date. Dates use Africa/Lusaka.
        </p>
        <button
          className="text-button"
          disabled={loading || (!!supabase && !account)}
          onClick={() => {
            if (supabase) setReload((v) => v + 1);
            else
              setSource({
                ...demoReportSource,
                generated_at: new Date().toISOString(),
              });
          }}
        >
          {detailed ? "Refresh report snapshot" : "Refresh summary"}
        </button>
        <Form
          onSubmit={(e) => {
            e.preventDefault();
            setFilters({ ...draft });
            setPage(1);
            setHistory(null);
          }}
        >
          <div className="report-filters report-period-filters">
            <label>
              <span className="field-label">
                <RequiredMark />
                Activity from
              </span>
              <DateInput
                required
                min="1900-01-01"
                max={draft.to}
                value={draft.from}
                onChange={(e) => edit("from", e.target.value)}
              />
            </label>
            <label>
              <span className="field-label">
                <RequiredMark />
                Activity to
              </span>
              <DateInput
                required
                min={draft.from}
                max={draft.asOf}
                value={draft.to}
                onChange={(e) => edit("to", e.target.value)}
              />
            </label>
            <label>
              <span className="field-label">
                <RequiredMark />
                Balances as of
              </span>
              <DateInput
                required
                min={draft.to}
                max={today()}
                value={draft.asOf}
                onChange={(e) => edit("asOf", e.target.value)}
              />
            </label>
            <label>
              Report currency
              <select
                value={draft.currency}
                onChange={(e) => edit("currency", e.target.value)}
              >
                {currencies.map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </label>
          </div>
          <details className="report-extra-filters">
            <summary>
              More filters{changed ? " · changes not applied" : ""}
            </summary>
            <p className="form-hint">
              Narrow the summary by Client, department, designation, loan status
              or disbursement dates.
            </p>
            <div className="report-filters">
              <label>
                {clientLabels.search}
                <input
                  type="search"
                  value={draft.search}
                  placeholder={clientLabels.search}
                  onChange={(e) => edit("search", e.target.value)}
                />
              </label>
              <label>
                Department
                <select
                  value={draft.department}
                  onChange={(e) => edit("department", e.target.value)}
                >
                  <option value="">All departments</option>
                  {options("department").map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </label>
              <label>
                Designation
                <select
                  value={draft.designation}
                  onChange={(e) => edit("designation", e.target.value)}
                >
                  <option value="">All designations</option>
                  {options("designation").map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </label>
              <label>
                Loan status as of date
                <select
                  value={draft.status}
                  onChange={(e) => edit("status", e.target.value)}
                >
                  <option value="">All statuses</option>
                  {["Active", "Overdue", "Settled", "Written off"].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </label>
              <label>
                Disbursed from
                <DateInput
                  value={draft.disbursedFrom}
                  onChange={(e) => edit("disbursedFrom", e.target.value)}
                />
              </label>
              <label>
                Disbursed to
                <DateInput
                  value={draft.disbursedTo}
                  onChange={(e) => edit("disbursedTo", e.target.value)}
                />
              </label>
            </div>
          </details>
          <div className="report-actions">
            <button className="button primary" disabled={loading}>
              Apply report filters
            </button>
            <button
              className="button secondary"
              type="button"
              onClick={() => {
                const f = defaultReportFilters(today());
                setDraft(f);
                setFilters(f);
                setPage(1);
                setHistory(null);
              }}
            >
              Reset filters
            </button>
            {changed && (
              <span role="status">
                Apply changes to update the report and exports.
              </span>
            )}
          </div>
        </Form>
      </details>
      {loading && (
        <p role="status">
          {source
            ? `Updating displayed snapshot from ${formatBusinessTimestamp(source.generated_at)}… Downloads are available after refresh.`
            : detailed
              ? "Loading reports…"
              : "Loading financial summary…"}
        </p>
      )}
      {(error || result.error) && (
        <div className="notice error report-error" role="alert">
          {!report && <strong>Financial summary unavailable</strong>}
          <p>{error || result.error}</p>
          {!report && (
            <button
              className="button secondary"
              disabled={loading}
              onClick={() => setReload((v) => v + 1)}
            >
              Retry financial summary
            </button>
          )}
        </div>
      )}
      {!source && !loading && !error && (
        <p className="empty-state">Sign in to view your private reports.</p>
      )}
      {report && (
        <>
          <p className="report-scope">
            Activity: {filters.from} to {filters.to} (inclusive). Balances: end
            of {filters.asOf}. {filters.currency} only. {report.loans.length}{" "}
            matching loans · {report.overdueCount} overdue loans.
            {(filters.search ||
              filters.department ||
              filters.designation ||
              filters.status ||
              filters.disbursedFrom ||
              filters.disbursedTo) && (
              <span className="applied-report-filters">
                Filters:{" "}
                {[
                  filters.search && `Client: ${filters.search}`,
                  filters.department && `Department: ${filters.department}`,
                  filters.designation && `Designation: ${filters.designation}`,
                  filters.status && `Status: ${filters.status}`,
                  filters.disbursedFrom &&
                    `Disbursed from: ${filters.disbursedFrom}`,
                  filters.disbursedTo && `Disbursed to: ${filters.disbursedTo}`,
                ]
                  .filter(Boolean)
                  .join(" · ")}
              </span>
            )}
          </p>
          {downloadMessage && (
            <p className="notice" role="status">
              {downloadMessage}
            </p>
          )}
          <BusinessPerformance
            report={report}
            detailed={detailed}
            canLoans={canLoans}
            canRepayments={canRepayments}
            canExpenses={canExpenses}
          />
          {(detailed || canLoans) && (
            <p className="report-scope" aria-label="Disbursement counts">
              Clients Receiving Loans:{" "}
              <strong>{report.clientsReceivingLoans}</strong> · Loans issued in
              period: <strong>{report.loansIssued}</strong>.
            </p>
          )}
          {!detailed && (
            <>
              <p className="report-policy">
                Principal repayments are not income. These figures use{" "}
                {filters.currency} only.
              </p>
              {!report.loans.length && (
                <div className="notice dashboard-empty" role="status">
                  <strong>No loans in this selection</strong>
                  <p>
                    No loans match the selected dates, currency and filters.
                    Change the selection or record your first loan if your role
                    allows it.
                  </p>
                </div>
              )}
            </>
          )}
          {(detailed || (canLoans && canRepayments)) && canExpenses && (
            <ReportingCoverage
              filters={filters}
              eventCount={source?.ledger_event_count}
              certification={report.certification}
              onChanged={() => setReload((v) => v + 1)}
            />
          )}
          <details className="report-explanations">
            <summary>How these figures are calculated</summary>
            <p className="report-policy">
              Snapshot recorded: {formatBusinessTimestamp(report.generated_at)}.
              Financial dates and the balance date above determine the amounts.
            </p>
            {report.certification && (
              <p className="report-policy">
                Coverage approved by {report.certification.created_by} for this
                exact period/currency and financial snapshot. Certification:{" "}
                {report.certification.id}. Net Profit = Interest Income Received
                − net business expenses − recognized principal losses.
              </p>
            )}
            <p className="report-policy">
              Principal repayments are capital recovery, never profit. Expected
              interest is the original charge on loans disbursed in the period;
              adjustments appear separately. Interest Income Received is net of
              reversals effective in the period. Recognized losses are
              unrecovered principal at write-off, reversed when that decision is
              reversed.
              {report.certification
                ? "Expense and loss coverage is certified for this snapshot."
                : "Expense coverage is not certified complete, so Net Profit is unavailable."}{" "}
              Shared expenses are not allocated to Clients; expense totals are
              shown only for an unfiltered business scope.
            </p>
            <p className="report-policy">
              Linked corrections take effect on their posting date alongside the
              original reversal. Historical figures are restated using recorded
              effective dates: disbursement date, payment date, and business
              posting date for reversals/adjustments/write-offs. Client identity
              and department/designation are current register details.
              Outstanding includes written-off obligations; collectible and
              overdue totals exclude them.
              {report.inferred
                ? " Legacy allocations/metadata are inferred and limited to the recorded history boundary."
                : ""}
            </p>
          </details>
          {!detailed && canLoans && (
            <button
              className="button secondary"
              onClick={() => {
                const next = { ...filters, status: "Overdue" };
                setFilters(next);
                setDraft(next);
                setKind("loans");
                setPage(1);
                setHistory(null);
                setShowOverdue(true);
              }}
            >
              Review overdue loans
            </button>
          )}
          {(detailed || showOverdue) && (
            <>
              {canExport && (
                <div className="report-actions">
                  <button
                    className="button secondary"
                    disabled={
                      changed || !rows.length || exporting || loading || !!error
                    }
                    onClick={() =>
                      readAction(() =>
                        download(
                          reportCSV(report, kind),
                          "text/csv;charset=utf-8",
                          `${kind}-report-${filters.asOf}.csv`,
                        ),
                      )
                    }
                  >
                    Download {kind === "clients" ? "Client" : "loan"} CSV
                  </button>
                  <button
                    className="button secondary"
                    disabled={
                      changed ||
                      !report.loans.length ||
                      exporting ||
                      loading ||
                      !!error
                    }
                    onClick={excel}
                  >
                    {exporting ? "Preparing…" : "Download .xlsx report"}
                  </button>
                  <button
                    className="button primary"
                    disabled={
                      changed ||
                      !report.loans.length ||
                      exporting ||
                      loading ||
                      !!error
                    }
                    onClick={() => readAction(() => setPrintReport(report))}
                  >
                    Preview printable report
                  </button>
                </div>
              )}
              <section className="panel table-panel">
                <div className="panel-heading">
                  <h2>
                    {kind === "clients"
                      ? "Client period totals"
                      : "Loan balances and histories"}
                  </h2>
                  <div className="filter-tabs">
                    <button
                      className={kind === "clients" ? "active" : ""}
                      onClick={() => {
                        setKind("clients");
                        setPage(1);
                        setHistory(null);
                      }}
                    >
                      By Client
                    </button>
                    <button
                      className={kind === "loans" ? "active" : ""}
                      onClick={() => {
                        setKind("loans");
                        setPage(1);
                        setHistory(null);
                      }}
                    >
                      By loan
                    </button>
                  </div>
                </div>
                <div className="table-scroll">
                  <table>
                    <thead>
                      <tr>
                        <th>Client / Man#</th>
                        {kind === "loans" && <th>Loan / status / due date</th>}
                        <th>
                          {kind === "clients"
                            ? clientLabels.totalDisbursed
                            : "Amount Disbursed"}
                          <br />
                          in period
                        </th>
                        <th>
                          Net Repayment Received
                          <br />
                          in period
                        </th>
                        <th>
                          {kind === "clients"
                            ? clientLabels.interestIncome
                            : "Interest Income Received"}
                          <br />
                          in period
                        </th>
                        <th>
                          Outstanding principal
                          <br />
                          as of date
                        </th>
                        <th>
                          Unpaid interest
                          <br />
                          as of date
                        </th>
                        <th>
                          {clientLabels.outstanding}
                          <br />
                          as of date
                        </th>
                        <th>History</th>
                      </tr>
                    </thead>
                    <tbody>
                      {visible.map((r) => (
                        <tr key={"loan_id" in r ? r.loan_id : r.client_id}>
                          <td>
                            <strong>{r.name}</strong>
                            <small>
                              {r.man_number} · {r.department} · {r.designation}
                            </small>
                          </td>
                          {"loan_id" in r && (
                            <td>
                              <strong>{r.loan_reference}</strong>
                              <small>
                                {r.status} · {r.due_date}
                              </small>
                            </td>
                          )}
                          <td>{fmt(r.disbursed)}</td>
                          <td>{fmt(r.received)}</td>
                          <td>{fmt(r.interestReceived)}</td>
                          <td>{fmt(r.principal)}</td>
                          <td>{fmt(r.interest)}</td>
                          <td>{fmt(r.owed)}</td>
                          <td>
                            {"loan_id" in r ? (
                              <button
                                className="text-button"
                                onClick={() =>
                                  setHistory(
                                    history === r.loan_id ? null : r.loan_id,
                                  )
                                }
                              >
                                {clientLabels.history}
                              </button>
                            ) : (
                              <button
                                className="text-button"
                                onClick={() => onStatement(r.client_id)}
                              >
                                {clientLabels.statement}
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {!rows.length && (
                  <p className="empty-state">
                    No loans match these report filters. Change the dates,
                    search, or filters to see results.
                  </p>
                )}
                <div className="report-pagination">
                  <button
                    className="button secondary"
                    disabled={page <= 1}
                    onClick={() => {
                      setPage((p) => p - 1);
                      setHistory(null);
                    }}
                  >
                    Previous page
                  </button>
                  <span role="status">
                    Page {page} of {pageCount} · {rows.length} {kind} · exports
                    include all matching rows
                  </span>
                  <button
                    className="button secondary"
                    disabled={page >= pageCount}
                    onClick={() => {
                      setPage((p) => p + 1);
                      setHistory(null);
                    }}
                  >
                    Next page
                  </button>
                </div>
              </section>
              {history && source && (
                <LoanHistory
                  source={source}
                  id={history}
                  currency={filters.currency}
                  onClose={() => setHistory(null)}
                />
              )}
            </>
          )}
        </>
      )}
      {printReport &&
        !defaults.loading &&
        sourceScope === scope &&
        createPortal(
          <PrintableReport
            permission={detailed ? "view_reports" : "reporting"}
            report={printReport}
            onClose={() => setPrintReport(null)}
          />,
          document.body,
        )}
    </section>
  );
}
function LoanHistory({
  source,
  id,
  currency,
  onClose,
}: {
  source: ReportSource;
  id: string;
  currency: string;
  onClose: () => void;
}) {
  const loan = source.loans.find((l) => l.id === id)!;
  const payments = source.repayments.filter((r) => r.loan_id === id);
  const audits = [...source.terms_audit, ...source.status_audit]
    .filter((a) => a.loan_id === id)
    .sort((a, b) => a.created_at.localeCompare(b.created_at));
  return (
    <section
      className="panel report-history"
      aria-label="Selected loan history"
    >
      <div className="panel-heading">
        <h2>History · {loan.loan_reference ?? loan.id}</h2>
        <button className="text-button" onClick={onClose}>
          Close history
        </button>
      </div>
      <h3>{clientLabels.history}</h3>
      <p>
        Complete recorded history through this snapshot, including events
        outside the selected activity period. Allocations use posting order.
      </p>
      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              <th>Payment / date</th>
              <th>Original amount</th>
              <th>Interest / principal</th>
              <th>Status / reversal date</th>
              <th>Reason / actor</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((r) => (
              <tr key={r.id}>
                <td>
                  {r.payment_reference}
                  <small>
                    Payment {r.payment_date} · Effective{" "}
                    {repaymentEffectiveDate(r)}
                  </small>
                </td>
                <td>{reportMoney(r.amount_cents, currency)}</td>
                <td>
                  {reportMoney(r.interest_allocation_cents ?? 0, currency)} /{" "}
                  {reportMoney(r.principal_allocation_cents ?? 0, currency)}
                </td>
                <td>
                  {r.reversed_at
                    ? "Reversed · " + businessDate(r.reversed_at)
                    : "Posted"}
                  <small>
                    {r.reversed_at ? "Current net effect: zero" : ""}
                  </small>
                </td>
                <td>
                  {r.reversal_reason ?? "Repayment Received"}
                  <small>{r.reversed_by ?? r.created_by}</small>
                  {r.replaces_repayment_id && (
                    <small>Replaces {r.replaces_repayment_id}</small>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!payments.length && <p>No repayments recorded for this loan.</p>}
      <ul>
        {audits.map((a) => (
          <li key={a.id}>
            {formatBusinessTimestamp(a.created_at)} ·{" "}
            {a.action.replaceAll("_", " ")} · {a.reason} ·{" "}
            {a.actor_id ?? "Migration"}
            {a.action === "adjust" && (
              <>
                {" "}
                · Interest{" "}
                {reportMoney(
                  a.before_data?.interest_cents ?? 0,
                  currency,
                )} → {reportMoney(a.after_data.interest_cents ?? 0, currency)} ·
                Due {a.before_data?.due_date} → {a.after_data.due_date}
              </>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
function PrintableReport({
  report,
  onClose,
  permission,
}: {
  permission: "view_reports" | "reporting";
  report: FinancialReport;
  onClose: () => void;
}) {
  const active = useRef(true);
  useEffect(() => {
    active.current = true;
    return () => {
      active.current = false;
    };
  }, []);
  const supabase = useSupabase();
  const defaults = useLoanDefaults();
  const [accessError, setAccessError] = useState("");
  async function print() {
    try {
      if (supabase) {
        await requireReadAccess(supabase);
        await requireReadAccess(supabase, permission);
      }
      if (!active.current) return;
      setAccessError("");
      await new Promise((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(resolve)),
      );
      if (active.current) window.print();
    } catch (failure) {
      if (failure instanceof ReadAccessError && failure.denied)
        void defaults.reload();
      setAccessError(
        failure instanceof Error
          ? failure.message
          : "Read access could not be verified.",
      );
    }
  }
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    dialog.current?.showModal();
  }, []);
  const f = report.filters,
    fmt = (n: number) => reportMoney(n, f.currency);
  return (
    <dialog
      className="report-document"
      ref={dialog}
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
    >
      <div className="print-actions">
        <button className="button primary" onClick={() => void print()}>
          Print filtered report
        </button>
        <button className="button secondary" onClick={onClose}>
          Close report preview
        </button>
      </div>
      {accessError && (
        <p className="notice error" role="alert">
          {accessError}
        </p>
      )}
      <article className="print-area">
        <header className="document-header">
          <h1>{brand.name} · Financial report</h1>
          <p>
            Activity {f.from} to {f.to} · Balances at end of {f.asOf} ·{" "}
            {f.currency} · Africa/Lusaka
          </p>
          <p>
            Search: {f.search || "All"} · Department: {f.department || "All"} ·
            Designation: {f.designation || "All"} · Status as of date:{" "}
            {f.status || "All"} · Disbursed: {f.disbursedFrom || "Any"} to{" "}
            {f.disbursedTo || "Any"}
          </p>
          <p>
            Clients Receiving Loans: {report.clientsReceivingLoans} · Loans
            issued in period: {report.loansIssued}
          </p>
          <p>
            Snapshot: {report.generated_at} · {report.loans.length} matching
            loans · All pages included
          </p>
        </header>
        <dl className="document-details">
          {(Object.keys(reportAmountLabels) as (keyof ReportAmounts)[]).map(
            (k) => (
              <div key={k}>
                <dt>{reportAmountLabels[k]}</dt>
                <dd>{fmt(report.totals[k])}</dd>
              </div>
            ),
          )}
        </dl>
        <p>
          Business expenses:{" "}
          {report.expenses === null
            ? report.expenseScope === "unrecorded"
              ? "Not recorded"
              : "Unallocated for Client/loan filters"
            : fmt(report.expenses)}
          .{" "}
          {report.certification && report.netProfit !== null
            ? `Coverage approved for this snapshot: ${report.certification.id}. Net Profit: ${fmt(report.netProfit!)}.`
            : "Coverage is not certified complete; Net Profit unavailable."}
          Principal repayments are capital recovery. Recognized losses:
          unrecovered principal at write-off, reversed on write-off reversal.
          Shared expenses are not allocated to Clients.
        </p>
        <p>
          Result from recorded entries (not final profit):{" "}
          {report.recordedResult === null
            ? "Unavailable / unallocated"
            : fmt(report.recordedResult)}
          .
        </p>
        <h2>Client period totals</h2>
        <table>
          <thead>
            <tr>
              <th>Client / Man#</th>
              <th>{clientLabels.totalDisbursed}</th>
              <th>Net Repayment Received</th>
              <th>{clientLabels.interestIncome}</th>
              <th>{clientLabels.outstanding} as of date</th>
            </tr>
          </thead>
          <tbody>
            {report.clients.map((c) => (
              <tr key={c.client_id}>
                <td>
                  {c.name}
                  <br />
                  {c.man_number}
                </td>
                <td>{fmt(c.disbursed)}</td>
                <td>{fmt(c.received)}</td>
                <td>{fmt(c.interestReceived)}</td>
                <td>{fmt(c.owed)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <h2>Loan balances as of date</h2>
        <table>
          <thead>
            <tr>
              <th>Loan / Client</th>
              <th>Outstanding principal</th>
              <th>Unpaid interest</th>
              <th>Total owed</th>
              <th>Status / due date</th>
            </tr>
          </thead>
          <tbody>
            {report.loans.map((l) => (
              <tr key={l.loan_id}>
                <td>
                  {l.loan_reference}
                  <br />
                  {l.name}
                </td>
                <td>{fmt(l.principal)}</td>
                <td>{fmt(l.interest)}</td>
                <td>{fmt(l.owed)}</td>
                <td>
                  {l.status}
                  <br />
                  {l.due_date}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p>
          Figures are restated by effective dates: disbursement/payment dates
          and posting business dates of reversals, adjustments, linked
          corrections and write-offs. Expected interest is separate from
          received income. Identity and department/designation filters use
          current Client details. Total owed includes written-off balances;
          collectible and overdue exclude them.
          {report.inferred
            ? " Legacy allocations/metadata are inferred; the recorded history boundary applies."
            : ""}
        </p>
      </article>
    </dialog>
  );
}
