import { RequiredMark } from "./form-controls";
import type { Client } from "@/lib/domain";
export function ClientFields({
  client,
  manNumber = "",
  readOnly = false,
  onManNumberChange,
}: {
  client?: Client | null;
  manNumber?: string;
  readOnly?: boolean;
  onManNumberChange?: (value: string) => void;
}) {
  return (
    <>
      <label>
        <span className="field-label">
          <RequiredMark />
          Man#
        </span>
        <input
          readOnly={readOnly}
          name="man_number"
          type="text"
          autoComplete="off"
          aria-describedby="client-man-hint"
          autoCapitalize="none"
          spellCheck={false}
          required
          maxLength={50}
          defaultValue={client?.man_number ?? manNumber}
          onChange={(event) => onManNumberChange?.(event.target.value)}
        />
      </label>
      <p id="client-man-hint" className="form-hint">
        Enter the Client’s chosen or assigned Man# manually. No Man# is
        generated. Use 1–50 text characters without control characters;
        surrounding spaces are removed. Leading zeros are preserved. Man# must
        be unique within this business, regardless of letter case.
      </p>
      <label>
        <span className="field-label">
          <RequiredMark />
          Client name
        </span>
        <input
          readOnly={readOnly}
          name="name"
          required
          minLength={2}
          maxLength={120}
          defaultValue={client?.name ?? ""}
        />
      </label>
      <div className="form-row">
        <label>
          <span className="field-label">
            <RequiredMark />
            Department
          </span>
          <input
            readOnly={readOnly}
            name="department"
            required
            maxLength={120}
            defaultValue={client?.department ?? ""}
          />
        </label>
        <label>
          <span className="field-label">
            <RequiredMark />
            Designation
          </span>
          <input
            readOnly={readOnly}
            name="designation"
            required
            maxLength={120}
            defaultValue={client?.designation ?? ""}
          />
        </label>
      </div>
      <label>
        Email
        <input
          readOnly={readOnly}
          name="email"
          type="email"
          maxLength={254}
          defaultValue={client?.email ?? ""}
        />
      </label>
      <label>
        Phone
        <input
          readOnly={readOnly}
          name="phone"
          type="tel"
          maxLength={30}
          defaultValue={client?.phone ?? ""}
        />
      </label>
      <label>
        Address
        <input
          readOnly={readOnly}
          name="address"
          maxLength={500}
          defaultValue={client?.address ?? ""}
        />
      </label>
      <label className="checkbox-label">
        <input
          readOnly={readOnly}
          name="is_active"
          role="switch"
          type="checkbox"
          disabled={readOnly}
          defaultChecked={client?.is_active ?? true}
        />
        Active Client
      </label>
    </>
  );
}
