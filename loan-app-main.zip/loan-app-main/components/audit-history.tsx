"use client";
import { formatBusinessTimestamp } from "@/lib/business-time";
import { useEffect, useState } from "react";
import { useSupabase } from "@/lib/workspace-context";
import { permissionModules, permissionActions } from "@/lib/permissions";
import { serviceError } from "@/lib/errors";
type Source =
  | "client_audit"
  | "loan_terms_audit"
  | "loan_status_audit"
  | "settings_audit"
  | "audit_events";
type Entry = {
  id: string;
  created_at: string;
  reason: string;
  actor_id?: string | null;
  action?: string;
  entity_type?: string;
  entity_id?: string;
  before_data?: Record<string, unknown> | null;
  after_data?: Record<string, unknown>;
  before_status?: string;
  after_status?: string;
};
type Cursor = { stamp: string; id: string } | null;
const fieldNames: Record<string, string> = {
  man_number: "Man#",
  client_id: "Client ID",
  name: "Client name",
  is_active: "Active status",
  interest_rate_bps: "Entire-term rate (basis points)",
  principal_cents: "Amount Disbursed (ngwee)",
  interest_cents: "Interest charge (ngwee)",
  balance_cents: "Outstanding balance (ngwee)",
  amount_cents: "Amount (ngwee)",
  default_rate_bps: "Default entire-term rate (basis points)",
  default_term_days: "Default loan term (days)",
};
const permissionLabels = Object.fromEntries([
  ...permissionModules,
  ...permissionActions,
]);
function permissionChanges(before: unknown, after: unknown) {
  const old = (before ?? {}) as Record<string, boolean>;
  const next = (after ?? {}) as Record<string, boolean>;
  return (
    <details>
      <summary>Changed module access and sensitive actions</summary>
      <ul>
        {Object.keys(next)
          .filter((key) => old[key] !== next[key])
          .map((key) => (
            <li key={key}>
              {permissionLabels[key] ?? key}:{" "}
              {old[key] === undefined
                ? "Not assigned"
                : old[key]
                  ? "Allowed"
                  : "Denied"}{" "}
              → {next[key] ? "Allowed" : "Denied"}
            </li>
          ))}
      </ul>
    </details>
  );
}
const actionNames: Record<string, string> = {
  baseline: "Migration baseline",
  role_assigned: "User added",
  role_changed: "User access changed",
  permissions_changed: "Permissions changed",
  originate: "Amount Disbursed recorded",
  settle: "Loan settled",
  reopen: "Loan reopened",
  write_off: "Loan written off",
  reverse_write_off: "Write-off reversed",
  correct: "Correction",
  create: "Client created",
};
export function AuditHistory({
  source,
  recordId,
  title,
  revision,
}: {
  source: Source;
  recordId?: string;
  title: string;
  revision?: string | number;
}) {
  const supabase = useSupabase();
  const [rows, setRows] = useState<Entry[]>([]),
    [cursors, setCursors] = useState<Cursor[]>([null]),
    [index, setIndex] = useState(0),
    [more, setMore] = useState(false),
    [search, setSearch] = useState(""),
    [query, setQuery] = useState(""),
    [refresh, setRefresh] = useState(0),
    [loading, setLoading] = useState(false),
    [error, setError] = useState("");
  useEffect(() => {
    if (search.trim() === query) return;
    const timer = setTimeout(() => {
      setQuery(search.trim());
      setCursors([null]);
      setIndex(0);
    }, 250);
    return () => clearTimeout(timer);
  }, [search, query]);
  useEffect(() => {
    setIndex(0);
    setCursors([null]);
  }, [source, recordId, revision]);
  const cursor = cursors[index];
  useEffect(() => {
    let active = true;
    setRows([]);
    setMore(false);
    setError("");
    if (!supabase) return;
    setLoading(true);
    let request = supabase
      .from(source)
      .select("*", { count: "exact" })
      .order("created_at", { ascending: false })
      .order("id", { ascending: false })
      .limit(51);
    if (recordId)
      request = request.eq(
        source === "client_audit"
          ? "client_id"
          : source === "settings_audit"
            ? "owner_id"
            : "loan_id",
        recordId,
      );
    if (query)
      request = request.ilike(
        "reason",
        "%" + query.replace(/[\\%_]/g, "\\$&") + "%",
      );
    if (cursor)
      request = request.or(
        `created_at.lt.${cursor.stamp},and(created_at.eq.${cursor.stamp},id.lt.${cursor.id})`,
      );
    void request.then((r) => {
      if (!active) return;
      setLoading(false);
      if (r.error) {
        setError(serviceError(r.error, "audit history"));
        return;
      }
      const values = r.data as Entry[];
      setRows(values.slice(0, 50));
      setMore(
        values.length > 50 ||
          (r.count !== null && r.count > Math.min(values.length, 50)),
      );
    });
    return () => {
      active = false;
    };
  }, [source, recordId, revision, query, cursor?.id, cursor?.stamp, refresh]);
  function next() {
    const last = rows.at(-1);
    if (!last) return;
    setCursors((c) => [
      ...c.slice(0, index + 1),
      { stamp: last.created_at, id: last.id },
    ]);
    setIndex((i) => i + 1);
  }
  return (
    <section className="audit-trail">
      <h3>{title}</h3>
      <label>
        Search {title.toLowerCase()}
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") e.preventDefault();
          }}
        />
      </label>
      <button
        type="button"
        className="text-button"
        disabled={loading}
        onClick={() => {
          setIndex(0);
          setCursors([null]);
          setRefresh((v) => v + 1);
        }}
      >
        Refresh audit history
      </button>
      {loading && <p role="status">Loading audit history…</p>}
      {error && (
        <p role="alert" className="form-error">
          {error}
        </p>
      )}
      {!loading && !error && !rows.length && <p>No audit entries available.</p>}
      {rows.map((row) => (
        <article key={row.id}>
          <strong>
            {row.entity_type ? row.entity_type + " · " : ""}
            {row.action &&
              (actionNames[row.action] ?? row.action.replaceAll("_", " "))}
          </strong>
          <p>{row.reason}</p>
          <small>
            {row.actor_id ?? "Migration / trusted administration"} ·{" "}
            {formatBusinessTimestamp(row.created_at)}
            {row.entity_id && " · " + row.entity_id}
          </small>
          {row.before_status && (
            <p>
              {row.before_status} → {row.after_status}
            </p>
          )}
          {row.after_data && (
            <ul>
              {Object.keys(row.after_data)
                .filter(
                  (k) =>
                    JSON.stringify(row.before_data?.[k]) !==
                    JSON.stringify(row.after_data?.[k]),
                )
                .map((k) => (
                  <li key={k}>
                    <b>{fieldNames[k] ?? k.replaceAll("_", " ")}:</b>{" "}
                    {k === "permissions" ? (
                      permissionChanges(
                        row.before_data?.[k],
                        row.after_data?.[k],
                      )
                    ) : (
                      <>
                        {typeof row.before_data?.[k] === "object"
                          ? JSON.stringify(row.before_data?.[k])
                          : String(row.before_data?.[k] ?? "—")}{" "}
                        →{" "}
                        {typeof row.after_data?.[k] === "object"
                          ? JSON.stringify(row.after_data?.[k])
                          : String(row.after_data?.[k] ?? "—")}
                      </>
                    )}
                  </li>
                ))}
            </ul>
          )}
        </article>
      ))}
      <div className="report-pagination">
        <button
          type="button"
          className="button secondary"
          disabled={loading || index === 0}
          onClick={() => setIndex((i) => i - 1)}
        >
          Newer audit entries
        </button>
        <span role="status">Audit page {index + 1}</span>
        <button
          type="button"
          className="button secondary"
          disabled={loading || !more}
          onClick={next}
        >
          Older audit entries
        </button>
      </div>
      <p>
        Immutable history · Africa/Lusaka · New events do not shift older pages.
      </p>
    </section>
  );
}
