"use client";
import { useId, useState, useRef, useEffect, type ReactNode } from "react";
import Link from "next/link";
import {
  LayoutDashboard,
  Users,
  CirclePlus,
  LogOut,
  ChartNoAxesColumn,
  ArrowDownLeft,
  FileSpreadsheet,
  BookOpen,
  Settings,
  Menu,
  X,
  Wallet,
  ScrollText,
  ShieldCheck,
  PanelLeftClose,
  PanelLeftOpen,
  ChartNoAxesCombined,
} from "lucide-react";
import {
  firstAccessiblePath,
  hasCapability,
  viewCapability,
} from "@/lib/access";
import type { LoanDefaults } from "@/lib/interest";
import { viewHashes, type WorkspaceView } from "@/lib/ui-labels";
import { useWorkspaceBase } from "@/lib/workspace-context";
import { sidebarStorageKey, sidebarPreference } from "@/lib/sidebar";
import { brand } from "@/lib/brand";
import { useSessionSafety } from "./session-boundary";
import { ThemeSelector } from "./theme-selector";
const items = [
  { name: "Dashboard", icon: LayoutDashboard, group: "Overview" },
  { name: "Clients", icon: Users, group: "Lending Operations" },
  { name: "Loans", icon: BookOpen, group: "Lending Operations" },
  { name: "New Loan", icon: CirclePlus, group: "Lending Operations" },
  { name: "Repayments", icon: ArrowDownLeft, group: "Lending Operations" },
  { name: "Reports", icon: ChartNoAxesColumn, group: "Finance & Reporting" },
  {
    name: "Excel Imports",
    icon: FileSpreadsheet,
    group: "Finance & Reporting",
  },
  { name: "Settings", icon: Settings, group: "Administration" },
] as const;
const groups = [
  "Overview",
  "Lending Operations",
  "Finance & Reporting",
  "Administration",
];
export function WorkspaceNavigation({
  current,
  capabilities,
  demo = false,
  onNavigate,
  standalone = false,
  pending = false,
  children,
}: {
  current: string;
  capabilities: LoanDefaults["capabilities"] | undefined;
  demo?: boolean;
  onNavigate?: (view: WorkspaceView) => void;
  standalone?: boolean;
  pending?: boolean;
  children?: ReactNode;
}) {
  const session = useSessionSafety();
  const [signingOut, setSigningOut] = useState(false);
  const workspaceBase = useWorkspaceBase(),
    id = useId();
  const [ready, setReady] = useState(false),
    [collapsed, setCollapsed] = useState(false),
    [storageError, setStorageError] = useState("");
  const [expanded, setExpanded] = useState(false);
  const toggle = useRef<HTMLButtonElement>(null),
    drawer = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const apply = (value: unknown) => {
      const p = sidebarPreference(value);
      document.documentElement.dataset.sidebar = p;
      setCollapsed(p === "collapsed");
    };
    try {
      apply(localStorage.getItem(sidebarStorageKey));
    } catch {
      apply(document.documentElement.dataset.sidebar);
    }
    setReady(true);
    const storage = (e: StorageEvent) => {
      if (e.key === sidebarStorageKey || e.key === null) apply(e.newValue);
    };
    const resize = () => {
      if (matchMedia("(min-width: 601px)").matches) drawer.current?.close();
    };
    window.addEventListener("storage", storage);
    window.addEventListener("resize", resize);
    return () => {
      window.removeEventListener("storage", storage);
      window.removeEventListener("resize", resize);
    };
  }, []);
  useEffect(() => {
    if (!expanded) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [expanded]);
  function collapse() {
    const value = collapsed ? "expanded" : "collapsed";
    document.documentElement.dataset.sidebar = value;
    setCollapsed(!collapsed);
    try {
      localStorage.setItem(sidebarStorageKey, value);
      setStorageError("");
    } catch {
      setStorageError(
        "Sidebar preference applies for this visit; your browser could not save it.",
      );
    }
  }
  function close() {
    drawer.current?.close();
  }
  const home = demo ? workspaceBase + "/" : firstAccessiblePath(capabilities);
  const branding = (
    <Link
      className="brand"
      href={home}
      prefetch={false}
      aria-label={`${brand.name} home`}
    >
      <span className="brand-icon">
        <ChartNoAxesCombined size={23} aria-hidden="true" />
      </span>
      <span className="brand-wordmark">
        {brand.name}
        <span className="brand-dot">.</span>
      </span>
    </Link>
  );
  function links(includeSupplement = false) {
    const entries = items
      .filter(
        ({ name }) => demo || hasCapability(capabilities, viewCapability[name]),
      )
      .map(({ name, icon, group }) => ({
        group,
        name: name === "Loans" ? "Loan History" : name,
        current: name === current,
        icon,
        href:
          name === "Settings"
            ? demo
              ? "/demo/settings"
              : "/settings"
            : `${workspaceBase}/#${viewHashes[name]}`,
        view: name !== "Settings" ? name : undefined,
      }));
    const extra = !demo
      ? (
          [
            [
              "can_view_expenses",
              "/expenses",
              "Expenses",
              Wallet,
              "Finance & Reporting",
            ],
            [
              "can_view_users",
              "/users",
              "User Management",
              Users,
              "Administration",
            ],
            [
              "can_view_audit",
              "/audit-logs",
              "Audit Logs",
              ScrollText,
              "Administration",
            ],
          ] as const
        )
          .filter(([flag]) => hasCapability(capabilities, flag))
          .map(([, href, name, icon, group]) => ({
            name,
            href,
            icon,
            group,
            current: current === name,
            view: undefined,
          }))
      : [];
    const ordered = [...entries, ...extra].sort((a, b) => {
      const order = [
        "Dashboard",
        "Clients",
        "Loan History",
        "New Loan",
        "Repayments",
        "Expenses",
        "Reports",
        "Excel Imports",
        "User Management",
        "Audit Logs",
        "Settings",
      ];
      return order.indexOf(a.name) - order.indexOf(b.name);
    });
    return (
      <nav aria-label="Main navigation">
        {groups.map((group) => {
          const visible = ordered.filter((item) => item.group === group);
          if (!visible.length) return null;
          return (
            <section
              className="nav-section"
              role="group"
              aria-label={group}
              key={group}
            >
              <h2 className="nav-section-heading">{group}</h2>
              {visible.map(
                ({ name, current: active, icon: Icon, href, view }) => (
                  <Link
                    key={name}
                    className={`nav-item ${active ? "selected" : ""}`}
                    href={href}
                    prefetch={false}
                    aria-label={name}
                    title={name}
                    aria-current={active ? "page" : undefined}
                    aria-disabled={pending || undefined}
                    onClick={(e) => {
                      if (pending) {
                        e.preventDefault();
                        return;
                      }
                      if (
                        !e.metaKey &&
                        !e.ctrlKey &&
                        !e.shiftKey &&
                        !e.altKey &&
                        e.button === 0
                      ) {
                        close();
                        if (onNavigate && view) {
                          e.preventDefault();
                          onNavigate(view);
                        }
                      }
                    }}
                  >
                    <Icon size={19} aria-hidden="true" />
                    <span className="nav-label">{name}</span>
                  </Link>
                ),
              )}
            </section>
          );
        })}
        {includeSupplement && children && (
          <div className="sidebar-supplemental">{children}</div>
        )}
        {!demo && (
          <div className="nav-account" role="group" aria-label="Account">
            <Link
              className={`nav-item ${current === "Account security" ? "selected" : ""}`}
              href="/security"
              prefetch={false}
              aria-current={current === "Account security" ? "page" : undefined}
              title="Account Security"
              aria-label="Account Security"
              aria-disabled={pending || undefined}
              onClick={(e) => {
                if (pending) e.preventDefault();
                else close();
              }}
            >
              <ShieldCheck size={19} aria-hidden="true" />
              <span className="nav-label">Account Security</span>
            </Link>
            {session.state === "active" && (
              <button
                type="button"
                className="nav-item"
                aria-label="Sign Out"
                title="Sign Out"
                disabled={pending || signingOut}
                onClick={() => {
                  setSigningOut(true);
                  close();
                  void session.logout().finally(() => setSigningOut(false));
                }}
              >
                <LogOut size={19} aria-hidden="true" />
                <span className="nav-label">
                  {signingOut ? "Signing out…" : "Sign Out"}
                </span>
              </button>
            )}
          </div>
        )}
      </nav>
    );
  }
  return (
    <>
      <aside className="sidebar desktop-sidebar" aria-label="Workspace sidebar">
        <div className="sidebar-brand-row">
          {branding}
          <button
            className="sidebar-collapse"
            type="button"
            onClick={collapse}
            disabled={!ready}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            aria-expanded={!collapsed}
            title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {collapsed ? (
              <PanelLeftOpen size={20} />
            ) : (
              <PanelLeftClose size={20} />
            )}
            <span className="nav-label">Collapse sidebar</span>
          </button>
        </div>
        <div className="navigation-wrap">{links(true)}</div>
        {storageError && (
          <p className="sidebar-save-note" role="status">
            {storageError}
          </p>
        )}
      </aside>
      <header
        className={`workspace-nav-tools ${standalone ? "standalone-tools" : ""}`}
      >
        <button
          ref={toggle}
          type="button"
          className="mobile-navigation-trigger icon-button"
          disabled={!ready || pending}
          aria-label="Open navigation"
          aria-haspopup="dialog"
          aria-controls={id}
          aria-expanded={expanded}
          onClick={() => {
            drawer.current?.showModal();
            setExpanded(true);
          }}
        >
          <Menu size={22} aria-hidden="true" />
        </button>
        {standalone && (
          <>
            <span className="workspace-header-title">{brand.name}</span>
            <ThemeSelector />
          </>
        )}
      </header>
      <dialog
        ref={drawer}
        id={id}
        className="mobile-sidebar"
        aria-label="Workspace navigation"
        onKeyDown={(event) => {
          if (event.key !== "Tab") return;
          const controls = Array.from(
            event.currentTarget.querySelectorAll<HTMLElement>(
              "a[href],button:not(:disabled)",
            ),
          );
          const first = controls[0],
            last = controls.at(-1);
          if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last?.focus();
          } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first?.focus();
          }
        }}
        onClose={() => {
          setExpanded(false);
        }}
        onClick={(e) => {
          if (e.target !== e.currentTarget) return;
          const rect = e.currentTarget.getBoundingClientRect();
          if (
            e.clientX < rect.left ||
            e.clientX > rect.right ||
            e.clientY < rect.top ||
            e.clientY > rect.bottom
          )
            close();
        }}
      >
        <div className="drawer-heading">
          {branding}
          <button
            type="button"
            className="icon-button"
            aria-label="Close navigation"
            onClick={close}
            autoFocus
          >
            <X size={22} aria-hidden="true" />
          </button>
        </div>
        {links()}
      </dialog>
    </>
  );
}
