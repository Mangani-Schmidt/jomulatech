import type { Client } from "@/lib/domain";
export function ClientManConflict({
  client,
  onOpen,
  busy,
}: {
  client: Client;
  onOpen?: () => void;
  busy: boolean;
}) {
  return (
    <section
      className="notice client-man-conflict"
      aria-label="Existing Client with this Man#"
      role="status"
    >
      <div>
        <h3>This Man# is already registered</h3>
        <dl className="review-details">
          <div>
            <dt>Man#</dt>
            <dd>{client.man_number}</dd>
          </div>
          <div>
            <dt>Client name</dt>
            <dd>{client.name}</dd>
          </div>
          <div>
            <dt>Department</dt>
            <dd>{client.department ?? "Not recorded"}</dd>
          </div>
          <div>
            <dt>Designation</dt>
            <dd>{client.designation ?? "Not recorded"}</dd>
          </div>
          <div>
            <dt>Status</dt>
            <dd>{client.is_active ? "Active Client" : "Inactive Client"}</dd>
          </div>
        </dl>
        <p>
          No Client has been created or changed. Use another Man# or open the
          existing record. Corrections require a separate audited action.
        </p>
        {onOpen && (
          <>
            <button
              type="button"
              className="button secondary"
              disabled={busy}
              onClick={onOpen}
            >
              Open existing Client Details
            </button>
            <p className="form-hint">
              Opening it discards the unsaved entries in this form. Its internal
              Client ID and loan history are preserved.
            </p>
          </>
        )}
      </div>
    </section>
  );
}
