"use client";
import { Form, DateInput, RequiredMark } from "./form-controls";
import { useReadScope } from "@/lib/use-read-scope";
import { SESSION_REVALIDATING_EVENT } from "@/lib/session-activity";
import { formatBusinessTimestamp } from "@/lib/business-time";
import { hasCapability } from "@/lib/access";
import { useEffect, useRef, useState, useMemo } from "react";
import { usePostingIntent } from "@/lib/use-posting-intent";
import { PostingRecovery } from "./posting-recovery";
import { WorkspaceNavigation } from "./workspace-navigation";
import { serviceError } from "@/lib/errors";
import { useSupabase } from "@/lib/workspace-context";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import { today, type Expense } from "@/lib/domain";
import {
  buildExpenseReport,
  type ExpenseFilters,
  type ExpenseReport,
} from "@/lib/expense-report";
import { requireReadAccess, ReadAccessError } from "@/lib/read-access";
import { ExpensePrint } from "./expense-print";
import { paymentMethods } from "@/lib/repayments";
export function ExpenseRegister() {
  const supabase = useSupabase();
  const defaults = useLoanDefaults();
  const verifyScope = useReadScope(
    JSON.stringify([
      defaults.value?.settings.owner_id,
      defaults.value?.capabilities,
    ]),
  );
  const admin = hasCapability(
      defaults.value?.capabilities,
      "can_approve_adjustments",
    ),
    canManage = hasCapability(
      defaults.value?.capabilities,
      "can_manage_expenses",
    );
  const [source, setSource] = useState<Expense[] | null>(null),
    [loading, setLoading] = useState(true),
    [loadError, setLoadError] = useState("");
  const [filters, setFilters] = useState<ExpenseFilters>({
    from: "1900-01-01",
    to: today(),
    currency: "ZMW",
    search: "",
    category: "",
    status: "",
  });
  const [draft, setDraft] = useState(filters);
  const [exporting, setExporting] = useState(false),
    [printReport, setPrintReport] = useState<ExpenseReport | null>(null);
  const canExport = hasCapability(
    defaults.value?.capabilities,
    "can_export_reports",
  );
  const [page, setPage] = useState(0),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [message, setMessage] = useState(""),
    [revision, setRevision] = useState(0);
  const computed = useMemo(() => {
    try {
      return {
        report: source ? buildExpenseReport(source, filters) : null,
        error: "",
      };
    } catch (e) {
      return { report: null, error: (e as Error).message };
    }
  }, [source, filters]);
  const report = computed.report,
    rows = report?.items.slice(page * 20, page * 20 + 20) ?? [],
    more = (report?.items.length ?? 0) > (page + 1) * 20;
  const changed = JSON.stringify(draft) !== JSON.stringify(filters);
  const fmt = (n: number) =>
    new Intl.NumberFormat("en-ZM", {
      style: "currency",
      currency: filters.currency,
    }).format(n / 100);
  async function verifyExport() {
    if (!supabase) throw new Error("Sign in before exporting expenses.");
    try {
      await requireReadAccess(supabase, "view_expenses");
      await requireReadAccess(supabase);
      verifyScope();
    } catch (e) {
      if (e instanceof ReadAccessError && e.denied) {
        setSource(null);
        setPrintReport(null);
        setError(e.message);
        void defaults.reload();
      }
      throw e;
    }
  }
  async function exportExpenses(kind: "excel" | "pdf" | "print") {
    if (!report || changed || !canExport || exporting) return;
    setExporting(true);
    setError("");
    setMessage("");
    try {
      await verifyExport();
      const snapshot = { ...report, generated_at: new Date().toISOString() };
      if (kind === "print") {
        setPrintReport(snapshot);
        return;
      }
      const { downloadBlob, saveWorkbook } = await import("@/lib/workbook");
      if (kind === "excel") {
        const { expenseWorkbook } = await import("@/lib/report-exports");
        const wb = expenseWorkbook(snapshot);
        await verifyExport();
        await saveWorkbook(
          wb,
          `expenses-${filters.from}-${filters.to}-${filters.currency}.xlsx`,
          verifyExport,
        );
      } else {
        const { expensePDFBlob } = await import("@/lib/expense-pdf");
        const blob = await expensePDFBlob(snapshot);
        await verifyExport();
        downloadBlob(
          blob,
          `expenses-${filters.from}-${filters.to}-${filters.currency}.pdf`,
        );
      }
      setMessage(
        "Expense " +
          (kind === "excel" ? "Excel workbook" : "PDF") +
          " downloaded.",
      );
    } catch (e) {
      if (e instanceof ReadAccessError && e.denied) {
        setSource(null);
        setPrintReport(null);
        void defaults.reload();
      }
      setError((e as Error).message ?? "Expense export failed.");
    } finally {
      setExporting(false);
    }
  }
  const [selected, setSelected] = useState<Expense | null>(null),
    [reason, setReason] = useState(""),
    [approve, setApprove] = useState(false);
  const intent = usePostingIntent();
  const formRef = useRef<HTMLFormElement>(null);
  const blocked = intent.checking || !!intent.pending || !!intent.storageError;
  const reverseRequest = useRef<{ payload: string; id: string } | null>(null);
  useEffect(() => {
    let cancelled = false;
    setSource(null);
    setLoadError("");
    setLoading(true);
    if (
      !supabase ||
      !hasCapability(defaults.value?.capabilities, "can_view_expenses")
    ) {
      setLoading(false);
      return;
    }
    void (async () => {
      try {
        const all: Expense[] = [];
        for (let offset = 0; ; offset += 1000) {
          const r = await supabase
            .from("expenses")
            .select("*")
            .eq("currency", filters.currency)
            .order("expense_date", { ascending: false })
            .order("id")
            .range(offset, offset + 999);
          if (r.error) throw r.error;
          all.push(...r.data);
          if (all.length > 10000)
            throw new Error(
              "More than 10,000 expenses in this currency. Contact your Administrator for a server-filtered report; no truncated totals are shown.",
            );
          if (r.data.length < 1000) break;
        }
        if (!cancelled) {
          setSource(all);
          setPage(0);
        }
      } catch (e) {
        if (!cancelled) setLoadError(serviceError(e, "expenses"));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [
    defaults.value?.settings.owner_id,
    defaults.value?.capabilities.can_view_expenses,
    filters.currency,
    revision,
  ]);
  useEffect(() => {
    const resumed = () => setRevision((v) => v + 1);
    window.addEventListener(SESSION_REVALIDATING_EVENT, resumed);
    return () =>
      window.removeEventListener(SESSION_REVALIDATING_EVENT, resumed);
  }, []);
  async function post(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!supabase || blocked || !canManage) return;
    const form = e.currentTarget;
    const f = new FormData(form);
    const text = (key: string) => String(f.get(key) ?? "").trim();
    const body = {
      p_details: {
        amount: text("amount"),
        expense_date: text("expense_date"),
        currency: "ZMW",
        category: text("category"),
        description: text("description"),
        payee: text("payee"),
        payment_method: text("payment_method"),
        external_reference: text("external_reference"),
      },
      p_confirm: f.get("confirm") === "on",
    };
    setBusy(true);
    setError("");
    setMessage("");
    try {
      await intent.post("post_expense", body);
      await intent.complete();
      form.reset();
      setRevision((v) => v + 1);
      setPage(0);
      setMessage("Expense posted and audited.");
    } catch (e) {
      setError(
        (e as { message?: string }).message ?? "Could not post expense.",
      );
    } finally {
      setBusy(false);
    }
  }
  async function recover() {
    setBusy(true);
    setError("");
    try {
      const saved = await intent.recover();
      await intent.complete();
      if (saved.operation === "post_expense") {
        formRef.current?.reset();
        setRevision((v) => v + 1);
        setMessage("Original expense recovered without a duplicate.");
      } else
        window.location.assign(
          saved.operation === "originate_loan"
            ? "/dashboard/#loan-history"
            : "/dashboard/#repayments",
        );
    } catch (e) {
      setError(
        (e as { message?: string }).message ??
          "Could not recover the original transaction.",
      );
    } finally {
      setBusy(false);
    }
  }
  async function reverse(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase || !selected) return;
    setBusy(true);
    setError("");
    setMessage("");
    const body = {
      p_expense_id: selected.id,
      p_reason: reason.trim(),
      p_confirm: approve,
    };
    const payload = JSON.stringify(body);
    if (reverseRequest.current?.payload !== payload)
      reverseRequest.current = { payload, id: crypto.randomUUID() };
    try {
      const r = await supabase.rpc("reverse_expense", {
        ...body,
        p_request_id: reverseRequest.current.id,
      });
      if (r.error) throw r.error;
      setSelected(null);
      setReason("");
      setApprove(false);
      setRevision((v) => v + 1);
      setMessage(
        "Expense reversed; original remains visible with zero net effect.",
      );
    } catch (e) {
      setError(
        (e as { message?: string }).message ?? "Could not reverse expense.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <main
      className="settings-page standalone-page"
      id="workspace-content"
      tabIndex={-1}
    >
      <WorkspaceNavigation
        current="Expenses"
        capabilities={defaults.value?.capabilities}
        demo={!supabase}
        standalone
        pending={busy || exporting}
      />
      {hasCapability(defaults.value?.capabilities, "can_view_dashboard") && (
        <a className="text-button" href="/dashboard">
          ← Back to workspace
        </a>
      )}
      <div className="page-heading">
        <div>
          <div className="eyebrow">BUSINESS COSTS</div>
          <h1>Expenses</h1>
          <p>
            Actual paid business expenses in ZMW. Shared costs are not allocated
            to Clients.
          </p>
        </div>
      </div>
      <PostingRecovery
        intent={intent}
        busy={busy}
        onRecover={() => void recover()}
      />
      {defaults.loading && !defaults.value ? (
        <p role="status">Checking access…</p>
      ) : !hasCapability(defaults.value?.capabilities, "can_view_expenses") ? (
        <p className="notice error" role="alert">
          Sign in with an assigned business role to view expenses.
        </p>
      ) : (
        <>
          {canManage && (
            <section className="panel settings-panel">
              <h2>Record paid expense</h2>
              <Form
                ref={formRef}
                onSubmit={post}
                onChange={(e) => {
                  const confirmation = e.currentTarget.elements.namedItem(
                    "confirm",
                  ) as HTMLInputElement | null;
                  if (confirmation && e.nativeEvent.target !== confirmation)
                    confirmation.checked = false;
                }}
              >
                <fieldset disabled={busy || blocked || exporting}>
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Expense date
                    </span>
                    <DateInput
                      name="expense_date"
                      required
                      min="1900-01-01"
                      max={today()}
                      defaultValue={today()}
                    />
                  </label>
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Expense amount (ZMW)
                    </span>
                    <input
                      name="amount"
                      required
                      inputMode="decimal"
                      pattern="[0-9]{1,9}(\.[0-9]{1,2})?"
                      placeholder="0.00"
                    />
                  </label>
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Category
                    </span>
                    <input name="category" required maxLength={120} />
                  </label>
                  <label>
                    Payee
                    <input name="payee" maxLength={120} />
                  </label>
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Description / purpose
                    </span>
                    <textarea
                      name="description"
                      required
                      minLength={5}
                      maxLength={500}
                    />
                  </label>
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Payment method
                    </span>
                    <select
                      name="payment_method"
                      required
                      aria-label="Payment method"
                    >
                      <option value="">Select method</option>
                      {Object.entries(paymentMethods).map(([key, label]) => (
                        <option value={key} key={key}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    External reference
                    <input name="external_reference" maxLength={120} />
                  </label>
                  <label className="import-confirm">
                    <RequiredMark />
                    <input type="checkbox" name="confirm" required />I approve
                    this paid expense and confirm its amount and date.
                  </label>
                  <button className="button primary" disabled={busy}>
                    {busy ? "Saving…" : "Post approved expense"}
                  </button>
                </fieldset>
              </Form>
            </section>
          )}
          <section className="panel settings-panel">
            <h2>Expense history</h2>
            <button
              type="button"
              className="text-button"
              disabled={busy || exporting || loading}
              onClick={() => setRevision((v) => v + 1)}
            >
              Reload expenses
            </button>
            <p className="form-hint">
              Posted expenses and reversals remain visible. Recording some
              expenses does not certify a complete expense ledger or enable Net
              Profit.
            </p>
            <Form
              onSubmit={(e) => {
                e.preventDefault();
                setFilters({
                  ...draft,
                  currency: draft.currency.toUpperCase(),
                });
                setPage(0);
              }}
            >
              <fieldset disabled={exporting || busy} className="report-filters">
                <label>
                  <span className="field-label">
                    <RequiredMark />
                    Expense activity from
                  </span>
                  <DateInput
                    required
                    value={draft.from}
                    onChange={(e) =>
                      setDraft({ ...draft, from: e.target.value })
                    }
                  />
                </label>
                <label>
                  <span className="field-label">
                    <RequiredMark />
                    Expense activity to
                  </span>
                  <DateInput
                    required
                    value={draft.to}
                    onChange={(e) => setDraft({ ...draft, to: e.target.value })}
                  />
                </label>
                <label>
                  <span className="field-label">
                    <RequiredMark />
                    Expense currency
                  </span>
                  <input
                    required
                    pattern="[A-Za-z]{3}"
                    maxLength={3}
                    value={draft.currency}
                    onChange={(e) =>
                      setDraft({
                        ...draft,
                        currency: e.target.value.toUpperCase(),
                      })
                    }
                  />
                </label>
                <label>
                  Search expenses
                  <input
                    type="search"
                    value={draft.search}
                    onChange={(e) =>
                      setDraft({ ...draft, search: e.target.value })
                    }
                  />
                </label>
                <label>
                  Expense category
                  <input
                    value={draft.category}
                    onChange={(e) =>
                      setDraft({ ...draft, category: e.target.value })
                    }
                    placeholder="All categories"
                  />
                </label>
                <label>
                  Expense status
                  <select
                    value={draft.status}
                    onChange={(e) =>
                      setDraft({
                        ...draft,
                        status: e.target.value as ExpenseFilters["status"],
                      })
                    }
                  >
                    <option value="">All</option>
                    <option>Posted</option>
                    <option>Reversed</option>
                  </select>
                </label>
                <button className="button secondary">
                  Apply expense filters
                </button>
              </fieldset>
            </Form>
            <p className="form-hint">
              Activity {filters.from} to {filters.to}, inclusive ·{" "}
              {filters.currency} · Africa/Lusaka. Includes payments and
              reversals effective in this period. {report?.items.length ?? "—"}{" "}
              matching expenses; exports include all pages.
            </p>
            {changed && (
              <p role="status">Apply filter changes before exporting.</p>
            )}
            {loading && <p role="status">Loading expenses…</p>}
            {(loadError || computed.error) && (
              <p role="alert">{loadError || computed.error}</p>
            )}
            {report && (
              <>
                <p aria-label="Expense period totals">
                  Paid in period: {fmt(report.paid)} · Reversed in period:{" "}
                  {fmt(report.reversed)} · Net expenses in period:{" "}
                  {fmt(report.net)}
                </p>
                {canExport && (
                  <div className="modal-actions">
                    {(["excel", "pdf", "print"] as const).map((kind) => (
                      <button
                        key={kind}
                        className="button secondary"
                        disabled={changed || exporting || busy}
                        onClick={() => void exportExpenses(kind)}
                      >
                        {kind === "excel"
                          ? "Export Expenses to Excel"
                          : kind === "pdf"
                            ? "Export Expenses to PDF"
                            : "Print Expenses"}
                      </button>
                    ))}
                  </div>
                )}
                {exporting && <p role="status">Preparing expense report…</p>}
                <div className="table-scroll">
                  <table>
                    <thead>
                      <tr>
                        <th>Reference / date</th>
                        <th>Category / payee</th>
                        <th>Original amount</th>
                        <th>Net expense in period</th>
                        <th>Creator / status</th>
                        {admin && <th>Approval</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map(({ expense: r, net }) => (
                        <tr key={r.id}>
                          <td>
                            {r.expense_reference}
                            <small>Effective: {r.expense_date}</small>
                            <small>
                              Recorded: {formatBusinessTimestamp(r.created_at)}
                            </small>
                          </td>
                          <td>
                            {r.category}
                            <small>
                              {r.payee ?? "—"} · {r.description}
                            </small>
                          </td>
                          <td>{fmt(r.amount_cents)}</td>
                          <td>{fmt(net)}</td>
                          <td>
                            {r.reversed_at ? "Reversed" : "Posted"}
                            <small>{r.created_by}</small>
                            {r.reversed_at && (
                              <small>
                                {r.reversal_reason} · {r.reversed_by}
                                <br />
                                Reversed:{" "}
                                {formatBusinessTimestamp(r.reversed_at)}
                              </small>
                            )}
                          </td>
                          {admin && (
                            <td>
                              <button
                                className="text-button"
                                disabled={busy || !!r.reversed_at}
                                onClick={() => {
                                  setSelected(r);
                                  setReason("");
                                  setApprove(false);
                                }}
                              >
                                Reverse expense
                              </button>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {!rows.length && (
                  <p className="empty-state">
                    No expenses match these filters.
                  </p>
                )}
                <div className="report-pagination">
                  <button
                    className="button secondary"
                    disabled={!page || busy}
                    onClick={() => setPage((p) => p - 1)}
                  >
                    Previous page
                  </button>
                  <span>Page {page + 1}</span>
                  <button
                    className="button secondary"
                    disabled={!more || busy}
                    onClick={() => setPage((p) => p + 1)}
                  >
                    Next page
                  </button>
                </div>
              </>
            )}
          </section>
          {selected && (
            <section className="panel settings-panel">
              <h2>Approve expense reversal · {selected.expense_reference}</h2>
              <Form onSubmit={reverse}>
                <label>
                  <span className="field-label">
                    <RequiredMark />
                    Reversal reason
                  </span>
                  <textarea
                    required
                    minLength={5}
                    maxLength={500}
                    value={reason}
                    onChange={(e) => {
                      setReason(e.target.value);
                      setApprove(false);
                    }}
                  />
                </label>
                <label className="import-confirm">
                  <RequiredMark />
                  <input
                    type="checkbox"
                    required
                    checked={approve}
                    onChange={(e) => setApprove(e.target.checked)}
                  />
                  I approve reversing this expense; the original remains in the
                  audit history.
                </label>
                <button className="button primary" disabled={busy || !approve}>
                  Confirm expense reversal
                </button>
                <button
                  className="button secondary"
                  type="button"
                  disabled={busy}
                  onClick={() => setSelected(null)}
                >
                  Cancel reversal
                </button>
              </Form>
            </section>
          )}
        </>
      )}
      {printReport && (
        <ExpensePrint
          report={printReport}
          onClose={() => setPrintReport(null)}
          verify={verifyExport}
        />
      )}
      {error && (
        <p className="notice error" role="alert">
          {error}
        </p>
      )}
      {message && (
        <p className="notice" role="status">
          {message}
        </p>
      )}
    </main>
  );
}
