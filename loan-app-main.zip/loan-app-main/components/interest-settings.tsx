"use client";
import { formatBusinessTimestamp } from "@/lib/business-time";
import { Form, RequiredMark } from "./form-controls";
import { hasCapability } from "@/lib/access";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { WorkspaceNavigation } from "./workspace-navigation";
import { AuditHistory } from "./audit-history";
import { useSupabase, useWorkspaceBase } from "@/lib/workspace-context";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import { rateBps } from "@/lib/interest";
export function InterestSettings() {
  const supabase = useSupabase();
  const workspaceBase = useWorkspaceBase();
  const defaults = useLoanDefaults();
  const [rate, setRate] = useState("");
  const [days, setDays] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  useEffect(() => {
    if (defaults.value) {
      setRate(String(defaults.value.settings.default_rate_bps / 100));
      setDays(String(defaults.value.settings.default_term_days));
      setReason("");
    }
  }, [defaults.value?.settings.owner_id, defaults.value?.settings.revision]);
  async function save(event: React.FormEvent) {
    event.preventDefault();
    if (
      !supabase ||
      !defaults.value ||
      !hasCapability(defaults.value.capabilities, "can_manage_settings")
    )
      return;
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const settings = {
        ...defaults.value.settings,
        default_rate_bps: rateBps(rate),
        default_term_days: Number(days),
      };
      const { error } = await supabase.rpc("save_interest_settings", {
        p_settings: settings,
        p_expected_revision: defaults.value.settings.revision,
        p_reason: reason,
      });
      if (error) throw error;
      setMessage("Defaults updated. Existing loans are unchanged.");
      await defaults.reload();
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : ((e as { message?: string }).message ?? "Could not save settings."),
      );
    } finally {
      setBusy(false);
    }
  }
  const permitted =
    !supabase ||
    hasCapability(defaults.value?.capabilities, "can_view_settings");
  return (
    <main
      className="settings-page standalone-page"
      id="workspace-content"
      tabIndex={-1}
    >
      <WorkspaceNavigation
        current="Settings"
        capabilities={defaults.value?.capabilities}
        demo={!supabase}
        standalone
        pending={busy}
      />
      {(!supabase ||
        hasCapability(defaults.value?.capabilities, "can_view_dashboard")) && (
        <Link
          className="text-button"
          href={`${workspaceBase}/`}
          prefetch={false}
        >
          <ArrowLeft size={15} />
          Back to workspace
        </Link>
      )}
      <div className="page-heading">
        <div>
          <div className="eyebrow">ADMINISTRATION</div>
          <h1>Interest settings</h1>
          <p>
            Defaults for future loans. Actual terms are saved on every loan.
          </p>
        </div>
        <ShieldCheck size={27} />
      </div>
      {defaults.loading ? (
        <p role="status">Checking administrator access…</p>
      ) : !permitted ? (
        <div className="notice error" role="alert">
          Administrator access required. Sign in with an administrator account.
        </div>
      ) : (
        <section className="panel settings-panel">
          {!supabase && (
            <p className="demo-note">
              Read-only sample settings. Connect Supabase and provision an
              administrator to edit real defaults.
            </p>
          )}
          <p className="mode-explanation">
            <b>One-time flat interest for the entire loan term.</b>
            <br />
            Interest = Amount Disbursed × rate ÷ 100
            <br />
            Total obligation = Amount Disbursed + interest
          </p>
          <Form onSubmit={save}>
            <fieldset
              disabled={
                busy ||
                !supabase ||
                !hasCapability(
                  defaults.value?.capabilities,
                  "can_manage_settings",
                )
              }
              className="import-fields"
            >
              <div className="form-row">
                <label>
                  <span className="field-label">
                    <RequiredMark />
                    Default interest rate for entire term (%)
                  </span>
                  <input
                    inputMode="decimal"
                    required
                    value={rate}
                    onChange={(e) => setRate(e.target.value)}
                  />
                </label>
                <label>
                  <span className="field-label">
                    <RequiredMark />
                    Default loan term (days)
                  </span>
                  <input
                    type="number"
                    min={1}
                    max={3650}
                    step={1}
                    required
                    value={days}
                    onChange={(e) => setDays(e.target.value)}
                  />
                </label>
              </div>
              <label>
                Interest calculation method
                <input readOnly value="One-time flat interest" />
              </label>
              <label>
                Rate basis
                <input readOnly value="Entire loan term" />
              </label>
              <div className="form-row">
                <label>
                  Currency
                  <input readOnly value="ZMW" />
                </label>
                <label>
                  Rounding rules
                  <input
                    readOnly
                    value="Half up to 2 decimal places (nearest ngwee)"
                  />
                </label>
              </div>
              <label>
                Business timezone
                <input readOnly value="Africa/Lusaka" />
              </label>
              <p className="form-hint">
                This release supports the values shown for method, basis,
                currency, rounding, and timezone. Unsupported values are
                rejected by the database. Changes affect future loans only.
              </p>
              {hasCapability(
                defaults.value?.capabilities,
                "can_manage_settings",
              ) && (
                <label>
                  <span className="field-label">
                    <RequiredMark />
                    Settings change reason
                  </span>
                  <input
                    required
                    minLength={5}
                    maxLength={500}
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                  />
                </label>
              )}
              {hasCapability(
                defaults.value?.capabilities,
                "can_manage_settings",
              ) && (
                <button className="button primary">
                  {busy ? "Saving…" : "Save future defaults"}
                </button>
              )}
            </fieldset>
          </Form>
          <button
            className="text-button"
            disabled={busy}
            onClick={() => void defaults.reload()}
          >
            Reload current defaults (discards edits)
          </button>
          {defaults.value && (
            <p className="form-hint">
              Revision {defaults.value.settings.revision} · Updated{" "}
              {formatBusinessTimestamp(defaults.value.settings.updated_at)}
            </p>
          )}
          {hasCapability(defaults.value?.capabilities, "can_view_audit") && (
            <AuditHistory
              source="settings_audit"
              title="Settings audit trail"
              revision={defaults.value?.settings.revision}
            />
          )}
        </section>
      )}
      {(error || defaults.error) && (
        <p role="alert" className="form-error">
          {error || defaults.error}
        </p>
      )}
      {message && (
        <p role="status" className="notice success">
          {message}
        </p>
      )}
    </main>
  );
}
