"use client";
import { useEffect, type ReactNode } from "react";
import { useVerifiedAccessSnapshot } from "@/lib/use-verified-access";
import { LoanDefaultsProvider } from "@/lib/use-loan-defaults";
import type { Capability } from "@/lib/access";
import { AccessDenied } from "./access-denied";
import { PublicShell } from "./public-shell";
export function AccessGate({
  children,
  requireBusiness = true,
  capability = "can_read",
}: {
  children: ReactNode;
  requireBusiness?: boolean;
  capability?: Capability;
}) {
  const snapshot = useVerifiedAccessSnapshot(requireBusiness, capability);
  const state = snapshot.state;
  const refreshing = snapshot.loading || snapshot.refreshing;
  useEffect(() => {
    // SessionBoundary owns an in-progress logout and its explanation. Avoid
    // replacing its inactivity/sign-out URL with a second anonymous redirect.
    if (
      state === "signed-out" &&
      document.documentElement.dataset.sessionLocked !== "true"
    )
      window.location.replace(
        "/login?next=" +
          encodeURIComponent(
            window.location.pathname +
              window.location.search +
              window.location.hash,
          ),
      );
  }, [state]);
  if (state === "allowed")
    return (
      <>
        {refreshing && (
          <p role="status" className="notice access-refresh">
            Checking your business permissions… Existing content is read-only
            until verification completes.
          </p>
        )}
        <div aria-busy={refreshing} inert={refreshing}>
          <LoanDefaultsProvider
            value={{
              value: snapshot.value,
              loading: refreshing,
              error: snapshot.error,
              reload: snapshot.reload,
            }}
          >
            {children}
          </LoanDefaultsProvider>
        </div>
      </>
    );
  if (state === "denied")
    return (
      <PublicShell authenticated>
        <AccessDenied standalone capabilities={snapshot.value?.capabilities} />
      </PublicShell>
    );
  return (
    <PublicShell>
      <section className="auth-card access-card">
        <h1>
          {state === "pending"
            ? "Business access pending"
            : state === "unavailable"
              ? "Business sign-in is not configured"
              : state === "error"
                ? "We couldn't verify your access"
                : "Checking your access…"}
        </h1>
        <p>
          {state === "pending"
            ? "Your account does not have an active business role. Ask an Administrator to assign or restore your access. Signing up does not grant access to existing Client records."
            : state === "unavailable"
              ? "Configure the application's Supabase public settings to use the business workspace. You can explore the fictional demo without an account."
              : state === "error"
                ? "Check your connection and try again. Your records and pending transaction references are retained."
                : "Verifying your sign-in before opening the workspace."}
        </p>
        {state === "error" && (
          <button
            className="button primary"
            onClick={() => window.location.reload()}
          >
            Retry access check
          </button>
        )}
        {state === "pending" && (
          <>
            <a className="text-button" href="/security">
              Account security
            </a>
            <button
              className="button secondary"
              onClick={() => window.location.assign("/login")}
            >
              Log in with another account
            </button>
          </>
        )}
        {state === "checking" && <p role="status">Please wait…</p>}
        <a className="text-button" href="/">
          Back to home
        </a>
      </section>
    </PublicShell>
  );
}
