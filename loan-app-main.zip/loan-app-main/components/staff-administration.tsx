"use client";
import { Form, RequiredMark } from "./form-controls";
import { hasCapability } from "@/lib/access";
import { useEffect, useRef, useState } from "react";
import { WorkspaceNavigation } from "./workspace-navigation";
import { useSupabase } from "@/lib/workspace-context";
import { useLoanDefaults } from "@/lib/use-loan-defaults";
import {
  permissionModules,
  permissionActions,
  roleLabels,
  rolePermissions,
  type BusinessRole,
  type UserPermissions,
} from "@/lib/permissions";
type UserRole = {
  user_id: string;
  role: BusinessRole;
  is_active: boolean;
  revision: number;
  permissions: UserPermissions;
  updated_at: string;
  assigned_by: string | null;
};
export function StaffAdministration() {
  const db = useSupabase(),
    defaults = useLoanDefaults();
  const readable = hasCapability(
      defaults.value?.capabilities,
      "can_view_users",
    ),
    writable = hasCapability(defaults.value?.capabilities, "can_manage_users");
  const [rows, setRows] = useState<UserRole[]>([]),
    [loading, setLoading] = useState(true),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [message, setMessage] = useState("");
  const [selectedRevision, setSelectedRevision] = useState(0);
  const [user, setUser] = useState(""),
    [role, setRole] = useState<BusinessRole>("viewer"),
    [active, setActive] = useState(true),
    [permissions, setPermissions] = useState<UserPermissions>(() =>
      rolePermissions("viewer"),
    ),
    [reason, setReason] = useState(""),
    [confirm, setConfirm] = useState(false);
  const generation = useRef(0),
    request = useRef<{ payload: string; id: string } | null>(null),
    heading = useRef<HTMLHeadingElement>(null);
  async function load() {
    if (!db || !readable) return;
    const expected = ++generation.current;
    setLoading(true);
    try {
      const all: UserRole[] = [];
      for (let n = 0; ; n += 1000) {
        const r = await db
          .from("user_roles")
          .select("*")
          .order("user_id")
          .range(n, n + 999);
        if (r.error) throw new Error("Could not load business users.");
        all.push(...r.data);
        if (r.data.length < 1000) break;
      }
      if (expected === generation.current) setRows(all);
    } finally {
      if (expected === generation.current) setLoading(false);
    }
  }
  useEffect(() => {
    setRows([]);
    if (readable)
      void load().catch(() =>
        setError("Could not load business users. Try Reload users."),
      );
    return () => {
      generation.current++;
    };
  }, [readable, defaults.value?.settings.owner_id]);
  function changed() {
    setConfirm(false);
    setError("");
    setMessage("");
  }
  function selectUser(id: string) {
    changed();
    setUser(id);
    setReason("");
    const row = rows.find((r) => r.user_id === id.trim().toLowerCase());
    setSelectedRevision(row?.revision ?? 0);
    setRole(row?.role ?? "viewer");
    setActive(row?.is_active ?? true);
    setPermissions(row?.permissions ?? rolePermissions(row?.role ?? "viewer"));
  }
  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!db || !writable || busy) return;
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const body = {
        p_user_id: user.trim().toLowerCase(),
        p_role: role,
        p_is_active: active,
        p_permissions: permissions,
        p_expected_revision: selectedRevision,
        p_reason: reason.trim(),
        p_confirm: confirm,
      };
      const payload = JSON.stringify(body);
      if (request.current?.payload !== payload)
        request.current = { payload, id: crypto.randomUUID() };
      const result = await db.rpc("manage_user_access", {
        ...body,
        p_request_id: request.current.id,
      });
      if (result.error) throw result.error;
      setSelectedRevision(result.data.revision);
      await load();
      await defaults.reload();
      setReason("");
      setConfirm(false);
      setMessage("User access saved and audited.");
    } catch (failure) {
      setError(
        failure instanceof Error
          ? failure.message
          : ((failure as { message?: string }).message ??
              "Could not save user access."),
      );
    } finally {
      setBusy(false);
    }
  }
  const current = rows.find((r) => r.user_id === user.trim().toLowerCase());
  return (
    <main
      className="settings-page standalone-page"
      id="workspace-content"
      tabIndex={-1}
    >
      <WorkspaceNavigation
        current="User Management"
        capabilities={defaults.value?.capabilities}
        standalone
        pending={busy}
      />
      <div className="page-heading">
        <div>
          <div className="eyebrow">ADMINISTRATION</div>
          <h1>User Management</h1>
          <p>Review module access and approve sensitive actions separately.</p>
        </div>
      </div>
      {!readable ? (
        <p role="alert" className="notice error">
          User Management access is required.
        </p>
      ) : (
        <>
          {writable && (
            <section className="panel settings-panel">
              <h2 ref={heading} tabIndex={-1}>
                {current ? "Edit User" : "Add User"}
              </h2>
              <p className="form-hint">
                Register or invite the person through Supabase Auth first, then
                assign their Auth user ID here. Signup alone grants no business
                access. Viewing a module does not authorize posting or
                administration. Role eligibility still limits sensitive actions.
              </p>
              <Form onSubmit={submit}>
                <fieldset
                  className="user-access-fields"
                  disabled={busy || loading}
                >
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Auth user ID
                    </span>
                    <input
                      required
                      pattern="[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
                      value={user}
                      onChange={(e) => selectUser(e.target.value)}
                    />
                  </label>
                  <label>
                    Business role
                    <select
                      value={role}
                      onChange={(e) => {
                        changed();
                        const next = e.target.value as BusinessRole;
                        setRole(next);
                        const eligible = rolePermissions(next);
                        setPermissions(
                          (p) =>
                            Object.fromEntries(
                              Object.entries(p).map(([key, value]) => [
                                key,
                                key.startsWith("view_")
                                  ? value
                                  : value &&
                                    (["imports", "delete_clients"].includes(
                                      key,
                                    ) ||
                                      eligible[key as keyof UserPermissions]),
                              ]),
                            ) as UserPermissions,
                        );
                      }}
                    >
                      {Object.entries(roleLabels).map(([value, label]) => (
                        <option key={value} value={value}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      role="switch"
                      checked={active}
                      onChange={(e) => {
                        changed();
                        setActive(e.target.checked);
                      }}
                    />
                    Active user
                  </label>
                  <fieldset className="permission-grid">
                    <legend>Module access — view</legend>
                    {permissionModules.map(([key, label]) => (
                      <label className="checkbox-label" key={key}>
                        <input
                          type="checkbox"
                          checked={permissions[key]}
                          onChange={(e) => {
                            changed();
                            setPermissions((p) => ({
                              ...p,
                              [key]: e.target.checked,
                            }));
                          }}
                        />
                        View {label}
                      </label>
                    ))}
                  </fieldset>
                  <fieldset className="permission-grid">
                    <legend>Sensitive actions</legend>
                    {permissionActions.map(([key, label]) => (
                      <label className="checkbox-label" key={key}>
                        <input
                          type="checkbox"
                          checked={permissions[key]}
                          disabled={
                            !(
                              ["imports", "delete_clients"].includes(key) ||
                              rolePermissions(role)[key]
                            )
                          }
                          onChange={(e) => {
                            changed();
                            setPermissions((p) => ({
                              ...p,
                              [key]: e.target.checked,
                            }));
                          }}
                        />
                        {label}
                        {!(
                          ["imports", "delete_clients"].includes(key) ||
                          rolePermissions(role)[key]
                        ) && (
                          <span className="form-hint">
                            {" "}
                            — requires an eligible role
                          </span>
                        )}
                      </label>
                    ))}
                  </fieldset>
                  <p className="form-hint">
                    Posting requires its related module. Imports require Imports
                    and Clients views; loan imports additionally require
                    origination. Deletion requires a separate grant and is
                    blocked by retained financial/import records or a retention
                    hold. Authorized Client corrections can archive a Client.
                  </p>
                  <button
                    type="button"
                    className="button secondary"
                    onClick={() => {
                      changed();
                      setPermissions(rolePermissions(role));
                    }}
                  >
                    Use role defaults
                  </button>
                  <label>
                    <span className="field-label">
                      <RequiredMark />
                      Permission change reason
                    </span>
                    <textarea
                      required
                      minLength={5}
                      maxLength={500}
                      value={reason}
                      onChange={(e) => {
                        changed();
                        setReason(e.target.value);
                      }}
                    />
                  </label>
                  <label className="checkbox-label">
                    <RequiredMark />
                    <input
                      type="checkbox"
                      required
                      checked={confirm}
                      onChange={(e) => setConfirm(e.target.checked)}
                    />
                    I approve this user's role, module access and sensitive
                    actions.
                  </label>
                  <button className="button primary" disabled={!confirm}>
                    {busy ? "Saving…" : "Save approved access"}
                  </button>
                </fieldset>
              </Form>
            </section>
          )}
          <section className="panel settings-panel">
            <h2>Business users</h2>
            <button
              type="button"
              className="text-button"
              disabled={busy || loading}
              onClick={() =>
                void load().catch(() => setError("Could not reload users."))
              }
            >
              Reload users
            </button>
            {loading ? (
              <p role="status">Loading business users…</p>
            ) : (
              <>
                <div
                  className="table-scroll"
                  tabIndex={0}
                  role="region"
                  aria-label="Business users table"
                >
                  <table>
                    <thead>
                      <tr>
                        <th>Auth user ID</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Revision</th>
                        {writable && <th>Actions</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((row) => (
                        <tr key={row.user_id}>
                          <td>{row.user_id}</td>
                          <td>{roleLabels[row.role]}</td>
                          <td>{row.is_active ? "Active" : "Inactive"}</td>
                          <td>{row.revision}</td>
                          {writable && (
                            <td>
                              <button
                                type="button"
                                className="text-button"
                                disabled={busy}
                                aria-label={`Edit user ${row.user_id}`}
                                onClick={() => {
                                  selectUser(row.user_id);
                                  heading.current?.focus();
                                  heading.current?.scrollIntoView({
                                    block: "start",
                                  });
                                }}
                              >
                                Edit User
                              </button>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {!rows.length && <p>No business users found.</p>}
              </>
            )}
          </section>
        </>
      )}
      {error && (
        <p className="notice error" role="alert">
          {error}
        </p>
      )}
      {message && (
        <p className="notice success" role="status">
          {message}
        </p>
      )}
    </main>
  );
}
