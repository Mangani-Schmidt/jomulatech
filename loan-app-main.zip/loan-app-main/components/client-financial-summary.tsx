import { type Loan, type Repayment, isPosted } from "@/lib/domain";
import { clientLabels } from "@/lib/ui-labels";
export function ClientFinancialSummary({
  clientId,
  loans,
  repayments,
  unavailable = false,
  refreshing = false,
  onRetry,
}: {
  clientId: string;
  loans: Loan[];
  repayments: Repayment[];
  unavailable?: boolean;
  refreshing?: boolean;
  onRetry?: () => void;
}) {
  if (unavailable)
    return (
      <section className="client-summary" aria-label="Client financial summary">
        <h3>Client Financial Summary</h3>
        <p role={refreshing ? "status" : "alert"}>
          {refreshing
            ? "Refreshing Client financial summary…"
            : "Client financial summary unavailable. No balance or loan count is shown until the ledger can be loaded."}
        </p>
        {onRetry && (
          <button
            type="button"
            className="button secondary"
            disabled={refreshing}
            onClick={onRetry}
          >
            Retry Client financial summary
          </button>
        )}
      </section>
    );
  const related = loans.filter((l) => l.client_id === clientId),
    currencies = [...new Set(related.map((l) => l.currency ?? "ZMW"))];
  function amount(values: number[], currency: string) {
    const value = values.reduce((s, n) => s + BigInt(n), 0n);
    if (value > BigInt(Number.MAX_SAFE_INTEGER))
      return "Use a narrower report to display this amount.";
    return new Intl.NumberFormat("en-ZM", {
      style: "currency",
      currency,
    }).format(Number(value) / 100);
  }
  return (
    <section className="client-summary" aria-label="Client financial summary">
      <h3>Client Financial Summary</h3>
      <p className="form-hint">
        All recorded disbursements · Current unpaid obligations, including
        written-off balances · Posted interest received
      </p>
      {!currencies.length ? (
        <p>No loans recorded for this Client.</p>
      ) : (
        currencies.map((currency) => {
          const group = related.filter(
              (l) => (l.currency ?? "ZMW") === currency,
            ),
            ids = new Set(group.map((l) => l.id)),
            payments = repayments.filter(
              (r) => ids.has(r.loan_id) && isPosted(r),
            );
          return (
            <div key={currency}>
              <h3>{currency}</h3>
              <dl>
                <div>
                  <dt>{clientLabels.totalDisbursed}</dt>
                  <dd>
                    {amount(
                      group.map((l) => l.principal_cents),
                      currency,
                    )}
                  </dd>
                </div>
                <div>
                  <dt>{clientLabels.outstanding}</dt>
                  <dd>
                    {amount(
                      group.map((l) => l.balance_cents),
                      currency,
                    )}
                  </dd>
                </div>
                <div>
                  <dt>{clientLabels.interestIncome}</dt>
                  <dd>
                    {amount(
                      payments.map((r) => r.interest_allocation_cents ?? 0),
                      currency,
                    )}
                  </dd>
                </div>
              </dl>
              {payments.some((r) => r.metadata_inferred) && (
                <p className="form-hint">
                  Historic interest allocations marked inferred remain subject
                  to their recorded limitations.
                </p>
              )}
            </div>
          );
        })
      )}
    </section>
  );
}

export function ClientBalance({
  clientId,
  loans,
}: {
  clientId: string;
  loans: Loan[];
}) {
  const related = loans.filter((l) => l.client_id === clientId);
  const currencies = [...new Set(related.map((l) => l.currency ?? "ZMW"))];
  if (!currencies.length) return <>No loans</>;
  return (
    <>
      {currencies.map((currency) => {
        const total = related
          .filter((l) => (l.currency ?? "ZMW") === currency)
          .reduce((sum, l) => sum + BigInt(l.balance_cents), 0n);
        return (
          <div key={currency}>
            {total > BigInt(Number.MAX_SAFE_INTEGER)
              ? "Use a narrower report."
              : new Intl.NumberFormat("en-ZM", {
                  style: "currency",
                  currency,
                }).format(Number(total) / 100)}
          </div>
        );
      })}
    </>
  );
}
