"use client";
import { useEffect, useRef, type ReactNode } from "react";
export function FinancialReview({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => {
    heading.current?.focus();
  }, []);
  return (
    <section className="financial-review" aria-label={title}>
      <h3 ref={heading} tabIndex={-1}>
        {title}
      </h3>
      <p>
        Review this financial summary before posting. Go back to change any
        details.
      </p>
      {children}
    </section>
  );
}
