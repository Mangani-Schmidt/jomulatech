"use client";
import {
  reportMoney,
  reportAmountLabels,
  type FinancialReport,
  type ReportAmounts,
} from "@/lib/reporting";
const primary = ["disbursed", "received", "owed", "interestReceived"] as const;
const labels = {
  disbursed: "Amount Disbursed",
  received: "Repayment Received",
  owed: "Clients still owe",
  interestReceived: "Interest collected",
};
export function BusinessPerformance({
  report,
  detailed,
  canLoans,
  canRepayments,
  canExpenses,
}: {
  report: FinancialReport;
  detailed: boolean;
  canLoans: boolean;
  canRepayments: boolean;
  canExpenses: boolean;
}) {
  const f = report.filters;
  const money = (n: number) => reportMoney(n, f.currency);
  const result = report.netProfit ?? report.recordedResult;
  const final = report.netProfit !== null;
  const profit = (detailed || (canLoans && canRepayments)) && canExpenses && (
    <section
      className={`performance-profit ${result !== null && result < 0 ? "is-loss" : ""}`}
      aria-label="Profit and expenses"
    >
      <div className="performance-heading">
        <h2>
          {final
            ? result! > 0
              ? "Profit this period"
              : result! < 0
                ? "Loss this period"
                : "Break-even this period"
            : "Result from recorded entries"}
        </h2>
        <span className="performance-badge">
          {final ? "Costs reviewed" : "Review costs to finalize profit"}
        </span>
      </div>
      <strong className="performance-result">
        {result === null
          ? "Not available"
          : money(final ? Math.abs(result) : result)}
      </strong>
      {!detailed && (
        <p className="profit-equation">
          Interest {money(report.totals.interestReceived)} − expenses{" "}
          {report.expenses === null ? "unavailable" : money(report.expenses)} −
          loan losses {money(report.totals.recognizedLoss)}.
        </p>
      )}
      <details className="profit-calculation" open={detailed || undefined}>
        <summary>See how this was calculated</summary>
        <dl>
          <div>
            <dt>Interest collected</dt>
            <dd>{money(report.totals.interestReceived)}</dd>
          </div>
          <div>
            <dt>Expenses</dt>
            <dd data-expense-total>
              {report.expenses === null
                ? report.expenseScope === "unallocated"
                  ? "Business-wide only"
                  : "Unavailable"
                : money(report.expenses)}
            </dd>
          </div>
          <div>
            <dt>Loan losses</dt>
            <dd>{money(report.totals.recognizedLoss)}</dd>
          </div>
        </dl>
        <p>Interest collected − expenses − loan losses.</p>
        {!final && (
          <p>
            {report.expenseScope === "unallocated"
              ? "Clear Client and loan filters to see the business-wide result. Shared costs are not split between Clients."
              : report.expenses === null
                ? "Expense records are unavailable for this view. They have not been counted as zero."
                : "An authorized Administrator must confirm this period’s costs are complete before this becomes final profit or loss."}
          </p>
        )}
        <p className="performance-footnote">
          Original loan money returned is not profit. Loan losses are original
          loan money written off, after reversals.
        </p>
      </details>
    </section>
  );
  return (
    <div className={`business-performance ${detailed ? "is-detailed" : ""}`}>
      {!detailed && profit}
      <h2>Business performance</h2>
      <div
        className="report-metrics performance-primary"
        aria-label="Filtered financial totals"
      >
        {primary
          .filter(
            (k) =>
              detailed ||
              (k === "disbursed" || k === "owed" ? canLoans : canRepayments),
          )
          .map((k) => (
            <article
              className="stat-card featured-metric"
              data-metric={k}
              key={k}
            >
              <span>{labels[k]}</span>
              <strong>{money(report.totals[k])}</strong>
              <small className={k === "owed" ? "metric-period" : "sr-only"}>
                {k === "owed"
                  ? `Balance · end of ${f.asOf}`
                  : `Activity · ${f.from} to ${f.to}`}
              </small>
              <small>
                {
                  {
                    disbursed: "Money lent to Clients.",
                    received: "Includes the original loan money and interest.",
                    owed: "Includes unpaid interest and written-off obligations.",
                    interestReceived: "Income before costs, after reversals.",
                  }[k]
                }
              </small>
            </article>
          ))}
      </div>
      {detailed && profit}
      {(detailed || canLoans) && (
        <section className="performance-health" aria-label="Loans to follow up">
          <h2>Loans to follow up</h2>
          <p>Balances on {f.asOf}</p>
          <dl>
            <div>
              <dt>Overdue loans</dt>
              <dd>{report.overdueCount}</dd>
            </div>
            <div>
              <dt>Overdue balance</dt>
              <dd>{money(report.totals.overdue)}</dd>
            </div>
            <div>
              <dt>Unpaid interest</dt>
              <dd>{money(report.totals.interest)}</dd>
            </div>
          </dl>
        </section>
      )}
      {detailed && (
        <details className="performance-details">
          <summary>More financial details</summary>
          <p>
            Period activity uses {f.from} to {f.to}. Balances use {f.asOf}.
          </p>
          <div className="report-metrics">
            {(Object.keys(reportAmountLabels) as (keyof ReportAmounts)[])
              .filter((k) => !primary.includes(k as (typeof primary)[number]))
              .map((k) => (
                <article className="stat-card" key={k} data-metric={k}>
                  <span>{reportAmountLabels[k]}</span>
                  <strong>{money(report.totals[k])}</strong>
                </article>
              ))}
          </div>
        </details>
      )}
    </div>
  );
}
