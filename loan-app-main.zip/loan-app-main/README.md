# LendTrack

A responsive Next.js / TypeScript application for a lending business. Tailwind CSS styles the interface, Supabase Auth identifies users, and PostgreSQL owns financial integrity. ExcelJS (with its UUID dependency pinned to a patched release via npm overrides) handles `.xlsx` Client imports and reports. Deploy to Vercel.

## Implemented stages

1. **Repository inspection and foundation:** Next.js/TypeScript/Tailwind, locked dependencies, responsive navigation and a read-only fictional demo.
2. **Database, authentication and permissions:** sixteen migrations, Supabase Auth integration, shared business roles, RLS and protected PL/pgSQL operations.
3. **Client register and Man# lookup:** unique text Man#, explicit registration/selection, optional contacts and audited corrections preserving internal relationships.
4. **Excel preview and confirmation:** bounded server-side XLSX parsing, explicit register/disbursement modes, mapping, diagnostics, history and duplicate protection.
5. **Interest settings and loans:** future-only defaults, one-time flat interest, exact rounding, actual-term snapshots and multiple loans per Client.
6. **Repayments, receipts and adjustments:** interest-first allocation, transaction locks, idempotent receipts, statements, approved immutable reversals/adjustments/write-offs and expenses.
7. **Dashboard and reports:** period activity versus dated balances, per-Client summaries, effective-date history, currency isolation, filters, pagination, exports and print.
8. **Testing and deployment preparation:** domain/SQL/browser tests, real PostgreSQL concurrency and recovery exercises, CI, setup/deployment and backup/restoration guidance.

The [delivery record](docs/DELIVERY.md) lists source locations, checks and remaining work for each stage. The [operations runbook](docs/OPERATIONS.md) covers staging acceptance, Vercel release/rollback and backup/restoration. The owner manages the existing Vercel deployment. This change does not apply hosted migrations or alter service configuration; local verification does not establish production readiness. See the [audit remediation and upgrade guide](docs/AUDIT-REMEDIATION.md).

Staff share a business workspace using Administrator, Loan Officer, Cashier, or Viewer roles. A user belongs to one business; inactive and unassigned users cannot access business records. Database-controlled roles, RLS, and composite ownership keys isolate businesses. Currency is **ZMW**, stored as integer ngwee; business dates use **Africa/Lusaka**. New loans use a one-time flat percentage charge for the entire loan term. Loans are immediately issued. Due-today loans remain active until the next business day. These are explicit initial business rules, not configurable lending products.

## Local setup

The root `/` is a public LendTrack landing page with **Sign Up**, **Log In** and **Explore demo**. It contains no business records or financial metrics. There are no public dashboard shortcuts. Authenticated pages hide Explore Demo prompts. Login opens the permitted Dashboard or first accessible module. The business workspace is at `/dashboard`; an active business role is required before its components mount. Signup creates an Auth identity only; a trusted Administrator must assign business access. See [authentication and access](docs/AUTHENTICATION.md) for routes, security boundaries and hosted setup.

The [interface and branding guide](docs/DESIGN.md) describes the LendTrack theme, keyboard/touch behavior and compatibility safeguards for existing recovery keys and download links.

Click the **color-theme icon** in the public/workspace header or standalone navigation to open **Light / Dark / System**. The dropdown supports keyboard arrows, Home/End, Enter/Space, Escape, outside-click dismissal and touch. System follows the device by default; an explicit choice is remembered in this browser. Both themes apply to forms, reports, dialogs and sign-in. Printed documents stay light.

The dashboard shows four figures: Amount Disbursed, Outstanding Balance, Repayment Received and Interest Income Received. Each distinguishes period activity from balances at the selected date. Cards and quick actions follow the user's effective module/action grants; detailed totals and loan histories remain in Reports and Client Loan History. A failed summary request shows an unavailable state and retry action, never a zero balance. See [dashboard behavior and financial definitions](docs/DASHBOARD.md).

Navigation, direct screen access and financial actions use the capability flags returned by PostgreSQL. Unavailable actions are hidden; restricted direct navigation shows Access denied. A shared verified snapshot prevents permission-loading flashes across nested forms. Read-only staff retain the records, reports and exports permitted by the existing database policy. See [permission-based visibility and enforcement](docs/PERMISSIONS.md).

To try the application without an account, choose **Explore demo** or open `/demo`. The isolated demo works on a Supabase-connected deployment and includes an import walkthrough. Download the [dummy Excel workbook](public/samples/lendtrack-dummy-clients.xlsx) with 10 fictional Clients, or choose **Excel Imports → Download dummy Excel sheet**. See [the demo guide](docs/DEMO.md) for both import modes and exact example totals.

Use **Node.js 24** (`.nvmrc`) and npm for the tested setup. The package engine allows Node.js 22+, but other majors have not been separately verified. Dependencies are locked in `package-lock.json`.

```sh
cd /workspace/loan-app
npm ci
cp -n .env.example .env.local
npm run dev -- --hostname 127.0.0.1 --port 3000
```

The example has empty public values and starts the fictional read-only demo. `cp -n` preserves an existing environment file. If the machine restricts the default npm cache, use `npm ci --cache /tmp/loan-npm-cache`. To force the demo even when existing shell/file values select a project, use `NEXT_PUBLIC_SUPABASE_URL= NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY= npm run dev -- --hostname 127.0.0.1 --port 3000`.

To connect an explicitly selected development/staging project, create it in Supabase and apply `supabase/migrations/001_ledger.sql`, then `supabase/migrations/002_client_register.sql`, then `supabase/migrations/003_excel_import.sql`, then `supabase/migrations/004_interest_settings.sql`, then `supabase/migrations/005_loan_register.sql`, then `supabase/migrations/006_repayments.sql`, then `supabase/migrations/007_reporting.sql`, then `supabase/migrations/008_roles_and_expenses.sql`, then `supabase/migrations/009_financial_review_guards.sql`, then `supabase/migrations/010_reporting_coverage.sql`, then `supabase/migrations/011_administrator_assurance.sql`, then `supabase/migrations/012_client_man_lookup.sql`, then `supabase/migrations/013_user_permissions.sql`, then `supabase/migrations/014_inactivity_sessions.sql`, then `supabase/migrations/015_imports_and_client_lifecycle.sql`, then `supabase/migrations/016_fresh_session_status.sql`, in order, once each, in its SQL editor. Apply only unapplied migrations to existing ledgers. Migrations 002–016 include their own transactions; submit each entire file together. Submit migration 001 as one transaction if the chosen SQL client does not execute a multi-statement request atomically. A CLI workflow requires initializing its configuration and reconciling applied migration history first; this repository does not include an initialized Supabase CLI stack. Do not disable RLS.

Set these two **public** values in `.env.local`:

```dotenv
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

Use the project publishable key (or its legacy anon key), never the service-role or secret key. Project URLs on custom domains require adjusting `connect-src` in `next.config.ts`. No server-held Supabase credential is necessary.

In Supabase Authentication:

- Enable email/password login and email confirmation.
- Set the Site URL to the deployment origin. Allow the exact `https://YOUR_DOMAIN/login` signup-confirmation and `https://YOUR_DOMAIN/security` recovery URLs, plus intended local equivalents. The default email confirmation template confirms the account; users can then log in with their password.
- Set **Minimum password length = 6** in the email/password provider's password policy (Auth configuration field **`password_min_length: 6`**). Login, signup and password updates share this minimum in the application. Hosted policy was not readable or changeable in this environment; verify it explicitly. Preserve confirmation, rate limits, compromised-password protections and MFA. Use production SMTP for reliable emails. **Log In → Forgot password?** opens `/forgot-password`; the recovery email opens `/security` to update the password. Verify actual delivery and expired-link behavior on the hosted project.
- For a private business deployment, invite the intended account and disable new sign-ups in Supabase after onboarding. The registration UI respects the provider setting.

```sh
npm run dev -- --hostname 127.0.0.1 --port 3000
```

The public landing page appears with or without Supabase configuration. Without both environment values, authentication is unavailable; `/demo` offers isolated fictional data and cannot persist changes. With them configured, internal routes verify identity and active business access before showing records. Restart Next.js after changing public environment values. For a local production-mode check, stop development, then run:

```sh
npm run build
npm run start -- --hostname 127.0.0.1 --port 3000
```

Run `curl --fail --silent --output /dev/null http://127.0.0.1:3000` from another terminal to check availability; Ctrl-C stops the server. Public values are bundled during the build. The browser test runner builds a forced demo; rebuild with the intended project values after browser tests before starting a connected application. See [Operations](docs/OPERATIONS.md#local-startup-and-configuration) for the full setup sequence.

## User permissions and inactivity

Apply migrations **013** and **014** after 012 before using this release. The [upgrade/session guide](docs/SESSIONS.md#upgrade-the-existing-deployment) gives the exact sequence and hosted checks. Existing access is preserved as explicit per-user grants. User Management and Audit Logs are separate, and sensitive actions require their own checkboxes and server authorization. Client deletion requires a separate explicit grant and retention checks under migration 015.

Signed-in sessions expire after **15 minutes of inactivity**, warn at 14 minutes, offer **Stay Signed In**, synchronize across tabs, and recheck after suspension. Application RLS and posting functions enforce the server-clock session deadline; provider JWT validity for unrelated services is a separate limit. No hosted setting was changed. See [session behavior and limitations](docs/SESSIONS.md).

## Using the ledger

1. Have the first Administrator provisioned through the trusted SQL bootstrap below. Invite/register staff through Supabase Auth, confirm email, and assign an active business role before using real records.
2. Open **Clients → Add Client**. Enter Man#, full Client name, department, and designation. Phone, email, and address are optional. Active status defaults to active. Man# is text, preserving leading zeros; comparisons ignore letter case and surrounding spaces. PostgreSQL enforces uniqueness within the business workspace, including inactive Clients.
3. For imports, choose **Excel Imports**, download the six-column template, select **Client Register Import** or **Loan Disbursement Import** explicitly, and follow the preview/confirmation workflow described below. A spreadsheet never implicitly creates loans or repayments.
4. Choose **New Loan**, type a Man# (or Client name), and explicitly select a match. The Client name, department, and designation fill automatically; the loan uses the hidden internal `client_id`. Confirmation also binds to the reviewed Client revision; corrections require re-selection/review, while a retry of an already-created loan remains idempotent. Unmatched searches display “No client found” and do not create a Client. An Administrator or Loan Officer may choose **Add Client** to open a separate manual registration form. Only active Clients with complete register details can receive new loans. Current defaults prefill the entire-term rate and loan term. Enter **Amount Disbursed** and disbursement date, review the one-time interest charge, total obligation, and calculated due date, then choose **Review Loan**, check the confirmation, and choose **Confirm Loan**. Rates differing from the current default require permission and a recorded reason. Existing terms can be changed only through the explicit audited administrator adjustment described below.
5. Choose **Record Repayment Received**, or the arrow beside a loan. Choose **Review Repayment**, verify the financial summary, check the confirmation, and choose **Confirm Repayment Received**. Overpayments, zero/negative payments, and cross-account operations are rejected in PostgreSQL.
6. Open **Reports**, select an activity period and balance date, apply filters, then download the matching CSV/Excel report or preview the printable report. Reports include sensitive Client details. Spreadsheet text is written as text cells, and CSV fields are protected against formula injection.

The same Client can have multiple independent loans. Amount Disbursed (principal) and interest are each capped at ZMW 999,999,999.99. Payments reduce outstanding interest first, then principal. Authorized receipt reversals/corrections, loan term adjustments, and write-off reversals are audited. Installments, penalties, accruals, and physical refunds are not implemented. Do not manually modify production balances.

## Client corrections and existing records

Man# is entered manually, preserving leading zeros. Duplicate previews offer **Open existing Client Details** without overwriting the record; a fresh exact server lookup and the database unique constraint protect saving. Apply migration **012_client_man_lookup.sql** to an existing 011 project before using these saves. See [manual Man# and existing Clients](docs/CLIENT-REGISTER.md) for rules, permissions, race handling and deployment steps.

Open **Clients → Client Details**. Authorized correction access means an active Administrator or Loan Officer in that business. Review the internal Client ID, creator, creation/update timestamps, and audit trail. Make corrections, provide a 5–500 character reason, then choose **Save audited correction**. The database locks the Client row, checks the expected revision, and writes the changes and a before/after audit entry in one transaction. Actor IDs are Supabase Auth user IDs. Creation and correction entries cannot be changed/deleted through the API. If a newer revision exists, use **Reload latest details (discards edits)** and review it before resubmitting.

Changing Man# does not change `clients.id` or `loans.client_id`. Old values remain in the audit history. Migration 009 rejects control characters in new/updated Man# values, including direct API writes. Legacy control-bearing records are preserved for explicit audited correction, never silently merged. Man# uniqueness applies to current register values per business workspace; a released old Man# can be assigned to another Client. No aliases or extra Clients are automatically created. Inactive Clients retain their records, loans, and repayment capability, but cannot receive new loans.

Migration 002 preserves all existing IDs and records. Legacy Clients without Man#/department/designation remain visible and are marked as incomplete. Their missing fields must be completed through the audited correction form before a new loan can be created. Required-field constraints are `NOT VALID` only to preserve those legacy rows; they still reject every new or updated incomplete row. After all legacy rows have been completed, an administrator may run `ALTER TABLE public.clients VALIDATE CONSTRAINT clients_register_required;`. Legacy creators are inferred from the existing ledger owner, creation timestamps are retained, and baseline audit entries identify the migration with a null actor instead of inventing a historical correction.

Spreadsheet imports now use `no#`, `name`, `man#`, `department`, `designation`, `amount`. Replace earlier three/seven-column templates with the downloadable template. Reports include Man#, department, and designation alongside the internal loan ID. The demo remains read-only; correction details and sample history can be inspected, while saving requires an assigned Administrator or Loan Officer on a configured Supabase project.

## Excel imports

Apply migration **003_excel_import.sql** before using this stage. It adds private `import_batches`/`import_rows` history, immutable completed results, and a loan disbursement date/import reference. It also revokes authenticated access to the old immediate `import_clients` RPC. Client IDs and existing loans are preserved; existing loan disbursement dates are inferred from their original creation dates in Africa/Lusaka. No existing loan balance, principal, or interest changes during migration/import. Migration 004 subsequently requires the one-time flat method for all new loans and adds actual-term snapshots and administrator-only adjustments.

### Columns and mapping

Download **Clients → Import .xlsx → Download Excel template**. The template includes an example row which must be replaced or removed, and an instruction worksheet. The **first worksheet** contains:

| Column        | Meaning                                                                             |
| ------------- | ----------------------------------------------------------------------------------- |
| `no#`         | Positive source row number for traceability; never a Client ID or relationship key. |
| `name`        | Full Client name, 2–120 characters.                                                 |
| `man#`        | Client register match key, 1–50 text characters, preserving leading zeros.          |
| `department`  | Required department, up to 120 characters.                                          |
| `designation` | Required designation, up to 120 characters.                                         |
| `amount`      | Ignored in register mode; Amount Disbursed in ZMW in disbursement mode.             |

Standard headers match without regard to letter case or column order. For nonstandard/ambiguous headers, map all six fields explicitly to distinct physical source columns. An ambiguous duplicate header is never silently selected. Extra source columns are ignored. Limits: `.xlsx` only; 2 MB compressed; 500 data rows; 30 source columns; 1,000 ZIP entries; 20 MB total expanded content. Requests are bounded before parsing. ExcelJS parses the workbook on the **server**, after Supabase verifies the bearer token. ZIP entry streams are checked with yauzl before ExcelJS loads them. Formulas in identity/source fields are rejected without evaluating them; formula amounts are rejected in loan mode and ignored in register mode. Server-side PostgreSQL validation remains authoritative even when the browser is bypassed.

Use Excel **Text** format for Man#. Text values retain all zeros. Numeric Man# cells always generate a warning because original leading zeros cannot be recovered reliably. Simple numeric zero-pad display formats such as `00000` are preserved where available, but still require review. Numeric values beyond Excel’s reliable 15-digit integer precision, fractional or negative numeric Man# values are rejected. Verify against an authoritative source and re-upload a text Man# if uncertain; the software does not guess missing zeros or merge different Man# values.

### Explicit modes and confirmation

**Client Register Import** creates missing Client details only. The `amount` column is ignored, including blank/nonmonetary values, and no loans, repayments, or opening balances are created. An exact existing Client match is **unchanged**; existing Client contact details and active status are retained. Newly imported Clients default to active, with optional contact/address fields empty.

**Loan Disbursement Import** creates or matches Clients and creates a new loan per accepted row **only after confirmation**. Supply a real disbursement date (1900 through today), a one-time flat percentage of principal for the entire loan term (0–100%, up to two decimal places), prefilled from current defaults, and the explicit **days after disbursement** due-date rule (1–3650 days). A zero rate is allowed; if it differs from the default it requires the same override authorization and reason. Interest is added once and rounded to the nearest ngwee. Historical disbursements and their calculated past due dates are supported. The spreadsheet amount is the positive **Amount Disbursed** (principal) with up to two decimals; it is never treated as a repayment or opening balance. Terms are saved in the batch history and displayed again for confirmation. Loans store the disbursement date and batch reference.

Both modes match only the signed-in account’s local `clients` table by case-insensitive Man# (surrounding spaces trimmed). Client name, department, and designation must match exactly after trimming; differences are rejected as conflicts. Use the audited Client correction workflow first. Imports never silently update Client details, reactivate inactive Clients, or modify existing loans. Inactive Clients cannot receive new loans. Every occurrence of a repeated Man# within one workbook is rejected, even if the rows are identical, to avoid accidental duplicate disbursements.

Preview stages rows and diagnostics in private import history; it creates no Clients, loans, or repayments. Review every row, all warnings, and the **accepted / rejected / unchanged** counts. Download the error/validation workbook before or after saving; it includes physical Excel row, original `no#`, mapped data, outcome, errors, warnings, and resulting IDs. Excel text is written as text, not executable formulas.

Confirmation applies accepted rows atomically, skips rejected rows, and records unchanged matches without modifying Clients. If every row is rejected, resolve errors and preview again; that batch cannot be completed. A Client change since preview or a competing Client creation aborts the entire confirmation, including new Clients, audit entries, and loans. Generate and review a new preview before retrying. Confirmation counts are never silently recalculated. Draft re-previews increment a version, invalidating older confirmation requests.

### History and duplicate submissions

Import history lists previews and completed batches, uploader Auth user ID, upload/completion timestamps, mode, terms, counts, and per-row results. History is paginated, 20 batches per page. Use **View result** to reopen a report or resume an unchanged staged preview; use **Download error / validation report** to export diagnostics.

Database locks and batch IDs make retries of confirmation idempotent. A semantic fingerprint plus full payload equality detects the same mode, Client/amount rows, and terms even if the filename, source numbering, row order, or decimal formatting changes. A completed duplicate returns the original result and creates nothing. Identical Client/amount/date/term combinations are deliberately treated as the same batch; use the explicit manual loan workflow for a genuinely separate identical loan. For a partially accepted completed batch, create a workbook containing **only its rejected rows**, resolve their conflicts/errors, and preview that new subset. Do not re-submit accepted rows. An all-rejected draft remains available for corrected re-preview. Only the file hash, staged mapped rows/diagnostics, and batch metadata are stored; the original workbook binary is not retained. Completed rows/results have no direct write/delete grants. Re-previewing the same unfinished semantic batch replaces its draft diagnostics, rather than fabricating another completed attempt.

### Future existing-Man# database integration

Spreadsheet parsing is independent of any external Man# database. **No external Man# connection, credentials, background synchronization, or automatic creation from a search exists.** The integration point is a server-only resolver in `app/api/imports/preview/route.ts`, after `mappedRows(...)` and before `preview_import`. A future adapter can look up verified employment records by text Man# and add explicit discrepancies to the staged preview. It must never cast identifiers to numbers, bypass the local Client ownership/audit rules, or write loans. `classify_import_row` remains the database boundary for matching local Clients and rejecting conflicts; adapting a resolver must preserve the mandatory preview and confirmation contract. API/UI import parsing should remain unchanged when a connector is added.

## Interest settings and administrator permissions

New Loan prefills the current Settings rate. Users with the database's `can_override_rate` capability can edit it for that loan and must record a 5–500 character reason when it differs from the default. **Use default rate** restores only the rate and clears the override reason; it preserves the selected Client, amount, term and date. The review shows the actual rate, one-time flat method, entire-term basis, interest charge and total obligation. See [default and per-loan rates](docs/LOAN-RATES.md) for validation, saved terms and stale-default handling.

Apply **004_interest_settings.sql** to an existing project with migrations 001–003. It adds `account_permissions`, `ledger_settings`, `settings_audit`, and `loan_terms_audit`, and snapshots actual terms on loans. It does not change existing charges or balances. The deprecated fixed-charge `create_loan` RPC and unguarded version-3 import functions cannot be executed by authenticated/anonymous API users.

### Provision the first Administrator

Migration 008 retires `account_permissions` as live authority. It preserves existing explicitly provisioned Administrators in `user_roles`; other legacy ledger owners become Viewers pending a trusted role assignment. Existing businesses/records are never silently merged. New Auth accounts are unassigned and cannot create their own business or self-promote. Auth `user_metadata`/role claims cannot grant business permissions.

For a **new business**, or to promote the known owner of its existing ledger, a trusted Supabase database administrator runs this transaction in the SQL editor. Replace the email with the intended **existing, confirmed Auth account**. It refuses to move a user already belonging to another business:

```sql
begin;
do $$
declare v_user uuid;
begin
 select id into v_user from auth.users where email = 'administrator@example.com';
 if v_user is null then raise exception 'Auth user not found'; end if;
 if exists(select 1 from public.user_roles where user_id=v_user and owner_id<>v_user) then
   raise exception 'User already belongs to another business; review membership instead of bootstrapping';
 end if;
 insert into public.businesses(id,name) values(v_user,'Lendtrack') on conflict(id) do nothing;
 insert into public.ledger_settings(owner_id) values(v_user) on conflict(owner_id) do nothing;
 perform set_config('app.role_reason','Trusted first Administrator provisioning',true);
 insert into public.user_roles(user_id,owner_id,role,is_active,permissions,assigned_by)
 values(v_user,v_user,'administrator',true,public.role_permissions('administrator'),v_user)
 on conflict(user_id) do update set role='administrator',is_active=true,permissions=public.role_permissions('administrator'),
   revision=public.user_roles.revision+1,assigned_by=v_user,updated_at=clock_timestamp();
end $$;
commit;
```

Sign in/reload after provisioning. In **User Management** (`/users`), authorized Administrators add existing Auth identities, edit their saved module/action checkboxes and activate/deactivate members. **Audit Logs** (`/audit-logs`) separately provides the searchable, paginated unified audit history. `/administration` redirects to `/users`. See [User Management and permission dependencies](docs/PERMISSIONS.md). The signed-in user's Auth ID appears in the workspace. Auth registration/invitations, provider password policies, account disabling and trusted account recovery remain in Supabase Auth's dashboard; in-app password recovery and authenticator setup are available at `/security`; the app never receives a service-role key. An invitation or signup alone grants no business access.

Role changes require a reason, current revision, explicit approval, and an idempotency key. Users cannot disable/demote their own Administrator role, and the API refuses to transfer identities between businesses. Use a fresh staff Auth identity when joining a business; migrating records/memberships between established legacy businesses requires a separately reviewed trusted database migration. Deactivation immediately blocks subsequent server operations and RLS reads; it does not terminate an in-flight transaction already holding the membership lock. Refresh/sign in again to update the visible controls. SQL bootstrap is trusted administration, not a public RPC.

These role presets preserve existing access during migration 013. An authorized Administrator may explicitly narrow grants; role ceilings and MFA still govern sensitive actions.

| Role              | Preset business actions                                                                                                                                                                                                                                 |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Administrator** | Users/roles, settings, imports, Client registration/corrections, origination/rate overrides, repayments/receipts, approved reversals/corrections/term adjustments/write-offs, expenses and expense reversals, reports, and all business records/audits. |
| **Loan Officer**  | Read permitted business data/reports; register/correct Clients with audited reasons; originate loans at current defaults. No imports, rate overrides, repayments, or financial adjustments.                                                             |
| **Cashier**       | Read permitted business data/reports; post Repayment Received and print receipts. No Client registration, origination, imports, or reversals/financial adjustments.                                                                                     |
| **Viewer**        | Read permitted business reports, statements, loan/repayment histories, and expense history. No writes.                                                                                                                                                  |

Business access does not grant access to another business. Module views, including saved import history, user lists and Audit Logs, can be granted separately; importing, changing permissions, settings changes and financial approvals remain eligible-Administrator actions. Private request details require adjustment approval access. Source Client/loan/receipt audit histories remain readable in permitted record histories. Existing `can_override_rate` flags in the retired table no longer authorize overrides; this release reserves them to Administrators.

### Defaults

Users with Settings view can open `/settings`; changes require authorized Administrator settings access. A view grant alone is read-only; loan forms can read their own ledger’s defaults to prefill origination. With no Supabase project, the Settings route displays only read-only sample values.

Initial defaults are **10% for the entire loan term** and **30 days**. Review them before lending. Administrators can change either at any time with a reason. Rates are stored as integer basis points (12.34% = 1,234); supported range is 0–100%, with two percentage decimal places. Terms are 1–3650 days. This release supports only:

- Calculation method: **one-time flat interest**.
- Rate basis: **entire loan term**.
- Currency: **ZMW**.
- Rounding: **half up to two decimal places**, to the nearest ngwee.
- Business timezone: **Africa/Lusaka**.

Method, basis, currency, rounding, and timezone appear as read-only supported settings; unsupported values are rejected in PostgreSQL. The rate is not multiplied by the number of months or compounded. For principal ZMW 1,000 and a 10% entire-term rate, interest is ZMW 100 and the total obligation is ZMW 1,100, whether the agreed term is 30 or 60 days.

Changing defaults writes a before/after audit entry with actor, reason, and timestamp. It never updates existing loans. Settings use revisions and row locks: stale saves require reloading, and a loan/import staged under an old revision must be reviewed again. Users with Audit Logs access can also inspect the Settings page's searchable, cursor-paginated immutable audit history without a 100-entry cutoff.

### Creating loans and overrides

Manual loans and disbursement imports prefill current rate and term defaults. Review **Amount Disbursed, one-time interest charge, and total obligation** before checking confirmation. Interest is calculated exactly using integer basis points and PostgreSQL numeric half-up rounding; the browser uses equivalent integer arithmetic. Due date is disbursement date plus term days.

`originate_loan` requires a current settings revision, explicit supported method/basis, a request ID, and confirmation. The server calculates charges rather than trusting browser totals. Actual rate, method, rate basis, term, currency, rounding, timezone, original default rate, original settings revision, disbursement/due dates, and override reason are saved on the loan. Creation is idempotent for retries with the same request ID and identical payload. Review the ledger after an ambiguous failure before starting a new form/payment intent.

An Administrator may choose a different rate, including zero, with a 5–500 character reason. Other users’ rate fields are read-only; bypassing the interface is still rejected in PostgreSQL. Imports use the same permission/reason and current-revision checks, and show Amount Disbursed, calculated interest, and total obligation per accepted row before confirmation. A permission revoked after preview is rechecked at confirmation.

### Existing loans and audited adjustments

Open **Client Loan History → Terms & audit** to inspect actual terms and history. Only an administrator of that business sees **Authorized adjustment**. Enter the new entire-term percentage and term, supply a 5–500 character reason, review the new interest/obligation/due date, and explicitly confirm. The `adjust_loan_terms` operation locks that loan, checks its terms revision, records before/after terms and actor, and updates the outstanding amount to **new obligation minus posted, non-reversed Repayment Received** in one transaction. Repayments lock the same loan row, so adjustments cannot race a payment into an inconsistent balance. An obligation below Repayment Received already recorded is rejected; this stage does not implement refunds. Principal, Client ID, original disbursement, original settings snapshot, and receipt history remain unchanged. Adjustment request IDs prevent replay; audit records cannot be changed/deleted through the API.

Historical loans keep their original actual charges. A recorded percentage from an earlier flat-rate import is retained. Where an older fixed charge has no reliable recorded rate, migration 004 labels it `legacy_fixed_charge` with no inferred percentage and creates a baseline audit entry. An administrator may explicitly convert it to supported one-time flat terms through the audited adjustment workflow; it is never silently converted by changing defaults. Reports export the actual terms of each loan.

## Loan register and lifecycle

Apply **005_loan_register.sql** after migrations 001–004. It adds stable, globally unique references such as `LN-00000001`, creator/update metadata, stored lifecycle state, write-off metadata, and an immutable status audit. References are database-assigned, cannot be edited, and may have gaps after rolled-back transactions. They identify loans; Client relationships continue to use `client_id`, so correcting Man# never changes loan history. There is no one-loan-per-Client restriction: every loan has its own reference, terms, due date, balance, and receipt history.

**Amount Disbursed** is money actually given to a Client, stored as `loans.principal_cents` and exposed as `amount_disbursed_cents` in the register view. This release records completed disbursements, not approvals, limits, or future promises. **Repayment Received** is money collected, stored separately as `repayments.amount_cents`, always against an internal loan ID. Neither write-offs nor changes to interest defaults create receipts.

The loan register stores/exposes:

| Field                                 | Storage                                                                       |
| ------------------------------------- | ----------------------------------------------------------------------------- |
| Unique loan reference / internal ID   | `loan_reference` / `id`                                                       |
| Client relationship                   | `client_id`                                                                   |
| Amount Disbursed                      | `principal_cents` (integer ngwee)                                             |
| Disbursement date                     | `disbursement_date`                                                           |
| Actual interest rate / method / basis | `interest_rate_bps`, `calculation_method`, `rate_basis`                       |
| One-time interest charge              | `interest_cents`                                                              |
| Total repayment obligation            | Generated `total_obligation_cents` = Amount Disbursed + interest              |
| Due date / currency                   | `due_date` / `currency`                                                       |
| Stored lifecycle / current status     | `lifecycle_status` / `loan_register.status`                                   |
| Creator / timestamps                  | `created_by`, `created_at`, `updated_by`, `updated_at`                        |
| Write-off decision                    | `written_off_cents`, `written_off_by`, `written_off_at`, `written_off_reason` |

Amount Disbursed must be positive, at most ZMW 999,999,999.99, with up to two decimals. New loans require an owned, active, complete Client, supported actual terms/rates/currency, a confirmed obligation, and a real disbursement date from 1900 through the current Africa/Lusaka business date. New due dates must equal disbursement date plus a supported positive term (1–3650 days), so they are strictly after disbursement. Historical imports are allowed and may be immediately overdue. PostgreSQL validates these rules and assigns creator/reference/timestamps; browser checks are only assistance. Identifiers, Amount Disbursed, creator, original disbursement, and original settings metadata cannot be edited. Existing zero-day legacy dates are retained if originally consistent; new zero-day terms are not supported.

### Status rules

Status priority is Written off, then Settled, then Overdue, then Active:

| Status          | Exact rule                                                                                                                                                         |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Active**      | Not written off, with a positive outstanding amount, and due today or later. Partial Repayment Received does not settle the loan.                                  |
| **Overdue**     | Not written off, with a positive outstanding amount, and due date strictly before the current business date. There is no automatic penalty or automatic write-off. |
| **Settled**     | Not written off, with zero outstanding amount against the current total obligation. Full Repayment Received or an explicitly audited adjustment can settle it.     |
| **Written off** | An administrator explicitly closed a positive unpaid balance, with a reason and confirmation. This takes priority even when its due date has passed.               |

`loans.lifecycle_status` persists Active/Settled/Written off (machine values `active`, `settled`, `written_off`). **Overdue is a date-derived current status**, not a stored flag that can become stale overnight. Query the RLS-preserving, invoker-security **`loan_register` view** for the current four-state `status`; it reads the business date at query time. No nightly scheduler is required. The browser checks the business date every minute and when a tab becomes visible. The API/dashboard/report use the same rules. Automatic overnight aging does not invent an audit event or change loan timestamps.

Recorded lifecycle transitions—origination, settlement, authorized reopening, and write-off—are saved in `loan_status_audit` with actor, timestamps, before/after status and record snapshots, and reason. A settled loan can reopen only if an explicit administrator terms adjustment creates an additional obligation; it then becomes Active or Overdue according to its due date. This preserves the earlier audited-adjustment feature rather than treating a new charge as Repayment Received.

### Explicit write-off

Open the correct **loan reference → Terms & audit → Write off loan**. Only an administrator of the business workspace sees this action. Review the unpaid amount, enter a 5–500 character reason, and explicitly confirm. `write_off_loan` locks that loan and verifies its current balance and terms revision. If a receipt or adjustment changed them after opening the form, reload and confirm the current balance. The operation is idempotent for the same request and payload and records an immutable status decision.

A write-off **preserves** Amount Disbursed, interest, total obligation, unpaid balance, and all Repayment Received history. `written_off_cents` snapshots the unpaid amount; it is not a cash receipt or a reduction of the original disbursement. Written-off balances are excluded from collectible dashboard/Client balances and active counts and are reported separately. Reports retain the full original obligation and written-off balance. No Client’s other loans are changed.

Written-off loans are closed to new receipts and term adjustments until an administrator explicitly reverses the write-off with a reason and confirmation, as added in migration 006. Reopening changes collectibility only; it does not create cash, a receipt, or a refund. Retrying an already recorded receipt safely returns that existing receipt even after write-off, without adding money. A settled loan has no unpaid balance to write off. Merely becoming overdue never initiates a write-off.

Migration 005 preserves all internal IDs, existing financial amounts, and original creation dates. Where an original actor exists in the origination audit or import history, it is retained as creator. Otherwise the original ledger owner is used and explicitly flagged `creator_inferred`; no historical actor is fabricated. The latest known receipt/adjustment timestamp supplies historical `updated_at`. Baseline status audit entries identify the migration with a null actor. New records always use the authenticated creator and database timestamps.

## Repayments, reversals, adjustments, and printing

Apply **006_repayments.sql** after migrations 001–005. The app reads the RLS-preserving `repayment_register` view and uses the richer `post_repayment` RPC. The old `record_repayment` API accepts only safe retries of already-recorded legacy receipts; it cannot post a new transaction without the required metadata.

### Posting Repayment Received

Choose **Record Repayment Received**, select the exact loan reference, and enter:

- Payment date, from the loan’s disbursement date through the current Africa/Lusaka business date.
- Positive Amount Received, with up to two decimals, not exceeding current outstanding.
- Payment method: Cash, Bank transfer, Mobile money, Card, or Other.
- Optional external reference, at most 120 characters.

Review the **interest allocation, principal allocation, and outstanding after posting** before confirming. Every receipt stores a unique database-assigned `PAY-00000001` reference, internal loan ID, payment date, original amount, both allocations, method, external reference, creator, creation/update timestamps, terms revision at posting, immutable Client/loan document snapshot, and allocation policy. References can have gaps; they never replace internal relationship IDs.

**Interest-first policy:** at posting time, use current audited loan terms and all non-reversed receipts. Allocate `min(Amount Received, outstanding interest)` to interest and the remainder to principal. Partial payments are supported; the exact remaining total settles the loan. Amounts beyond the current balance are rejected with an explanation of the received and outstanding ZMW amounts. The allocated amounts always sum to the full receipt.

Allocation uses a database posting sequence, not payment-date order. Backdated dates remain visible but never rewrite previously posted allocations. Reversing an earlier receipt restores **its own** interest/principal allocations; it does not redistribute later receipts. The next receipt pays the restored outstanding interest first. Thus some principal can already be paid while restored interest remains outstanding, with a fully traceable history.

All posting/reversal/correction/write-off operations acquire request-key locks and the loan row lock in a consistent order. The server checks current balance, terms revision, and both allocation balances before accepting the reviewed posting. Migration 009 also checks every effective historical allocation boundary: valid backdating remains supported, but a receipt that would allocate more interest/principal than existed on any earlier date rolls back with a clear error. This guard does not rewrite legacy receipts. Competing or stale requests must reload; they cannot overpay. The receipt, balance change, lifecycle event, audit entries, and idempotency result commit or roll back together.

The `financial_operations` ledger has a unique `(owner_id, request_id)`. Retrying the same operation with identical payload returns its original result, including after later reversals; reusing the key for a different operation/payload is rejected. Repayment, replacement receipt, loan and expense forms persist only an opaque original request reference before sending; reviewed payloads stay in memory. Reloading/reopening shows recovery before another posting. **Recover pending transaction** checks the original server result. If no posted result exists after a reload, re-enter and review in the original module; the same request UUID and operation are reused and PostgreSQL binds/reconciles the payload. Uncertain outcomes and re-entry failures retain the reference. Storage failure prevents sending. Do not discard a pending reference or switch devices to enter the transaction again without reconciliation. Logout/session changes clear in-memory forms and redact legacy persisted payloads. No passwords or financial form contents are saved by posting recovery. See [sessions and recovery](docs/SESSIONS.md). Posted external references additionally must be unique, case-insensitively, within the business and payment method. Splitting one provider transaction across several loans is not supported by this stage; use separately traceable provider references. Reversing a receipt releases its external reference for a linked replacement.

### Authorized reversals and adjustments

Cashiers and Administrators may post payments in their business workspace but cannot delete or edit posted transactions. Only Administrators may use **Receipt & audit → Authorized reversal** or **Correct posted payment**, with an explicit confirmation and a 5–500 character reason. Direct financial updates/deletes are denied; the repayment trigger also protects original amounts, allocations, date, method, external reference, Client snapshot, creator, and timestamps from ordinary editing.

- **Reverse posted payment:** retain the original receipt/reference and mark it Reversed with actor, time, reason, and request ID. Restore its allocations and outstanding balance. A previously settled loan reopens as Active or Overdue. No physical cash refund or negative receipt is fabricated.
- **Correct posted payment:** atomically reverse the erroneous receipt and post a new reference linked through `replaces_repayment_id`, on the **same loan**. Enter the corrected date/amount/method/reference and review its new allocation. If replacement validation fails, the reversal and every intermediate balance/audit change roll back. The original and all replacement-chain entries remain visible.
- **Loan terms adjustment:** still requires administrator authorization, reason, expected terms revision, and confirmation. Calculations exclude reversed receipts. Interest cannot be reduced below already-posted interest allocations; correct/reverse affected receipts before repricing. Principal remains immutable, and obligations below posted funds are rejected.
- **Write off / reverse write-off:** the administrator decision is retained in status history. Before reversing or correcting a receipt on a written-off loan, use **Terms & audit → Reverse write-off**, confirm the exact original write-off decision, and provide a reason. This reopens the unpaid loan without changing amounts or creating a receipt. A later actual recovery is recorded separately as Repayment Received. Retrying the original write-off request after reversal remains inert; it cannot reapply the old decision.

All original and reversed receipts remain visible in Repayment history, receipts, statements, and audit history. Original amounts/allocations remain shown on reversed rows, alongside **zero net effect**. Dashboard collection totals, loan balances, allocation balances, loan exports, and Client statement totals use only **posted, non-reversed** receipts. Audit records include before/after transaction snapshots, actor, reason, request ID, and timestamp.

### Printable receipts and Client statements

Open **Repayments → Receipt & audit → Print receipt**. The receipt includes the payment and loan references, Client/Man#, payment date, original amount, allocations, method, optional external reference, creator/timestamps, original post-payment balance, and reversal/replacement details. Client identity is captured at posting; later Client corrections do not rewrite an original receipt. A reversed receipt is prominently marked **REVERSED** and shows zero financial effect while preserving its original recorded values.

Open **Clients → Client Statement → Print Client Statement** for all loans, their current actual obligations/statuses, every posted and reversed receipt, net Repayment Received, collectible/written-off balances, and reasons/actors/times for reversals, term adjustments, and write-off decisions. There is no invented historical running balance for records whose original terms were not recorded. Statement data is assembled in one database statement snapshot. Print documents are refreshed before printing, styled for A4 with repeating table headers, and can be saved as PDF through the browser. No document is emailed, uploaded, or sent to another person automatically.

### Existing receipt migration

Migration 006 preserves original receipt IDs, amounts, timestamps, and loan balances. Old receipts did not record allocations, method, or actual payment date: their allocations are explicitly **inferred** in original posting order against the current recorded obligation, method is `not_recorded`, payment date derives from posting date, creator derives from the original ledger owner, and Client details are captured at migration. Baseline audit entries and printed notes identify these limitations. New payments require actual metadata and have `metadata_inferred = false`. An inconsistent legacy balance aborts migration for reconciliation; it is never silently repaired. Historical write-off request identities are retained so a replay cannot resurrect a reversed write-off.

## Dashboard and reports

Apply **007_reporting.sql** after migrations 001–006. The application now uses migration 010’s `report_source_filtered(jsonb)` to select matching Clients, loans, receipts, and their term/status/receipt audits in **one PostgreSQL statement snapshot**; the original `report_source()` remains for compatibility. It uses invoker permissions, RLS, and an explicit account predicate on every source. Anonymous execution is denied. It does not add/change financial records or introduce a privileged key. `lib/reporting.ts` builds the same report object used for displayed totals, pagination, CSV/Excel, and print. No export reruns a broader unfiltered ledger query. The legacy loan-list Excel export also respects its displayed Client/reference search and status filter.

### Dates and historical balances

**Activity from/to** are inclusive business dates; **Balances as of** is the end of that Africa/Lusaka date. Require activity start ≤ activity end ≤ balance date ≤ today. A loan disbursed before the activity period still contributes its unpaid balance. Optional **Disbursed from/to** fields explicitly restrict the loan cohort; status is calculated as of the balance date. Department/designation filters and Client identity reflect the **current** register, rather than invented historical employment details. Search accepts Man#, Client name, or loan reference. Each report selects exactly one currency; no combined-currency total is produced. New loans still support ZMW only, while the report engine isolates any separately supported historical currency.

Historical reports are **restated effective-date reports**, not “what the system knew then.” A later-entered backdated payment changes earlier effective-date results, and the report identifies its source snapshot timestamp. Disbursements use disbursement date; ordinary repayments use payment date. A linked replacement receipt is an adjustment effective on its correction posting date alongside reversal of the original, rather than a second backdated cash receipt; its actual payment date remains visible in history. Reversals, term adjustments, write-offs, and write-off reversals use their recorded posting business date; this release does not allow backdating these decisions. Reversed receipts reduce income/collection activity **in the reversal period**, not the original receipt period. A later reversal does not remove an earlier receipt from an earlier balance. Original allocations remain unchanged. Original loan charges/due dates come from origination audit; adjustments apply from their effective date. Status uses the obligation, due date, and write-off decisions effective on the selected date. Settled/overdue status is reconstructed rather than copied from today's loan row.

Some legacy data predates complete auditing. Reporting refuses a period/balance before a migrated loan's first recorded terms baseline or an inferred receipt's migration baseline. It displays the earliest usable date and never presents inferred allocations as accurate earlier history. If a backdated receipt's allocation exceeds the terms effective on an earlier balance date, reporting explains the inconsistency and requires a later date or reconciliation instead of clamping or fabricating a bucket. The same error disables exports. Historical interest allocations before they were recorded cannot be recovered by software. Existing financial amounts are unchanged.

### Income, capital, and losses

The dashboard and per-Client/per-loan reports show:

- **Activity:** Amount Disbursed (principal), net Repayment Received, principal recovery, Interest Income Received, original expected interest on period disbursements, interest-charge adjustments, and recognized principal losses.
- **Dated balances:** outstanding principal, unpaid interest, total amount Clients owe, collectible balance, written-off balance, and overdue balance/count. Total owed preserves written-off contractual obligations; collectible and overdue totals exclude them.

**Principal repayments are capital recovery, never profit.** Expected interest is the original charge on loans disbursed during the period, not accrued/received income; rate adjustments appear separately. Unpaid interest is a dated balance. Interest Income Received is actual allocated interest receipts less reversals effective in the period and can be negative when prior-period receipts are reversed.

The reporting recognition policy is cash interest with principal impairment: a write-off recognizes the **unrecovered principal at the write-off posting**, using the original allocations effective at that posting; a write-off reversal recognizes the exact opposite principal loss in its period. The full written-off balance, including unpaid interest, is shown separately. Uncollected expected interest was never received income and is not counted as a principal loss. This is a defined operational report policy, not a full accrual accounting/general ledger system; review it for the business's accounting requirements.

**Migration 008 records actual paid business expenses.** The dashboard shows their net period effect only for an unfiltered business scope. Client/department/designation/status/loan-cohort filters show **Unallocated** instead of assigning shared costs to those Clients. When no expense entries exist for the currency, “Not recorded” remains explicit. Expense entries alone never certify coverage. Migration 010 lets an Administrator explicitly attest complete expenses **and recognized principal losses**, with a reason, for the exact period, currency and reviewed financial event revision. Only an unfiltered business report with an active matching certification displays **Net Profit = Interest Income Received − net paid expenses − recognized principal losses**. A certified zero-expense period is valid. Any subsequent loan, repayment, adjustment, reversal or expense event invalidates certification conservatively until re-review; revocations are immutable and audited. Filtered Client/cohort reports retain **Interest Income Received** and never allocate shared costs. Certification is a human reconciliation attestation under this operational cash-interest policy, not proof of complete external accounts.

### Filtering, exports, history, and pagination

Choose filters and select **Apply report filters**. Pending changes are identified and exports are disabled until applied. **By Client** aggregates only matching loans, including multiple loans per Client. **By loan** shows references, dated status/balances, and complete recorded loan histories with original receipts, allocations, reversals, linked replacements, term changes, reasons, actors, and dates. **Client Statement** deliberately opens the existing all-loan current statement, independent of historical report scope; the current scope is stated in the document.

Tables show ten rows per page, with counts, navigation, and an explicit empty state. **CSV**, **Excel**, and **Preview printable report** include **all matching pages** from the displayed snapshot. CSV exports either the Client or loan grouping; Excel includes filtered loans and a scope worksheet. Exports include dates, currency, applied filters, and the expense-coverage/loss policy. CSV fields are quoted and dangerous spreadsheet formula prefixes neutralized. Print preview includes scope, totals, all matching Clients and loans, and A4 print styling with repeating headers; browser Print/save PDF produces the report without workspace controls.

Reports filter search, department, designation, currency and disbursement dates on the server before returning histories; historical status is reconstructed from effective events. Grouped indexes replace repeated portfolio scans. Reports support up to 10,000 matching loans and 100,000 matching receipts, with explicit capacity errors instead of partial totals. Current registers use one consistent `ledger_snapshot()` and 20-row display pagination (up to 20,000 Clients, 20,000 loans and 100,000 receipts); delayed prior refreshes cannot replace newer results or another account’s data. Report tables retain 10-row pagination. JSON snapshots avoid ordinary API row truncation; exports include every matching page. Further growth requires measured hosted performance testing and server aggregation/streaming that retains historical correctness. Use **Refresh report snapshot** to load newly posted records from another session. Posted changes in this app refresh the reporting snapshot. Hosted multi-session/Supabase validation remains required before production.

## Database security and expenses

Apply **008_roles_and_expenses.sql** after migrations 001–007, as one transaction. It seeds a business for each existing ledger, maps trusted legacy Administrators and otherwise Viewer access, changes live membership authority to `user_roles`, and preserves existing Clients, loans, receipts, audit timestamps, amounts, and internal relationship IDs. `owner_id` now means the stable **business key**, while `created_by`, `updated_by`, `uploaded_by`, and audit actors identify the actual authenticated staff member. Never delete an Auth identity anchoring a business or referenced by financial history; deactivate access instead.

All monetary storage uses **exact PostgreSQL decimal types**. Existing `*_cents` columns become `numeric(14,0)` exact minor units, preserving the existing API and values. Loan/receipt views additionally expose `numeric(14,2)` major-unit projections such as `amount_disbursed`, `interest_charge`, `outstanding_amount`, `amount_received`, and allocation amounts. Expenses store `amount numeric(14,2)` and generate exact `amount_cents numeric(14,0)`. PL/pgSQL validates input precision/range **before** storage, calculates/rounds obligations and allocations, locks records, and posts atomically. Existing private integer helpers remain exact integer/numeric arithmetic; no `real`, `double precision`, or locale-dependent PostgreSQL `money` type is used. TypeScript performs only safe-integer previews/report projections and display formatting; submitted preview totals never authorize financial writes.

Every role mutation and financial/Client write requires a server-side capability check against active database membership. Role/identity fields supplied through signup metadata are ignored. Membership row locks serialize revocation against authorized in-flight operations; request locks and loan/receipt locks retain their financial atomicity guarantees. RLS guards workspace reads and permitted Client registration, and financial table insert/update/delete grants remain revoked. All security-definer functions have explicit authorization/ownership checks, restricted execution grants, and an empty `search_path`; old versioned entry points and private helpers remain uncallable by API users. The API also checks import capability after verifying Auth and **before** reading/parsing an upload. The downloadable empty template remains public.

The append-only **audit_events** index links Client identity, loan term/status, repayment, settings, role, import, and expense changes with reasons, actors, times, and before/after data. Historical source events are backfilled without changing their original timestamps/actors. Detailed existing source audits remain immutable. No application code logs Client identities, financial request payloads, Auth tokens, credentials, or audit contents. Audit records belong in the restricted database, not application logs; apply appropriate access, backups/PITR, retention, and hosted access monitoring.

### Expense register

Open **Expenses** (`/expenses`). Administrators record an actual paid expense: effective payment date, exact ZMW amount, category, purpose, payment method, optional payee and external reference, and explicit approval. Amounts are positive with at most two decimals, capped at ZMW 999,999,999.99; dates run from 1900 through the current business date. The database assigns an immutable `EXP-` reference, creator, timestamp, and idempotency record. Posted external references are unique within the business and payment method, case-insensitively. Original expense request references survive form remounts and reloads through the same pending-posting recovery workflow as repayments. Recover an uncertain result before another entry.

Only an Administrator may approve a reversal with a reason and confirmation. Original values remain visible; current net effect is zero, and the expense/audit cannot be ordinarily edited or deleted. Correct an expense by reversing it and posting the corrected record. Reversals use their business posting date in historical activity; they do not erase an earlier period's cost or fabricate a bank refund. Expense history is paginated and read-only for other active business roles. No Client allocation is stored or inferred.

## Interface and keyboard navigation

The shared navigation uses **Dashboard, Clients, New Loan, Repayments, Excel Imports, Reports, Settings** on the ledger, Settings, user administration, and expense pages. Role-protected items explain when they are unavailable; PostgreSQL permissions still enforce every operation. Administrator tools remain additional business navigation items. **New Loan** and **Excel Imports** have dedicated workspace views, while row/toolbar actions can open focused dialogs. Hash links such as `/#clients`, `/#new-loan`, and `/#excel-imports` support direct links and browser Back/Forward. The full portfolio remains available from **View all loans** and Client-scoped histories.

**Clients** opens the **Client Register**. Each row offers **Client Details, Client Statement, Client Loan History**. Search fields consistently say **Search by Man# or Client Name**; loan views also accept a reference. Client Details exposes **Total Amount Disbursed to Client, Client Outstanding Balance, Interest Income per Client**, with currency groups kept separate. These are all recorded disbursements, current unpaid obligations (including written-off balances), and posted interest receipts respectively. Principal recovery is not interest income. Report Client metrics use the same labels with their period/as-of scope. All active reading roles can inspect Client Details and audit history; only Administrators and Loan Officers receive correction controls.

Loan and repayment forms have separate **details → review → confirmation** steps. Review makes no posting request. It shows the Client/Man#, dates, actual terms or payment method, and the financial summary: loan principal/interest/obligation/due date, or Repayment Received/interest allocation/principal allocation/balance after posting. A final unchecked confirmation is required. **Back to Loan Details** / **Back to Repayment Details** preserve input, clear approval, and focus the amount field; edits require a new review. Busy states disable posting/navigation and show progress. Existing revision/balance checks and idempotency remain authoritative in PostgreSQL.

At mobile widths, **Open navigation** expands a two-column menu; Escape closes it and restores focus to the menu button. Desktop and tablet navigation stays within the sidebar, which can scroll on short screens. Focus indicators, a skip link, current-page announcements, labeled controls, keyboard Man# selection, focus on changed page/review headings, and native dialog focus restoration support keyboard use. Mobile sign-in/sign-out controls remain available. Financial supporting labels meet the tested 4.5:1 contrast threshold. Tables are keyboard-focusable and scroll within their containers, confirmation actions wrap, and loading/empty/error states remain explicit. The audit remediation requires migrations 009–011; manual Man# saving additionally requires migration 012. See the upgrade guides before using the new build.

## Tests and validation

See [validation and delivery](docs/VALIDATION.md) for requirement coverage, responsive/theme checks, exact commands and hosted verification limits.

Run the complete gate with **Node.js 24, local Docker, and Chromium**:

```sh
npm ci
# If system Chromium is absent:
npx playwright install --with-deps chromium
npm run verify
```

`verify` runs type generation/type checking, all Vitest tests, real PostgreSQL connection/locking tests, the production demo build/browser suite, and the authenticated browser contract suite. Failed prerequisites or assertions fail the command; concurrency checks are never silently skipped. The GitHub Actions workflow in `.github/workflows/test.yml` runs the same gate, with read-only repository permissions and no deployment/production credentials. Its remote CI run is separate from validation in this workspace.

Individual commands:

| Command                     | What it verifies                                                                                                                                                                                                                     |
| --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `npm test`                  | Domain/parser/API tests, versioned migration/upgrade tests, a fresh final-schema integration suite, and fixture safety. PostgreSQL runs in fresh in-memory PGlite databases.                                                         |
| `npm run test:postgres`     | Eleven real PostgreSQL tests and one backup/restoration drill against all sixteen migrations in fresh, digest-pinned PostgreSQL 17 containers. Requires the local Docker socket.                                                     |
| `npm run test:browser`      | Builds the app with both public Supabase values explicitly empty, starts/stops its own read-only production server on port 3000, and exercises Chromium. Stop an existing server on that port first; the runner refuses to reuse it. |
| `npm run test:browser:auth` | Starts/stops its own port-3002 Next dev server with a fake project/key and intercepted HTTP. Stop other Next dev processes in this checkout first.                                                                                   |
| `npm run typecheck`         | Generates Next route types, then checks TypeScript; it also works before a production build in a clean checkout.                                                                                                                     |
| `npm run build`             | Standard production build for the currently configured application environment.                                                                                                                                                      |
| `npm run sample:generate`   | Regenerates the fictional 10-Client XLSX from `lib/import-sample.json`; never connects to a database.                                                                                                                                |

Set `CHROMIUM_PATH` if Chromium is elsewhere; otherwise `/usr/bin/chromium` or Playwright's installed browser is selected. Both browser suites run against loopback addresses and enforce an external-request boundary. A missing fictional Supabase mock fails the test instead of reaching a hosted service. Service workers are blocked during tests.

### Test coverage

| Requirement                                               | Evidence                                                                                                                                                                                                                                                                                                                                                            |
| --------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Man# lookup and leading zeros                             | `domain.test.ts`, `import-parser.test.ts`, `current-ledger.test.ts`, `browser/ledger.spec.ts`, and `browser/interface.spec.ts`: text Man#, keyboard lookup/autofill, cleared stale selection, unmatched search without automatic creation, and corrected Man# preserving `client_id`.                                                                               |
| Client registration and duplicate prevention              | `client-register.test.ts`, `database.test.ts`, `security-database.test.ts`, `current-ledger.test.ts`, `postgres/concurrency.test.mjs`, and `browser/manual-man-auth.spec.ts`: required fields, case/whitespace duplicates, authenticated creator, audited identity corrections, unchanged relationships and stale-revision denial.                                  |
| Excel mapping, invalid/conflicting rows, repeated imports | `import-parser.test.ts`, `import-api.test.ts`, `import-database.test.ts`, and `current-ledger.test.ts`: real XLSX parsing/manual mapping, archive/size/type/row limits, numeric-zero warnings, formulas, preview counts, conflicts, unchanged rows, confirmation, stale preview rollback and semantic duplicate submissions.                                        |
| Loan imports require dates and interest terms             | `interest-database.test.ts` and `current-ledger.test.ts`: all required date/method/basis/rate/term/due-rule/settings fields are individually omitted and rejected; Client/financial side effects remain absent. Confirmed imports create actual loans and do not invent repayments or modify existing loans.                                                        |
| Exact interest and rounding                               | `interest.test.ts`, `interest-database.test.ts`, `security-migration.test.ts`, and `current-ledger.test.ts`: entire-term flat interest, half-ngwee half-up rounding, supported limits and maximum-value decimal migration preservation.                                                                                                                             |
| Defaults affect future loans only                         | `interest-database.test.ts` and `current-ledger.test.ts`: existing full loan snapshots remain unchanged; new loans use the new rate/revision; stale imports/defaults are rejected.                                                                                                                                                                                  |
| Partial repayment, settlement, reversal and retries       | `repayments-database.test.ts`, `repayments-migration.test.ts`, and `current-ledger.test.ts`: interest-first buckets, exact settlement, reversals visible with zero current effect, immutable originals, duplicate request payload checks and rollback of failed replacements.                                                                                       |
| Concurrent repayment protection                           | `postgres/concurrency.test.mjs`: different PostgreSQL backend PIDs, active RLS roles and observed `pg_blocking_pids` waits; competing overpayments, stale-but-affordable payments with reviewed settlement retry, same request across two Cashiers, changed payload under the same key, repayment vs rate adjustment, rollback/retry and in-flight role revocation. |
| Reports and historical date filters                       | `reporting.test.ts`, `reporting-database.test.ts`, `current-ledger.test.ts`, and browser report suites: effective-date disbursement/receipt/reversal/adjustment histories, historical status, negative reversal-period income, dated balances, currency separation, expense non-allocation, pagination and matching CSV/print scope.                                |
| Roles and RLS                                             | `security-database.test.ts`, `security-migration.test.ts`, `current-ledger.test.ts`, and `browser/security-auth.spec.ts`: all four roles, actual staff actors, cross-business isolation, suspended/unassigned users, spoofed metadata denial, direct-write denial, Administrator approvals, restricted helper execution and safe definer search paths.              |
| Public landing and approved account access                | `auth.test.ts`, `browser/public-auth.spec.ts`, and recovery/MFA browser suites: no public business reads, protected-route redirects, verified identity and active-role checks, signup without privileges, six-character validation, safe return paths, expired-link guidance, loading/error states and theme continuity.                                            |
| Fictional data / production protection                    | `fixture-safety.test.ts` and `browser/fixture-safety.spec.ts`: no external database targets, fresh database/run identity, owned networkless/tmpfs-only containers, blocked remote browser traffic, and a deliberate aborted POST to the reserved `production.invalid` name.                                                                                         |

Older migration-specific suites intentionally retain their original schema boundaries to prove upgrades. `current-ledger.test.ts` repeats critical business flows after **all sixteen migrations**, using separate rollback transactions per case; real-connection concurrency tests also run the final schema.

`postgres/recovery.test.mjs` adds a fictional in-memory dump/restore round trip into a second fresh database. It checks all 20 application tables, policies/effective role grants and schema access, matching reports/history, saved-request retry protection and a new settlement after restoration. The [read-only recovery checks](supabase/verification/recovery-checks.sql) are executed in that restored database. Hosted Supabase Auth and provider backup/PITR recovery remain separate acceptance requirements.

### Fictional fixtures and isolation

All names, Man# values, Auth IDs, email addresses, loans, payment references and workbooks used by the tests/demo are fictional. No email/SMS is sent. The app's `lib/demo.ts` data is presentation-only in the isolated `/demo` workspace; it is never a production seed. There is no general-purpose seed command or `supabase/seed.sql`, and migrations contain no fictional Client or financial records.

The PostgreSQL runner accepts **no database URLs, credentials, existing containers or alternate targets**. It forces the local Docker Unix socket rather than inherited remote contexts, creates a uniquely named/marked database, and verifies its own run marker before fixture loading. The container has **no network, published ports, host bind mounts or persistent volumes**: its root is read-only and PostgreSQL data uses tmpfs. Unix-socket trust is confined to that isolated container. Cleanup removes only the container bearing the current run marker. PostgreSQL timeouts bound failed connections; no Docker-wide cleanup or existing-database reset is performed. The reviewed PostgreSQL image digest is in `tests/support/postgres-image.json`; update it deliberately for future patch releases. These tests verify transactional locking, not crash durability.

The normal browser runner explicitly clears public Supabase values for **both build and startup**, even if a developer has a live `.env.local` or inherited values. The authenticated runner forces a fake URL/key, uses fake sessions, and fulfills fictional Supabase calls locally. Its shared browser fixture aborts any unmocked external request and fails the test; fixture safety also verifies that behavior. Supabase identity-provider/email delivery is not exercised by those mocks.

Before production, validate Supabase Auth and policies using actual staging accounts for all four roles and a second business, including imports, staff revocation, expenses and exports. Local real PostgreSQL establishes multi-session ledger locking; hosted Supabase deployment/authentication and CI execution still require their own environment and are not claimed by local tests.

## Security design

- All twenty public tables have RLS and explicit grants. Active database membership defines each business scope; legacy permission rows are retained without application grants. Composite foreign keys enforce matching ownership for Client/loan/repayment relationships.
- Only Administrators and Loan Officers may insert approved Client detail columns. Active staff roles may read permitted business Clients, loans, repayments, expenses, and source histories. Client creator/timestamps are assigned by database triggers. Client updates are available only through `correct_client`, which requires ownership, a correction reason, and an expected revision. Staff cannot update/delete financial records or insert them directly; permitted posting functions and Administrator-only approved adjustment functions perform audited writes.
- Financial functions use `SECURITY DEFINER` with an empty search path, explicitly qualified table references, authentication/ownership checks, bounded amounts, and no dynamic SQL. Execute access is revoked from anonymous users and PUBLIC.
- Repayments take a transaction-scoped request-key advisory lock and a loan row lock, insert a receipt, then update the balance in one transaction. Failures roll back all effects. Original request IDs persist across reloads/remounts; reviewed payloads remain in memory only. Pending recovery blocks replacement intents; database request locks wait for in-flight completion. Other-device manual re-entry still requires receipt reconciliation.
- Provider tokens are managed by the Supabase browser SDK. RLS is the authorization boundary. No service-role key, custom cookie authentication, or server action trusts a browser-supplied owner. Untrusted values render as React text.
- Security headers block framing, MIME sniffing, camera/microphone/location access, and external scripts. The CSP permits inline scripts/styles for Next.js; development additionally permits React’s required eval debugging, while production does not. TOTP enrollment and optional business enforcement are implemented at **Account security**. Enabling/disabling requires a signed AAL2 session with TOTP verified within 15 minutes; the database enforces protected Administrator operations when enabled. It defaults off for safe rollout. Stronger nonce-based CSP remains optional.
- An immutable payment history records amounts, timestamps, loan IDs, and account ownership. This is not a complete regulatory audit system. Use Supabase backups/PITR and access logging appropriate to your business. Do not delete Auth users referenced by live financial records.

## Deploy to Vercel

These steps are preparation for an explicitly authorized release. No deployment command is run automatically.

1. After authorization, push the application repository and import it into Vercel. Select the application Root Directory, Next.js preset and tested Node.js 24. Build: `npm run build`; install: `npm ci`. Keep the default output directory; this app needs server Route Handlers and cannot use static export.
2. Add both public environment variables to the intended Vercel environments. Keep preview deployments isolated from production data using a separate Supabase project.
3. Apply all sixteen SQL migrations in order to each new Supabase project (only unapplied migrations for existing projects) before deploying the application.
4. Configure Supabase Site URL, confirmation redirects, SMTP, password requirements, and sign-up policy for the deployed origin. Redeploy after changing `NEXT_PUBLIC_*` variables because they are bundled at build time.
5. Provision the first Administrator, assign staff roles, and verify permitted actions for each role. Confirm staff share only their assigned business and a second business cannot access those rows. Test expense posting/reversal, report scope, and immediate denial after deactivation. Review backups before accepting real funds.

No hosted deployment, Supabase configuration, or email delivery is performed by the repository itself. No Vercel configuration file is needed for the standard Next.js deployment.

The [operations runbook](docs/OPERATIONS.md) details environment separation, hosted import limits, staging acceptance and compatible application rollback.

## Backup, restoration and delivery limitations

Follow [Operations](docs/OPERATIONS.md#backup-policy-and-scope) for backup scope, business-approved RPO/RTO, provider backup/PITR setup, independent encrypted storage, recovery ordering, read-only reconciliation, hosted Auth/role checks and authorized cutover. Reports/CSV exports and a `public`-only database dump are not complete Supabase backups. Preserve original Auth UUIDs, transaction/audit/request histories and reference sequences. Recovery to an older point can lose later idempotency keys; reconcile external cash evidence before re-entering payments or imports.

The [delivery record](docs/DELIVERY.md) lists every implemented stage, its checks, accepted financial assumptions and what remains. The [audit remediation record](docs/AUDIT-REMEDIATION.md) maps fixes and rollout requirements. Current local verification covers the application and SQL behavior; remote CI execution, hosted identity/email, actual Vercel resource limits, provider backup restoration and operational acceptance remain unverified. Payment-provider integrations, installments/penalties/accruals, multi-currency origination, full-scale server report aggregation and a regulatory audit system are outside this release. This change does not establish hosted production readiness or alter the existing deployment’s data/configuration. The owner handles hosted acceptance and deployment.

## Import repair and safe Client lifecycle

Apply migration **015** after 014 for delegated **Import Clients** access and explicitly granted Client deletion. Preview now survives unchanged session/default refreshes. The importer offers Upload → Validate and Preview → Confirm → Import Summary and **Download Import Template**. Unlinked, unheld Clients can be deleted with confirmation while immutable audit identities remain; retained history requires Archive/Deactivate. See [the upgrade, permissions and retention guide](docs/IMPORTS-AND-CLIENT-LIFECYCLE.md). Migration 015 established fifteen ordered migrations and 20 application tables; the current session correction also requires 016 as described below. No hosted migration or deployment setting is changed by this delivery.

## Professional report exports and periods

Reports and loan/repayment histories now produce branded, formatted genuine Excel workbooks. Expenses supports filtered Excel, PDF and printing, with period payments/reversals and single-currency totals. Reports and Dashboard show **Clients Receiving Loans**, distinct from loans issued in the period. Repayment history offers Today / This Week / This Month / Custom Date Range using payment dates in Africa/Lusaka. No migration or financial-rule change is required. See [export definitions, setup and verification](docs/REPORT-EXPORTS.md), including the Poppler prerequisite for PDF tests and the limits of receipt-history versus accounting-period activity.

### Navigation, forms and recorded times

See [sidebar, forms and business times](docs/USABILITY.md) for the remembered desktop sidebar, accessible phone drawer, upper-right theme control, required fields, native date pickers and timezone-aware recorded events. This update requires no new migration or environment variable.

### Navigation performance

[Navigation measurements and caching boundaries](docs/PERFORMANCE.md) include before/after local production-build samples, request counts, an isolated database profile, reproducible commands and hosted limitations. Fresh authorization, financial refreshes and inactivity logout remain enforced. The delivery preserves newer main-branch session/navigation fixes, including migration **016** for fresh-session registration. Apply it after 015 if not already applied; no deployment setting changes are needed.

### Clearer business performance and matching sidebar themes

[Business performance and result definitions](docs/BUSINESS-PERFORMANCE.md) describe the simplified Reports/Dashboard, verified zero-expense periods, recorded results versus approved final profit/loss, matching CSV/XLSX/print figures and light/dark navigation. Existing approvals, financial rules, permissions, data and migrations are preserved; no migration needs to be reapplied.
