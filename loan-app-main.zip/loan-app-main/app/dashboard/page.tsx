import { Ledger } from "@/components/ledger";
import { AccessGate } from "@/components/access-gate";
export default function Page() {
  return (
    <AccessGate>
      <Ledger />
    </AccessGate>
  );
}
