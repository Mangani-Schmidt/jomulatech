import type { Metadata } from "next";
import "./globals.css";
import "./lendtrack.css";
import "./themes.css";
import "./public.css";
import "./usability.css";
import "./performance.css";
import { SessionBoundary } from "@/components/session-boundary";
import { VerifiedAccessProvider } from "@/lib/use-verified-access";
import { brand } from "@/lib/brand";
import { ThemeProvider } from "@/components/theme-provider";
import { sidebarStartupScript } from "@/lib/sidebar";
import { themeStartupScript } from "@/lib/theme";
export const metadata: Metadata = {
  title: `${brand.name} · Client ledger`,
  description: brand.description,
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          id="sidebar-init"
          dangerouslySetInnerHTML={{ __html: sidebarStartupScript }}
        />
        <script
          id="theme-init"
          dangerouslySetInnerHTML={{ __html: themeStartupScript }}
        />
      </head>
      <body>
        <ThemeProvider>
          <SessionBoundary>
            <VerifiedAccessProvider>{children}</VerifiedAccessProvider>
          </SessionBoundary>
        </ThemeProvider>
      </body>
    </html>
  );
}
