import {
  importAuth,
  uploadForm,
  workbookFile,
  importFailure,
} from "@/lib/import-api";
import { mappedRows, readWorkbook } from "@/lib/import-server";
export const runtime = "nodejs";
export async function POST(request: Request) {
  try {
    const db = await importAuth(request);
    const form = await uploadForm(request);
    const file = workbookFile(form);
    const { sheet, inspection } = await readWorkbook(file);
    const mapping = JSON.parse(String(form.get("mapping") ?? "{}"));
    const mode = String(form.get("mode") ?? "");
    if (mode !== "clients" && mode !== "loans")
      throw new Error("Select an explicit import mode.");
    const terms = JSON.parse(String(form.get("terms") ?? "{}"));
    const { data: id, error } = await db.rpc("preview_import", {
      p_filename: file.name,
      p_file_sha256: inspection.fileHash,
      p_mode: mode,
      p_terms: terms,
      p_rows: mappedRows(sheet, mapping, mode),
    });
    if (error) throw error;
    const report = await db.rpc("import_report", { p_batch_id: id });
    if (report.error) throw report.error;
    return Response.json(report.data, {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    return importFailure(error);
  }
}
