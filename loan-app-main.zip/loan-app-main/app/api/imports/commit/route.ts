import { importAuth, importFailure, boundedJson } from "@/lib/import-api";
export async function POST(request: Request) {
  try {
    const db = await importAuth(request);
    const body = await boundedJson(request);
    const { data: id, error } = await db.rpc("commit_import", {
      p_batch_id: body.batch_id,
      p_preview_version: body.preview_version,
      p_confirm: body.confirm === true,
    });
    if (error) throw error;
    const report = await db.rpc("import_report", { p_batch_id: id });
    if (report.error) throw report.error;
    return Response.json(report.data, {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    return importFailure(error);
  }
}
