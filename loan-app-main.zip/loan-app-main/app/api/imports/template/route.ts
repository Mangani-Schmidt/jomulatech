import ExcelJS from "exceljs";
export const runtime = "nodejs";
export async function GET() {
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet("Import");
  sheet.addRow(["no#", "name", "man#", "department", "designation", "amount"]);
  sheet.addRow([1, "Example Client", "00124", "Finance", "Analyst", 1000]);
  sheet.getColumn(3).numFmt = "@";
  sheet.getRow(1).font = { bold: true };
  sheet.columns.forEach((c) => {
    c.width = 22;
  });
  const guide = wb.addWorksheet("Instructions");
  guide.addRow(["Delete or replace the example data row before importing."]);
  guide.addRow([
    "First worksheet only. .xlsx, 2 MB maximum, 500 data rows, 30 source columns.",
  ]);
  guide.addRow([
    "Man# must be text to preserve leading zeros. no# is the source row number, never a Client ID.",
  ]);
  guide.addRow([
    "Select an import mode. Client Register Import ignores amount. Loan Disbursement Import requires confirmed terms.",
  ]);
  return new Response(new Uint8Array(await wb.xlsx.writeBuffer()), {
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition":
        'attachment; filename="lendtrack-import-template.xlsx"',
      "Cache-Control": "public, max-age=3600",
    },
  });
}
