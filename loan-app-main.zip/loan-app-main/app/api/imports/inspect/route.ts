import {
  importAuth,
  uploadForm,
  workbookFile,
  importFailure,
} from "@/lib/import-api";
import { readWorkbook } from "@/lib/import-server";
export const runtime = "nodejs";
export async function POST(request: Request) {
  try {
    await importAuth(request);
    const { inspection } = await readWorkbook(
      workbookFile(await uploadForm(request)),
    );
    return Response.json(inspection, {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    return importFailure(error);
  }
}
