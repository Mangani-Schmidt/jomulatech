import { importAuth, importFailure } from "@/lib/import-api";
export async function GET(request: Request) {
  try {
    const db = await importAuth(request, "view_imports");
    const page = Number(new URL(request.url).searchParams.get("page") ?? 0);
    if (!Number.isSafeInteger(page) || page < 0 || page > 1000000)
      throw new Error("Invalid history page.");
    const { data, error } = await db
      .from("import_batches")
      .select(
        "id,filename,mode,terms,status,preview_version,accepted,rejected,unchanged,uploaded_by,created_at,completed_at",
      )
      .order("created_at", { ascending: false })
      .order("id")
      .range(page * 20, page * 20 + 19);
    if (error) throw error;
    return Response.json(data, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return importFailure(error);
  }
}
