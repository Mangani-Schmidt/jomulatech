import { importAuth, importFailure } from "@/lib/import-api";
export async function GET(request: Request) {
  try {
    const db = await importAuth(request, "view_imports");
    const { data, error } = await db.rpc("import_report", {
      p_batch_id: new URL(request.url).searchParams.get("id"),
    });
    if (error) throw error;
    if (!data)
      return Response.json({ error: "Import not found." }, { status: 404 });
    return Response.json(data, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return importFailure(error);
  }
}
