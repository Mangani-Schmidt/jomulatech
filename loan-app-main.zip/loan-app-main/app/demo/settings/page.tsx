import { InterestSettings } from "@/components/interest-settings";
export default function Page() {
  return <InterestSettings />;
}
