import { DemoProvider } from "@/lib/workspace-context";
import { brand } from "@/lib/brand";
export const metadata = {
  title: `Explore demo · ${brand.name}`,
  robots: { index: false, follow: false },
};
export default function DemoLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <DemoProvider>{children}</DemoProvider>;
}
