import { InterestSettings } from "@/components/interest-settings";
import { AccessGate } from "@/components/access-gate";
export default function SettingsPage() {
  return (
    <AccessGate capability="can_view_settings">
      <InterestSettings />
    </AccessGate>
  );
}
