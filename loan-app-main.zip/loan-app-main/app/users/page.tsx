import { StaffAdministration } from "@/components/staff-administration";
import { AccessGate } from "@/components/access-gate";
export default function UsersPage() {
  return (
    <AccessGate capability="can_view_users">
      <StaffAdministration />
    </AccessGate>
  );
}
