import { AccountSecurity } from "@/components/account-security";
import { AccessGate } from "@/components/access-gate";
export default function Page() {
  return (
    <AccessGate requireBusiness={false}>
      <AccountSecurity />
    </AccessGate>
  );
}
