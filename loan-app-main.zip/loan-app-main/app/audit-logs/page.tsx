import { AuditLogs } from "@/components/audit-logs";
import { AccessGate } from "@/components/access-gate";
export default function AuditLogsPage() {
  return (
    <AccessGate capability="can_view_audit">
      <AuditLogs />
    </AccessGate>
  );
}
