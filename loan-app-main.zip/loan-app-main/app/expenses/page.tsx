import { ExpenseRegister } from "@/components/expense-register";
import { AccessGate } from "@/components/access-gate";
export default function ExpensesPage() {
  return (
    <AccessGate capability="can_view_expenses">
      <ExpenseRegister />
    </AccessGate>
  );
}
