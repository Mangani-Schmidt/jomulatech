import { defineConfig } from "@playwright/test";
import base from "./playwright.config";
export default defineConfig({
  ...base,
  testIgnore: [],
  testMatch: [
    "**/report-delivery-auth.spec.ts",
    "**/usability-auth.spec.ts",
    "**/navigation-refresh-auth.spec.ts",
    "**/client-lifecycle-auth.spec.ts",
    "**/user-access-session.spec.ts",
    "**/manual-man-auth.spec.ts",
    "**/loan-rate-auth.spec.ts",
    "**/permissions-auth.spec.ts",
    "**/dashboard-auth.spec.ts",
    "**/public-auth.spec.ts",
    "**/demo-explorer-auth.spec.ts",
    "**/audit-fixes.spec.ts",
    "**/authorized-register.spec.ts",
    "**/interest-settings.spec.ts",
    "**/loans.spec.ts",
    "**/repayments.spec.ts",
    "**/reports-auth.spec.ts",
    "**/security-auth.spec.ts",
  ],
  use: { ...base.use, baseURL: "http://127.0.0.1:3002" },
  webServer: {
    command: "npm run dev -- --port 3002",
    url: "http://127.0.0.1:3002",
    reuseExistingServer: false,
    env: {
      NEXT_PUBLIC_SUPABASE_URL: "https://register-tests.supabase.co",
      NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY:
        "test-publishable-key-not-a-credential",
    },
    timeout: 60000,
  },
});
