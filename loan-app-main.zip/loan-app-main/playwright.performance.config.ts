import { defineConfig } from "@playwright/test";
import base from "./playwright.config";
export default defineConfig({
  ...base,
  testDir: "./tests/performance",
  testIgnore: [],
  testMatch: "**/*.bench.ts",
  timeout: 90000,
  use: { ...base.use, baseURL: "http://127.0.0.1:3002" },
  webServer: {
    command: "node scripts/performance-test-server.mjs",
    url: "http://127.0.0.1:3002",
    reuseExistingServer: false,
    timeout: 120000,
  },
});
