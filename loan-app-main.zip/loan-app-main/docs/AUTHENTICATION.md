# Public pages, authentication and business access

LendTrack opens at a public landing page. It shows an application explanation, Sign Up, Log In, theme preferences and a fictional demo link. It does not mount the ledger, query business records or display financial metrics. There are no public dashboard shortcuts. Explore Demo is offered only to signed-out visitors; authenticated pages contain no demo prompt. Successful login opens an allowed return destination, the permitted Dashboard, or the first accessible module. An unassigned account opens its own Account security page.

| Route                                   | Access and purpose                                                                                                     |
| --------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `/`                                     | Public explanation, Sign Up and Log In; no records, metrics or dashboard shortcut.                                     |
| `/login`, `/signup`, `/forgot-password` | Public account forms; signup preserves approval, recovery avoids account enumeration.                                  |
| `/dashboard` and workspace fragments    | Verified identity, active application session and corresponding module/action capability.                              |
| `/settings`, `/expenses`                | Corresponding module view; sensitive actions need independent grants.                                                  |
| `/users`, `/audit-logs`                 | Separate User Management and Audit Logs view grants; editing requires authorized Administrator user-management access. |
| `/administration`                       | Compatibility redirect to `/users`, with its access gate.                                                              |
| `/security`                             | Verified identity including unassigned/recovery accounts; business policy edits still require their privileged grant.  |
| `/demo`, `/demo/settings`               | Public isolated fictional read-only examples; never initialize Supabase.                                               |

## Security boundaries

The existing Supabase browser SDK session model is retained. The root SessionBoundary first checks the application session. Internal pages initially render a public access-check shell. For a first or changed identity, `AccessGate` verifies the cached token with `auth.getUser` before the existing authorized `loan_defaults` RPC. For an already verified application session, both fresh checks run in parallel to require `can_read` and any screen-specific capability. Denied, forged, unavailable and unassigned sessions never mount restricted financial components. Anonymous configured visits redirect to Log In, retaining an allowlisted internal return path; access-check failures offer a retry. An account change rechecks access before mounting the next account's workspace. The verified capability/defaults snapshot is shared with nested components. During same-account rechecks the previously verified workspace and loan dialogs remain visible and inert/read-only with a status message; dialogs retain their input state, and explicit reload still resets loan defaults. Workspace navigation and posting shortcuts recheck access before entry. The demo has its own explicit boundary. See [permissions and enforcement](PERMISSIONS.md).

These are browser navigation gates, not HTTP middleware redirects or a server-cookie session migration. Financial data is not embedded in the public shell. Supabase RLS, database capability checks and protected RPCs remain the server-side authority on every record and transaction, including direct API requests. Changing the browser UI or signup metadata cannot assign a business role. Existing upload handlers continue to validate bearer identities and permissions. No service-role key is added.

Signup calls Supabase Auth only; it does not create a business, grant Administrator privileges, assign a role or read Client records. After confirmation where required, a trusted existing Administrator assigns the identity to the intended business with an active role through User Management. First-Administrator provisioning remains the trusted manual bootstrap in README. Disabled open registration produces a helpful invitation message. Keep registration disabled for an invitation-only deployment after onboarding.

## Password policy and provider configuration

Login, signup and password updates use the shared validation in `lib/auth.ts`: **at least 6 characters**. Passwords are never trimmed. Password updates require matching values. Password inputs have show/hide controls, appropriate autocomplete, visible labels and the same HTML minimum. Zod validates before requests; Supabase Auth remains the authoritative password-policy server. Forms provide loading, disabled submission and safe, understandable error messages without logging credentials. Recovery responses avoid revealing whether an email has an account.

Inspection found no initialized `supabase/config.toml`, configured project values or provider-management access in this environment. Hosted password policy could not be inspected or changed. The required hosted setting is **Authentication → email/password provider → Minimum password length = 6**, represented by the Auth configuration field **`password_min_length: 6`**. Verify and set it in the intended hosted project; do not claim local form validation changes the provider. If a local Supabase CLI stack is initialized later, its corresponding setting is `[auth] minimum_password_length = 6`. Do not introduce an incomplete CLI stack just to change a hosted setting.

Keep email confirmation, rate limits, compromised-password protection and existing MFA requirements. Additional provider password requirements may still reject a password; the form explains that rejection. Hosted protections/configuration were not changed here. The permission/session migrations preserve financial terms and records; apply them using [the upgrade instructions](SESSIONS.md#upgrade-the-existing-deployment).

Set the Supabase **Site URL** to the deployment origin. Add exact redirect allowlist entries for each intended environment:

- `https://YOUR_DOMAIN/login` for signup confirmation.
- `https://YOUR_DOMAIN/security` for password recovery.
- Intended local equivalents, for example `http://localhost:3000/login` and `http://localhost:3000/security`. Use the hostname actually opened in the browser.

Preserve existing required redirect entries and use a separately configured staging project for previews. Configure production SMTP. The app requests these redirects explicitly; templates/provider settings must also preserve the documented flow. The owner manages these hosted settings and Vercel deployment.

## Hosted acceptance

Before relying on the feature with real staff, verify against the intended non-production project:

1. Check the actual `password_min_length` is 6. A five-character signup/update must fail at the provider, a six-character password meeting other protections must work, and longer existing passwords must still log in.
2. Confirm a new signup can receive and follow the real email. It must not see Client records before a trusted Administrator assigns an active business role. Test disabled registration as well.
3. Request a real recovery email, follow it to `/security`, set a matching password and log in with it. Test expired/used links, provider email rate limits and network failures. Confirm MFA/reauthentication requirements remain enforced where configured.
4. Test signed-out, inactive, unassigned, other-business and each authorized role against internal routes and direct Supabase APIs. Test actual session revocation/refresh and the existing Administrator MFA flow.
5. Visit `/` signed out and signed in in both themes on mobile and desktop. Confirm no dashboard shortcut and no authenticated demo prompt. Test the permitted first-module login destination and [two-tab inactivity acceptance](SESSIONS.md#upgrade-the-existing-deployment). It must fetch no business records and contain no financial metrics. Verify demo isolation and the `/dashboard` destination of existing navigation links.

Local browser contracts use intercepted fictional Auth responses. They exercise routing, identity verification, role denial, six-character validation, signup/recovery requests and loading/errors; they do not verify real SMTP, hosted policy or provider lifecycle behavior. The SQL and PostgreSQL suites separately verify server permission/session enforcement and financial integrity.
