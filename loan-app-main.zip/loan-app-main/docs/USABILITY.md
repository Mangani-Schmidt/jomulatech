# Sidebar, forms and business times

This batch preserves the existing navy/slate/emerald design, business permissions, database connection, financial calculations and stored records. There is no new migration, dependency or environment variable. Existing migrations through 016 are still required. No hosted data or settings are changed.

## Navigation and themes

Desktop and tablet widths above 600px use the same sidebar on the ledger, Settings, Account security, Expenses, User Management and Audit Logs pages. **Collapse sidebar / Expand sidebar** switches between a 238px labelled sidebar and an 80px icon rail. Every link keeps an accessible name and title, and the active page remains indicated. Account security now has a shield icon. Help and sign-out stay available in the desktop sidebar.

The device-local `lendtrack:sidebar` preference is restored before paint, survives reloads and page changes, and synchronizes across tabs. Invalid values default to expanded. When browser storage is blocked, the selection still works for the visit and a save-failure message explains the limitation. It contains no account or financial data and does not alter authentication or pending transaction keys.

On phones, **Open navigation** opens a left-side modal drawer with a labelled close button, backdrop and selected-page styling. The native dialog makes background content inert; explicit Tab/Shift+Tab wrapping keeps keyboard focus inside. Escape, the close button and a backdrop click dismiss it. Dismissal returns focus to the menu button; inline navigation closes the drawer and focuses the destination heading. Resizing to desktop closes the drawer. Mobile state does not replace the saved desktop preference. Animation is disabled with reduced-motion preference.

The existing **Choose color theme** icon now sits at the upper right of public, workspace and standalone application headers. Its Light / Dark / System menu, keyboard behavior, saved preference, cross-tab updates and pre-paint System resolution remain unchanged. Header DOM order follows the new visual order, so Tab exits the public theme menu into the main page actions.

All module links still derive from the existing verified database capabilities. Initial access gates, direct-route checks, backend permissions and RLS are unchanged. No new frontend grant policy is introduced.

## Forms and dates

Shared form controls add one **\* Required** explanation per form and visible asterisks on mandatory labels. Required indicators are hidden from accessible names; native required semantics remain available to assistive technology, and existing label-based navigation keeps working. Conditional rate-override reasons are marked only when required. Confirmations required by existing financial validation now expose the same requirement natively. Optional contact/reference labels no longer include “(optional)” and remain unmarked.

Standalone repayment custom-range controls identify their required dates. Client archival/deletion requirements are explicitly scoped to those actions; they do not make a normal Client correction require an archival reason. Validation failures retain the existing controlled/uncontrolled input state. Resets remain associated with successful saves or explicit discard actions.

Active Client and Active user use native checkbox-backed switches. These edit the existing form draft and still require its authorized Save action. Module and sensitive-action permissions remain checkboxes. Approvals, MFA policy changes, financial confirmations and reversals retain their existing review and save flows; they do not become immediate business writes.

Labels, controls, sections, errors and action groups have consistent spacing and theme tokens. Existing keyboard-focus, hover, pressed, disabled, loading and result states remain available without hiding essential information behind hover.

All date inputs on loans, repayments, expenses, imports and reports use the same native date wrapper. Clicking the input area requests `showPicker()` during that user gesture, including clicks near the native calendar icon. Keyboard editing and clearing remain native. If the browser does not support the API, rejects it or restricts it, the ordinary native input remains usable. The application does not intercept date keyboard events or replace mobile platform calendars.

## Exact times and effective dates

The existing database already captures server-generated `timestamptz` posting, creation, update, audit, reversal, write-off and import-completion events. For example, migration 002 uses `clock_timestamp()` for Client creation/updates; migrations 006 and 008 retain exact financial posting/audit/reversal timestamps. No backfill or timestamp migration is necessary, and all fifteen migration checksums remain unchanged.

Screens now consistently format recorded events in the current supported business timezone, **Africa/Lusaka**, with seconds and an explicit timezone label. Client details, loan terms, receipts, statements, audits, imports and expense history use the same formatter. Repayment and expense rows distinguish their **effective date** from **Recorded** time; expense reversals also show the recorded reversal time. Missing update timestamps display **Not recorded**, rather than borrowing creation time.

A date-only historical value displays its date and **Time not recorded**. An offset-free time does not establish an exact instant and is also labelled **Time not recorded**. Invalid dates display **Not recorded**. These labels never synthesize a historical midnight. Disbursement, payment, expense and due dates remain date-only financial concepts. A posting timestamp records when the event was recorded by the system; it does not claim an exact physical cash-hand-over time for a backdated transaction. Existing historical financial calculations still use their original effective-date rules.

## Validation and remaining boundaries

`tests/usability.test.ts` checks business midnight/offset equivalence, unknown/invalid historical times and safe preference defaults. `tests/browser/usability.spec.ts` checks desktop persistence across reloads/pages/tabs, icon navigation, mobile focus wrapping/Escape/backdrop/destination focus, reduced motion, required labels, date-picker requests and clearing, both themes and overflow at 390px, 820px and 1440px. `usability-auth.spec.ts` checks fictional expense effective/recorded dates, a real native date-control gesture, required versus optional labels, and restricted mobile navigation with the Account security icon. Existing permission, session, financial, import, export, recovery and RLS suites remain applicable.

The automated picker checks verify that clicking the field requests the supported native API, that typing/clearing work, and that Escape preserves normal interaction. Operating-system calendar chrome, physical touchscreen behavior, Safari/Firefox and screen-reader sessions require separate acceptance. Hosted Supabase/Vercel behavior and remote CI/deployment results cannot be established by local fictional fixtures. There is no configured linter; TypeScript and Prettier checks are reported separately.

## Verified locally — 2026-11-14

The completed batch passed route generation/TypeScript, **270 unit/SQL tests**, **11 real PostgreSQL concurrency/recovery checks**, **48 production browser tests**, **109 authenticated browser tests** and the production build. The final form/header refinements passed another TypeScript/build, all 48 production browser cases, the three timestamp/preference unit tests and seven targeted authenticated report/usability cases. No database migration was run. All fifteen migration checksums, documentation file targets, changed-file Prettier checks and whitespace checks passed. No lint pass is claimed because the repository has no configured linter.

Initial regressions were corrected: required markers retain stable accessible/lookup names; public theme-menu Tab exit matches the new header order; and Tab wraps explicitly at the drawer boundaries. Native picker restrictions are caught without losing ordinary editing. Invalid Client submission retains the entered Man#, name and Active switch state. No unresolved local test failure remains.

Representative fictional captures are committed for review; automated runs also generate them in ignored `test-results/`. Full-page captures show the fixed sidebar only within the captured viewport's height. The public demo illustrations intentionally show demo prompts; authenticated pages keep those prompts hidden.

| View            | Light                                                  | Dark                                                  |
| --------------- | ------------------------------------------------------ | ----------------------------------------------------- |
| Phone, 390px    | [Loan form](screenshots/usability/loan-390-light.png)  | [Loan form](screenshots/usability/loan-390-dark.png)  |
| Tablet, 820px   | [Loan form](screenshots/usability/loan-820-light.png)  | [Loan form](screenshots/usability/loan-820-dark.png)  |
| Desktop, 1440px | [Loan form](screenshots/usability/loan-1440-light.png) | [Loan form](screenshots/usability/loan-1440-dark.png) |
| Phone drawer    | [Navigation](screenshots/usability/drawer-light.png)   | [Navigation](screenshots/usability/drawer-dark.png)   |

Additional fictional captures show [permission-filtered navigation and Account security](screenshots/usability/permitted-mobile-sidebar.png) and [expense effective dates versus exact recorded time](screenshots/usability/expenses-timestamps.png). Browser-emulated screenshots do not establish hosted acceptance or physical-device compatibility. GitHub delivery is a normal verified push to `main`; no manual deployment or deployment-setting change is part of this batch.

## Grouped sidebar update

The sidebar follows the selected reference layout in desktop and phone navigation:

| Section             | Order                                       |
| ------------------- | ------------------------------------------- |
| Overview            | Dashboard                                   |
| Lending Operations  | Clients, Loan History, New Loan, Repayments |
| Finance & Reporting | Expenses, Reports, Excel Imports            |
| Administration      | User Management, Audit Logs, Settings       |
| Account footer      | Account Security, Sign Out                  |

**Loan History** is the shorter sidebar label; existing Client Loan History page titles, statements and internal routes remain unchanged. New Loan is a peer navigation item with a plus-circle icon and the same active-page treatment as other pages. Reports has its own chart icon. Section dividers and muted headings use the existing shared theme tokens. Permission filtering removes empty groups, and the collapsed rail retains labelled icons and group separators.

Account Security and Sign Out have shield/exit icons with visible labels below a divider on desktop and mobile, including standalone modules. Sign Out invokes the existing session boundary's revocation, cache clearing, cross-tab logout and login redirect. Duplicate authenticated sign-out icons are removed from the ledger profile/header. Demo mode retains its existing sign-in option and never offers a real account logout. The Help action and profile remain available; the decorative sidebar support card has been removed to keep navigation compact.

This update changes no financial code, data, database permissions, connection settings, dependencies or migrations. No SQL needs to be reapplied. Validation uses fictional provider data; hosted Vercel/Supabase acceptance remains separate.

Final local validation passed TypeScript, the production build, **11 existing access/theme unit tests**, **48 production browser tests**, **126 authenticated browser tests**, and a final six-case screenshot/logout run. Existing browser suites cover keyboard focus, Escape/backdrop dismissal, collapsed preference persistence, touch layouts, both themes, direct-access denial and inactivity. New cases verify group/item order, empty-group permission filtering and successful session removal after Sign Out at 390px, 820px and 1440px. Formatting, whitespace and unchanged migration checksums pass. No linter is configured. Real hosted Auth/Vercel verification was not performed.

Captured fictional development UI (the Next development indicator is hidden for screenshots only): [desktop light](screenshots/grouped-sidebar-desktop-light.png), [desktop dark](screenshots/grouped-sidebar-desktop-dark.png), [phone light](screenshots/grouped-sidebar-phone-light.png), [phone dark](screenshots/grouped-sidebar-phone-dark.png). These screenshots record the earlier navy navigation surface. The current [business-performance and theme update](BUSINESS-PERFORMANCE.md) makes the sidebar follow Light/Dark/System.
