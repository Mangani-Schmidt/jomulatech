# Current defaults and editable loan rates

Open **New Loan** from the workspace or an authorized posting shortcut. The existing permission gate refreshes the current settings before entry. The rate field contains the actual current default percentage, rather than a placeholder. The form also displays that Settings default and the supported 0–100% range with at most two decimal places.

## Choosing and reviewing a rate

- Without `can_override_rate`, the rate is read-only and the form explains the permission requirement. Origination permission is still required separately.
- With `can_override_rate`, edit the rate for this loan. A rate differing numerically from the current default requires a trimmed reason of 5–500 characters. `10` and `10.00` represent the same rate; a zero-rate exception also requires authorization/reason when the default is nonzero.
- **Use default rate** restores the current default rate and clears the override reason, without changing the selected Client, Amount Disbursed, term or disbursement date. It does not call the Settings update function.
- **Reload current defaults (resets rate and term)** explicitly refreshes Settings, resets both rate and term and requires a new review. Permission-only rechecks preserve draft terms when the settings revision and override permission have not changed.
- The preview shows Amount Disbursed, one-time interest charge, total obligation and due date. Confirmation separately identifies the applied loan rate, calculation method and rate basis. An override review also shows the Settings default and its recorded reason.

The only supported method remains **one-time flat interest for the entire loan term**:

```text
Interest charge = principal × rate / 100
Total obligation = principal + interest charge
```

The rate is charged once over the whole term. No new method, monthly rate or compounding is introduced. Existing exact integer preview calculations and authoritative PostgreSQL numeric calculations retain half-up rounding to two currency decimals. Repayment allocation remains interest first, then principal.

## Validation and server authority

`lib/loan-rate.ts` reuses the existing `rateBps` parser and database-returned override capability. It validates the rate and the recorded reason before confirmation/posting, without mutating the Settings snapshot. Numeric input is not silently truncated: out-of-range rates, excess decimal places and scientific notation are rejected. Unicode reason length uses the same character-count semantics as PostgreSQL.

The obligation preview passes the actual loaded calculation method and rate basis to the existing `flatInterest` validator. An unsupported or malformed settings response cannot produce an assumed flat-interest preview or an enabled review action.

The unchanged `originate_loan` / `checked_loan_terms` database functions independently authorize origination and overrides, validate the current settings revision, require the reason, calculate exact amounts and save the actual terms atomically. The loan retains its actual rate/method/basis/term, interest and obligation, original default-rate snapshot, settings revision and override reason. Origination and subsequent authorized adjustments retain their existing audit history and actor attribution. Client selection/revision checks and duplicate-request protection remain unchanged.

A per-loan override does not update the global default or create a Settings audit event. Authorized changes to Settings apply to future loans. Existing loans retain their saved terms, balances and audit history until an explicit authorized adjustment. If Settings changes after a loan was reviewed, the server rejects the stale revision; reload current defaults and explicitly review/confirm again. A failed stale request does not create a loan.

## Verification boundaries

Tests cover default prefill and read-only permissions, editable overrides and reset behavior, validation/reason boundaries, exact zero/maximum/half-up charges, actual reviewed payloads, malformed methods and stale-default recovery. Final-schema SQL tests verify saved actual terms and audit snapshots, no Settings changes from overrides, unchanged existing loans after a new default, future-loan inheritance and server rejection of unauthorized/stale terms. Browser Auth responses are fictional and intercepted; hosted runtime and provider behavior require the owner's separate acceptance.

No migration, new environment variable, interest-method change, repayment-allocation change or hosted configuration update is required.
