# Manual Man# and existing Clients

**Clients → Add Client** starts with an empty, editable text Man# field. Enter the Client's chosen or assigned identifier; the application never generates a Man#. The database independently generates the internal `clients.id`, which remains the relationship key for every loan.

Man# is required and accepts 1–50 text characters without control characters. Surrounding spaces are trimmed. Leading zeros and the entered spelling are retained; `000042` differs from `42`. Uniqueness is case insensitive within the business, so `00Ab-01` and `00ab-01` identify the same registered Client. There is no new digits-only format restriction. Inactive Clients retain their Man# and cannot be registered again under it.

As the user types, the currently loaded register can show an existing Client's Man#, name, department, designation and active status. **Open existing Client Details** is available only with the existing read capability. Opening deliberately discards the unsaved entries in the registration/correction form, as the preview explains. It does not create, overwrite, merge or reactivate a Client. Any later authorized correction still needs the existing audited correction reason and expected revision. Correcting Man# preserves `clients.id`, `loans.client_id` and loan history.

Before registration or a changed-Man# correction, saving makes a fresh exact lookup through `find_client_by_man`. It uses PostgreSQL `lower(man_number)` equality and the existing business-scoped unique index, rather than pattern matching. `%`, `_`, `*` and backslashes remain literal text. The function is read only, uses `SECURITY INVOKER` with an empty search path, checks the existing read capability and retains Client RLS. Anonymous users cannot execute it; suspended/unassigned users are denied; other businesses' Clients are never returned. A failed lookup blocks saving and retains the draft.

The existing database unique constraint is the final authority when two users register the same Man# simultaneously or direct API writes bypass the form. On a uniqueness rejection, the form reloads the winning record and offers the same explicit open action. It never automatically retries creation or silently updates that record.

**New Loan → Search by Man# or Client Name** retains its keyboard search, selection and name/department/designation autofill. An unmatched search still creates nothing; authorized users can choose **Add Client**, review the prefilled search text and explicitly save. Use the existing **New Loan** lookup to select a registered Client for origination; opening a duplicate preview does not post a loan or transfer a loan draft.

## Upgrade the existing deployment

After verifying the target and taking the backup described in [Operations](OPERATIONS.md), apply **only unapplied migrations**, in order. A project already on migration 011 needs [012_client_man_lookup.sql](../supabase/migrations/012_client_man_lookup.sql), submitted as one entire transaction in the Supabase SQL editor. Do not rerun migrations 001–011. Migration 012 adds only the read-only lookup function, its execution grants and a comment; it changes no tables, records, financial terms, balances or existing constraints.

The GitHub/Vercel connection does not apply Supabase migrations. Apply 012 before using this build's manual registration or changed-Man# correction. If the app is deployed first, these saves fail safely at the lookup until the migration is installed; the error preserves the entered details. Existing lookups, read access, loans, repayments and unchanged-Man# audited detail corrections retain their existing paths. No new environment variable, secret or connection configuration is needed.

Verify on the hosted application with approved test data: manual `000042`, a case-varied duplicate, an inactive duplicate, a Man# containing punctuation, a conflict introduced after loading, authorized opening and denied registration for a Viewer. Check existing lookup/autofill and the internal Client ID before/after an authorized correction. Local fictional browser/provider contracts do not verify hosted Supabase or Vercel behavior.

## Local verification

`tests/client-register.test.ts` checks text validation, identity matching and safe lookup failure. `tests/current-ledger.test.ts` checks literal database lookup, uniqueness, unchanged loan relationships, grants, inactive membership and business isolation after all migrations. `tests/postgres/concurrency.test.mjs` uses two real authenticated connections to prove competing case-varied registrations produce one Client and one creation audit. `tests/browser/manual-man-auth.spec.ts` checks manual save, existing-record navigation, races, failed lookups/retry, conflicting corrections and maximum-length mobile previews in both themes. The existing authorized-register and lookup browser tests retain the unmatched/manual creation and audited correction workflows.
