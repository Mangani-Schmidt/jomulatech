# Business performance, results and themes

Reports and Dashboard share four primary figures: **Amount Disbursed**, **Repayment Received**, **Clients still owe**, and **Interest collected**. Each card explains its meaning and identifies period activity or the balance date. Reports puts the remaining exact totals in **More financial details**. Filters, calculation notes and the existing period-approval form are disclosures, so detailed work remains available without filling the first screen. Dashboard keeps its existing permission-based quick actions and loan drill-downs.

## Expenses and profit

An authorized, successfully loaded expense array with no matching paid expenses or effective reversals in the selected period/currency produces **K0.00** (formatted in the chosen currency). Missing, redacted or failed data is unavailable rather than zero. Expenses in other currencies are not combined. Client/department/status/disbursement filters never allocate shared expenses to individual Clients.

**Result from recorded entries** = Interest collected − net business expenses − recognized principal losses. The calculation uses the existing checked integer-cent arithmetic and original effective-date/reversal policies. Principal repayments are capital returned, not income. Expected interest remains separate from interest actually collected. A loss is displayed with a negative recorded result; after period approval, **Loss this period** shows its magnitude under an explicit loss heading. Approved zero shows **Break-even this period**.

This adds a clearly labelled provisional result; it does not relax the existing final Net Profit safeguard. **Profit this period / Loss this period / Break-even this period** appears only for a currently valid administrator-approved period, currency and financial snapshot. The existing **Reporting coverage approval** form confirms that expenses and loan losses are complete, including a reviewed zero-cost period. A later financial event or revoked approval removes the final-profit label. The Dashboard calculation breakdown is expandable; Reports opens that breakdown by default. Only existing permitted financial/expense readers see this panel or approval controls.

CSV, XLSX and printable reports include the same recorded result with **not final profit** stated explicitly. Their final Net Profit field retains its original approval requirement. Download/print permissions, source filtering, request verification and stale-export cancellation are preserved. Successful empty data is different from a failed request: financial failures remove figures and offer retry.

## Light and dark navigation

Both desktop and phone sidebars use shared theme tokens. Light mode uses a pale slate background with navy text; dark mode uses navy surfaces and slate text. Inactive hover and keyboard-focus surfaces are pale blue in light mode and dark slate in dark mode. Brand, section headings, account controls and separators follow the same theme. Active links retain a readable teal treatment. Saved Light/Dark/System behavior, pre-paint theme resolution, collapsed preference and mobile focus handling are unchanged. Dark hover overrides also cover legacy secondary controls and row actions.

## Upgrade and verification boundary

There is **no new migration, dependency, environment variable, financial transaction change or deployment setting**. Existing migrations through 016 are unchanged; do not reapply them for this update. The fictional demo explicitly declares an empty expense array; no real expense, Client, loan, approval or business setting is seeded or changed.

Local checks use fictional browser responses and isolated database fixtures. They do not verify the hosted project's actual record completeness, Supabase policy configuration or Vercel deployment status. An approval is the existing administrator's attestation of completeness, not an automatic accounting certification.

## Local validation

The completed update passed TypeScript and production builds, **276 unit/SQL tests**, **12 real PostgreSQL checks**, **52 production browser tests** and **131 authenticated browser tests**. The final financial subset passed **31 tests**; final production screenshot/hover checks cover phone and desktop in both themes. Existing coverage approval is explicitly exercised before and after a financial revision, along with approved profit/loss/break-even, principal exclusion, verified zero expenses, redacted/unavailable costs, currency isolation, role visibility and matching exports. No configured linter exists; formatting is checked separately.

Fictional captures: [Dashboard light](screenshots/performance-dashboard-desktop-light.png), [Dashboard dark](screenshots/performance-dashboard-desktop-dark.png), [Reports light](screenshots/performance-reports-desktop-light.png), [Reports dark](screenshots/performance-reports-desktop-dark.png), [phone Dashboard light](screenshots/performance-dashboard-phone-light.png), [phone Dashboard dark](screenshots/performance-dashboard-phone-dark.png), [phone Reports light](screenshots/performance-reports-phone-light.png), [phone Reports dark](screenshots/performance-reports-phone-dark.png). These use the existing demo ledger, not the illustrative values from the design image.
