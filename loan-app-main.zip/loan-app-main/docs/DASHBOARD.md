# Dashboard behavior and financial definitions

Open `/dashboard` with an active application session and Dashboard module access. The public `/` landing page remains separate. The dashboard uses the existing authorized `report_source_filtered` snapshot and `buildReport` calculation, with unchanged financial formulas. The current [permission/session migrations](SESSIONS.md#upgrade-the-existing-deployment) govern access. The isolated `/demo` workspace shows its existing fictional source explicitly; connected workspaces never fall back to demo figures.

| Dashboard figure         | Existing report value     | Meaning                                                                                                                                                              |
| ------------------------ | ------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Amount Disbursed         | `totals.disbursed`        | Principal actually disbursed during the selected activity period.                                                                                                    |
| Outstanding Balance      | `totals.owed`             | Principal plus unpaid interest at the end of the selected balance date, including written-off obligations. Collectible balance remains a separate figure in Reports. |
| Repayment Received       | `totals.received`         | Receipts net of reversals effective during the activity period. It can be negative when period reversals exceed receipts.                                            |
| Interest Income Received | `totals.interestReceived` | Interest allocations received, net of reversals effective during the period. Principal repayments are not income. This figure is not Net Profit.                     |

The default activity period is the current month through today; the balance date defaults to today. Dates use Africa/Lusaka and both activity boundaries are inclusive. Each card identifies whether it describes activity or an end-of-day balance. Changing activity dates does not erase outstanding debt from earlier disbursements. A historical balance date continues to use recorded disbursement, repayment, adjustment, reversal and write-off effective dates through the existing reporting engine. Each summary uses one selected currency; currencies are never combined.

Loan module access controls the Amount Disbursed and Outstanding Balance cards; Repayments access controls Repayment Received and Interest Income Received. Users without either financial view see no financial summary or source query. These are permission-based omissions, not zero balances.

## Daily work and secondary information

Quick actions follow the financial summary and show New Loan and Add Client to authorized originators/register staff, Record Repayment Received to authorized Cashiers and Administrators, and report/loan-history navigation to permitted readers. Buttons wait for business capabilities and preserve the existing confirmation screens, financial operations, authorization and transaction recovery behavior. Demo actions remain read-only previews.

The selected dates, currency and applied filters stay visible above the cards. Open **Change dates and filters** to edit Activity from, Activity to, Balances as of and Report currency. **More filters** contains Client search, department, designation, loan status and disbursement dates. Apply report filters updates the selection; unapplied changes are announced, and active filters remain visible in the applied scope when controls are collapsed. **View detailed reports** retains those filters.

**Reports** retains all principal/interest breakdowns, expected interest, collectible/written-off/overdue balances, losses, expenses, certified business Net Profit where available, Client summaries, pagination, CSV/XLSX/print and calculation policies. Shared expenses remain at business level. **View all loans** opens Client Loan History. **Review overdue loans** keeps the current Client/department/date/currency scope and expands a filtered overdue report. The dashboard's duplicate general loan table is removed; existing loan-history actions remain available in their dedicated view.

## Loading, empty results and failures

- A pending report request shows Loading financial summary and no balance cards.
- A successful, complete response with no matching loans shows No loans in this selection and valid zero totals. This may mean restrictive filters or a historical date before any loan, rather than an empty business.
- Failed, incomplete or uncalculable financial history shows Financial summary unavailable, the relevant error and Retry financial summary. It does not display zero balances or an empty-business claim. Retry uses the same applied filters. Rejected request promises also finish in the unavailable state.
- Financial summaries and operational record lists use separate authorized snapshots. An operational ledger failure remains visibly reported; it does not manufacture financial figures. There is no duplicate operational loan table on the dashboard.

## Verification boundaries

Browser tests compare the four cards with the existing report engine, exercise both themes at 390px and 1440px, distinguish zero period activity from an outstanding balance, verify historical empty selections and retained filters, and check role-based actions. Connected-workspace contracts intercept fictional responses to verify loading, successful-empty, failed-refresh/retry and incomplete-response states. Existing report exports, financial tests, PostgreSQL concurrency/recovery and RLS checks remain part of `npm run verify`.

No hosted data, Supabase settings or Vercel configuration is changed. Hosted runtime acceptance and remote CI results must be verified separately by the deployment owner.
