# Financial workbooks, expenses and repayment periods

This release changes reporting and downloads only. It adds no database migration or environment variable and does not change roles, financial transaction rules, saved terms, repayment allocation, loss recognition or history. Existing migrations through 015 remain required. Install the locked dependencies with `npm ci`; the PDF renderer is pinned pdfmake 0.3.14 with embedded Roboto fonts, and ExcelJS continues to produce actual XLSX archives. Neither report generation nor printing connects to an external document service.

## Professional Excel workbooks

**Reports → Download .xlsx report** exports the applied report snapshot, including all matching pages on **Filtered loans** and **Filtered Clients** sheets. **Client Loan History → Export report** retains its original detail columns and splits each currency into a separate sheet with separate totals. It describes current history/balances, rather than claiming a dated accounting-period snapshot. **Repayments → Export Repayments to Excel** exports the selected receipt period, search and currency, including reversed rows and current posted-only totals.

Every workbook has LendTrack branding, a report title, a **Report scope** sheet, generation time in Africa/Lusaka, applied filters and currency, clear totals, navy/teal styling, alternating rows, readable widths, wrapped text, aligned amounts, date/number formats, frozen title/header rows and Excel filters. Detailed reports distinguish activity dates, end-of-day balance date and the source snapshot time. Text, including Man# and strings beginning with formula-like characters, is written as literal spreadsheet text, never as executable formulas or hyperlinks. Man# leading zeros are preserved. These are generated XLSX ZIP archives, not renamed CSV files. Existing CSV exports retain their formula-injection escaping and include the new disbursement counts.

Totals include every exported row, not just the visible page. They are fixed to the exported selection; changing Excel's own filters does not recalculate those fixed values. Money is calculated from the existing report/receipt data in exact minor units. Excel's 15-significant-digit limit is handled explicitly: larger exact totals become literal decimal text rather than losing cents. Their currency is identified by the sheet/scope. Ordinary monetary cells have two-decimal currency formats. Exports never sum different currencies into one monetary total.

Downloads show preparation, success and error states. Existing server-controlled `can_export_reports` and the source module/reporting capability are checked before preparation and again immediately before releasing a workbook. A denied or failed check prevents download. Printing checks authorization again when Print is pressed. Previously downloaded files cannot be recalled; permission checks do not provide copy protection for data a user has already legitimately read.

## Clients Receiving Loans

The report summary and compact dashboard summary show **Clients Receiving Loans** and **Loans issued in period** separately. The first counts distinct internal Client IDs among matching loans with actual principal disbursed during the selected inclusive activity dates; the second counts those loans. Multiple loans to the same Client contribute one Client. Old loans can contribute outstanding balances without contributing to either period count. Currency, Client/Man#, department, designation, disbursement and as-of status filters apply through the existing report engine. The count appears in relevant Excel, CSV and printable reports. The dashboard hides it without loan-view access; detailed Reports access authorizes its financial summary.

The existing database persists issued loans only: previews and abandoned review forms create no loan rows. It has no posted draft, cancellation or voided-disbursement state. This feature does not invent such states. Settled and written-off loans were still actually disbursed and count when their dates and selected filters match. A future disbursement-void model must explicitly update this count and the financial reporting engine together. Legacy inferred-date/history notices remain in place.

## Expense exports and printing

**Expenses** now offers date, currency, search, exact category and current-status filters, plus **Export Expenses to Excel**, **Export Expenses to PDF** and **Print Expenses** for permitted users. Apply draft filters before exporting. Screen totals and downloads use the same complete filtered records across all pages.

Expense period activity follows the existing Financial Reports policy:

- **Paid in period:** original payments whose expense dates fall inside the inclusive range.
- **Reversed in period:** original expense amounts reversed on business posting dates inside that range.
- **Net expenses in period:** paid minus reversed, which can be negative.

A reversal of an older expense appears even if its original payment date is outside the selected range. An expense reversed after the period still contributes its original period payment; status is explicitly labelled **current**, not historical. Itemization shows payment/reversal dates and amounts so these differences can be reconciled. For example, ZMW 7.25 paid minus ZMW 1.01 reversed is ZMW 6.24 net. Shared expenses remain business-level and are not allocated to Clients. These expense exports do not calculate Net Profit; the existing exact-period expense/loss coverage certification is still required in Financial Reports.

PDF downloads are real PDF files with embedded fonts, landscape A4 tables, wrapped descriptions, repeated headers and page numbering. Print Expenses opens a dedicated preview, rechecks permission at print time, omits navigation/forms, repeats headers where the browser supports it and uses readable light print styling. PDF export is independent of the operating system's Save as PDF dialog. Print cancellation/saving remains controlled by the browser.

Expense reads are bounded to 10,000 records per selected currency, fetched in API pages using the normal Supabase 1,000-row configuration. Exceeding the bound produces an error instead of truncated totals. Projects with a custom lower Data API row cap need that configuration reconciled or a separately reviewed server snapshot/streaming implementation. Date/search filtering then uses the full loaded currency selection. Large-ledger streaming and simultaneous multi-page update consistency are not newly guaranteed; refresh the screen before exporting new activity. Specialized scripts outside the bundled Roboto glyph coverage need additional PDF fonts; Excel preserves Unicode text. Hosted capacity, other browsers and specialized print drivers remain separate acceptance checks.

## Repayment period definitions

Choose **Today**, **This Week** (Monday through today), **This Month** (first day through today), or **Custom Date Range**. Boundaries use the business date in **Africa/Lusaka**, and both dates are inclusive. Filtering uses `payment_date`, with the existing business-date fallback for legacy receipts, never loan creation/disbursement dates. The same period, search and single currency control rows, totals and Excel export, and page selection resets when the period changes.

This screen is **receipt history by payment date and current posting status**. Reversed receipts remain visible with zero current effect; totals include currently posted receipts only. Unknown legacy principal/interest allocations display **Not recorded** instead of fabricated income. **Financial Reports** remains the accounting-period view: it recognizes reversals and linked replacements on their effective posting dates. These different views are labelled explicitly. Principal receipts are capital recovery, never profit; received interest is separate from expected interest, expenses, losses and certified Net Profit.

## Repeating validation

Use the existing Node 24/npm/Docker/Chromium setup. The PDF text checks additionally require Poppler; on Ubuntu/Debian:

```sh
sudo apt-get update
sudo apt-get install -y poppler-utils
npm ci
npm run verify
sha256sum --check docs/MIGRATIONS.sha256
```

CI installs Poppler for these read-only fictional PDF checks. Its test setup change does not alter Vercel deployment settings. There is no configured lint command; TypeScript and Prettier are used without claiming an ESLint/Biome pass.

Unit tests verify distinct Client counts versus loan counts, period/currency filters, exact sums, week/month/year/leap-day boundaries, payment-date filtering and missing allocations, XLSX round trips, literal text/Man#, freezes/filter/totals/date formats, and high-precision text fallback. Browser tests reconcile a 22-Client filtered loan workbook to ZMW 22,000 disbursed and a 26-expense selection to ZMW 6.24 net, verify all export pages, PDF Unicode text and actual file signatures, print isolation, repayment filtering, revoked downloads and revoked access to an open print preview. Existing RLS, session, concurrency, recovery, import and financial tests remain in the full gate. Fixtures never contact a hosted project.

### Verified locally — 2026-11-14

`npm run verify` passed TypeScript, **267 unit/SQL tests**, **11 real PostgreSQL tests**, **40 production browser tests**, **107 authenticated browser tests** and the production build. A final workbook-width refinement passed another production build, TypeScript, all six new unit tests and all four new authenticated export/period cases. `npm audit --omit=dev --audit-level=high` reported zero known production dependency vulnerabilities.

The downloaded PDF and Chromium print output were also inspected as rendered pages. Both contained all 26 selected expense rows across three pages, repeated table headers, and no text outside the page bounds. These fictional local checks do not verify hosted Supabase/Vercel configuration, remote CI results, physical printers or other browser engines. This batch does not change hosted settings or manually deploy; the owner retains control of the existing GitHub deployment integration.
