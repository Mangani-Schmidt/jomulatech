# Deployment, backup and recovery

The owner manages the existing Vercel deployment. This change delivers source through GitHub without performing hosted database, backup, restore or provider configuration operations. Follow provider procedures against explicitly identified projects. Keep real Client data out of development fixtures and CI.

## Local startup and configuration

From the checkout, use Node 24 (`nvm use` if nvm is installed):

```sh
cd /workspace/loan-app
npm ci --cache /tmp/loan-npm-cache --no-fund --no-audit
cp -n .env.example .env.local
npm run dev -- --hostname 127.0.0.1 --port 3000
```

`cp -n` preserves an existing environment file. The example leaves both public Supabase values empty, so a new environment opens the public landing page; choose **Explore demo** for the fictional read-only workspace. Existing shell or `.env.local` values can select a project: review the intended environment before running with real credentials. To disable business connections irrespective of those values:

```sh
NEXT_PUBLIC_SUPABASE_URL= NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY= npm run dev -- --hostname 127.0.0.1 --port 3000
```

Stop the development process before using the same port for a local production-mode run:

```sh
npm run build
npm run start -- --hostname 127.0.0.1 --port 3000
```

In a second terminal, `curl --fail --silent --output /dev/null http://127.0.0.1:3000` checks HTTP availability. Ctrl-C stops the process. Public Supabase values must be set correctly **before the build**; changing them only at server startup does not change the browser bundle. The browser suite builds an explicitly forced demo; rebuild with your intended values after running that suite before starting a connected application.

For a configured development/staging project, replace both empty values in `.env.local` with that project's URL and public publishable key, apply migrations and configure Auth following [README](../README.md#local-setup), and provision the first Administrator through the trusted bootstrap. Never add a service-role key or database password to Next.js environment files. Neither PostgreSQL nor the Supabase CLI is required for the read-only demo; local Docker and Chromium are required for the full tests.

## Supabase deployment preparation

Use a separate non-production project for acceptance. The documented migration path uses the Supabase SQL editor, so it does not depend on an unconfigured local CLI:

1. Record the chosen project, database version, region, Auth policy and migration baseline. Back up any existing ledger before changing it.
2. For a fresh project, submit `001_ledger.sql` through `015_imports_and_client_lifecycle.sql` in numeric order, one entire file at a time. Apply only unapplied files for an existing ledger. Record file checksums and success/failure outside sensitive application logs. Do not rerun an applied migration or continue after a failure; review the transaction outcome first. Migration 001 should be submitted as one transaction when using a client without atomic multi-statement execution.
3. Keep the Data API enabled for the `public` application schema with its RLS/grants. `auth` is provider-managed and must not be exposed as an application API schema. No Storage bucket, Realtime subscription, service-role application credential or scheduled worker is required by this release.
4. Configure email/password login, email confirmation, provider rate limits and production SMTP. Set **Minimum password length = 6** (Auth configuration `password_min_length: 6`); this hosted setting has not been read or changed here. Set Site URL to the deployment origin and allow exact `/login` signup-confirmation and `/security` recovery URLs for intended deployment/local origins. Preserve other provider protections. Follow [the authentication acceptance checklist](AUTHENTICATION.md#hosted-acceptance). Test actual reset/confirmation links and TOTP enrollment/challenge before optionally enabling the business MFA policy. Signups alone grant no business access. Use a trusted confirmed Auth identity for first-Administrator provisioning; assign existing staff identities through User Management. Disable open registration for a private business after onboarding.
5. Run the [read-only recovery checks](../supabase/verification/recovery-checks.sql) as a trusted database administrator. Then test with real staging Auth sessions for each role and another business. Administrative SQL checks bypass RLS; they do not replace authenticated access tests.

The repo's sixteen numeric migration files are the source of truth. If adopting Supabase CLI migration tracking, explicitly initialize its configuration and reconcile any SQL-editor-applied history using the provider's migration guidance before using `db push`; the repository does not supply an initialized CLI stack. Never run `db reset` against an existing ledger.

## Vercel release preparation

After deployment authorization, import the application repository and select its application directory as the Vercel Root Directory (repository root when this checkout is the repository). Use the Next.js preset, Node 24, Install Command `npm ci`, and Build Command `npm run build`. Leave the default Next.js output directory; this app requires server Route Handlers and is not a static export. Excel parsing routes explicitly use the Node.js runtime.

Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` for each intended environment. Preview must use a separate staging project; do not point preview branches at production. Do not add database passwords or service-role keys. Confirm the deployment environment is connected to the intended project rather than the read-only demo. Set Supabase Site URL/confirmation origins for the chosen domain and rebuild after changing public values.

Before enabling real use, exercise the largest supported imports (2 MB compressed, 500 rows) on the chosen Vercel plan and verify upload/body, memory and duration limits; local parser tests do not establish hosted capacity. Test no-store import responses, confirmation email delivery, current settings, role denial, second-business isolation, stale previews, receipts, printed reports and exports. Review CSP if using a custom Supabase domain; the current `connect-src` supports the standard Supabase project domains. No deployment job is configured in CI.

Keep the last accepted application release and its compatible migration set. To roll back an application release, first establish database compatibility, then redeploy the known release with the correct environment values. Do not drop tables, remove financial history or run reverse migrations as an automatic rollback. Database changes generally require a forward fix; a backup restore is an incident action with a potential data-loss window, not routine deployment rollback.

## Backup policy and scope

Choose the required **recovery point objective (RPO)**, maximum acceptable data loss, and **recovery time objective (RTO)**, maximum acceptable outage, with the business before taking real funds. They have not been agreed or measured. As a proposal for review, enable provider PITR at a retention/restore-point granularity meeting the chosen RPO, retain an independent encrypted backup according to business/legal policy, back up before each schema change, and drill restoration at least quarterly and after major schema/auth changes. Verify the project's actual Supabase plan, backup retention and PITR entitlements; do not assume the free tier provides recoverable backups.

| Item                                | What must be retained/recovered                                                                                                                                                                                                                                                                            |
| ----------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| PostgreSQL application              | All 20 tables, original UUIDs and Auth references, money/allocations, audit rows, import batches/rows, request keys, immutable references/sequences, constraints, indexes, views, functions, RLS, grants and migration history. CSV/report exports are not backups.                                        |
| Supabase Auth and database platform | Real Auth users/identities and their stable UUIDs, required platform roles/permissions, supported extensions and provider-managed configuration. Use Supabase's supported database backup/restore procedure; a `public`-only dump is insufficient. Do not recreate staff identities with new UUIDs.        |
| Service configuration               | Auth settings, redirect allowlists, templates/SMTP configuration, signing/key management procedure, rate limits, network restrictions and any deployed integrations. Keep secret values in the approved secret manager, outside this repo. A database backup alone does not recreate all service settings. |
| Application and hosting             | Exact Git/source release, lockfile, migration checksums, Node version, Vercel project/domain/environment configuration and approved rollback release. Hosting settings are not a database backup.                                                                                                          |
| Original files / Storage            | Original import XLSX binaries are not retained by the app. Preserve them separately if required. If future Supabase Storage is added, back up the object bytes separately; database storage metadata is not the objects.                                                                                   |

Use the Supabase dashboard's database backup/PITR controls and the [official backup guidance](https://supabase.com/docs/guides/platform/backups) for the project's plan. For independent logical backups/moving projects, use the [provider's supported CLI backup and restore procedure](https://supabase.com/docs/guides/platform/migrating-within-supabase/backup-restore); record the exact CLI/PostgreSQL versions, schema scope and restore dependencies. Generic `pg_dump` does not capture cluster roles, Auth service settings, object storage or external secrets; `--no-owner` restores may need explicit platform/schema access prerequisites. Do not copy the local test Auth stub into a real project.

Keep backups encrypted at rest/in transit in restricted storage outside the checkout, application logs, browser reports and CI artifacts. Keep decryption keys and a second authorized recovery operator available independently of the primary Supabase/Vercel accounts. Alert on backup failures and age, verify checksums/readability, document retention/deletion, and record the most recent successful restore drill. `.gitignore` is a guard against accidental commits, not backup access control. Database owners bypass RLS; restrict backup access as strongly as the live ledger.

## Recovery procedure

1. **Identify and authorize.** Record the incident, exact source project, last good backup/time, target project, affected application release, expected RPO loss window and operator approval. Stop writes across all staff/apps and API access using the approved provider maintenance controls; a web maintenance page alone does not block direct Supabase RPCs. Preserve the damaged state/available logs securely for investigation.
2. **Recover in isolation first.** Restore the chosen backup/PITR point to an explicitly identified isolated project where the provider supports it; otherwise follow the provider's supported recovery path with a reviewed recovery plan. Never experiment on the only live ledger. Disable outbound email, webhooks, payment integrations and schedulers in the recovery environment. The app has no payment integration today, but provider Auth email still needs control.
3. **Rebuild required context.** Restore supported platform roles, schema access, extensions and Auth records with original UUIDs before dependent application data, following the provider ordering. Restore the saved application schema/data together with grants/policies/functions and migration history; do not apply all migrations again to an already-restored schema. Recover service/hosting configuration separately. Do not blindly grant broad privileges to make errors disappear.
4. **Reconcile.** Run the read-only checks; compare trusted pre-incident counts and per-currency balances/allocations, receipt references/status, outstanding principal/interest, expenses/losses, original actors/timestamps, audit histories, import results and financial request keys. Validate constraints/indexes and loan/payment/expense reference sequences. Inspect historical statements as well as current totals. A table-count match is insufficient. The check file raises on missing RLS, direct financial write grants, invalid allocations or mismatched balances; it does not prove every aspect of security or historical completeness.
5. **Test actual access and retries.** Use authorized recovery-project Auth accounts for every role, another business and an unassigned/deactivated identity. Verify permitted reads and denied direct writes/privileged RPCs; confirm default terms and restored receipt/reversal history. On fictional recovery records only, verify new unique references and settlement and that an already-posted request ID cannot post again. Sign in with fresh sessions after recovery; old tokens/credentials may require provider-managed revocation/rotation depending on the incident.
6. **Account for the lost interval.** Reconcile cash/bank records and receipts after the recovery point before re-entering anything. An idempotency key that existed only after the selected backup is absent after recovery and cannot prevent replay. Obtain reasoned authorization and retain evidence for reconstructed transactions; never bulk replay payments/imports or silently adjust balances.
7. **Cut over only after acceptance.** Record reconciliation and measured restore duration, obtain explicit release authorization, set the intended application's public project values and rebuild, verify Auth origins and permissions, then re-enable approved access. Monitor errors and backups. Retain the pre-recovery evidence and close the incident with actual RPO/RTO results.

## Safe local recovery drill

With dependencies, local Docker and Chromium prepared, `npm run verify` runs the complete gate. To run only the fictional PostgreSQL backup round trip:

```sh
node --test tests/postgres/recovery.test.mjs
```

The drill creates two independent nonce-labelled PostgreSQL 17 containers, with no network, published ports or persistent mounts. It applies all migrations to the source, posts fictional loans/receipts/reversals/expenses, certifies a reporting period and enables an MFA policy using explicitly fictional signed-claim fixtures, dumps `public` plus the test Auth stub into memory, and restores only into the second verified fresh database. Supabase-style role/schema prerequisites are explicitly represented. It compares all application rows and effective permissions/policies, matches reports, checks cross-business reads/direct-write denial, retries a saved payment request without duplication, settles the loan and cleans up both containers. It accepts no target URL or credentials and cannot be used to restore a hosted project.

This is a local SQL recovery check. Provider PITR, real Auth identity recovery, external backup storage/decryption, outbound-service suppression and measured hosted recovery time remain unverified until the authorized staging drill.

## Acceptance record before production

The release owner must record the source revision, dependency/migration checksums, local and remote-CI results, staging Supabase/Vercel project identities, migration history, all-role/second-business acceptance, email delivery and import capacity results, accepted financial rules, backup/PITR configuration, last hosted restore evidence and actual RPO/RTO, monitoring/support ownership, and deployment/live-data authorization. None of the hosted items are completed by saving this document. See [Delivery](DELIVERY.md) for feature-level limitations.

## Upgrading the existing connected deployment

The owner’s GitHub → Vercel connection already exists. For a project current through 012, back up and apply **013_user_permissions.sql**, then **014_inactivity_sessions.sql** before enabling the new application. Older projects apply only unapplied files in numeric order through 014. Follow [the current upgrade and hosted acceptance instructions](SESSIONS.md#upgrade-the-existing-deployment). A Vercel build cannot upgrade Supabase. This batch pushes source to main only; it does not run a manual deployment or change deployment settings.

For this import/lifecycle release, apply 015 after 014 and follow [the current import and retention guide](IMPORTS-AND-CLIENT-LIFECYCLE.md). Client deletion starts disabled until explicitly granted. Backups include client_identities; never remove immutable audit evidence.

## Fresh session registration upgrade

Apply [016_fresh_session_status.sql](../supabase/migrations/016_fresh_session_status.sql) after 015 if it has not already been applied. It corrects the first-touch response to use the inserted/updated session row rather than a stable-function snapshot. It preserves existing financial records, session revocation, permissions and inactivity limits. Follow the same backup/target/history safeguards above; a Vercel build does not apply SQL. Verify a fresh staging login registers an active application session, and that touching a revoked session cannot revive it. No hosted migration was applied during the navigation-performance work.
