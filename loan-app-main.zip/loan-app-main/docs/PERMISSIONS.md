> Current update: migration **015** adds delegated Import Clients and explicitly granted eligible Client deletion. Follow [the import/lifecycle guide](IMPORTS-AND-CLIENT-LIFECYCLE.md) after 014. It supersedes the original role ceilings for imports and the earlier deletion prohibition below. Financial action ceilings remain unchanged.

# User Management, module access and enforcement

Apply migrations [013_user_permissions.sql](../supabase/migrations/013_user_permissions.sql) and [014_inactivity_sessions.sql](../supabase/migrations/014_inactivity_sessions.sql), in that order, after 012. Back up first. GitHub/Vercel does not apply these files to Supabase. Neither migration changes Client IDs, financial values, allocations or loan terms. See [upgrade and session instructions](SESSIONS.md#upgrade-the-existing-deployment).

## Granting access

**User Management** (`/users`) and **Audit Logs** (`/audit-logs`) have separate navigation items, view grants and pages. The old `/administration` URL redirects to `/users`. Audit Logs provides the existing searchable, paginated immutable business history.

User Management lists existing business members. To **Add User**, first invite/register and confirm an Auth identity using Supabase's existing approval process, then enter its Auth user ID. This creates an audited business membership, not a new Auth account or an automatic Administrator. No service-role key is used. An identity already assigned to another business cannot be moved through this screen.

**Edit User** prefills the stored role, active status and all saved module/action checkboxes. Module views and sensitive actions are separate. Changing the role removes actions outside that role's eligibility; it does not silently grant its full preset. **Use role defaults** explicitly selects the preset. Review all checkboxes, record a 5–500 character reason, and confirm **Save approved access**. Optimistic revision checking prevents overwriting a concurrent edit. Reloading the user list does not advance an existing form draft's revision; select Edit User again to prefill and review newer grants. Request IDs make retries idempotent. A failed save retains the draft and explains the error.

Only an active **Administrator** with **View User Management** and **Add users and change permissions** may save access; recent MFA assurance is also required when the business policy enables it. A view-only reader cannot edit. Administrator status alone does not bypass unchecked actions. An Administrator cannot remove their own active Administrator/User Management access. Creating a membership and changing permissions produces immutable actor/time/reason/before/after audit entries in the same transaction.

Migration 013 backfills every existing member's role permissions to match prior access, including read/export access. It retains revisions, activity status and original membership timestamps, and records migration audit entries. Subsequent permission changes require explicit approved edits. Migration 015 permits explicitly granted deletion only with retention checks and preserved audit identity; authorized Client correction access permits archival.

## Permission source and dependencies

PostgreSQL `has_capability` is authoritative; `loan_defaults` returns the effective flags. The browser never infers live grants from roles, signup metadata or local presets. `lib/permissions.ts` supplies labels and form presets, tested against SQL. Missing flags deny access.

| Module or operation                                                | Effective capability                                                                                                   |
| ------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------- |
| Dashboard, Clients, Client Loan History, Repayments                | `can_view_dashboard`, `can_view_clients`, `can_view_loans`, `can_view_repayments`                                      |
| Excel Imports, Reports, Expenses, Settings                         | `can_view_imports`, `can_view_reports`, `can_view_expenses`, `can_view_settings`                                       |
| User Management, Audit Logs                                        | `can_view_users`, `can_view_audit`                                                                                     |
| Register/correct/deactivate Clients                                | `can_register_clients`; Administrator or Loan Officer, plus Clients view                                               |
| Originate loans                                                    | `can_originate`; Administrator or Loan Officer, plus loan view                                                         |
| Post Repayment Received                                            | `can_post_repayments`; Administrator or Cashier, plus repayment view                                                   |
| Import Clients or disbursements                                    | `can_import`; Administrator, Imports view, Client registration and Clients view; loan imports also require origination |
| Post expenses / change defaults                                    | `can_manage_expenses` / `can_manage_settings`; Administrator plus the corresponding module view                        |
| Financial adjustments, reversals, write-offs and coverage approval | `can_approve_adjustments`; Administrator plus the affected financial module view                                       |
| User permissions / business MFA policy / rate override             | `can_manage_users` / `can_manage_security` / `can_override_rate`; Administrator, with MFA assurance where enabled      |
| Financial CSV/XLSX exports and printing                            | `can_export_reports`, plus access to the source document/report                                                        |

All roles remain eligible for the original core read/report/export presets; Administrators can explicitly narrow or expand module views. Sensitive-action ceilings remain role based. Optional MFA protects privileged actions and Administrator views of Settings, Imports, User Management and Audit Logs. Own Account security remains available to verified unassigned users for recovery, password change and authenticator setup; business policy changes still require their separate grant.

Posting requires its corresponding module even if its action checkbox is selected. A replacement receipt additionally requires repayment-posting permission; reversal alone requires adjustment approval and repayment view. Dependencies are described beside the checkboxes and enforced by SQL; an incomplete combination grants no effective posting access. Loan-rate overrides require origination as well as override authorization, preserve the global default, and keep existing reasons/audits.

## UI and server boundaries

Navigation, mobile menus, dashboard cards, quick actions, lookups, record controls and exports use these flags. Views without financial access show no financial summary. Loan cards need loan view; repayment/income cards need repayment view. On initial entry or identity changes, protected forms do not mount or start their module queries before access is verified. Direct forbidden URLs/hash routes render Access denied. Login selects the permitted requested destination or the first accessible module; it falls back to Account security when no business module is available. There are no public dashboard shortcuts or authenticated Explore Demo prompts.

Route access verifies Supabase identity and fresh database capabilities. During same-account rechecks the previously verified workspace remains visible and inert/read-only, preserving drafts until access is confirmed. A status message explains the check; denied or failed verification removes protected content. Initial and changed-identity access still withhold it. Account/session changes and inactivity remove the sensitive workspace. Exports/printing recheck their action permission immediately before use. Previously downloaded files cannot be recalled. Permission changes apply to subsequent database/API requests; they do not recall completed downloads or abort an already-authorized transaction holding the membership lock.

Supabase RLS scopes data to an active business and an active application session. Direct financial mutations remain forbidden. Privileged RPCs use explicit capabilities, restricted execution grants and fixed safe search paths. Import parsing/preview/confirmation endpoints require `imports` before work; history and saved diagnostics require `view_imports`. Public templates contain fictional or empty data only. All import responses remain no-store.

Some data is necessarily shared by approved workflows: loan balances require receipt allocations and Client identities, and repayment/report views require loan histories. Consequently either loan, repayment or report view permits the underlying Client/financial source rows under RLS. Clients-only access cannot read loans/repayments. Expense rows require Expenses or Reports access. Settings and Audit Logs have their separate policies. Receipt, statement and report RPCs additionally check their applicable view requirements. Module grants are workflow boundaries, **not per-column secrecy between the shared financial source rows**. A staff member permitted a financial history can query its necessary source rows through the authenticated API. Shared expenses remain business-level; financial definitions are unchanged.

The app retains the Supabase browser SDK model. Internal HTTP pages initially contain an access-check shell; they do not embed financial records. This is not a cookie-authenticated middleware migration or an HTTP 403 page response. Database/API operations enforce permissions independently of browser visibility, including requests made outside the interface. [Application sessions](SESSIONS.md) add server-clock inactivity checks without changing database credentials or provider policy.

## Verification and hosted acceptance

The local final-schema tests cover custom grants, role ceilings, self-lockout protection, audit entries, stale edits, idempotency, anonymous execution denial, cross-business RLS and direct financial-write denial. The migration test compares existing financial rows before/after 013/014 and verifies all four old role presets remain available. Browser contracts cover saved checkbox prefill/editing, read-only users, separate Audit Logs, denied direct navigation, loading flashes, granular dashboard cards and first-module login. Existing role, import, financial and export tests remain in `npm run verify`.

Before hosted use, apply the two migrations, verify real JWT `session_id` claims and Auth lifecycle/MFA, and exercise customized roles and another business against actual APIs. No hosted database or Auth configuration was changed here. Fictional browser Auth responses do not verify hosted provider behavior.

[Navigation performance and cache boundaries](PERFORMANCE.md) document parallel fresh checks, coordinated return refreshes and actor/session/business/grant-scoped display snapshots. No permission decision is cached to authorize a new module or bypass backend checks.
