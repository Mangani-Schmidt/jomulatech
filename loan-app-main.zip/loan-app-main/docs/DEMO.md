# Explore demo and dummy Excel workbook

Choose **Explore demo** in the public landing page footer or workspace header, or open `/demo` on the deployed site. No account is needed. The demo uses fictional Clients, loans, repayments and reports; it also works when Supabase is configured for the business workspace.

Demo navigation stays under `/demo`, including read-only `/demo/settings`. **Exit demo** returns to the public landing page, where verified signed-in staff can choose **Open Dashboard**. Opening or exploring the demo does not initialize Supabase Auth, refresh a token, fetch business records, sign out staff or create database records. Existing business sign-in state is retained. The business workspace at `/dashboard` continues to enforce authentication, active business roles and database rules.

## Download the workbook

In **Excel Imports**, choose **Download dummy Excel sheet**. The file is also available at `/samples/lendtrack-dummy-clients.xlsx` on the deployed site, or [in this repository](../public/samples/lendtrack-dummy-clients.xlsx).

The first worksheet contains these exact import columns:

| Column        | Sample content                                                              |
| ------------- | --------------------------------------------------------------------------- |
| `no#`         | Source row numbers 1–10; never a Client ID.                                 |
| `name`        | Demo Client 01 through Demo Client 10.                                      |
| `man#`        | Text values 009001–009010 with leading zeros.                               |
| `department`  | Fictional Finance, Operations, Education, Health and Transport assignments. |
| `designation` | Fictional job titles.                                                       |
| `amount`      | Positive example amounts totalling ZMW 21,250.00.                           |

The second worksheet contains instructions. Only the first worksheet is imported. All identities and financial examples are fictional.

## Practice without uploading or saving

1. Open **Explore demo → Excel Imports → Try sample import**. This loads the bundled sample rows. Arbitrary file uploads remain disabled in the public demo.
2. Explicitly choose **Client Register Import** or **Loan Disbursement Import**. Register mode ignores amount and shows no loan obligation. Loan mode requires a disbursement date, the supported one-time flat interest for the entire term and the days-after-disbursement due-date rule; the demo prefills 10% and 30 days.
3. Review the six column mappings and select **Validate and preview**. The original mapping produces 10 accepted rows, zero rejected and zero unchanged against the demo register. Incorrect mappings can show validation errors, including duplicate Man#.
4. Inspect the preview and optionally download the validation report. At 10% in loan mode, the sample principal is ZMW 21,250.00, interest is ZMW 2,125.00 and total obligation is ZMW 23,375.00. This is one charge for the entire term, not monthly or compounded interest.
5. Check the review confirmation and choose **Confirm 10 accepted rows**. The result explicitly says **Demo confirmation complete**. This is a walkthrough: the Client register, loans, financial records and business import history are unchanged. Reloading resets it.

## Test a real upload in development or staging

Use a configured non-production business with an authorized Administrator. Download the workbook, open **Excel Imports**, choose the mode, select the downloaded `.xlsx`, review the mapping and preview, then explicitly confirm only after checking the result. **Client Register Import** is the initial choice when only testing Client registration. **Loan Disbursement Import** creates actual loan records in that selected test business; provide the date, rate and due rule. Existing server-side validation, conflict detection and duplicate-submission protection remain authoritative. Do not place fictional records in the live business.

## Reproduce and verify

`lib/import-sample.json` is the single source for both the workbook generator and the presentation-only demo preview. With Node 24 and installed dependencies, run:

```sh
npm run sample:generate
npm run verify
```

The generator writes only `public/samples/lendtrack-dummy-clients.xlsx` and connects to no database. Tests parse the shipped binary with the real bounded XLSX parser, preserve all text Man# values, confirm totals, stage and confirm it through the final SQL schema, and verify replay creates no extra loans. Browser tests cover the connected-deployment demo on mobile and desktop, isolated settings/navigation, both import modes, confirmation, public download and preservation of an expired fictional Auth session without refresh or upload requests.

This feature adds no database migration or environment variable. The existing business workspace still requires all previously delivered migrations. The Vercel connection deploys the new `/demo` routes and public workbook from the pushed source.

Verified on **2026-11-13**: `npm run verify` passed type checking, 183 unit/SQL tests, nine real PostgreSQL tests, 12 production-demo browser tests and 26 connected-deployment browser-contract tests, including a production build. Migration checksums and whitespace checks passed. Hosted deployment acceptance remains with the owner.
