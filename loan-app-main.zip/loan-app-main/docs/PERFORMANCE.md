# Navigation and tab-return performance

This batch targets measured browser delays without changing financial calculations, saved terms, authentication providers, business grants, RLS, database connections or existing records. The performance changes add no dependency, environment variable, deployment setting or financial SQL. During delivery, remote main advanced to `978d46eba9b50a3ecabecdfd8b9a7560e0073c93`; its persistent access provider, client navigation, login guards and migration **016** were merged and preserved. Apply any unapplied migrations through **016** in order. [016_fresh_session_status.sql](../supabase/migrations/016_fresh_session_status.sql) corrects first-session registration without changing financial records; Vercel does not apply it automatically.

## Method and limits

Measurements were captured **before application changes** at commit `63e0775fc8072433eef9dd899ca099f78b41696a`, then repeated against the final integrated application on 2026-11-14. After results include the preserved upstream navigation/session changes; the comparison does not attribute their benefits solely to this batch. Both versions used the same local Next production-build configuration, desktop Chromium, fictional Auth/ledger/report fixtures and **150 ms synthetic latency for each provider request**. Each version used three fresh browser contexts and the same workflow sequence. The final comparison ran without other test/build work in parallel. It did not connect to Supabase or Vercel.

**Ready** measures the scripted navigation until the expected screen/summary becomes visible; it includes browser actionability and test polling overhead. **Settled** also waits for the observed provider requests and a 40 ms quiet check. Neither is a production Core Web Vitals measurement or an SLO. Three samples are diagnostic, not a large statistical study. Tab return uses a deterministic bubbling visibility event (including the actual Supabase SDK handler) and paired focus event, without recording human activity. A frame probe records time when the previous heading disappears. It cannot survive a full document navigation; those before values are unavailable.

Raw request counts, samples, timing details and methodology are committed in [navigation.json](performance/navigation.json). Each full-document reload resets browser resource timing; the raw final-document JavaScript counters are diagnostic and must not be compared as cumulative journey bundle totals.

## Before and after

Medians in milliseconds:

| Workflow                        | Before ready | After ready | Before settled | After settled |
| ------------------------------- | -----------: | ----------: | -------------: | ------------: |
| Initial Dashboard               |        1,634 |       1,083 |          1,681 |         1,127 |
| Clients                         |          868 |         285 |            911 |           329 |
| Client Loan History             |          866 |         286 |            909 |           330 |
| Repayments                      |          863 |         291 |            906 |           337 |
| Reports                         |          711 |         274 |            758 |           446 |
| Tab return                      |          358 |         194 |            403 |           237 |
| Expenses route                  |          980 |         276 |          1,028 |           447 |
| Return from Expenses to Clients |        1,002 |         350 |          1,048 |           471 |

Clients/Loans/Repayments/Reports had approximately 317–334 ms of hidden content during permission rechecks before; every after sample recorded **0 ms** for these rechecks. Tab return had 308–315 ms hidden before and **0 ms** after. New route entry can still briefly show its access shell while that route is verified; no protected data is rendered before initial or changed-identity verification.

| Provider request                         | Before                                            | After                                                                          |
| ---------------------------------------- | ------------------------------------------------- | ------------------------------------------------------------------------------ |
| Initial Dashboard report snapshot        | 2                                                 | 1                                                                              |
| Initial Dashboard total provider calls   | 6                                                 | 5                                                                              |
| Each Clients/Loans/Repayments navigation | 1 Auth user + 1 defaults/capabilities, sequential | Same fresh checks, parallel after the session has passed identity verification |
| Reports navigation                       | Auth + defaults + 1 report                        | Same checks and fresh report; cached display during refresh                    |
| Tab return                               | 1 Auth + 2 session status + 1 defaults            | 1 Auth + 1 status + 1 defaults + 1 ledger + 1 report, coordinated in parallel  |
| Standalone route navigation              | Full document reload and session bootstrap        | Client routing; existing session boundary retained                             |

Tab return intentionally adds fresh ledger/report reads: the old path checked access while leaving balances unchanged. Deduplicating status requests and removing the request waterfall makes the refreshed result quicker despite that extra work. No security check was removed to obtain these results.

## Root causes and targeted changes

- `useVerifiedAccessSnapshot` previously waited for `auth.getUser` before requesting capabilities. For a previously verified session, these fresh authenticated server checks now run in parallel. First/changed identities still pass `getUser` before any membership read, including forged cached-session attempts. A transient identity-ordering marker is cleared on blocked sessions, identity changes and logout; it stores no permissions and never replaces a fresh check. Same-session SDK notifications with the same credentials share an in-flight check; rotated credentials supersede old pending checks instead of being suppressed. Navigation still explicitly verifies identity and current database capabilities. New identities wait for application-session activation before a business RPC can run. An activation event covers fast/batched SDK transitions.
- `AccessGate` previously hid the whole workspace on same-account rechecks. It now keeps the last verified content visible and **inert/read-only**, with a compact status message. Loan dialogs remain visible but inert while checking. Initial entry, changed identity, denied access and failed identity verification still withhold protected content. A failed session-status request stays locked across further focus events and supports explicit Retry. No cached capability decision grants access to a new route.
- Initial ledger completion previously incremented the report's invalidation revision and started a second report request. Initial loading and subsequent invalidations are separate. After successful mutations, ledger and report snapshots refresh in parallel after the write has committed.
- Focus and visibility previously issued two session-status calls. They share one in-flight request. Local elapsed inactivity is checked before deduplication, so a suspended expired tab still logs out immediately. Focus, polling, status reads, data reads and token refresh remain non-activity.
- An already verified, locally unexpired session now coordinates fresh permission, session-status and financial reads on return. Every business request still independently enforces its JWT, database session clock, capabilities and RLS. Session-check failure hides the workspace; revoked/expired server sessions cannot read financial data. No resume event is emitted for locally expired sessions or initial unverified entry.
- The merged root-level `VerifiedAccessProvider` retains session metadata between protected routes and clears it at public boundaries. Each new route still waits for fresh identity/capability verification; own Account security can open after identity verification without waiting for business membership. Its defaults lookup is shared rather than repeated by the page.
- Workspace/sidebar links now use Next client routing instead of full document navigation. Prefetch is disabled for these permission-controlled links; route access gates still run on entry. The shared session boundary and downloaded modules survive route transitions.
- A small component-owned report cache preserves a recent **display** while the matching fresh filtered RPC runs. It is keyed by verified Auth user/session, business, effective grants and exact filters/currency. It holds at most six selections for up to 60 seconds, stays in memory only and is cleared on teardown/scope change. Old responses cannot populate a different scope. This is not an authoritative financial cache or an authorization TTL.
- Report exports wait for successful refresh; failures remove balance cards and offer retry rather than showing zero. Ledger refreshes retain existing rows with loading feedback, clear on error/identity change, and disable exports during the refresh. An open Client financial summary shows an unavailable state with an in-place retry rather than falsely implying an empty loan history. Affected data refreshes after successful mutations; navigation refreshes an interactive ledger older than 30 seconds, and tab return refreshes it regardless of age. Delayed exports are cancelled if the captured access scope changes or the source view unmounts.
- Expenses also reload on tab return. Receipt/statement posting, reversals, import transactions, manual Man# lookup and financial confirmation semantics are unchanged.

## Database, pagination and bundle investigation

[queries.json](performance/queries.json) records a separate **isolated PostgreSQL 17.12** profile with all sixteen migrations, authenticated RLS, 120 fictional Clients, 480 loans and 480 repayments. The fixture was created in the existing harness-owned, networkless tmpfs-only container, using actual origination/repayment functions, and destroyed afterwards. It never accepts a database URL or hosted credentials.

Three warm execution samples, excluding the first warm-up, were:

| Query                                    | Execution time range |
| ---------------------------------------- | -------------------: |
| `loan_defaults()`                        |     10.750–12.950 ms |
| `ledger_snapshot()`                      |     52.996–69.523 ms |
| `report_source_filtered(...)`            |   221.189–254.403 ms |
| Representative Client identity predicate |       1.334–1.490 ms |
| Representative report loan selection     |       2.928–3.616 ms |

The predicate/selection plans used existing owner indexes. The index inventory contains 61 public indexes. Function EXPLAIN measures their total execution and buffers; it does not identify individual nested statements. These local results do not establish production selectivity, concurrency or absence of every useful index. No index migration is justified solely by this small fixture; the measured duplicate aggregate request was eliminated instead.

The interactive ledger still uses one consistent, bounded full snapshot (up to 20,000 Clients, 20,000 loans and 100,000 receipts). Display pagination does not turn this into server pagination. Reports already have server-side filters and bounds; expense retrieval remains bounded as documented in [report exports](REPORT-EXPORTS.md). Larger ledgers need a separately reviewed server-pagination/aggregate design that preserves global Man# lookup, balances, statements and export reconciliation. This release does not silently truncate these datasets or claim to solve arbitrary-scale loading.

Existing Excel and PDF generation libraries are dynamically imported when requested. No unnecessary financial calculations were moved to server-rendered public HTML, no provider auth model was rewritten and no bundle-size improvement is claimed. Client routing avoids repeated document bootstrap; hosted compression, CDN/chunk timing, database query plans, region placement, provider cold starts and actual network latency require hosted measurements.

## Repeating the checks

Use the existing Node 24/npm/Docker/Chromium/Poppler setup. Do not run another Next dev/build server in this checkout concurrently:

```sh
npm ci
PERFORMANCE_OUTPUT_DIR=/tmp/lendtrack-performance npm run test:performance
npm run profile:queries
npm run verify
sha256sum --check docs/MIGRATIONS.sha256
git diff --check
```

The performance server forces the fictional provider for both build and startup. The network boundary blocks every unmocked external request. The query profiler only creates its own isolated test container. No local configuration file, service-role key, real Client record or production seed is needed.

`navigation-refresh-auth.spec.ts` covers initial request behavior, visible read-only rechecks, cached report refresh/error/retry, disabled stale exports, coalesced tab return with actual fresh balances, actor changes, delayed-export cancellation, rotated-token races, session-outage retry, failed Client summaries and client route persistence. `scoped-snapshot.test.ts` covers identity/session/business/grant/filter isolation, expiry, bounded selections, clearing and late foreign-scope responses. The full existing suite checks earlier delivery batches independently, including real PostgreSQL RLS, financial concurrency and recovery. The repository has no configured linter; TypeScript/Prettier results are reported separately.

## Verification result

On **2026-11-14**, the integrated source passed `npm run verify`: TypeScript, **274 unit/SQL tests**, **12 real PostgreSQL checks**, **48 production browser tests**, **120 authenticated browser tests** and the production build. The three-sample production benchmark and isolated PostgreSQL profile also passed. Formatting, changed Markdown targets, all sixteen immutable migration checksums and whitespace passed; no linter is configured. No regressions were observed in the executed prior-batch checks. These are local results, not hosted acceptance.
