import { beforeEach, afterEach, it, expect, vi } from "vitest";
import {
  INACTIVITY_MS,
  WARNING_MS,
  inactivityRemaining,
  validActivity,
  saveActivity,
  readActivity,
  setSessionBinding,
  assertActiveSession,
  sessionFetch,
  SESSION_EXPIRED_EVENT,
} from "../lib/session-activity";
let values: Map<string, string>, expired: number;
beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-11-14T10:00:00Z"));
  values = new Map();
  expired = 0;
  vi.stubGlobal("localStorage", {
    getItem: (k: string) => values.get(k) ?? null,
    setItem: (k: string, v: string) => values.set(k, v),
  });
  const window = new EventTarget();
  window.addEventListener(SESSION_EXPIRED_EVENT, () => expired++);
  vi.stubGlobal("window", window);
  setSessionBinding(null);
});
afterEach(() => {
  setSessionBinding(null);
  vi.useRealTimers();
  vi.unstubAllGlobals();
});
it("uses a 15 minute deadline and a one minute warning without extending the deadline on checks", () => {
  expect(INACTIVITY_MS).toBe(900000);
  expect(WARNING_MS).toBe(60000);
  const at = Date.now();
  expect(inactivityRemaining(at, at + 840000)).toBe(60000);
  expect(inactivityRemaining(at, at + 900000)).toBe(0);
  expect(inactivityRemaining(at, at + 900001)).toBe(0);
});
it("accepts only bounded timestamps for the current session", () => {
  const at = Date.now();
  expect(validActivity({ session: "a", at }, "a")).toBe(true);
  for (const value of [
    null,
    { session: "b", at },
    { session: "a", at: Infinity },
    { session: "a", at: at + 60000 },
    { session: "a", at, ended: "yes" },
  ])
    expect(validActivity(value, "a")).toBe(false);
});
it("protects requests against expired or ended cross-tab state even before a timer runs", async () => {
  const fetch = vi.fn().mockResolvedValue(new Response("[]"));
  vi.stubGlobal("fetch", fetch);
  const at = Date.now();
  setSessionBinding({ session: "a", at, blocked: false });
  await sessionFetch("https://fictional.invalid/rest/v1/clients");
  expect(fetch).toHaveBeenCalledTimes(1);
  vi.setSystemTime(at + 900000);
  const denied = await sessionFetch(
    "https://fictional.invalid/rest/v1/clients",
  );
  expect(denied.status).toBe(401);
  expect(fetch).toHaveBeenCalledTimes(1);
  expect(expired).toBe(1);
});
it("synchronizes shared activity while retaining the original expiry for polling/Auth requests", async () => {
  const at = Date.now();
  setSessionBinding({ session: "a", at, blocked: false });
  vi.setSystemTime(at + 840000);
  saveActivity({ session: "a", at: Date.now() });
  expect(readActivity("a")?.at).toBe(Date.now());
  assertActiveSession();
  const fetch = vi.fn().mockResolvedValue(new Response("{}"));
  vi.stubGlobal("fetch", fetch);
  await sessionFetch("https://fictional.invalid/auth/v1/token");
  await sessionFetch(
    "https://fictional.invalid/rest/v1/rpc/app_session_status",
  );
  vi.setSystemTime(at + 840000 + 900000);
  expect(() => assertActiveSession()).toThrow("inactivity");
  expect(expired).toBe(1);
});
it("an ended session takes precedence over a fresh timestamp", () => {
  setSessionBinding({ session: "a", at: Date.now(), blocked: false });
  saveActivity({ session: "a", at: Date.now(), ended: true });
  expect(() => assertActiveSession()).toThrow("Log in again");
});

it("initial verification rejects protected data requests without revoking the new login", async () => {
  const fetch = vi.fn().mockResolvedValue(new Response("{}"));
  vi.stubGlobal("fetch", fetch);
  for (const binding of [null, { session: "fresh", at: 0, blocked: true }]) {
    setSessionBinding(binding);
    const response = await sessionFetch(
      "https://fictional.invalid/rest/v1/rpc/loan_defaults",
    );
    expect(response.status).toBe(401);
    expect(expired).toBe(0);
  }
  expect(fetch).not.toHaveBeenCalled();
  const at = Date.now();
  setSessionBinding({ session: "fresh", at, blocked: false });
  const allowed = await sessionFetch(
    "https://fictional.invalid/rest/v1/rpc/loan_defaults",
  );
  expect(allowed.status).toBe(200);
  expect(expired).toBe(0);
  expect(fetch).toHaveBeenCalledTimes(1);
});
