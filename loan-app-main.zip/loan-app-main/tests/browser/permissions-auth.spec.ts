import { capabilitiesForRole } from "../../lib/permissions";
import { test, expect, type Page } from "./fixtures";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { demoDefaults } from "../../lib/interest";
import { demoReportSource } from "../../lib/demo";
const owner = "11111111-1111-4111-8111-111111111111";
type Role = "administrator" | "loan_officer" | "cashier" | "viewer";
function capabilities(role: Role) {
  const admin = role === "administrator";
  return {
    ...capabilitiesForRole(
      role as "administrator" | "loan_officer" | "cashier" | "viewer",
    ),
    can_read: true,
    role,
    is_admin: admin,
    can_override_rate: admin,
    can_register_clients: admin || role === "loan_officer",
    can_originate: admin || role === "loan_officer",
    can_post_repayments: admin || role === "cashier",
    can_import: admin,
    can_manage_expenses: admin,
  };
}
async function workspace(page: Page, role: Role) {
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "fictional-signature",
  ].join(".");
  const session = {
    access_token: token,
    refresh_token: "fictional-refresh",
    token_type: "bearer",
    expires_at: Math.floor(Date.now() / 1000) + 3600,
    expires_in: 3600,
    user: {
      id: owner,
      email: "fictional-permissions@example.test",
      aud: "authenticated",
      role: "authenticated",
      app_metadata: {},
      user_metadata: { is_admin: true },
      created_at: "2026-01-01T00:00:00Z",
    },
  };
  await page.addInitScript((session) => {
    if (!sessionStorage.getItem("permissions-fixture-seeded")) {
      sessionStorage.setItem("permissions-fixture-seeded", "true");
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify(session),
      );
    }
    (window as unknown as { __prints: number }).__prints = 0;
    window.print = () => {
      (window as unknown as { __prints: number }).__prints++;
    };
  }, session);
  const state = {
    role,
    readDenied: false,
    hold: null as Promise<void> | null,
    queries: [] as string[],
  };
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const path = new URL(route.request().url()).pathname;
      state.queries.push(path);
      if (path === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      if (path.endsWith("/loan_defaults")) {
        if (state.hold) await state.hold;
        if (state.readDenied)
          return route.fulfill({
            status: 403,
            json: {
              code: "42501",
              message: "Permission denied for this role: read",
            },
          });
        return route.fulfill({
          json: { ...demoDefaults, capabilities: capabilities(state.role) },
        });
      }
      if (path.endsWith("/has_capability")) {
        expect([
          "export_reports",
          "view_reports",
          "reporting",
          "view_loans",
          "view_repayments",
        ]).toContain(route.request().postDataJSON().p_action);
        return route.fulfill({ json: !state.readDenied });
      }
      if (path.endsWith("/ledger_snapshot"))
        return route.fulfill({
          json: {
            clients: demoReportSource.clients,
            loans: demoReportSource.loans,
            repayments: demoReportSource.repayments,
          },
        });
      if (path.endsWith("/report_source_filtered"))
        return route.fulfill({ json: demoReportSource });
      if (path.endsWith("/expenses")) return route.fulfill({ json: [] });
      if (path.endsWith("/settings_audit")) return route.fulfill({ json: [] });
      throw new Error("Unexpected fictional request: " + path);
    }),
  );
  return { state, session };
}
for (const width of [390, 820, 1440])
  for (const role of [
    "administrator",
    "loan_officer",
    "cashier",
    "viewer",
  ] as const)
    test(`${role} sees only database-permitted navigation and actions at ${width}px`, async ({
      page,
    }) => {
      await page.setViewportSize({ width, height: 900 });
      await workspace(page, role);
      await page.goto("/dashboard");
      await expect(page.locator("[data-metric]")).toHaveCount(4);
      if (width === 390)
        await page
          .getByRole("button", { name: "Open navigation", exact: true })
          .click();
      const nav = page.getByRole("navigation", { name: "Main navigation" });
      const flags = capabilities(role);
      await expect(
        nav.getByRole("group", { name: "Administration", exact: true }),
      ).toHaveCount(flags.is_admin ? 1 : 0);
      for (const [name, allowed] of [
        ["New Loan", flags.can_originate],
        ["Excel Imports", flags.can_import],
        ["Settings", flags.is_admin],
        ["User Management", flags.is_admin],
      ] as const) {
        await expect(nav.getByRole("link", { name, exact: true })).toHaveCount(
          allowed ? 1 : 0,
        );
      }
      for (const name of [
        "Dashboard",
        "Clients",
        "Repayments",
        "Reports",
        "Expenses",
        "Account Security",
      ])
        await expect(
          nav.getByRole("link", { name, exact: true }),
        ).toBeVisible();
      const quick = page.getByRole("region", { name: "Quick actions" });
      await expect(
        quick.getByRole("button", { name: "New Loan", exact: true }),
      ).toHaveCount(flags.can_originate ? 1 : 0);
      await expect(
        quick.getByRole("button", { name: "Add Client", exact: true }),
      ).toHaveCount(flags.can_register_clients ? 1 : 0);
      await expect(
        quick.getByRole("button", {
          name: "Record Repayment Received",
          exact: true,
        }),
      ).toHaveCount(flags.can_post_repayments ? 1 : 0);
    });
for (const [role, path] of [
  ["viewer", "/settings"],
  ["loan_officer", "/administration"],
  ["cashier", "/dashboard#new-loan"],
  ["viewer", "/dashboard#new-loan"],
  ["loan_officer", "/dashboard#excel-imports"],
] as const)
  test(`${role} direct navigation to ${path} is denied before restricted forms or lookup results mount`, async ({
    page,
  }) => {
    const { state } = await workspace(page, role);
    await page.goto(path);
    await expect(
      page.getByRole("heading", { name: "Access denied", exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("combobox", {
        name: "Search by Man# or Client Name",
        exact: true,
      }),
    ).toHaveCount(0);
    await expect(
      page.getByRole("button", { name: "Save future defaults" }),
    ).toHaveCount(0);
    await expect(
      page.getByRole("button", { name: "Save approved role" }),
    ).toHaveCount(0);
    await expect(page.locator('input[type="file"]')).toHaveCount(0);
    expect(
      state.queries.some((path) =>
        /settings_audit|user_roles|import_batches|originate_loan/.test(path),
      ),
    ).toBe(false);
  });
test("delayed capability loading never flashes privileged modules, even with Administrator signup metadata", async ({
  page,
}) => {
  const { state } = await workspace(page, "viewer");
  let release!: () => void;
  state.hold = new Promise<void>((resolve) => {
    release = resolve;
  });
  await page.goto("/dashboard");
  await expect(
    page.getByRole("heading", { name: "Checking your access…" }),
  ).toBeVisible();
  await expect(
    page.getByRole("navigation", { name: "Main navigation" }),
  ).toHaveCount(0);
  await expect(page.locator("[data-metric]")).toHaveCount(0);
  release();
  await expect(page.locator("[data-metric]")).toHaveCount(4);
  await expect(
    page.getByRole("link", { name: "Settings", exact: true }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("button", { name: "New Loan", exact: true }),
  ).toHaveCount(0);
  expect(
    state.queries.filter((path) => path.endsWith("/loan_defaults")),
  ).toHaveLength(1);
});
test("navigation rechecks a changed role before showing a formerly permitted module", async ({
  page,
}) => {
  const { state } = await workspace(page, "loan_officer");
  await page.goto("/dashboard");
  await expect(page.locator("[data-metric]")).toHaveCount(4);
  state.role = "viewer";
  await page
    .getByRole("navigation", { name: "Main navigation" })
    .getByRole("link", { name: "New Loan", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Access denied", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("combobox", {
      name: "Search by Man# or Client Name",
      exact: true,
    }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: "New Loan", exact: true }),
  ).toHaveCount(0);
});
test("same-account permission rechecks keep the workspace visible and preserve a loan draft", async ({
  page,
}) => {
  const { state, session } = await workspace(page, "loan_officer");
  await page.goto("/dashboard");
  await page.getByRole("button", { name: "New Loan", exact: true }).click();
  await page
    .getByRole("combobox", {
      name: "Search by Man# or Client Name",
      exact: true,
    })
    .fill("00124");
  await page.getByRole("dialog").getByRole("option").first().click();
  await page.getByLabel("Amount Disbursed (ZMW)", { exact: true }).fill("1000");
  await page.getByLabel("Loan term (days)", { exact: true }).fill("45");
  let release!: () => void;
  state.hold = new Promise<void>((resolve) => {
    release = resolve;
  });
  await page.evaluate((session) => {
    const channel = new BroadcastChannel("sb-register-tests-auth-token");
    channel.postMessage({ event: "TOKEN_REFRESHED", session });
    channel.close();
  }, session);
  await expect(page.locator(".access-refresh")).toContainText(
    "Checking your business permissions",
  );
  await expect(page.locator("dialog[open]")).toHaveAttribute("inert", "");
  // A refresh should no longer cover or unmount an already verified module.
  // Existing drafts remain visible while the authoritative permission request
  // is pending; server RLS still rejects newly revoked mutations.
  await expect(
    page.getByLabel("Amount Disbursed (ZMW)", { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("status", { name: "Checking your business permissions…" }),
  ).toHaveCount(0);
  release();
  await expect(
    page.getByLabel("Amount Disbursed (ZMW)", { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByLabel("Amount Disbursed (ZMW)", { exact: true }),
  ).toHaveValue("1000");
  await expect(page.getByLabel("Client name", { exact: true })).toHaveValue(
    "Chanda Mwansa",
  );
  await expect(
    page.getByLabel("Loan term (days)", { exact: true }),
  ).toHaveValue("45");
  state.hold = null;
  await page
    .getByRole("button", {
      name: "Reload current defaults (resets rate and term)",
      exact: true,
    })
    .click();
  await expect(
    page.getByLabel("Loan term (days)", { exact: true }),
  ).toHaveValue("30");
  await expect(
    page.getByLabel("Amount Disbursed (ZMW)", { exact: true }),
  ).toHaveValue("1000");
});
for (const action of [
  "Download Client CSV",
  "Download .xlsx report",
  "Preview printable report",
  "Print filtered report",
]) {
  test(`revoked read access blocks ${action} and closes the cached workspace`, async ({
    page,
  }) => {
    const { state } = await workspace(page, "viewer");
    const downloads: string[] = [];
    page.on("download", (d) => downloads.push(d.suggestedFilename()));
    await page.goto("/dashboard#reports");
    const report = page.getByRole("region", { name: "Financial reporting" });
    await expect(report.locator("tbody tr")).not.toHaveCount(0);
    if (action === "Print filtered report") {
      await report
        .getByRole("button", { name: "Preview printable report" })
        .click();
      await expect(
        page.getByRole("dialog").getByRole("button", { name: action }),
      ).toBeVisible();
    }
    state.readDenied = true;
    await page.getByRole("button", { name: action, exact: true }).click();
    await expect(
      page.getByRole("heading", {
        name: "Business access pending",
        exact: true,
      }),
    ).toBeVisible();
    await expect(
      page.getByRole("navigation", { name: "Main navigation" }),
    ).toHaveCount(0);
    await expect(page.locator("[data-metric],table")).toHaveCount(0);
    await expect(page.getByRole("dialog")).toHaveCount(0);
    expect(downloads).toEqual([]);
    expect(
      await page.evaluate(
        () => (window as unknown as { __prints: number }).__prints,
      ),
    ).toBe(0);
  });
}

test("a Viewer cannot retry a formerly permitted pending transaction and its request reference is retained", async ({
  page,
}) => {
  await workspace(page, "viewer");
  const request = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";
  await page.addInitScript(
    ({ owner, request }) => {
      localStorage.setItem(
        "lendwell:pending-posting:" + owner,
        JSON.stringify({
          version: 1,
          id: request,
          operation: "post_repayment",
          body: { p_loan_id: "fictional" },
          createdAt: "2026-01-01T00:00:00Z",
        }),
      );
    },
    { owner, request },
  );
  await page.goto("/expenses");
  await expect(
    page
      .getByRole("alert")
      .filter({ hasText: "do not allow retrying this transaction" }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Recover pending transaction" }),
  ).toHaveCount(0);
  expect(
    await page.evaluate(
      (owner) => localStorage.getItem("lendwell:pending-posting:" + owner),
      owner,
    ),
  ).toContain(request);
});

test("module links preserve the document and verified permissions while rechecking in the background", async ({
  page,
}) => {
  const { state } = await workspace(page, "administrator");
  await page.goto("/dashboard");
  await expect(page.locator("[data-metric]")).toHaveCount(4);
  await page.evaluate(() => {
    (window as Window & { __navigationMarker?: number }).__navigationMarker = 1;
  });
  const before = state.queries.filter((p) =>
    p.endsWith("/loan_defaults"),
  ).length;
  await page
    .getByRole("navigation", { name: "Main navigation" })
    .getByRole("link", { name: "Settings", exact: true })
    .click();
  await expect(page).toHaveURL(/\/settings$/);
  await expect(
    page.getByRole("heading", { name: "Interest settings" }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () =>
        (window as Window & { __navigationMarker?: number }).__navigationMarker,
    ),
  ).toBe(1);
  await expect(
    page.getByText("Checking your business permissions…"),
  ).toHaveCount(0);
  await expect
    .poll(
      () => state.queries.filter((p) => p.endsWith("/loan_defaults")).length,
    )
    .toBeGreaterThan(before);
  await page
    .getByRole("navigation", { name: "Main navigation" })
    .getByRole("link", { name: "Dashboard", exact: true })
    .click();
  await expect(page).toHaveURL(/\/dashboard/);
  expect(
    await page.evaluate(
      () =>
        (window as Window & { __navigationMarker?: number }).__navigationMarker,
    ),
  ).toBe(1);
});

for (const width of [390, 820, 1440])
  for (const theme of ["light", "dark"])
    test(`grouped sidebar order and account logout at ${width}px in ${theme}`, async ({
      page,
    }, testInfo) => {
      await page.setViewportSize({ width, height: 1050 });
      await page.addInitScript(
        (theme) => localStorage.setItem("lendtrack:appearance", theme),
        theme,
      );
      await workspace(page, "administrator");
      await page.goto("/dashboard");
      await expect(page.locator("[data-metric]")).toHaveCount(4);
      if (width === 390)
        await page
          .getByRole("button", { name: "Open navigation", exact: true })
          .click();
      const nav = page.getByRole("navigation", { name: "Main navigation" });
      await expect(nav.locator(".nav-section-heading")).toHaveText([
        "Overview",
        "Lending Operations",
        "Finance & Reporting",
        "Administration",
      ]);
      await expect(nav.getByRole("link")).toHaveText([
        "Dashboard",
        "Clients",
        "Loan History",
        "New Loan",
        "Repayments",
        "Expenses",
        "Reports",
        "Excel Imports",
        "User Management",
        "Audit Logs",
        "Settings",
        "Account Security",
      ]);
      await expect(
        nav.getByRole("link", { name: "Dashboard", exact: true }),
      ).toHaveAttribute("aria-current", "page");
      await expect(
        nav.getByRole("link", { name: "New Loan", exact: true }),
      ).not.toHaveAttribute("aria-current");
      const account = nav.getByRole("group", { name: "Account", exact: true });
      await expect(
        account
          .getByRole("link", { name: "Account Security", exact: true })
          .locator("svg"),
      ).toHaveCount(1);
      const logout = account.getByRole("button", {
        name: "Sign Out",
        exact: true,
      });
      expect((await logout.boundingBox())!.height).toBeGreaterThanOrEqual(44);
      await logout.scrollIntoViewIfNeeded();
      await page
        .locator(width === 390 ? ".mobile-sidebar" : ".desktop-sidebar")
        .screenshot({
          path: testInfo.outputPath(`sidebar-${width}-${theme}.png`),
          style: "nextjs-portal { display: none !important; }",
        });
      await logout.click();
      await expect(page).toHaveURL(/\/login\?reason=signed-out/);
      await expect(page.locator("[data-metric]")).toHaveCount(0);
      expect(
        await page.evaluate(() =>
          localStorage.getItem("sb-register-tests-auth-token"),
        ),
      ).toBeNull();
    });
