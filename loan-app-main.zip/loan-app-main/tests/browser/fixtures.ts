import { test as base, expect } from "@playwright/test";
import { testAppOrigin, permittedBrowserRequest } from "../support/test-safety";
export { expect };
export type { Page } from "@playwright/test";
type Boundary = {
  blockedOrigins: string[];
  expectBlocked: (origin: string) => void;
};
export const test = base.extend<{ networkBoundary: Boundary }>({
  networkBoundary: [
    async ({ context, baseURL }, use) => {
      const origin = testAppOrigin(baseURL),
        blockedOrigins: string[] = [],
        expected = new Set<string>();
      // Page-level fictional Supabase mocks take precedence. Any unmocked remote
      // request is aborted: even a mistakenly configured live project gets no data.
      await context.route("**/*", async (route) => {
        if (permittedBrowserRequest(route.request().url(), origin)) {
          await route.continue();
          return;
        }
        blockedOrigins.push(new URL(route.request().url()).origin);
        await route.abort("blockedbyclient");
      });
      await use({
        blockedOrigins,
        expectBlocked: (origin) => expected.add(origin),
      });
      expect(
        blockedOrigins.filter((origin) => !expected.has(origin)),
        "Unmocked external requests were blocked; fixtures must never contact a hosted project.",
      ).toEqual([]);
    },
    { auto: true },
  ],
});
