import { test, expect } from "./fixtures";
import { navigate } from "./navigation";
import { chooseTheme, openThemeMenu } from "./theme";
test("theme choice carries through connected sign-in and Account security pages", async ({
  page,
}) => {
  await page.goto("/");
  await chooseTheme(page, "dark");
  await page.getByRole("link", { name: "Log In", exact: true }).first().click();
  await expect(page.getByLabel("Email", { exact: true })).toHaveCSS(
    "background-color",
    "rgb(17, 30, 48)",
  );
  await page.goto("/security");
  await expect(page).toHaveURL(/\/login\?next=/);
  await expect(
    (await openThemeMenu(page)).getByRole("menuitemradio", {
      name: "Dark",
      exact: true,
    }),
  ).toHaveAttribute("aria-checked", "true");
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await expect(
    page.getByRole("heading", { name: "Log In", exact: true }),
  ).toBeVisible();
});
for (const width of [390, 1440])
  test(`Explore demo is available on a connected deployment and keeps navigation isolated at ${width}px`, async ({
    page,
  }) => {
    await page.setViewportSize({ width, height: 900 });
    await page.goto("/");
    await page.getByRole("link", { name: "Explore demo", exact: true }).click();
    await expect(page).toHaveURL(/\/demo\/?$/);
    await expect(page.getByText("You’re exploring a demo.")).toBeVisible();
    await navigate(page, "Clients");
    await expect(page).toHaveURL(/\/demo\/?#clients$/);
    await expect(page.locator("tbody tr")).toHaveCount(6);
    await page
      .getByRole("button", {
        name: "Client Statement for Chanda Mwansa",
        exact: true,
      })
      .click();
    await expect(page.getByRole("dialog").locator(".print-area")).toContainText(
      "Chanda Mwansa",
    );
    await page.keyboard.press("Escape");
    await navigate(page, "Settings");
    await expect(page).toHaveURL(/\/demo\/settings$/);
    await expect(
      page.getByLabel("Default interest rate for entire term (%)", {
        exact: true,
      }),
    ).toBeDisabled();
    await navigate(page, "Clients");
    await expect(page).toHaveURL(/\/demo\/?#clients$/);
    await expect(page.locator("tbody tr")).toHaveCount(6);
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth),
    ).toBeLessThanOrEqual(width);
    await page.getByRole("link", { name: "Exit demo", exact: true }).click();
    await expect(page).toHaveURL("http://127.0.0.1:3002/");
    await expect(
      page.getByRole("heading", {
        name: "Keep your lending business on track.",
        exact: true,
      }),
    ).toBeAttached();
    await expect(page.locator("tbody tr")).toHaveCount(0);
  });
for (const mode of ["clients", "loans"])
  test(`sample ${mode} import requires preview and confirmation with no Auth, upload or database requests`, async ({
    page,
  }) => {
    const mutations: string[] = [];
    const privateImports: string[] = [];
    page.on("request", (r) => {
      if (r.method() !== "GET") mutations.push(r.url());
      if (
        /\/api\/imports\/(inspect|preview|commit|report|history)(?:\?|$)/.test(
          r.url(),
        )
      )
        privateImports.push(r.url());
    });
    await page.addInitScript(() =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: "expired.fictional.token",
          refresh_token: "fictional-refresh",
          expires_at: 1,
          user: { id: "11111111-1111-4111-8111-111111111111" },
        }),
      ),
    );
    await page.goto("/demo/#excel-imports");
    const session = await page.evaluate(() =>
      localStorage.getItem("sb-register-tests-auth-token"),
    );
    await page
      .getByRole("button", { name: "Try sample import", exact: true })
      .click();
    await expect(
      page.getByRole("combobox", { name: "Import mode", exact: true }),
    ).toHaveValue("");
    await expect(
      page.getByLabel("Excel workbook", { exact: true }),
    ).toBeDisabled();
    await page
      .getByRole("combobox", { name: "Import mode", exact: true })
      .selectOption(mode);
    if (mode === "loans") {
      await expect(
        page.getByLabel("Flat interest (%)", { exact: true }),
      ).toHaveValue("10");
      await expect(
        page.getByLabel("Term in days", { exact: true }),
      ).toHaveValue("30");
    }
    await page
      .getByRole("button", { name: "Validate and preview", exact: true })
      .click();
    await expect(page.locator(".import-counts")).toContainText("10 accepted");
    await expect(page.locator(".import-preview-table tbody tr")).toHaveCount(
      10,
    );
    await expect(page.locator(".import-preview-table tbody")).toContainText(
      "009001",
    );
    await expect(
      page.getByRole("button", {
        name: "Confirm 10 accepted rows",
        exact: true,
      }),
    ).toBeDisabled();
    await page.getByRole("checkbox", { name: /I reviewed all rows/ }).check();
    await page
      .getByRole("button", { name: "Confirm 10 accepted rows", exact: true })
      .click();
    await expect(page.locator(".import-saved")).toContainText(
      "No Client, loan or financial records were saved",
    );
    await expect(
      page.getByRole("button", {
        name: "Confirm 10 accepted rows",
        exact: true,
      }),
    ).toHaveCount(0);
    expect(
      await page.evaluate(() =>
        localStorage.getItem("sb-register-tests-auth-token"),
      ),
    ).toBe(session);
    expect(mutations).toEqual([]);
    expect(privateImports).toEqual([]);
    await navigate(page, "Clients");
    await expect(page.locator("tbody tr")).toHaveCount(6);
    await expect(page.locator("tbody")).not.toContainText("Demo Client 01");
  });
test("import template downloads without login on a connected deployment", async ({
  page,
}) => {
  await page.goto("/demo/#excel-imports");
  const downloaded = page.waitForEvent("download");
  await page
    .getByRole("link", { name: "Download Import Template", exact: true })
    .click();
  const file = await downloaded;
  expect(file.suggestedFilename()).toBe("lendtrack-import-template.xlsx");
  expect(await file.failure()).toBeNull();
});
