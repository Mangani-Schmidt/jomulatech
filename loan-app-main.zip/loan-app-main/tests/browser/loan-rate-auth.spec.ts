import { capabilitiesForRole } from "../../lib/permissions";
import { test, expect, type Page } from "./fixtures";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { demoClients } from "../../lib/demo";
import { demoDefaults, type LoanDefaults } from "../../lib/interest";
import { money } from "../../lib/domain";
async function workspace(page: Page, editable = true) {
  const owner = "11111111-1111-4111-8111-111111111111";
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "fictional-signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "fictional-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "fictional-rate@example.test",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      ),
    { owner, token },
  );
  const state = {
    defaults: {
      ...demoDefaults,
      settings: {
        ...demoDefaults.settings,
        default_rate_bps: 725,
        default_term_days: 45,
        revision: 4,
      },
      capabilities: {
        ...capabilitiesForRole(editable ? "administrator" : "loan_officer"),
        is_admin: editable,
        can_override_rate: editable,
        role: editable ? "administrator" : "loan_officer",
      },
    } as LoanDefaults,
    attempts: [] as {
      p_details: Record<string, unknown>;
      p_confirm: boolean;
      p_request_id: string;
    }[],
    accepted: 0,
    settingsWrites: 0,
  };
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const path = new URL(route.request().url()).pathname;
      if (path === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({ json: state.defaults });
      if (path.endsWith("/ledger_snapshot"))
        return route.fulfill({
          json: { clients: demoClients, loans: [], repayments: [] },
        });
      if (path.endsWith("/report_source_filtered"))
        return route.fulfill({
          json: {
            generated_at: new Date().toISOString(),
            timezone: "Africa/Lusaka",
            clients: [],
            loans: [],
            repayments: [],
            terms_audit: [],
            status_audit: [],
            repayment_audit: [],
          },
        });
      if (path.endsWith("/save_interest_settings")) {
        state.settingsWrites++;
        return route.fulfill({ json: {} });
      }
      if (path.endsWith("/originate_loan")) {
        const body = route.request().postDataJSON();
        state.attempts.push(body);
        if (
          body.p_details.settings_revision !== state.defaults.settings.revision
        )
          return route.fulfill({
            status: 400,
            json: {
              code: "P0001",
              message: "Defaults changed. Reload and review current defaults.",
            },
          });
        state.accepted++;
        return route.fulfill({ json: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa" });
      }
      throw new Error("Unexpected fictional request: " + path);
    }),
  );
  return state;
}
async function open(page: Page) {
  await page.goto("/dashboard#new-loan");
  await page
    .getByRole("combobox", {
      name: "Search by Man# or Client Name",
      exact: true,
    })
    .fill("00124");
  await page.getByRole("option").first().click();
  await page.getByLabel("Amount Disbursed (ZMW)", { exact: true }).fill("1000");
}
async function post(page: Page) {
  await page.getByRole("button", { name: "Review Loan", exact: true }).click();
  await page
    .getByRole("region", { name: "Confirm New Loan" })
    .getByRole("checkbox")
    .check();
  await page.getByRole("button", { name: "Confirm Loan", exact: true }).click();
}
test("the latest Settings rate prefills a read-only loan rate without override permission and posts those actual terms", async ({
  page,
}) => {
  const state = await workspace(page, false);
  await open(page);
  const rate = page.getByLabel("Interest rate for entire term (%)", {
    exact: true,
  });
  await expect(rate).toHaveValue("7.25");
  await expect(rate).toHaveAttribute("readonly", "");
  await expect(
    page.getByText("Current Settings default: 7.25%", { exact: false }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Use default rate", exact: true }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("region", { name: "Loan obligation preview" }),
  ).toContainText(money(107250));
  await post(page);
  expect(state.attempts[0].p_details).toMatchObject({
    rate_bps: 725,
    settings_revision: 4,
    override_reason: "",
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    term_days: 45,
  });
  expect(state.settingsWrites).toBe(0);
});
test("an authorized per-loan rate can be reset without changing the rest of the draft, then confirmed with its audited reason", async ({
  page,
}) => {
  const state = await workspace(page);
  await open(page);
  const rate = page.getByLabel("Interest rate for entire term (%)", {
    exact: true,
  });
  await expect(rate).not.toHaveAttribute("readonly", "");
  await page.getByLabel("Loan term (days)", { exact: true }).fill("60");
  const date = await page
    .getByLabel("Disbursement date", { exact: true })
    .inputValue();
  await rate.fill("12.5");
  await expect(
    page.getByRole("button", { name: "Review Loan", exact: true }),
  ).toBeDisabled();
  await page
    .getByLabel("Rate override reason", { exact: true })
    .fill("Approved fictional Client exception");
  await expect(
    page.getByRole("region", { name: "Loan obligation preview" }),
  ).toContainText(money(112500));
  await page
    .getByRole("button", { name: "Use default rate", exact: true })
    .click();
  await expect(rate).toHaveValue("7.25");
  await expect(
    page.getByLabel("Loan term (days)", { exact: true }),
  ).toHaveValue("60");
  await expect(
    page.getByLabel("Amount Disbursed (ZMW)", { exact: true }),
  ).toHaveValue("1000");
  await expect(page.getByLabel("Client name", { exact: true })).toHaveValue(
    "Chanda Mwansa",
  );
  await expect(
    page.getByLabel("Disbursement date", { exact: true }),
  ).toHaveValue(date);
  await expect(
    page.getByLabel("Rate override reason", { exact: true }),
  ).toHaveCount(0);
  await rate.fill("12.50");
  await page
    .getByLabel("Rate override reason", { exact: true })
    .fill("  Approved fictional Client exception  ");
  await page.getByRole("button", { name: "Review Loan", exact: true }).click();
  const review = page.getByRole("region", { name: "Confirm New Loan" });
  await expect(review).toContainText("One-time flat interest");
  await expect(review).toContainText("The entire 60-day loan term");
  await expect(review).toContainText("Settings default at review");
  await expect(review).toContainText("7.25%");
  await expect(review).toContainText("12.50% · override for this loan");
  await review.getByRole("checkbox").check();
  await review
    .getByRole("button", { name: "Confirm Loan", exact: true })
    .click();
  expect(state.attempts[0].p_details).toMatchObject({
    rate_bps: 1250,
    term_days: 60,
    override_reason: "Approved fictional Client exception",
  });
  expect(state.defaults.settings.default_rate_bps).toBe(725);
  expect(state.settingsWrites).toBe(0);
});
test("invalid rates are rejected without truncation and supported zero, half-up and maximum charges remain exact", async ({
  page,
}) => {
  const state = await workspace(page);
  await open(page);
  const rate = page.getByLabel("Interest rate for entire term (%)", {
    exact: true,
  });
  for (const value of ["100.01", "1.001", "100.001", "1e2", "-1"]) {
    await rate.fill(value);
    await expect(rate).toHaveValue(value);
    await expect(rate).toHaveAttribute("aria-invalid", "true");
    await expect(
      page.getByRole("button", { name: "Review Loan", exact: true }),
    ).toBeDisabled();
    await expect(
      page.getByRole("region", { name: "Loan obligation preview" }),
    ).toHaveCount(0);
  }
  await rate.fill("0");
  await page.getByLabel("Rate override reason", { exact: true }).fill("abcd");
  await expect(page.locator(".form-error")).toContainText("5–500");
  await expect(
    page.getByRole("button", { name: "Review Loan", exact: true }),
  ).toBeDisabled();
  await page
    .getByLabel("Rate override reason", { exact: true })
    .fill("Approved fictional boundary-rate exception");
  for (const [rateValue, amount, interest, total] of [
    ["0", "1000", 0, 100000],
    ["50", "0.01", 1, 2],
    ["100", "1000", 100000, 200000],
  ] as const) {
    await rate.fill(rateValue);
    await page
      .getByLabel("Amount Disbursed (ZMW)", { exact: true })
      .fill(amount);
    const preview = page.getByRole("region", {
      name: "Loan obligation preview",
    });
    await expect(preview.locator("dd").nth(1)).toHaveText(money(interest));
    await expect(preview.locator("dd").nth(2)).toHaveText(money(total));
    await expect(
      page.getByRole("button", { name: "Review Loan", exact: true }),
    ).toBeEnabled();
  }
  expect(state.attempts).toHaveLength(0);
});
test("a changed global default requires a fresh review and never silently posts stale terms", async ({
  page,
}) => {
  const state = await workspace(page);
  await open(page);
  await page.getByRole("button", { name: "Review Loan", exact: true }).click();
  const review = page.getByRole("region", { name: "Confirm New Loan" });
  state.defaults = {
    ...state.defaults,
    settings: {
      ...state.defaults.settings,
      revision: 5,
      default_rate_bps: 1200,
    },
  };
  await review.getByRole("checkbox").check();
  await review
    .getByRole("button", { name: "Confirm Loan", exact: true })
    .click();
  await expect(page.locator(".form-error")).toContainText("Defaults changed");
  expect(state.accepted).toBe(0);
  await page
    .getByRole("button", { name: "Back to Loan Details", exact: true })
    .click();
  await page
    .getByRole("button", {
      name: "Reload current defaults (resets rate and term)",
      exact: true,
    })
    .click();
  await expect(
    page.getByLabel("Interest rate for entire term (%)", { exact: true }),
  ).toHaveValue("12");
  await expect(
    page.getByLabel("Amount Disbursed (ZMW)", { exact: true }),
  ).toHaveValue("1000");
  await page.getByRole("button", { name: "Review Loan", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Confirm Loan", exact: true }),
  ).toBeDisabled();
  await review.getByRole("checkbox").check();
  await review
    .getByRole("button", { name: "Confirm Loan", exact: true })
    .click();
  expect(state.accepted).toBe(1);
  expect(state.attempts[1].p_details).toMatchObject({
    rate_bps: 1200,
    settings_revision: 5,
    override_reason: "",
  });
  expect(state.settingsWrites).toBe(0);
});
test("an unsupported method in a malformed defaults response never produces an assumed flat-interest preview", async ({
  page,
}) => {
  const state = await workspace(page);
  state.defaults = {
    ...state.defaults,
    settings: { ...state.defaults.settings, calculation_method: "compound" },
  } as unknown as LoanDefaults;
  await open(page);
  await expect(page.locator(".form-error")).toContainText(
    "Unsupported interest calculation method or rate basis",
  );
  await expect(
    page.getByRole("region", { name: "Loan obligation preview" }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("button", { name: "Review Loan", exact: true }),
  ).toBeDisabled();
  expect(state.attempts).toHaveLength(0);
});
