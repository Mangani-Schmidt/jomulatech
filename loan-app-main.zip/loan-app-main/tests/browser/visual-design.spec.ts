import { test, expect } from "./fixtures";
import { navigate } from "./navigation";
import {
  buildReport,
  defaultReportFilters,
  reportAmountLabels,
  reportMoney,
} from "../../lib/reporting";
import { demoReportSource } from "../../lib/demo";
import { today } from "../../lib/domain";

test("Lendtrack branding appears in the workspace, statements and printable reports", async ({
  page,
}) => {
  await page.goto("/demo");
  await expect(page).toHaveTitle("Explore demo · LendTrack");
  await expect(
    page.getByRole("link", { name: "LendTrack home", exact: true }),
  ).toContainText("LendTrack");
  await expect(page.locator("body")).not.toContainText("Lendwell");
  await navigate(page, "Reports");
  await page
    .getByRole("button", { name: "Preview printable report", exact: true })
    .click();
  await expect(
    page.getByRole("dialog").getByRole("heading", {
      name: "LendTrack · Financial report",
      exact: true,
    }),
  ).toBeVisible();
  await page.emulateMedia({ media: "print" });
  await expect(
    page.getByRole("navigation", { name: "Main navigation" }),
  ).not.toBeVisible();
  await expect(
    page.getByRole("dialog").getByRole("heading", {
      name: "LendTrack · Financial report",
      exact: true,
    }),
  ).toBeVisible();
  await page.emulateMedia({ media: "screen" });
  await page
    .getByRole("button", { name: "Close report preview", exact: true })
    .click();
  await navigate(page, "Clients");
  await page
    .getByRole("button", {
      name: "Client Statement for Chanda Mwansa",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("dialog").locator(".document-header"),
  ).toContainText("LendTrack");
});

test("detailed reports retain every exact total and readable contrast", async ({
  page,
}) => {
  await page.goto("/demo");
  await navigate(page, "Reports");
  const expected = buildReport(demoReportSource, defaultReportFilters(today()));
  await page.getByText("More financial details", { exact: true }).click();
  const plainLabels: Record<string, string> = {
    disbursed: "Amount Disbursed",
    received: "Repayment Received",
    owed: "Clients still owe",
    interestReceived: "Interest collected",
  };
  for (const key of Object.keys(
    reportAmountLabels,
  ) as (keyof typeof reportAmountLabels)[]) {
    const card = page.locator(`[data-metric="${key}"]`);
    await expect(card.locator("span")).toHaveText(
      plainLabels[key] ?? reportAmountLabels[key],
    );
    await expect(card.locator("strong")).toHaveText(
      reportMoney(expected.totals[key], "ZMW"),
    );
  }
  for (const selector of [
    '[data-metric="disbursed"] > span',
    '[data-metric="owed"] > span',
    ".sidebar .nav-item.selected",
  ]) {
    const colors = await page.locator(selector).evaluate((el) => {
      let parent: Element | null = el,
        background = "";
      while (parent) {
        background = getComputedStyle(parent).backgroundColor;
        if (background !== "rgba(0, 0, 0, 0)" && background !== "transparent")
          break;
        parent = parent.parentElement;
      }
      return { foreground: getComputedStyle(el).color, background };
    });
    function luminance(value: string) {
      const [r, g, b] = value
        .match(/[\d.]+/g)!
        .slice(0, 3)
        .map(Number)
        .map((v) => {
          v /= 255;
          return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
        });
      return r * 0.2126 + g * 0.7152 + b * 0.0722;
    }
    const a = luminance(colors.foreground),
      b = luminance(colors.background);
    expect(
      (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05),
      selector,
    ).toBeGreaterThanOrEqual(4.5);
  }
});

test("primary actions and navigation provide both hover and keyboard focus feedback", async ({
  page,
}) => {
  await page.goto("/demo");
  const primary = page.getByRole("button", { name: "New Loan", exact: true });
  await expect(primary).toBeVisible();
  await primary.hover();
  await expect(primary).toHaveCSS("background-color", "rgb(6, 95, 70)");
  await page.mouse.move(0, 0);
  await primary.focus();
  await expect(primary).toBeFocused();
  await expect(primary).toHaveCSS("outline-style", "solid");
  await expect(primary).toHaveCSS("outline-width", "3px");
  await expect(primary).toHaveCSS("background-color", "rgb(6, 95, 70)");
  const clients = page
    .getByRole("navigation", { name: "Main navigation" })
    .getByRole("link", { name: "Clients", exact: true });
  await clients.hover();
  await expect(clients).toHaveCSS("background-color", "rgb(228, 237, 247)");
  await page.mouse.move(0, 0);
  await clients.focus();
  await expect(clients).toHaveCSS("outline-style", "solid");
  await expect(clients).toHaveCSS("background-color", "rgb(228, 237, 247)");
  await page.keyboard.press("Enter");
  await expect(
    page.getByRole("heading", { name: "Client Register", exact: true }),
  ).toBeVisible();
});

test.describe("touch usability", () => {
  test.use({ hasTouch: true, viewport: { width: 390, height: 844 } });
  test("Client actions and loan review work without hovering at phone width", async ({
    page,
  }) => {
    await page.goto("/demo/#clients");
    await page.getByRole("button", { name: "Add Client", exact: true }).tap();
    const dialog = page.getByRole("dialog");
    await expect(dialog.getByLabel("Man#", { exact: true })).toBeVisible();
    await dialog.getByRole("button", { name: "Cancel", exact: true }).tap();
    await page
      .getByRole("button", { name: "Open navigation", exact: true })
      .tap();
    await page
      .getByRole("navigation", { name: "Main navigation" })
      .getByRole("link", { name: "New Loan", exact: true })
      .tap();
    await page
      .getByRole("combobox", {
        name: "Search by Man# or Client Name",
        exact: true,
      })
      .fill("00124");
    await page.getByRole("option").tap();
    await page
      .getByLabel("Amount Disbursed (ZMW)", { exact: true })
      .fill("1000");
    await page.getByRole("button", { name: "Review Loan", exact: true }).tap();
    await expect(
      page.getByRole("button", { name: "Back to Loan Details", exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("button", { name: "Confirm Loan", exact: true }),
    ).toBeVisible();
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth),
    ).toBeLessThanOrEqual(390);
  });
});
