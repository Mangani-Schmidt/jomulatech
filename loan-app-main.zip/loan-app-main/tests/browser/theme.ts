import { expect, type Page } from "./fixtures";
export const themeButton = (page: Page) =>
  page.getByRole("button", { name: "Choose color theme", exact: true });
export async function openThemeMenu(page: Page) {
  const trigger = themeButton(page);
  await expect(trigger).toBeEnabled();
  if ((await trigger.getAttribute("aria-expanded")) !== "true")
    await trigger.click();
  const menu = page.getByRole("menu", { name: "Color theme", exact: true });
  await expect(menu).toBeVisible();
  return menu;
}
export async function chooseTheme(
  page: Page,
  value: "light" | "dark" | "system",
) {
  const menu = await openThemeMenu(page);
  await menu
    .getByRole("menuitemradio", {
      name: value[0].toUpperCase() + value.slice(1),
      exact: true,
    })
    .click();
  await expect(page.locator("html")).toHaveAttribute(
    "data-theme-preference",
    value,
  );
  await expect(menu).not.toBeVisible();
  await expect(themeButton(page)).toBeFocused();
}
