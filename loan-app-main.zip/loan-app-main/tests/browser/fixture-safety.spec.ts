import { test, expect } from "./fixtures";
test("browser fixture traffic cannot post to an unmocked external project", async ({
  page,
  networkBoundary,
}) => {
  networkBoundary.expectBlocked("https://production.invalid");
  // Use a blank document: the app CSP must not satisfy this assertion before
  // the browser fixture's independent network guard gets exercised.
  await page.goto("about:blank");
  const result = await page.evaluate(async () => {
    try {
      await fetch("https://production.invalid/rest/v1/clients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "Fictional Client Never Sent" }),
      });
      return "sent";
    } catch {
      return "blocked";
    }
  });
  expect(result).toBe("blocked");
  expect(networkBoundary.blockedOrigins).toContain(
    "https://production.invalid",
  );
});
