import { test, expect } from "./fixtures";
import { demoReportSource } from "../../lib/demo";
import { today } from "../../lib/domain";
import {
  buildReport,
  defaultReportFilters,
  reportMoney,
} from "../../lib/reporting";
const primary = ["disbursed", "received", "owed", "interestReceived"] as const;
for (const width of [390, 1440])
  for (const theme of ["light", "dark"] as const)
    test(`dashboard has four accurate totals and usable quick actions at ${width}px in ${theme}`, async ({
      page,
    }) => {
      await page.setViewportSize({ width, height: 900 });
      await page.emulateMedia({ colorScheme: theme });
      await page.goto("/demo");
      const report = page.getByRole("region", { name: "Financial reporting" });
      const expected = buildReport(
        demoReportSource,
        defaultReportFilters(today()),
      );
      await expect(report.locator(".stat-card")).toHaveCount(4);
      expect(
        await report
          .locator("[data-metric]")
          .evaluateAll((elements) =>
            elements.map((el) => el.getAttribute("data-metric")),
          ),
      ).toEqual(primary);
      for (const key of primary) {
        const card = report.locator(`[data-metric="${key}"]`);
        await expect(card.locator("strong")).toHaveText(
          reportMoney(expected.totals[key], "ZMW"),
        );
        await expect(card).toContainText(
          key === "owed"
            ? `Balance · end of ${today()}`
            : `Activity · ${expected.filters.from} to ${expected.filters.to}`,
        );
      }
      await expect(report.locator('[data-metric="owed"]')).toContainText(
        "written-off obligations",
      );
      await expect(report).toContainText("Principal repayments are not income");
      await expect(page.locator("table")).toHaveCount(0);
      await expect(
        report.getByRole("combobox", { name: "Department", exact: true }),
      ).not.toBeVisible();
      await expect(
        report.getByText(
          "Principal repayments are capital recovery, never profit.",
          { exact: false },
        ),
      ).not.toBeVisible();
      const quick = page.getByRole("region", { name: "Quick actions" });
      await quick
        .getByRole("button", { name: "Add Client", exact: true })
        .focus();
      await page.keyboard.press("Enter");
      await expect(
        page.getByRole("dialog", { name: "Add Client", exact: true }),
      ).toBeVisible();
      await page.keyboard.press("Escape");
      expect(
        await page.evaluate(() => document.documentElement.scrollWidth),
      ).toBeLessThanOrEqual(width);
    });
test("period activity can be zero while dated balances remain outstanding, and an earlier balance date is genuinely empty", async ({
  page,
}) => {
  await page.goto("/demo");
  const report = page.getByRole("region", { name: "Financial reporting" });
  await report.getByText("Change dates and filters", { exact: true }).click();
  await report.getByLabel("Activity from", { exact: true }).fill("2000-01-01");
  await report.getByLabel("Activity to", { exact: true }).fill("2000-01-31");
  await report.getByRole("button", { name: "Apply report filters" }).click();
  const expected = buildReport(demoReportSource, {
    ...defaultReportFilters(today()),
    from: "2000-01-01",
    to: "2000-01-31",
  });
  expect(expected.totals.owed).toBeGreaterThan(0);
  for (const key of primary)
    await expect(report.locator(`[data-metric="${key}"] strong`)).toHaveText(
      reportMoney(expected.totals[key], "ZMW"),
    );
  await expect(
    report.locator(".report-scope").filter({ hasText: "Balances:" }),
  ).toContainText(`Balances: end of ${today()}`);
  await report.getByLabel("Balances as of", { exact: true }).fill("2000-01-31");
  await report.getByRole("button", { name: "Apply report filters" }).click();
  await expect(
    report.getByText("No loans in this selection", { exact: true }),
  ).toBeVisible();
  await expect(report.locator('[data-metric="owed"] strong')).toHaveText(
    reportMoney(0, "ZMW"),
  );
  await expect(report.getByRole("alert")).toHaveCount(0);
});
test("advanced filters stay visible in the applied scope and carry into detailed reports", async ({
  page,
}) => {
  await page.goto("/demo");
  const report = page.getByRole("region", { name: "Financial reporting" });
  await report.getByText("Change dates and filters", { exact: true }).click();
  await report.getByText("More filters", { exact: true }).click();
  await report
    .getByRole("combobox", { name: "Department", exact: true })
    .selectOption("Operations");
  await report.getByRole("button", { name: "Apply report filters" }).click();
  await report.getByText("More filters", { exact: true }).click();
  await expect(report.locator(".applied-report-filters")).toContainText(
    "Department: Operations",
  );
  await page.getByRole("button", { name: "View detailed reports" }).click();
  await report.getByText("More filters", { exact: true }).click();
  await expect(
    report.getByRole("combobox", { name: "Department", exact: true }),
  ).toHaveValue("Operations");
  await report.getByText("More financial details", { exact: true }).click();
  await expect(report.locator('[data-metric="principal"]')).toBeVisible();
  await expect(report.locator("tbody")).toContainText("Grace Phiri");
  await expect(report.locator("tbody")).not.toContainText("Chanda Mwansa");
});

for (const width of [390, 1440])
  for (const theme of ["light", "dark"] as const)
    test(`sidebar surface and hover follow ${theme} at ${width}px`, async ({
      page,
    }, testInfo) => {
      await page.setViewportSize({ width, height: 1000 });
      await page.emulateMedia({ colorScheme: theme });
      await page.goto("/demo");
      await expect(page.locator('[data-metric="owed"] strong')).toBeVisible();
      if (width === 390)
        await page
          .getByRole("button", { name: "Open navigation", exact: true })
          .click();
      const nav = page.getByRole("navigation", { name: "Main navigation" });
      const surface = page.locator(
        width === 390 ? ".mobile-sidebar" : ".desktop-sidebar",
      );
      await expect(surface).toHaveCSS(
        "background-color",
        theme === "light" ? "rgb(248, 250, 252)" : "rgb(16, 35, 63)",
      );
      const clients = nav.getByRole("link", { name: "Clients", exact: true });
      await clients.hover();
      await expect(clients).toHaveCSS(
        "background-color",
        theme === "light" ? "rgb(228, 237, 247)" : "rgb(36, 60, 88)",
      );
      await clients.focus();
      await expect(clients).toHaveCSS(
        "background-color",
        theme === "light" ? "rgb(228, 237, 247)" : "rgb(36, 60, 88)",
      );
      if (width === 390) await page.keyboard.press("Escape");
      for (const name of ["Dashboard", "Reports"]) {
        if (name === "Reports")
          await (await import("./navigation")).navigate(page, "Reports");
        await expect(
          page.getByRole("heading", {
            name: "Business performance",
            exact: true,
          }),
        ).toBeVisible();
        await page.screenshot({
          path: testInfo.outputPath(
            `${name.toLowerCase()}-${width}-${theme}.png`,
          ),
          fullPage: true,
          style: "nextjs-portal { display:none !important; }",
        });
      }
      expect(
        await page.evaluate(() => document.documentElement.scrollWidth),
      ).toBeLessThanOrEqual(width);
    });
