import { capabilitiesForRole } from "../../lib/permissions";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { navigate } from "./navigation";
import { test, expect, type Page } from "./fixtures";
import { demoDefaults } from "../../lib/interest";
import { demoClients } from "../../lib/demo";
import { today } from "../../lib/domain";
const owner = "11111111-1111-4111-8111-111111111111";
const staff = "22222222-2222-4222-8222-222222222222";
function caps(role: string) {
  const admin = role === "administrator";
  return {
    ...capabilitiesForRole(
      role as "administrator" | "loan_officer" | "cashier" | "viewer",
    ),
    is_admin: admin,
    can_override_rate: admin,
    can_register_clients: admin || role === "loan_officer",
    can_originate: admin || role === "loan_officer",
    can_post_repayments: admin || role === "cashier",
    can_import: admin,
    can_manage_expenses: admin,
    can_read: true,
    role,
  };
}
async function auth(page: Page) {
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "test-signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "test-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "staff@example.com",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: { is_admin: true },
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      ),
    { owner, token },
  );
}
for (const role of ["viewer", "loan_officer", "cashier"])
  test(`${role} sees only permitted actions and cannot open administrator forms`, async ({
    page,
  }) => {
    await auth(page);
    const permissions = caps(role);
    await page.route(
      "https://register-tests.supabase.co/**",
      withSessionRequests(async (route) => {
        if (new URL(route.request().url()).pathname === "/auth/v1/user")
          return route.fulfill({ json: fictionalProviderUser(route) });
        const path = new URL(route.request().url()).pathname;
        let data: unknown = [];
        if (path.endsWith("/loan_defaults"))
          data = { ...demoDefaults, capabilities: permissions };
        else if (path.endsWith("/ledger_snapshot"))
          data = { clients: demoClients, loans: [], repayments: [] };
        else if (path.endsWith("/clients")) data = demoClients;
        await route.fulfill({ json: data });
      }),
    );
    await page.goto("/dashboard");
    const newLoan = page.getByRole("button", { name: "New Loan", exact: true });
    if (role === "loan_officer") await expect(newLoan).toBeEnabled();
    else await expect(newLoan).toHaveCount(0);
    const quick = page.getByRole("region", { name: "Quick actions" });
    await expect(
      quick.getByRole("button", { name: "Add Client", exact: true }),
    ).toHaveCount(role === "loan_officer" ? 1 : 0);
    await expect(
      quick.getByRole("button", {
        name: "Record Repayment Received",
        exact: true,
      }),
    ).toHaveCount(role === "cashier" ? 1 : 0);
    await expect(
      quick.getByRole("button", { name: "View detailed reports" }),
    ).toBeVisible();
    await navigate(page, "Clients");
    if (role === "loan_officer")
      await expect(
        page.getByRole("button", { name: "Add Client", exact: true }),
      ).toBeEnabled();
    else
      await expect(
        page.getByRole("button", { name: "Add Client", exact: true }),
      ).toHaveCount(0);
    await expect(
      page.getByRole("button", { name: "Import .xlsx" }),
    ).toHaveCount(0);
    if (role === "viewer") {
      await page
        .getByRole("button", {
          name: "Client Details for Chanda Mwansa",
          exact: true,
        })
        .click();
      const details = page.getByRole("dialog", { name: "Client Details" });
      await expect(
        details.getByLabel("Client name", { exact: true }),
      ).toHaveAttribute("readonly", "");
      await expect(
        details.getByRole("button", { name: "Save audited correction" }),
      ).toHaveCount(0);
      await page.keyboard.press("Escape");
    }

    await navigate(page, "Repayments");
    const pay = page.getByRole("button", {
      name: "Record Repayment Received",
      exact: true,
    });
    if (role === "cashier") await expect(pay).toBeEnabled();
    else await expect(pay).toHaveCount(0);
    await page.goto("/administration");
    await expect(
      page.getByRole("heading", { name: "Access denied", exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("button", { name: "Save approved access" }),
    ).toHaveCount(0);
    await page.goto("/expenses");
    await expect(
      page.getByRole("heading", { name: "Expense history" }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", { name: "Record paid expense" }),
    ).toHaveCount(0);
  });
test("Administrator assigns a role, posts an exact expense and approves its audited reversal", async ({
  page,
}) => {
  await auth(page);
  const stamp = new Date().toISOString();
  let members: Record<string, unknown>[] = [
    {
      user_id: owner,
      owner_id: owner,
      role: "administrator",
      is_active: true,
      revision: 1,
    },
  ];
  let expenses: Record<string, unknown>[] = [];
  const calls: string[] = [];
  const expenseKeys: string[] = [];
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const req = route.request(),
        path = new URL(req.url()).pathname;
      let data: unknown = [];
      if (path.endsWith("/loan_defaults"))
        data = { ...demoDefaults, capabilities: caps("administrator") };
      else if (path.endsWith("/user_roles")) data = members;
      else if (path.endsWith("/expenses")) data = expenses;
      else if (path.endsWith("/manage_user_access")) {
        const p = req.postDataJSON();
        expect(p).toMatchObject({
          p_user_id: staff,
          p_role: "cashier",
          p_is_active: true,
          p_expected_revision: 0,
          p_reason: "Approved new Cashier access",
          p_confirm: true,
          p_permissions: {
            repayments: true,
            view_repayments: true,
            users: false,
          },
        });
        expect(p.p_request_id).toMatch(/^[0-9a-f-]{36}$/);
        members = [
          ...members,
          {
            user_id: staff,
            owner_id: owner,
            role: "cashier",
            is_active: true,
            revision: 1,
          },
        ];
        data = members[1];
        calls.push("role");
      } else if (path.endsWith("/post_expense")) {
        const p = req.postDataJSON();
        expect(p.p_details).toMatchObject({
          amount: "0.29",
          currency: "ZMW",
          category: "Bank fees",
          description: "Confirmed bank transfer charge",
          payment_method: "bank_transfer",
        });
        expect(p.p_confirm).toBe(true);
        expenseKeys.push(p.p_request_id);
        expenses = [
          ...expenses,
          {
            id:
              "aaaaaaaa-aaaa-4aaa-8aaa-" +
              String(expenses.length + 1).padStart(12, "0"),
            expense_reference:
              "EXP-" + String(expenses.length + 1).padStart(10, "0"),
            expense_date: today(),
            amount: 0.29,
            amount_cents: 29,
            currency: "ZMW",
            category: "Bank fees",
            description: "Confirmed bank transfer charge",
            payee: "Bank",
            payment_method: "bank_transfer",
            created_by: owner,
            created_at: stamp,
            reversed_at: null,
          },
        ];
        data = { expense_id: expenses.at(-1)!.id };
        calls.push("expense");
      } else if (path.endsWith("/reverse_expense")) {
        const p = req.postDataJSON();
        expect(p).toMatchObject({
          p_expense_id: expenses[0].id,
          p_reason: "Approved incorrect charge reversal",
          p_confirm: true,
        });
        expenses = expenses.map((expense, i) =>
          i === 0
            ? {
                ...expense,
                reversed_at: stamp,
                reversed_by: owner,
                reversal_reason: p.p_reason,
              }
            : expense,
        );
        data = { expense_id: expenses[0].id };
        calls.push("reverse");
      }
      await route.fulfill({ json: data });
    }),
  );
  await page.goto("/administration");
  await page.getByLabel("Auth user ID", { exact: true }).fill(staff);
  await page
    .getByRole("combobox", { name: "Business role" })
    .selectOption("cashier");
  await page.getByRole("button", { name: "Use role defaults" }).click();
  await page
    .getByLabel("Permission change reason")
    .fill("Approved new Cashier access");
  await page
    .getByRole("checkbox", {
      name: "I approve this user's role, module access and sensitive actions.",
    })
    .check();
  await page.getByRole("button", { name: "Save approved access" }).click();
  await expect(page.locator('.notice[role="status"]')).toContainText(
    "saved and audited",
  );
  await expect(page.locator("tbody")).toContainText(staff);
  await page.goto("/expenses");
  await page.getByLabel("Expense amount (ZMW)").fill("0.29");
  await page.getByLabel("Category", { exact: true }).fill("Bank fees");
  await page.getByLabel("Payee").fill("Bank");
  await page
    .getByLabel("Description / purpose")
    .fill("Confirmed bank transfer charge");
  await page
    .getByRole("combobox", { name: "Payment method" })
    .selectOption("bank_transfer");
  await page
    .getByRole("checkbox", {
      name: "I approve this paid expense and confirm its amount and date.",
    })
    .check();
  await page.getByRole("button", { name: "Post approved expense" }).click();
  await expect(page.locator("tbody")).toContainText("EXP-0000000001");
  await expect(page.locator("tbody")).toContainText("0.29");
  // A confirmed success clears the old intent; a second identical paid fee
  // receives a new request ID, while in-flight retries retain their old ID.
  await page.getByLabel("Expense amount (ZMW)").fill("0.29");
  await page.getByLabel("Category", { exact: true }).fill("Bank fees");
  await page.getByLabel("Payee").fill("Bank");
  await page
    .getByLabel("Description / purpose")
    .fill("Confirmed bank transfer charge");
  await page
    .getByRole("combobox", { name: "Payment method" })
    .selectOption("bank_transfer");
  await page
    .getByRole("checkbox", {
      name: "I approve this paid expense and confirm its amount and date.",
    })
    .check();
  await page.getByRole("button", { name: "Post approved expense" }).click();
  await expect(page.locator("tbody tr")).toHaveCount(2);
  expect(new Set(expenseKeys).size).toBe(2);
  await page
    .getByRole("button", { name: "Reverse expense", exact: true })
    .first()
    .click();
  await page
    .getByLabel("Reversal reason")
    .fill("Approved incorrect charge reversal");
  await page
    .getByRole("checkbox", {
      name: "I approve reversing this expense; the original remains in the audit history.",
    })
    .check();
  await page.getByRole("button", { name: "Confirm expense reversal" }).click();
  await expect(page.locator("tbody")).toContainText("Reversed");
  await expect(page.locator("tbody")).toContainText("0.00");
  expect(calls).toEqual(["role", "expense", "expense", "reverse"]);
  await page.setViewportSize({ width: 390, height: 844 });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page.goto("/dashboard");
  await page
    .getByRole("button", { name: "Open navigation", exact: true })
    .click();
  await expect(
    page.getByRole("link", { name: "User Management" }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
});
