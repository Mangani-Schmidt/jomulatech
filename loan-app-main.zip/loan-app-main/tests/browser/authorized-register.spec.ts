import { capabilitiesForRole } from "../../lib/permissions";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { navigate } from "./navigation";
import { test, expect } from "./fixtures";
import { demoDefaults } from "../../lib/interest";
import { demoClients } from "../../lib/demo";
import type { Client, ClientAudit } from "../../lib/domain";
// UI contract tests use mocked Supabase HTTP. Database authorization and audit
// atomicity are independently exercised against both actual SQL migrations.
test("authorized unmatched search requires explicit manual creation, then audited correction", async ({
  page,
}) => {
  const owner = "11111111-1111-4111-8111-111111111111";
  let clients: Client[] = demoClients.map((c) => ({ ...c, created_by: owner }));
  const audits: ClientAudit[] = [];
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "test-signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "test-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "owner@example.com",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      ),
    { owner, token },
  );
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const request = route.request();
      const url = new URL(request.url());
      const payload =
        request.method() === "POST" ? request.postDataJSON() : null;
      const respond = (body: unknown, status = 200) =>
        route.fulfill({
          status,
          contentType: "application/json",
          body: JSON.stringify(body),
        });
      if (url.pathname === "/rest/v1/rpc/loan_defaults")
        return respond(demoDefaults);
      if (url.pathname.endsWith("/ledger_snapshot"))
        return respond({ clients, loans: [], repayments: [] });
      if (url.pathname.endsWith("/find_client_by_man"))
        return respond(
          clients.find(
            (c) =>
              c.man_number?.toLowerCase() ===
              payload.p_man_number.toLowerCase(),
          ) ?? null,
        );
      if (url.pathname === "/rest/v1/clients" && request.method() === "POST") {
        expect(payload.man_number).toBe("000999");
        expect(payload).not.toHaveProperty("owner_id");
        expect(payload).not.toHaveProperty("created_by");
        const c = {
          ...payload,
          id: "new-client",
          created_by: owner,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          revision: 1,
        };
        clients = [c, ...clients];
        return respond(null, 201);
      }
      if (url.pathname === "/rest/v1/rpc/correct_client") {
        expect(payload.p_expected_revision).toBe(1);
        expect(payload.p_reason).toBe("Verified updated department");
        expect(payload.p_details.man_number).toBe("000999");
        const before = clients.find((c) => c.id === payload.p_client_id)!;
        const after = {
          ...before,
          ...payload.p_details,
          revision: 2,
          updated_at: new Date().toISOString(),
        };
        clients = clients.map((c) => (c.id === after.id ? after : c));
        audits.push({
          id: "audit-correction",
          client_id: after.id,
          actor_id: owner,
          action: "correct",
          reason: payload.p_reason,
          before_data: before,
          after_data: after,
          created_at: after.updated_at,
        });
        return respond(after.id);
      }
      if (url.pathname === "/rest/v1/clients") return respond(clients);
      if (url.pathname === "/rest/v1/client_audit") return respond(audits);
      if (
        url.pathname === "/rest/v1/loan_register" ||
        url.pathname === "/rest/v1/repayment_register"
      )
        return respond([]);
      return respond({ message: "Unexpected test request" }, 400);
    }),
  );
  await page.goto("/dashboard");
  await page.getByRole("button", { name: "New Loan", exact: true }).click();
  const dialog = page.getByRole("dialog");
  await dialog
    .getByRole("combobox", { name: "Search by Man# or Client Name" })
    .fill("000999");
  await expect(dialog.getByRole("status")).toContainText("No client found");
  expect(clients).toHaveLength(6);
  await dialog.getByRole("button", { name: "Add Client", exact: true }).click();
  await expect(
    dialog.getByRole("heading", { name: "Add Client" }),
  ).toBeVisible();
  await expect(dialog.getByLabel("Man#", { exact: true })).toHaveValue(
    "000999",
  );
  expect(clients).toHaveLength(6);
  await dialog.getByLabel("Client name", { exact: true }).fill("New Client");
  await dialog.getByLabel("Department", { exact: true }).fill("Finance");
  await dialog.getByLabel("Designation", { exact: true }).fill("Analyst");
  await dialog
    .getByRole("button", { name: "Save Client", exact: true })
    .click();
  await expect(dialog).not.toBeVisible();
  expect(clients).toHaveLength(7);
  await navigate(page, "Clients");
  await page
    .getByRole("button", { name: "Client Details for New Client", exact: true })
    .click();
  await dialog.getByLabel("Department", { exact: true }).fill("Operations");
  await dialog
    .getByLabel("Correction reason")
    .fill("Verified updated department");
  await dialog.getByRole("button", { name: "Save audited correction" }).click();
  await expect(dialog).not.toBeVisible();
  await page
    .getByRole("button", { name: "Client Details for New Client", exact: true })
    .click();
  await expect(dialog.getByLabel("Department", { exact: true })).toHaveValue(
    "Operations",
  );
  await expect(
    dialog.getByText("Verified updated department", { exact: true }),
  ).toBeVisible();
  await expect(
    dialog.getByText("Finance → Operations", { exact: false }),
  ).toBeVisible();
});

test("Excel import requires explicit terms, preview, and confirmation and exposes history and errors", async ({
  page,
}) => {
  const owner = "11111111-1111-4111-8111-111111111111";
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "test-signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "test-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "owner@example.com",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      ),
    { owner, token },
  );
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) =>
      route.fulfill({
        contentType: "application/json",
        body: JSON.stringify(
          new URL(route.request().url()).pathname.endsWith("/loan_defaults")
            ? {
                ...demoDefaults,
                capabilities: {
                  ...capabilitiesForRole("administrator"),
                  is_admin: true,
                  can_import: true,
                  can_override_rate: false,
                  role: "administrator",
                },
              }
            : [],
        ),
      }),
    ),
  );
  await page.route("https://register-tests.supabase.co/auth/v1/user", (route) =>
    route.fulfill({ json: fictionalProviderUser(route) }),
  );
  let confirmed = false;
  let previews = 0;
  const row = {
    id: "row-1",
    excel_row: 2,
    source_no: "1",
    data: {
      source_no: "1",
      name: "Test Client",
      man_number: "00124",
      department: "Finance",
      designation: "Analyst",
      amount: "1000",
      principal_cents: 100000,
      interest_cents: 10000,
      total_obligation_cents: 110000,
      man_numeric: true,
      parse_errors: [],
    },
    outcome: "accepted",
    errors: [],
    warnings: [
      "Excel stored Man# numerically. Original leading zeros may be lost; verify this Man# before confirming.",
    ],
    client_id: null,
    loan_id: null,
  };
  const batch = {
    id: "test-batch",
    filename: "import.xlsx",
    mode: "loans",
    terms: {
      disbursement_date: "2026-01-01",
      interest_type: "flat_percent",
      interest_value: "10",
      due_rule: "days_after_disbursement",
      term_days: 30,
    },
    status: "preview",
    preview_version: 1,
    accepted: 1,
    rejected: 1,
    unchanged: 0,
    uploaded_by: owner,
    created_at: "2026-11-12T10:00:00Z",
    completed_at: null,
  };
  const report = () => ({
    batch: {
      ...batch,
      status: confirmed ? "completed" : "preview",
      completed_at: confirmed ? "2026-11-12T11:00:00Z" : null,
    },
    rows: [
      row,
      {
        ...row,
        id: "row-2",
        excel_row: 3,
        source_no: "2",
        outcome: "rejected",
        errors: ["Conflicting Client details"],
        warnings: [],
      },
    ],
  });
  await page.route("**/api/imports/**", async (route) => {
    const path = new URL(route.request().url()).pathname;
    const respond = (data: unknown) =>
      route.fulfill({
        contentType: "application/json",
        body: JSON.stringify(data),
      });
    if (path.endsWith("/inspect"))
      return respond({
        columns: [
          { index: 1, label: "NO#" },
          { index: 2, label: "NAME" },
          { index: 3, label: "MAN#" },
          { index: 4, label: "DEPARTMENT" },
          { index: 5, label: "DESIGNATION" },
          { index: 6, label: "AMOUNT" },
        ],
        mapping: {
          source_no: 1,
          name: 2,
          man_number: 3,
          department: 4,
          designation: 5,
          amount: 6,
        },
        rowCount: 2,
        fileHash: "a".repeat(64),
      });
    if (path.endsWith("/preview")) {
      const body = route.request().postDataBuffer()!.toString();
      expect(body).toContain("loans");
      expect(body).toContain("2026-01-01");
      expect(body).toContain("days_after_disbursement");
      expect(body).toContain("one_time_flat");
      expect(body).toContain("entire_term");
      previews++;
      return respond(report());
    }
    if (path.endsWith("/commit")) {
      expect(route.request().postDataJSON()).toEqual({
        batch_id: "test-batch",
        preview_version: 1,
        confirm: true,
      });
      confirmed = true;
      return respond(report());
    }
    if (path.endsWith("/history"))
      return respond(previews ? [report().batch] : []);
    if (path.endsWith("/report")) return respond(report());
    return route.continue();
  });
  await page.goto("/dashboard");
  await navigate(page, "Clients");
  await page.getByRole("button", { name: "Import .xlsx" }).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog.getByLabel("Import mode")).toHaveValue("");
  await dialog.getByLabel("Import mode").selectOption("clients");
  await expect(
    dialog.getByText("No loans, repayments, or balances are created.", {
      exact: false,
    }),
  ).toBeVisible();
  await dialog.getByLabel("Import mode").selectOption("loans");
  await dialog
    .getByLabel("Disbursement date", { exact: true })
    .fill("2026-01-01");
  await dialog
    .getByRole("combobox", { name: "Interest terms", exact: true })
    .selectOption("flat_percent");
  await expect(dialog.getByLabel("Flat interest (%)")).toHaveValue("10");
  await expect(dialog.getByLabel("Flat interest (%)")).toHaveAttribute(
    "readonly",
    "",
  );
  await dialog
    .getByLabel("Due-date rule")
    .selectOption("days_after_disbursement");
  await dialog.getByLabel("Term in days").fill("30");
  await dialog.getByLabel("Excel workbook").setInputFiles({
    name: "import.xlsx",
    mimeType:
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    buffer: Buffer.from(
      "Mocked HTTP fixture; server parser is tested independently",
    ),
  });
  await expect(
    dialog.getByRole("combobox", { name: "Map man#", exact: true }),
  ).toHaveValue("3");
  await dialog.getByRole("button", { name: "Validate and preview" }).click();
  await expect(
    dialog.getByRole("heading", {
      name: "Preview — nothing has been saved to the ledger",
    }),
  ).toBeVisible();
  const refreshed = page.waitForResponse((r) =>
    r.url().endsWith("/loan_defaults"),
  );
  await page.evaluate(() => {
    const channel = new BroadcastChannel("sb-register-tests-auth-token");
    channel.postMessage({
      event: "TOKEN_REFRESHED",
      session: JSON.parse(
        localStorage.getItem("sb-register-tests-auth-token")!,
      ),
    });
    channel.close();
  });
  await refreshed;
  await expect(
    dialog.getByRole("heading", {
      name: "Preview — nothing has been saved to the ledger",
    }),
  ).toBeVisible();
  expect(confirmed).toBe(false);
  await expect(
    dialog.getByText("1 accepted", { exact: false }).first(),
  ).toBeVisible();
  await expect(
    dialog.getByRole("button", { name: "Confirm 1 accepted rows" }),
  ).toBeDisabled();
  await expect(
    dialog.getByText("Original leading zeros may be lost", { exact: false }),
  ).toBeVisible();
  const download = page.waitForEvent("download");
  await dialog
    .getByRole("button", { name: "Download error / validation report" })
    .click();
  expect((await download).suggestedFilename()).toBe(
    "import-errors-test-batch.xlsx",
  );
  await dialog.getByRole("checkbox").check();
  await dialog.getByRole("button", { name: "Confirm 1 accepted rows" }).click();
  await expect(
    dialog.getByRole("heading", { name: "Import Summary" }),
  ).toBeVisible();
  expect(confirmed).toBe(true);
  await expect(dialog.getByText("Uploaded", { exact: false })).toContainText(
    owner,
  );
  await dialog.getByRole("button", { name: "View result" }).click();
  await expect(
    dialog.getByText(
      "Import completed. Repeated submissions return this result without creating duplicate records.",
    ),
  ).toBeVisible();
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await dialog.evaluate((e) => e.scrollWidth <= e.clientWidth)).toBe(
    true,
  );
});
