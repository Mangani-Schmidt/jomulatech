import { test, expect, type Page } from "./fixtures";
import { navigate } from "./navigation";
import { chooseTheme as choose, openThemeMenu, themeButton } from "./theme";
const key = "lendtrack:appearance";
const html = (page: Page) => page.locator("html");
for (const scenario of [
  { stored: null, device: "dark", theme: "dark", preference: "system" },
  { stored: "light", device: "dark", theme: "light", preference: "light" },
  { stored: "dark", device: "light", theme: "dark", preference: "dark" },
] as const)
  test(`first paint uses ${scenario.theme} for stored ${scenario.stored ?? "default"} before hydration`, async ({
    page,
  }) => {
    await page.emulateMedia({ colorScheme: scenario.device });
    if (scenario.stored)
      await page.addInitScript(
        ({ key, value }) => localStorage.setItem(key, value),
        { key, value: scenario.stored },
      );
    let release!: () => void;
    const held = new Promise<void>((resolve) => {
      release = resolve;
    });
    const errors: string[] = [];
    page.on("pageerror", (e) => errors.push(e.message));
    page.on("console", (message) => {
      if (message.type() === "error" && /hydrat|mismatch/i.test(message.text()))
        errors.push(message.text());
    });
    await page.route(/\/_next\/.*\.js(?:\?|$)/, async (route) => {
      await held;
      await route.continue();
    });
    try {
      await page.goto("/demo", { waitUntil: "commit" });
      await expect(
        page.getByRole("link", { name: "LendTrack home", exact: true }),
      ).toBeVisible();
      await expect(html(page)).toHaveAttribute("data-theme", scenario.theme);
      await expect(themeButton(page)).toHaveAttribute("disabled", "");
      await expect(page.locator("body")).toHaveCSS(
        "background-color",
        scenario.theme === "dark" ? "rgb(11, 18, 32)" : "rgb(238, 244, 250)",
      );
    } finally {
      release();
    }
    await page.waitForLoadState("load");
    await expect(themeButton(page)).toBeEnabled();
    await expect(themeButton(page)).toHaveAttribute("aria-expanded", "false");
    const menu = await openThemeMenu(page);
    await expect(
      menu.getByRole("menuitemradio", {
        name:
          scenario.preference[0].toUpperCase() + scenario.preference.slice(1),
        exact: true,
      }),
    ).toHaveAttribute("aria-checked", "true");
    await page.keyboard.press("Escape");
    await expect(html(page)).toHaveAttribute("data-theme", scenario.theme);
    expect(errors).toEqual([]);
  });

test("explicit preferences survive reload and standalone navigation while System follows device changes", async ({
  page,
}) => {
  await page.emulateMedia({ colorScheme: "light" });
  await page.goto("/demo");
  await expect(
    (await openThemeMenu(page)).getByRole("menuitemradio", {
      name: "System",
      exact: true,
    }),
  ).toHaveAttribute("aria-checked", "true");
  await choose(page, "dark");
  await page.reload();
  await expect(html(page)).toHaveAttribute("data-theme", "dark");
  expect(await page.evaluate((k) => localStorage.getItem(k), key)).toBe("dark");
  await page.emulateMedia({ colorScheme: "light" });
  await expect(html(page)).toHaveAttribute("data-theme", "dark");
  await navigate(page, "Settings");
  // Next.js client navigation can unmount the previous sidebar after the
  // click resolves. Wait for the destination before using its theme trigger.
  await expect(page).toHaveURL(/\/demo\/settings$/);
  await expect(
    page.getByRole("heading", { name: "Interest settings", exact: true }),
  ).toBeVisible();
  await expect(
    (await openThemeMenu(page)).getByRole("menuitemradio", {
      name: "Dark",
      exact: true,
    }),
  ).toHaveAttribute("aria-checked", "true");
  await expect(html(page)).toHaveAttribute("data-theme", "dark");
  await choose(page, "light");
  await page.emulateMedia({ colorScheme: "dark" });
  await expect(html(page)).toHaveAttribute("data-theme", "light");
  await choose(page, "system");
  await expect(html(page)).toHaveAttribute("data-theme", "dark");
  await page.emulateMedia({ colorScheme: "light" });
  await expect(html(page)).toHaveAttribute("data-theme", "light");
});

test("theme choices sync between tabs without changing other saved data", async ({
  page,
  context,
}) => {
  await page.goto("/demo");
  await page.evaluate(() =>
    localStorage.setItem("fictional-retained-request", "keep-this"),
  );
  const other = await context.newPage();
  await other.goto("/demo/settings");
  await choose(page, "dark");
  await expect(html(other)).toHaveAttribute("data-theme", "dark");
  await expect(
    (await openThemeMenu(other)).getByRole("menuitemradio", {
      name: "Dark",
      exact: true,
    }),
  ).toHaveAttribute("aria-checked", "true");
  await choose(other, "light");
  await expect(html(page)).toHaveAttribute("data-theme", "light");
  expect(
    await page.evaluate(() =>
      localStorage.getItem("fictional-retained-request"),
    ),
  ).toBe("keep-this");
  await other.close();
});

test("keyboard selection and storage-denied fallback remain usable", async ({
  page,
}) => {
  await page.addInitScript(() =>
    Object.defineProperty(window, "localStorage", {
      get() {
        throw new DOMException("Blocked", "SecurityError");
      },
    }),
  );
  await page.goto("/demo");
  const menu = await openThemeMenu(page);
  const dark = menu.getByRole("menuitemradio", { name: "Dark", exact: true });
  await dark.focus();
  await page.keyboard.press("Space");
  await expect(html(page)).toHaveAttribute("data-theme", "dark");
  await expect(themeButton(page)).toBeFocused();
  await expect(page.locator(".theme-save-note:visible")).toContainText(
    "apply for this visit",
  );
  await openThemeMenu(page);
  await expect(dark).toHaveAttribute("aria-checked", "true");
  await expect(dark).toBeFocused();
  await expect(dark).toHaveCSS("outline-style", "solid");
});

for (const mode of ["light", "dark"] as const)
  test(`${mode} theme shares readable surfaces across totals, dialogs, forms and authentication`, async ({
    page,
  }) => {
    await page.goto("/demo");
    await choose(page, mode);
    await expect(page.locator('[data-metric="disbursed"]')).toBeVisible();
    for (const selector of [
      '[data-metric="disbursed"] > span',
      '[data-metric="owed"] > span',
      ".sidebar .nav-item.selected",
      ".sidebar .nav-item:not(.selected)",
    ]) {
      const colors = await page
        .locator(selector)
        .first()
        .evaluate((el) => {
          let parent: Element | null = el,
            background = "";
          while (parent) {
            background = getComputedStyle(parent).backgroundColor;
            if (
              background !== "rgba(0, 0, 0, 0)" &&
              background !== "transparent"
            )
              break;
            parent = parent.parentElement;
          }
          return { fg: getComputedStyle(el).color, bg: background };
        });
      const lum = (s: string) => {
        const [r, g, b] = s
          .match(/[\d.]+/g)!
          .slice(0, 3)
          .map(Number)
          .map((v) => {
            v /= 255;
            return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
          });
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
      };
      const a = lum(colors.fg),
        b = lum(colors.bg);
      expect(
        (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05),
        selector,
      ).toBeGreaterThanOrEqual(4.5);
    }
    await navigate(page, "Clients");
    await page.getByRole("button", { name: "Add Client", exact: true }).click();
    const dialog = page.getByRole("dialog");
    await expect(dialog).toHaveCSS(
      "background-color",
      mode === "dark" ? "rgb(17, 30, 48)" : "rgb(252, 253, 255)",
    );
    await expect(dialog.getByLabel("Man#", { exact: true })).toHaveCSS(
      "background-color",
      mode === "dark" ? "rgb(17, 30, 48)" : "rgb(252, 253, 255)",
    );
    await dialog.getByLabel("Man#", { exact: true }).fill("009999");
    await dialog
      .getByLabel("Client name", { exact: true })
      .fill("Fictional Theme Client");
    await dialog.getByLabel("Department", { exact: true }).fill("Finance");
    await dialog.getByLabel("Designation", { exact: true }).fill("Analyst");
    await dialog
      .getByRole("button", { name: "Save Client", exact: true })
      .click();
    await expect(dialog.locator(".form-error")).toHaveCSS(
      "background-color",
      mode === "dark" ? "rgb(58, 32, 38)" : "rgb(255, 246, 244)",
    );
    await dialog.getByRole("button", { name: "Cancel", exact: true }).click();
    await page.getByRole("button", { name: "Sign in", exact: true }).click();
    await expect(dialog.getByLabel("Email", { exact: true })).toHaveCSS(
      "background-color",
      mode === "dark" ? "rgb(17, 30, 48)" : "rgb(252, 253, 255)",
    );
  });

test("dark mode keeps printing light and reduced motion works on phones", async ({
  page,
}) => {
  await page.goto("/demo");
  await choose(page, "dark");
  await page.emulateMedia({ reducedMotion: "reduce" });
  const durations = await page
    .getByRole("button", { name: "New Loan", exact: true })
    .evaluate((el) => getComputedStyle(el).transitionDuration);
  expect(durations.split(",").every((v) => parseFloat(v) <= 0.001)).toBe(true);
  await navigate(page, "Reports");
  await page
    .getByRole("button", { name: "Preview printable report", exact: true })
    .click();
  await page.emulateMedia({ media: "print" });
  await expect(page.locator("body")).toHaveCSS(
    "background-color",
    "rgb(255, 255, 255)",
  );
  await expect(html(page)).toHaveCSS("color-scheme", "light");
  await expect(page.locator(".theme-selection")).not.toBeVisible();
  await page.emulateMedia({ media: "screen" });
  await page
    .getByRole("button", { name: "Close report preview", exact: true })
    .click();
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(themeButton(page)).toBeVisible();
  expect(
    await page.evaluate(() => document.documentElement.scrollWidth),
  ).toBeLessThanOrEqual(390);
});

test("the icon menu supports keyboard navigation, selection, Escape and native Tab exit", async ({
  page,
}) => {
  await page.goto("/");
  const button = themeButton(page),
    menu = page.getByRole("menu", { name: "Color theme", exact: true });
  await expect(button).toBeEnabled();
  await expect(button).toHaveText("");
  await expect(button).toHaveAccessibleDescription("Current theme: System.");
  await expect(menu).not.toBeVisible();
  await button.focus();
  await page.keyboard.press("Enter");
  await expect(
    menu.getByRole("menuitemradio", { name: "System", exact: true }),
  ).toBeFocused();
  await page.keyboard.press("Home");
  await expect(
    menu.getByRole("menuitemradio", { name: "Light", exact: true }),
  ).toBeFocused();
  await page.keyboard.press("ArrowUp");
  await expect(
    menu.getByRole("menuitemradio", { name: "System", exact: true }),
  ).toBeFocused();
  await page.keyboard.press("ArrowDown");
  await expect(
    menu.getByRole("menuitemradio", { name: "Light", exact: true }),
  ).toBeFocused();
  await page.keyboard.press("End");
  await page.keyboard.press("ArrowUp");
  await page.keyboard.press("Space");
  await expect(menu).not.toBeVisible();
  await expect(button).toBeFocused();
  await expect(html(page)).toHaveAttribute("data-theme-preference", "dark");
  await page.keyboard.press("ArrowDown");
  await expect(
    menu.getByRole("menuitemradio", { name: "Light", exact: true }),
  ).toBeFocused();
  await page.keyboard.press("Escape");
  await expect(menu).not.toBeVisible();
  await expect(button).toBeFocused();
  await expect(html(page)).toHaveAttribute("data-theme-preference", "dark");
  await page.keyboard.press("ArrowUp");
  await expect(
    menu.getByRole("menuitemradio", { name: "System", exact: true }),
  ).toBeFocused();
  await page.keyboard.press("Tab");
  await expect(menu).not.toBeVisible();
  await expect(
    page
      .locator(".landing-actions")
      .getByRole("link", { name: "Sign Up", exact: true }),
  ).toBeFocused();
  await button.focus();
  await page.keyboard.press("Enter");
  await page.keyboard.press("Shift+Tab");
  await expect(menu).not.toBeVisible();
  await expect(button).toBeFocused();
});

test("hover and focus give feedback without opening the menu; outside pointer/focus dismiss it", async ({
  page,
}) => {
  await page.goto("/");
  const button = themeButton(page),
    menu = page.getByRole("menu", { name: "Color theme", exact: true });
  await expect(button).toBeEnabled();
  const before = await button.evaluate(
    (el) => getComputedStyle(el).backgroundColor,
  );
  await button.hover();
  await expect(button).not.toHaveCSS("background-color", before);
  await expect(menu).not.toBeVisible();
  await page.mouse.move(0, 0);
  await button.focus();
  await expect(button).toHaveCSS("outline-style", "solid");
  await expect(menu).not.toBeVisible();
  await button.click();
  await expect(menu).toBeVisible();
  await page.getByRole("heading", { level: 1 }).click();
  await expect(menu).not.toBeVisible();
  await openThemeMenu(page);
  const login = page
    .getByRole("navigation", { name: "Public navigation" })
    .getByRole("link", { name: "Log In", exact: true });
  await login.focus();
  await expect(menu).not.toBeVisible();
  await expect(login).toBeFocused();
});

test.describe("theme selection on touchscreens", () => {
  test.use({ hasTouch: true, viewport: { width: 390, height: 844 } });
  test("one icon opens usable choices and preserves the selected mode", async ({
    page,
  }) => {
    await page.goto("/");
    const button = themeButton(page),
      menu = page.getByRole("menu", { name: "Color theme", exact: true });
    await expect(button).toBeEnabled();
    const box = (await button.boundingBox())!;
    expect(box.width).toBeGreaterThanOrEqual(44);
    expect(box.height).toBeGreaterThanOrEqual(44);
    await button.tap();
    await menu.getByRole("menuitemradio", { name: "Dark", exact: true }).tap();
    await expect(menu).not.toBeVisible();
    await expect(html(page)).toHaveAttribute("data-theme", "dark");
    await button.tap();
    const popup = (await menu.boundingBox())!;
    expect(popup.x).toBeGreaterThanOrEqual(0);
    expect(popup.x + popup.width).toBeLessThanOrEqual(390);
    await page.locator(".public-header").tap({ position: { x: 5, y: 5 } });
    await expect(menu).not.toBeVisible();
    await page.reload();
    await expect(html(page)).toHaveAttribute("data-theme", "dark");
  });
});

for (const width of [390, 820, 1440]) {
  for (const mode of ["light", "dark"] as const) {
    test(`public, authentication, dashboard and loan layouts fit ${width}px in ${mode}`, async ({
      page,
    }) => {
      await page.setViewportSize({ width, height: 1000 });
      await page.emulateMedia({ colorScheme: mode });
      const errors: string[] = [];
      page.on("pageerror", (error) => errors.push(error.message));
      page.on("console", (message) => {
        if (
          message.type() === "error" &&
          /hydrat|mismatch/i.test(message.text())
        )
          errors.push(message.text());
      });
      for (const route of [
        { path: "/", name: "landing" },
        { path: "/login", name: "login" },
        { path: "/demo", name: "dashboard" },
        { path: "/demo/#new-loan", name: "loan" },
      ]) {
        await page.goto(route.path);
        await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
        await choose(page, mode);
        if (route.name === "dashboard")
          await expect(
            page.locator('[data-metric="disbursed"] > strong'),
          ).toBeVisible();
        if (route.name === "loan") {
          await page
            .getByRole("combobox", {
              name: "Search by Man# or Client Name",
              exact: true,
            })
            .fill("00124");
          await page.getByRole("option").first().click();
          await page
            .getByLabel("Amount Disbursed (ZMW)", { exact: true })
            .fill("1000");
          await expect(
            page.getByRole("region", { name: "Loan obligation preview" }),
          ).toContainText("1,100");
          const contrast = await page
            .locator(".client-lookup > label")
            .evaluate((el) => {
              let parent: Element | null = el;
              let background = "";
              while (parent) {
                background = getComputedStyle(parent).backgroundColor;
                if (
                  background !== "transparent" &&
                  background !== "rgba(0, 0, 0, 0)"
                )
                  break;
                parent = parent.parentElement;
              }
              const luminance = (color: string) => {
                const [r, g, b] = color
                  .match(/[\d.]+/g)!
                  .slice(0, 3)
                  .map(Number)
                  .map((channel) => {
                    const n = channel / 255;
                    return n <= 0.04045
                      ? n / 12.92
                      : ((n + 0.055) / 1.055) ** 2.4;
                  });
                return 0.2126 * r + 0.7152 * g + 0.0722 * b;
              };
              const a = luminance(getComputedStyle(el).color),
                b = luminance(background);
              return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
            });
          expect(contrast).toBeGreaterThanOrEqual(4.5);
        }
        expect(
          await page.evaluate(() => document.documentElement.scrollWidth),
          route.path,
        ).toBeLessThanOrEqual(width);
        if (
          width === 820 &&
          (route.name === "dashboard" || route.name === "loan")
        ) {
          const brand = page.getByRole("link", {
            name: "LendTrack home",
            exact: true,
          });
          expect(
            await brand.evaluate((el) => el.scrollWidth <= el.clientWidth + 1),
          ).toBe(true);
          const rail = (await page.locator(".sidebar").boundingBox())!;
          const icon = (await brand.locator(".brand-icon").boundingBox())!;
          expect(icon.x).toBeGreaterThanOrEqual(rail.x);
          expect(icon.x + icon.width).toBeLessThanOrEqual(rail.x + rail.width);
        }
        const menu = await openThemeMenu(page),
          bounds = (await menu.boundingBox())!;
        expect(bounds.x, route.path).toBeGreaterThanOrEqual(0);
        expect(bounds.x + bounds.width, route.path).toBeLessThanOrEqual(width);
        await page.screenshot({
          path: `/tmp/lendtrack-validation-${route.name}-${width}-${mode}.png`,
          fullPage: true,
        });
        await page.keyboard.press("Escape");
        await expect(themeButton(page)).toBeFocused();
      }
      expect(errors).toEqual([]);
    });
  }
}
