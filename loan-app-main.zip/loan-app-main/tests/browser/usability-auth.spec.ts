import { test, expect, type Page } from "./fixtures";
import { withSessionRequests, fictionalProviderUser } from "./auth-fixture";
import { capabilitiesForRole } from "../../lib/permissions";
import { demoDefaults } from "../../lib/interest";
import { demoClients } from "../../lib/demo";
async function fixture(page: Page, role: "administrator" | "loan_officer") {
  const actor = "11111111-1111-4111-8111-111111111111";
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: actor, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "fictional-signature",
  ].join(".");
  await page.addInitScript(
    ({ actor, token }) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "fictional",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          user: {
            id: actor,
            email: "fictional@example.test",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      ),
    { actor, token },
  );
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const p = new URL(route.request().url()).pathname;
      if (p === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      if (p.endsWith("/loan_defaults"))
        return route.fulfill({
          json: { ...demoDefaults, capabilities: capabilitiesForRole(role) },
        });
      if (p.endsWith("/ledger_snapshot"))
        return route.fulfill({
          json: { clients: demoClients, loans: [], repayments: [] },
        });
      if (p === "/rest/v1/expenses")
        return route.fulfill({
          json: [
            {
              id: "e1",
              expense_reference: "EXP-FICTIONAL",
              expense_date: "2026-11-01",
              amount_cents: 29,
              currency: "ZMW",
              category: "Fees",
              description: "Fictional fee",
              payee: "Fictional bank",
              created_by: actor,
              created_at: "2026-11-13T22:30:45Z",
              reversed_at: null,
            },
          ],
        });
      return route.fulfill({
        status: 400,
        json: { message: "Unexpected fictional request" },
      });
    }),
  );
}
test("expense effective dates stay date-only while exact recorded time uses the business timezone", async ({
  page,
}, testInfo) => {
  await fixture(page, "administrator");
  await page.goto("/expenses");
  const row = page.getByRole("row").filter({ hasText: "EXP-FICTIONAL" });
  await expect(row).toContainText("Effective: 2026-11-01");
  await expect(row).toContainText(
    "Recorded: 14 Nov 2026, 00:30:45 Africa/Lusaka",
  );
  const controls = page
    .locator("form")
    .filter({ has: page.getByLabel("Expense amount (ZMW)", { exact: true }) });
  await expect(controls.locator(".required-legend")).toHaveCount(1);
  expect(
    await controls
      .getByLabel("Payee", { exact: true })
      .evaluate(
        (e) =>
          (e as HTMLInputElement).labels?.[0].querySelector(
            ".required-mark",
          ) === null,
      ),
  ).toBe(true);
  expect(
    await controls
      .locator(":required")
      .evaluateAll((els) =>
        els.every((e) =>
          Array.from((e as HTMLInputElement).labels ?? []).some((l) =>
            l.querySelector(".required-mark"),
          ),
        ),
      ),
  ).toBe(true);
  const date = page.getByLabel("Expense date", { exact: true });
  await date.click({ position: { x: 12, y: 16 } });
  await page.keyboard.press("Escape");
  await date.fill("2026-11-01");
  await expect(date).toHaveValue("2026-11-01");
  await page.screenshot({
    path: testInfo.outputPath("expenses-timestamps.png"),
    fullPage: true,
    animations: "disabled",
  });
});
test("phone sidebar keeps permission filtering and an icon on Account security", async ({
  page,
}, testInfo) => {
  await fixture(page, "loan_officer");
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/dashboard#clients");
  await page
    .getByRole("button", { name: "Open navigation", exact: true })
    .click();
  const drawer = page.getByRole("dialog", { name: "Workspace navigation" });
  const security = drawer.getByRole("link", {
    name: "Account Security",
    exact: true,
  });
  await expect(security.locator("svg")).toBeVisible();
  await expect(
    drawer.getByRole("link", { name: "Settings", exact: true }),
  ).toHaveCount(0);
  await expect(
    drawer.getByRole("link", { name: "User Management", exact: true }),
  ).toHaveCount(0);
  await expect(
    drawer.getByRole("link", { name: "Clients", exact: true }),
  ).toHaveAttribute("aria-current", "page");
  await page.screenshot({
    path: testInfo.outputPath("permitted-mobile-sidebar.png"),
    animations: "disabled",
  });
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: "Add Client", exact: true }).click();
  const form = page.getByRole("dialog", { name: "Add Client", exact: true });
  const active = form.getByRole("switch", {
    name: "Active Client",
    exact: true,
  });
  await expect(active).toBeChecked();
  await active.focus();
  await page.keyboard.press("Space");
  await expect(active).not.toBeChecked();
  await form.getByLabel("Man#", { exact: true }).fill("000007");
  await form.getByLabel("Client name", { exact: true }).fill("D");
  await form.getByRole("button", { name: "Save Client", exact: true }).click();
  await expect(form).toBeVisible();
  await expect(form.getByLabel("Man#", { exact: true })).toHaveValue("000007");
  await expect(form.getByLabel("Client name", { exact: true })).toHaveValue(
    "D",
  );
  await expect(active).not.toBeChecked();
});
