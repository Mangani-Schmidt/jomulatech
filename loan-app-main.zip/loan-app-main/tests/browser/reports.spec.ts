import { navigate } from "./navigation";
import { test, expect } from "./fixtures";
import { readFile } from "node:fs/promises";
import { today } from "../../lib/domain";
test("report filters, CSV scope, printable snapshot, empty states and mobile layout", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/demo");
  await navigate(page, "Reports");
  const report = page.getByRole("region", { name: "Financial reporting" });
  await report.getByText("Report filters", { exact: true }).click();
  await report.getByText("More filters", { exact: true }).click();
  await expect(
    report.getByRole("heading", { name: "Dashboard and reports" }),
  ).toBeVisible();
  await report.getByLabel("Activity from", { exact: true }).fill("2026-01-01");
  await report
    .getByRole("combobox", { name: "Department", exact: true })
    .selectOption("Finance");
  await report.getByRole("button", { name: "Apply report filters" }).click();
  await expect(report.locator("tbody tr")).toHaveCount(2);
  await expect(report.locator("tbody")).toContainText("Chanda Mwansa");
  await expect(report.locator("tbody")).not.toContainText("Grace Phiri");
  const download = page.waitForEvent("download");
  await report.getByRole("button", { name: "Download Client CSV" }).click();
  const file = await download;
  expect(file.suggestedFilename()).toBe(`clients-report-${today()}.csv`);
  const csv = await readFile((await file.path())!, "utf8");
  expect(csv).toContain("00124");
  expect(csv).toContain("Interest Income per Client");
  expect(csv).toContain("Finance");
  expect(csv).not.toContain("Grace Phiri");
  await report
    .getByRole("button", { name: "Preview printable report" })
    .click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toContainText("All pages included");
  await expect(dialog).toContainText("Chanda Mwansa");
  await expect(dialog).not.toContainText("Grace Phiri");
  await page.emulateMedia({ media: "print" });
  await expect(
    page.getByRole("navigation", { name: "Main navigation" }),
  ).not.toBeVisible();
  await page.pdf({
    path: "test-results/filtered-report.pdf",
    format: "A4",
    printBackground: true,
  });
  await page.emulateMedia({ media: "screen" });
  await dialog.getByRole("button", { name: "Close report preview" }).click();
  await report.getByRole("button", { name: "By loan", exact: true }).click();
  await report
    .getByRole("button", { name: "Client Loan History", exact: true })
    .first()
    .click();
  await expect(
    page.getByRole("region", { name: "Selected loan history" }),
  ).toContainText("PAY-00000001");
  await report
    .getByLabel("Search by Man# or Client Name")
    .fill("no-such-client");
  await report.getByRole("button", { name: "Apply report filters" }).click();
  await expect(report).toContainText("No loans match these report filters");
  await expect(
    report.getByRole("button", { name: "Download loan CSV" }),
  ).toBeDisabled();
  await page.setViewportSize({ width: 390, height: 844 });
  await report.getByRole("button", { name: "Reset filters" }).click();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  expect(errors).toEqual([]);
});
