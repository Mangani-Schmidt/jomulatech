import { test, expect, type Page } from "./fixtures";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { navigate } from "./navigation";
import { demoReportSource } from "../../lib/demo";
import { demoDefaults } from "../../lib/interest";
import { capabilitiesForRole } from "../../lib/permissions";
const actor = "11111111-1111-4111-8111-111111111111";
async function fixture(page: Page) {
  const sessionFor = (id: string) => ({
    access_token: [
      "eyJhbGciOiJIUzI1NiJ9",
      Buffer.from(
        JSON.stringify({
          sub: id,
          session_id: id,
          exp: Math.floor(Date.now() / 1000) + 3600,
        }),
      ).toString("base64url"),
      "fictional-signature",
    ].join("."),
    refresh_token: "fictional",
    token_type: "bearer",
    expires_at: Math.floor(Date.now() / 1000) + 3600,
    expires_in: 3600,
    user: {
      id,
      email: "fixture@example.test",
      aud: "authenticated",
      role: "authenticated",
      app_metadata: {},
      user_metadata: {},
      created_at: "2026-01-01T00:00:00Z",
    },
  });
  await page.addInitScript(
    (session) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify(session),
      ),
    sessionFor(actor),
  );
  const state = {
    requests: [] as string[],
    holdDefaults: null as Promise<void> | null,
    holdReport: null as Promise<void> | null,
    holdRead: null as Promise<void> | null,
    failLedger: false,
    failReport: false,
    source: demoReportSource,
    invalidUser: false,
  };
  page.on("request", (request) => {
    if (new URL(request.url()).origin === "https://register-tests.supabase.co")
      state.requests.push(new URL(request.url()).pathname);
  });
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const path = new URL(route.request().url()).pathname;
      if (path === "/auth/v1/user")
        return state.invalidUser
          ? route.fulfill({
              status: 401,
              json: { message: "Fictional expired identity" },
            })
          : route.fulfill({ json: fictionalProviderUser(route) });
      if (path.endsWith("/loan_defaults")) {
        await state.holdDefaults;
        return route.fulfill({
          json: {
            ...demoDefaults,
            capabilities: capabilitiesForRole("administrator"),
          },
        });
      }
      if (path.endsWith("/ledger_snapshot")) {
        if (state.failLedger)
          return route.fulfill({
            status: 503,
            json: { message: "Fictional ledger unavailable" },
          });
        return route.fulfill({
          json: {
            clients: state.source.clients,
            loans: state.source.loans,
            repayments: state.source.repayments,
          },
        });
      }
      if (path.endsWith("/client_audit")) return route.fulfill({ json: [] });
      if (path.endsWith("/report_source_filtered")) {
        await state.holdReport;
        return state.failReport
          ? route.fulfill({
              status: 503,
              json: { message: "Fictional unavailable report" },
            })
          : route.fulfill({ json: state.source });
      }
      if (path.endsWith("/has_capability")) {
        await state.holdRead;
        return route.fulfill({ json: true });
      }
      if (path.endsWith("/expenses")) return route.fulfill({ json: [] });
      throw new Error("Unexpected fictional request: " + path);
    }),
  );
  return {
    ...state,
    state,
    sessionFor,
    count: (suffix: string) =>
      state.requests.filter((p) => p.endsWith("/" + suffix)).length,
  };
}
const dashboard = async (page: Page) => {
  await page.goto("/dashboard");
  await expect(page.locator('[data-metric="owed"] strong')).toBeVisible();
};
test("one initial report read and visible read-only content during a fresh navigation permission check", async ({
  page,
}) => {
  const f = await fixture(page);
  await dashboard(page);
  await expect.poll(() => f.count("ledger_snapshot")).toBe(1);
  // Development StrictMode replays effects; the production benchmark verifies one.
  expect(f.count("report_source_filtered")).toBeLessThanOrEqual(2);
  let release!: () => void;
  f.state.holdDefaults = new Promise((r) => (release = r));
  await page
    .getByRole("navigation", { name: "Main navigation" })
    .getByRole("link", { name: "Clients", exact: true })
    .click();
  await expect(page.locator(".access-refresh")).toBeVisible();
  await expect(page.locator('[data-metric="owed"] strong')).toBeVisible();
  await expect(page.locator(".access-refresh + div")).toHaveAttribute(
    "inert",
    "",
  );
  release();
  await expect(
    page.getByRole("heading", { name: "Client Register", exact: true }),
  ).toBeVisible();
  expect(f.count("user")).toBe(2);
  expect(f.count("loan_defaults")).toBe(2);
});
test("a same-scope cached report stays visible during refresh, blocks exports and is removed on failure", async ({
  page,
}) => {
  const f = await fixture(page);
  await dashboard(page);
  await navigate(page, "Clients");
  let release!: () => void;
  f.state.holdReport = new Promise((r) => (release = r));
  await navigate(page, "Reports");
  await expect(page.locator('[data-metric="owed"] strong')).toBeVisible();
  await expect(
    page.getByRole("status").filter({ hasText: "Updating displayed snapshot" }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Download .xlsx report", exact: true }),
  ).toBeDisabled();
  f.state.failReport = true;
  release();
  await expect(page.locator(".report-error")).toContainText(
    "Financial summary unavailable",
  );
  await expect(page.locator("[data-metric]")).toHaveCount(0);
  f.state.holdReport = null;
  f.state.failReport = false;
  await page.getByRole("button", { name: "Retry financial summary" }).click();
  await expect(page.locator('[data-metric="owed"] strong')).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Download .xlsx report", exact: true }),
  ).toBeEnabled();
});
test("paired focus and visibility recheck once and refresh actual financial snapshots without blanking", async ({
  page,
}) => {
  const f = await fixture(page);
  await dashboard(page);
  const reports = f.count("report_source_filtered"),
    ledger = f.count("ledger_snapshot"),
    statuses = f.count("app_session_status");
  f.state.source = {
    ...demoReportSource,
    generated_at: new Date().toISOString(),
    clients: [],
    loans: [],
    repayments: [],
    terms_audit: [],
    status_audit: [],
    repayment_audit: [],
  };
  await page.evaluate(() => {
    document.dispatchEvent(new Event("visibilitychange", { bubbles: true }));
    window.dispatchEvent(new Event("focus"));
  });
  await expect(
    page.locator("h1").filter({ hasText: "Dashboard" }),
  ).toBeVisible();
  await expect(
    page.getByText("No loans in this selection", { exact: true }),
  ).toBeVisible();
  await expect.poll(() => f.count("app_session_status")).toBe(statuses + 1);
  await expect.poll(() => f.count("ledger_snapshot")).toBe(ledger + 1);
  await expect.poll(() => f.count("report_source_filtered")).toBe(reports + 1);
});
test("switching actor while access is held removes all old private content before the new verification", async ({
  page,
}) => {
  const f = await fixture(page);
  await dashboard(page);
  let release!: () => void;
  f.state.holdDefaults = new Promise((r) => (release = r));
  const next = f.sessionFor("22222222-2222-4222-8222-222222222222");
  await page.evaluate((session) => {
    localStorage.setItem(
      "sb-register-tests-auth-token",
      JSON.stringify(session),
    );
    const c = new BroadcastChannel("sb-register-tests-auth-token");
    c.postMessage({ event: "SIGNED_IN", session });
    c.close();
  }, next);
  await expect(page.locator("[data-metric]")).toHaveCount(0);
  await expect(page.locator("main h1:visible").first()).toContainText(
    /Checking your (access|session)/,
  );
  f.state.source = {
    ...demoReportSource,
    clients: [],
    loans: [],
    repayments: [],
    terms_audit: [],
    status_audit: [],
    repayment_audit: [],
  };
  release();
  await expect(
    page.getByText("No loans in this selection", { exact: true }),
  ).toBeVisible();
});
test("standalone module navigation uses client routing and keeps session registration", async ({
  page,
}) => {
  await fixture(page);
  await dashboard(page);
  const marker = await page.evaluate(() => {
    (window as unknown as { navigationMarker: string }).navigationMarker =
      "retained";
    return "retained";
  });
  await navigate(page, "Expenses");
  await expect(
    page.getByRole("heading", { name: "Expenses", exact: true }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () =>
        (window as unknown as { navigationMarker: string }).navigationMarker,
    ),
  ).toBe(marker);
  await navigate(page, "Clients");
  await expect(
    page.getByRole("heading", { name: "Client Register", exact: true }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () =>
        (window as unknown as { navigationMarker: string }).navigationMarker,
    ),
  ).toBe(marker);
});

test("a held export cannot release the old actor's report after an account change", async ({
  page,
}) => {
  const f = await fixture(page);
  await dashboard(page);
  await navigate(page, "Reports");
  let release!: () => void;
  f.state.holdRead = new Promise((r) => (release = r));
  await page
    .getByRole("button", { name: "Download Client CSV", exact: true })
    .click();
  await expect.poll(() => f.count("has_capability")).toBe(1);
  f.state.source = {
    ...demoReportSource,
    clients: [],
    loans: [],
    repayments: [],
    terms_audit: [],
    status_audit: [],
    repayment_audit: [],
  };
  const next = f.sessionFor("22222222-2222-4222-8222-222222222222");
  await page.evaluate((session) => {
    localStorage.setItem(
      "sb-register-tests-auth-token",
      JSON.stringify(session),
    );
    const c = new BroadcastChannel("sb-register-tests-auth-token");
    c.postMessage({ event: "SIGNED_IN", session });
    c.close();
  }, next);
  await expect(
    page.getByText(/No loans match these report filters/),
  ).toBeVisible();
  const downloaded = page.waitForEvent("download", { timeout: 750 }).then(
    () => true,
    () => false,
  );
  release();
  expect(await downloaded).toBe(false);
});

test("a failed tab session check stays locked across focus and recovers through Retry", async ({
  page,
}) => {
  await fixture(page);
  await dashboard(page);
  let unavailable = true;
  await page.route(
    "https://register-tests.supabase.co/rest/v1/rpc/app_session_status",
    (route) =>
      unavailable
        ? route.fulfill({
            status: 503,
            json: { message: "Fictional temporary outage" },
          })
        : route.fulfill({
            json: {
              active: true,
              registered: true,
              server_now: new Date().toISOString(),
              last_activity_at: new Date().toISOString(),
            },
          }),
  );
  await page.evaluate(() => window.dispatchEvent(new Event("focus")));
  await expect(
    page.getByRole("heading", {
      name: "Session check unavailable",
      exact: true,
    }),
  ).toBeVisible();
  await page.evaluate(() => window.dispatchEvent(new Event("focus")));
  await expect(
    page.getByRole("heading", {
      name: "Session check unavailable",
      exact: true,
    }),
  ).toBeVisible();
  expect(page.url()).toContain("/dashboard");
  unavailable = false;
  await page
    .getByRole("button", { name: "Retry session check", exact: true })
    .click();
  await expect(page.locator('[data-metric="owed"] strong')).toBeVisible();
});

test("rotated credentials supersede a delayed old-token identity failure", async ({
  page,
}) => {
  const f = await fixture(page);
  await dashboard(page);
  let release!: () => void;
  const held = new Promise<void>((r) => (release = r));
  let first = true;
  await page.route(
    "https://register-tests.supabase.co/auth/v1/user",
    async (route) => {
      if (first) {
        first = false;
        await held;
        return route.fulfill({
          status: 401,
          json: { message: "Fictional expired old token" },
        });
      }
      return route.fulfill({ json: fictionalProviderUser(route) });
    },
  );
  await page.evaluate(() => window.dispatchEvent(new Event("focus")));
  await expect(page.locator(".access-refresh")).toBeVisible();
  const next = f.sessionFor(actor),
    parts = next.access_token.split(".");
  parts[1] = Buffer.from(
    JSON.stringify({
      ...JSON.parse(Buffer.from(parts[1], "base64url").toString()),
      exp: Math.floor(Date.now() / 1000) + 7200,
      jti: "fictional-rotated",
    }),
  ).toString("base64url");
  next.access_token = parts.join(".");
  await page.evaluate((session) => {
    localStorage.setItem(
      "sb-register-tests-auth-token",
      JSON.stringify(session),
    );
    const c = new BroadcastChannel("sb-register-tests-auth-token");
    c.postMessage({ event: "TOKEN_REFRESHED", session });
    c.close();
  }, next);
  await expect(page.locator(".access-refresh")).toHaveCount(0);
  release();
  await expect(page.locator('[data-metric="owed"] strong')).toBeVisible();
  expect(page.url()).toContain("/dashboard");
});

test("a failed background ledger refresh cannot turn an open Client summary into an empty history", async ({
  page,
}) => {
  const f = await fixture(page);
  await dashboard(page);
  await navigate(page, "Clients");
  await page
    .getByRole("button", {
      name: "Client Details for " + demoReportSource.clients[0].name,
      exact: true,
    })
    .click();
  const summary = page
    .getByRole("dialog")
    .getByRole("region", { name: "Client financial summary", exact: true });
  await expect(summary.locator("dd").first()).toBeVisible();
  f.state.failLedger = true;
  await page.evaluate(() => window.dispatchEvent(new Event("focus")));
  await expect(summary).toContainText("Client financial summary unavailable");
  await expect(
    summary.getByText("No loans recorded for this Client.", { exact: true }),
  ).toHaveCount(0);
  await expect(summary.locator("dd")).toHaveCount(0);
  f.state.failLedger = false;
  await summary
    .getByRole("button", { name: "Retry Client financial summary" })
    .click();
  await expect(summary.locator("dd").first()).toBeVisible();
});

test("own Account security opens after identity verification without waiting for business membership", async ({
  page,
}) => {
  const f = await fixture(page);
  let release!: () => void;
  f.state.holdDefaults = new Promise((r) => (release = r));
  await page.route(
    "https://register-tests.supabase.co/rest/v1/rpc/account_security",
    (route) =>
      route.fulfill({
        json: {
          role: "unassigned",
          admin_mfa_required: false,
          recent_assurance: false,
        },
      }),
  );
  await page.goto("/security");
  await expect(
    page.getByRole("heading", { name: "Account security", exact: true }),
  ).toBeVisible();
  await expect(page.getByLabel("New password", { exact: true })).toBeEnabled();
  // One shared membership lookup, no per-page duplicate subscription/request.
  expect(f.count("loan_defaults")).toBe(1);
  expect(f.count("ledger_snapshot")).toBe(0);
  release();
});
