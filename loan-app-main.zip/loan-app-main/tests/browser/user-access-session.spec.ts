import { test, expect, type Page } from "./fixtures";
import type { BrowserContext } from "@playwright/test";
import { demoDefaults } from "../../lib/interest";
import {
  demoClients,
  demoLoans,
  demoRepayments,
  demoReportSource,
} from "../../lib/demo";
import {
  capabilitiesForRole,
  permissionFlags,
  rolePermissions,
  type BusinessRole,
  type UserPermissions,
} from "../../lib/permissions";
import { INACTIVITY_MS, WARNING_MS } from "../../lib/session-activity";
const actor = "11111111-1111-4111-8111-111111111111",
  staff = "22222222-2222-4222-8222-222222222222",
  sid = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";
function flags(role: BusinessRole, p: UserPermissions) {
  const result = { ...capabilitiesForRole(role) };
  for (const [flag, key] of Object.entries(permissionFlags))
    result[flag as keyof typeof permissionFlags] = p[key];
  const eligible = rolePermissions(role);
  result.can_register_clients = p.clients && p.view_clients && eligible.clients;
  result.can_originate = p.originate && p.view_loans && eligible.originate;
  result.can_post_repayments =
    p.repayments && p.view_repayments && eligible.repayments;
  result.can_manage_users = role === "administrator" && p.users && p.view_users;
  result.can_import =
    role === "administrator" &&
    p.imports &&
    p.view_imports &&
    p.clients &&
    p.view_clients;
  return result;
}
function only(...modules: (keyof UserPermissions)[]): UserPermissions {
  const p = Object.fromEntries(
    Object.keys(rolePermissions("viewer")).map((key) => [key, false]),
  ) as UserPermissions;
  for (const key of modules) p[key] = true;
  return p;
}
async function workspace(
  page: Page,
  context: BrowserContext,
  options: {
    role?: BusinessRole;
    p?: UserPermissions;
    signedIn?: boolean;
    clock?: boolean;
    expired?: boolean;
  } = {},
) {
  const time = Date.now();
  if (options.clock) await page.clock.install({ time: new Date(time) });
  const role = options.role ?? "administrator",
    p = options.p ?? rolePermissions(role);
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({
        sub: actor,
        session_id: sid,
        exp: Math.floor(time / 1000) + 3600,
      }),
    ).toString("base64url"),
    "fictional-signature",
  ].join(".");
  const user = {
    id: actor,
    email: "fictional-access@example.test",
    aud: "authenticated",
    role: "authenticated",
    app_metadata: {},
    user_metadata: { is_admin: true },
    created_at: "2026-01-01T00:00:00Z",
    factors: [],
  };
  const session = {
    access_token: token,
    refresh_token: "fictional-refresh",
    token_type: "bearer",
    expires_at: Math.floor(time / 1000) + 3600,
    expires_in: 3600,
    user,
  };
  if (options.signedIn !== false)
    await page.addInitScript((session) => {
      if (!sessionStorage.getItem("fictional-auth-initialized")) {
        localStorage.setItem(
          "sb-register-tests-auth-token",
          JSON.stringify(session),
        );
        sessionStorage.setItem("fictional-auth-initialized", "yes");
      }
    }, session);
  const state = {
    p,
    role,
    touches: 0,
    ends: 0,
    last: options.expired ? time - INACTIVITY_MS - 1 : time,
    registered: true,
    ended: false,
    hold: null as Promise<void> | null,
    touchHold: null as Promise<void> | null,
    endHold: null as Promise<void> | null,
    requests: [] as string[],
    writes: [] as Record<string, any>[],
    users: [
      {
        user_id: actor,
        role: "administrator",
        is_active: true,
        revision: 1,
        permissions: rolePermissions("administrator"),
        assigned_by: actor,
        updated_at: "2026-01-01T00:00:00Z",
      },
      {
        user_id: staff,
        role: "loan_officer",
        is_active: true,
        revision: 3,
        permissions: {
          ...rolePermissions("loan_officer"),
          view_dashboard: false,
          view_reports: false,
          export_reports: false,
        },
        assigned_by: actor,
        updated_at: "2026-01-01T00:00:00Z",
      },
    ],
    audits: [] as Record<string, unknown>[],
  };
  await context.route(
    "https://register-tests.supabase.co/**",
    async (route) => {
      const request = route.request(),
        path = new URL(request.url()).pathname;
      state.requests.push(path);
      let now = time;
      try {
        now = await request
          .frame()
          .page()
          .evaluate(() => Date.now());
      } catch {}
      const status = () => ({
        active:
          state.registered && !state.ended && now - state.last < INACTIVITY_MS,
        registered: state.registered,
        server_now: new Date(now).toISOString(),
        last_activity_at: new Date(state.last).toISOString(),
      });
      if (path.endsWith("/app_session_status"))
        return route.fulfill({ json: status() });
      if (path.endsWith("/touch_app_session")) {
        state.touches++;
        if (
          !state.registered ||
          (!state.ended && now - state.last < INACTIVITY_MS)
        ) {
          state.registered = true;
          state.last = now;
        }
        const data = status();
        if (state.touchHold) await state.touchHold;
        return route.fulfill({ json: data });
      }
      if (path.endsWith("/end_app_session")) {
        state.ends++;
        state.ended = true;
        if (state.endHold) await state.endHold;
        return route.fulfill({ json: null });
      }
      if (path === "/auth/v1/logout") return route.fulfill({ status: 204 });
      if (path === "/auth/v1/user") return route.fulfill({ json: user });
      if (path === "/auth/v1/token") return route.fulfill({ json: session });
      if (path.endsWith("/loan_defaults")) {
        if (state.hold) await state.hold;
        return route.fulfill({
          json: {
            ...demoDefaults,
            settings: { ...demoDefaults.settings, owner_id: actor },
            capabilities: flags(state.role, state.p),
          },
        });
      }
      if (path.endsWith("/has_capability")) {
        const key = request.postDataJSON().p_action;
        return route.fulfill({
          json:
            key === "read" || state.p[key as keyof UserPermissions] === true,
        });
      }
      if (path.endsWith("/user_roles"))
        return route.fulfill({ json: state.users });
      if (path.endsWith("/audit_events"))
        return route.fulfill({ json: state.audits });
      if (path.endsWith("/manage_user_access")) {
        const body = request.postDataJSON();
        state.writes.push(body);
        const before = state.users.find(
          (row) => row.user_id === body.p_user_id,
        );
        if ((before?.revision ?? 0) !== body.p_expected_revision)
          return route.fulfill({
            status: 400,
            json: {
              code: "P0001",
              message:
                "Permissions changed. Reload and review the existing user.",
            },
          });
        const after = {
          user_id: body.p_user_id,
          role: body.p_role,
          is_active: body.p_is_active,
          revision: (before?.revision ?? 0) + 1,
          permissions: body.p_permissions,
          assigned_by: actor,
          updated_at: new Date(now).toISOString(),
        };
        state.users = state.users
          .filter((row) => row.user_id !== after.user_id)
          .concat(after);
        state.audits.unshift({
          id: "audit-" + state.writes.length,
          created_at: new Date(now).toISOString(),
          actor_id: actor,
          entity_id: after.user_id,
          entity_type: "User",
          action: before ? "permissions_changed" : "role_assigned",
          reason: body.p_reason,
          before_data: before ?? null,
          after_data: after,
        });
        return route.fulfill({ json: after });
      }
      const finance =
        state.p.view_loans || state.p.view_repayments || state.p.view_reports;
      if (path.endsWith("/ledger_snapshot"))
        return route.fulfill({
          json: {
            clients: state.p.view_clients || finance ? demoClients : [],
            loans: finance ? demoLoans : [],
            repayments: finance ? demoRepayments : [],
          },
        });
      if (path.endsWith("/report_source_filtered"))
        return route.fulfill({ json: demoReportSource });
      if (path.endsWith("/client_deletion_status"))
        return route.fulfill({
          json: { can_delete: false, reason: "Fictional retained history" },
        });
      if (path.endsWith("/client_audit")) return route.fulfill({ json: [] });
      throw new Error("Unexpected fictional request " + path);
    },
  );
  return state;
}

test("User Management prefills every saved grant and saves an explicit audited update separately from Audit Logs", async ({
  page,
  context,
}) => {
  const state = await workspace(page, context);
  await page.goto("/users");
  await expect(
    page.getByRole("heading", { name: "User Management", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Business audit history", exact: true }),
  ).toHaveCount(0);
  await page
    .getByRole("button", { name: `Edit user ${staff}`, exact: true })
    .click();
  await expect(page.getByLabel("Auth user ID", { exact: true })).toHaveValue(
    staff,
  );
  await expect(
    page.getByRole("checkbox", { name: "View Dashboard", exact: true }),
  ).not.toBeChecked();
  await expect(
    page.getByRole("checkbox", { name: "View Clients", exact: true }),
  ).toBeChecked();
  await expect(
    page.getByRole("checkbox", { name: "View Reports", exact: true }),
  ).not.toBeChecked();
  await expect(
    page.getByRole("checkbox", { name: "Originate loans", exact: true }),
  ).toBeChecked();
  // Reloading the list must not advance the revision of an older form draft.
  state.users[1].revision = 4;
  state.users[1].permissions.view_dashboard = true;
  await page.getByRole("button", { name: "Reload users", exact: true }).click();
  await expect(
    page
      .locator("tbody tr")
      .filter({ hasText: staff })
      .getByRole("cell", { name: "4", exact: true }),
  ).toBeVisible();
  await page
    .getByLabel("Permission change reason", { exact: true })
    .fill("Fictional stale permission edit");
  await page
    .getByRole("checkbox", {
      name: "I approve this user's role, module access and sensitive actions.",
      exact: true,
    })
    .check();
  await page
    .getByRole("button", { name: "Save approved access", exact: true })
    .click();
  await expect(page.getByRole("main").getByRole("alert")).toContainText(
    "Permissions changed",
  );
  expect(state.writes[0].p_expected_revision).toBe(3);
  expect(state.audits).toHaveLength(0);
  await page
    .getByRole("button", { name: `Edit user ${staff}`, exact: true })
    .click();
  await expect(
    page.getByRole("checkbox", { name: "View Dashboard", exact: true }),
  ).toBeChecked();
  await page
    .getByRole("checkbox", { name: "View Reports", exact: true })
    .check();
  await page
    .getByLabel("Permission change reason", { exact: true })
    .fill("Approved fictional report access");
  await page
    .getByRole("checkbox", {
      name: "I approve this user's role, module access and sensitive actions.",
      exact: true,
    })
    .check();
  await page
    .getByRole("button", { name: "Save approved access", exact: true })
    .click();
  await expect(page.getByRole("status")).toContainText("saved and audited");
  expect(state.writes[1]).toMatchObject({
    p_user_id: staff,
    p_expected_revision: 4,
    p_permissions: {
      view_dashboard: true,
      view_clients: true,
      view_reports: true,
      export_reports: false,
    },
    p_confirm: true,
  });
  await page
    .getByRole("navigation", { name: "Main navigation" })
    .getByRole("link", { name: "Audit Logs", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Audit Logs", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText("Approved fictional report access", { exact: true }),
  ).toBeVisible();
  await expect(page.getByLabel("Auth user ID", { exact: true })).toHaveCount(0);
  await expect(page.getByRole("link", { name: /Explore demo/i })).toHaveCount(
    0,
  );
});
test("a user with view-only User Management sees no grant actions and direct Audit Logs navigation is denied", async ({
  page,
  context,
}) => {
  await workspace(page, context, { role: "viewer", p: only("view_users") });
  await page.goto("/users");
  await expect(
    page.getByRole("heading", { name: "User Management", exact: true }),
  ).toBeVisible();
  await expect(page.getByLabel("Auth user ID", { exact: true })).toHaveCount(0);
  await expect(page.getByRole("button", { name: /Edit user / })).toHaveCount(0);
  const nav = page.getByRole("navigation", { name: "Main navigation" });
  await expect(
    nav.getByRole("link", { name: "Audit Logs", exact: true }),
  ).toHaveCount(0);
  await expect(
    nav.getByRole("link", { name: "Dashboard", exact: true }),
  ).toHaveCount(0);
  await page.goto("/audit-logs");
  await expect(
    page.getByRole("heading", { name: "Access denied", exact: true }),
  ).toBeVisible();
});
test("restricted modules never appear while access loads, including forged Administrator metadata", async ({
  page,
  context,
}) => {
  const state = await workspace(page, context, {
    role: "viewer",
    p: only("view_clients"),
  });
  let release!: () => void;
  state.hold = new Promise<void>((resolve) => (release = resolve));
  await page.goto("/users");
  await expect(
    page.getByText(/Checking your (access|session)/).first(),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "User Management", exact: true }),
  ).toHaveCount(0);
  await expect(page.getByLabel("Auth user ID", { exact: true })).toHaveCount(0);
  release();
  await expect(
    page.getByRole("heading", { name: "Access denied", exact: true }),
  ).toBeVisible();
  expect(state.requests.some((path) => path.endsWith("/user_roles"))).toBe(
    false,
  );
});
test("login opens the first permitted module when the Dashboard and requested route are inaccessible", async ({
  page,
  context,
}) => {
  await workspace(page, context, {
    role: "cashier",
    p: only("view_repayments", "repayments"),
    signedIn: false,
  });
  await page.goto("/login?next=%2Fsettings");
  await page
    .getByLabel("Email", { exact: true })
    .fill("fictional-access@example.test");
  await page.getByLabel("Password", { exact: true }).fill("abc123");
  await page.getByRole("button", { name: "Log In", exact: true }).click();
  await expect(page).toHaveURL(/\/dashboard#repayments$/);
  await expect(
    page
      .getByRole("navigation", { name: "Main navigation" })
      .getByRole("link", { name: "Dashboard", exact: true }),
  ).toHaveCount(0);
  await expect(page.locator("[data-metric]")).toHaveCount(0);
  await expect(page.getByRole("link", { name: /Explore demo/i })).toHaveCount(
    0,
  );
});
test("Dashboard cards, shortcuts and actions follow module and action grants independently", async ({
  page,
  context,
}) => {
  await workspace(page, context, {
    role: "loan_officer",
    p: only("view_dashboard", "view_loans"),
  });
  await page.goto("/dashboard");
  await expect(page.locator("[data-metric]")).toHaveCount(2);
  await expect(page.locator('[data-metric="owed"]')).toBeVisible();
  await expect(
    page.locator('[data-metric="received"],[data-metric="interestReceived"]'),
  ).toHaveCount(0);
  await expect(
    page.getByRole("button", { name: "New Loan", exact: true }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("button", { name: "View detailed reports", exact: false }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: "Clients", exact: true }),
  ).toHaveCount(0);
});
test("inactivity warns before expiry, ignores polling and clears sensitive forms on logout", async ({
  page,
  context,
}) => {
  const state = await workspace(page, context, { clock: true });
  await page.goto("/dashboard#clients");
  await page.getByRole("button", { name: "Add Client", exact: true }).click();
  await page.getByLabel("Man#", { exact: true }).fill("00009876");
  await page
    .getByLabel("Client name", { exact: true })
    .fill("Fictional private form name");
  await page.evaluate(
    (actor) =>
      localStorage.setItem(
        "lendwell:pending-posting:" + actor,
        JSON.stringify({
          version: 1,
          id: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
          operation: "post_repayment",
          createdAt: new Date().toISOString(),
          body: { private_form: "Fictional private form name" },
        }),
      ),
    actor,
  );
  const before = state.touches;
  await page.clock.fastForward(INACTIVITY_MS - WARNING_MS + 1000);
  await expect(
    page.getByRole("dialog", { name: "Are you still there?", exact: true }),
  ).toBeVisible();
  expect(state.touches).toBe(before);
  await page.keyboard.press("Tab");
  await page.clock.fastForward(WARNING_MS);
  await expect(page).toHaveURL(/\/login\?reason=inactive$/);
  await expect(page.getByRole("status")).toContainText(
    "15 minutes of inactivity",
  );
  expect(state.ends).toBeGreaterThan(0);
  await expect(page.getByLabel("Client name", { exact: true })).toHaveCount(0);
  const stored = await page.evaluate(
    (actor) => localStorage.getItem("lendwell:pending-posting:" + actor),
    actor,
  );
  expect(stored).toContain("bbbbbbbb");
  expect(stored).not.toContain("private_form");
});
test("Stay Signed In synchronizes activity and the later logout across two tabs", async ({
  page,
  context,
}) => {
  const state = await workspace(page, context, { clock: true });
  await page.goto("/dashboard");
  await expect(page.locator("[data-metric]")).toHaveCount(4);
  const other = await context.newPage();
  // Playwright shares one virtual clock across this browser context.
  await other.goto("/dashboard");
  await expect(other.locator("[data-metric]")).toHaveCount(4);
  await page.clock.fastForward(INACTIVITY_MS - WARNING_MS + 1000);
  await expect(
    page.getByRole("dialog", { name: "Are you still there?", exact: true }),
  ).toBeVisible();
  await expect(
    other.getByRole("dialog", { name: "Are you still there?", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Stay Signed In", exact: true })
    .click();
  await expect(
    other.getByRole("dialog", { name: "Are you still there?", exact: true }),
  ).not.toBeVisible();
  await expect.poll(() => state.touches).toBeGreaterThan(0);
  await page.clock.fastForward(INACTIVITY_MS + 2000);
  await expect(page).toHaveURL(/\/login\?reason=inactive$/);
  await expect(other).toHaveURL(/\/login\?reason=inactive$/);
  await other.close();
});
test("a suspended tab checks elapsed inactivity on resume without refreshing the deadline", async ({
  page,
  context,
}) => {
  await workspace(page, context, { clock: true });
  await page.goto("/dashboard");
  await expect(page.locator("[data-metric]")).toHaveCount(4);
  const at = await page.evaluate(() => Date.now());
  await page.clock.setSystemTime(new Date(at + INACTIVITY_MS + 1000));
  await page.evaluate(() => window.dispatchEvent(new Event("focus")));
  await expect(page).toHaveURL(/\/login\?reason=inactive$/);
  await expect(page.locator("[data-metric]")).toHaveCount(0);
});
test("an expired application session rejects access before financial components mount", async ({
  page,
  context,
}) => {
  const state = await workspace(page, context, { expired: true });
  await page.goto("/dashboard");
  await expect(page).toHaveURL(/\/login\?reason=inactive$/);
  expect(
    state.requests.some(
      (path) =>
        path.endsWith("/ledger_snapshot") ||
        path.endsWith("/report_source_filtered"),
    ),
  ).toBe(false);
});

for (const width of [390, 1440])
  for (const theme of ["light", "dark"]) {
    test(`User Management, Audit Logs and inactivity warning fit ${width}px in ${theme}`, async ({
      page,
      context,
    }, testInfo) => {
      await page.setViewportSize({ width, height: 900 });
      await page.addInitScript(
        (theme) => localStorage.setItem("lendtrack:appearance", theme),
        theme,
      );
      await workspace(page, context, { clock: true });
      await page.goto("/users");
      await expect(
        page.getByRole("heading", { name: "User Management", exact: true }),
      ).toBeVisible();
      await page
        .getByRole("button", { name: `Edit user ${staff}`, exact: true })
        .click();
      await expect(
        page.getByRole("checkbox", { name: "View Dashboard", exact: true }),
      ).not.toBeChecked();
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
      ).toBe(true);
      await page.screenshot({
        path: testInfo.outputPath("user-management.png"),
        fullPage: true,
      });
      await page.goto("/audit-logs");
      await expect(
        page.getByRole("heading", { name: "Audit Logs", exact: true }),
      ).toBeVisible();
      await expect(
        page.getByLabel("Auth user ID", { exact: true }),
      ).toHaveCount(0);
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
      ).toBe(true);
      await page.screenshot({
        path: testInfo.outputPath("audit-logs.png"),
        fullPage: true,
      });
      await page.clock.fastForward(INACTIVITY_MS - WARNING_MS + 1000);
      const warning = page.getByRole("dialog", {
        name: "Are you still there?",
        exact: true,
      });
      await expect(warning).toBeVisible();
      await expect(
        page.getByRole("button", { name: "Stay Signed In", exact: true }),
      ).toBeFocused();
      expect(
        await warning.evaluate((e) => e.scrollWidth <= e.clientWidth),
      ).toBe(true);
      await page.screenshot({
        path: testInfo.outputPath("inactivity-warning.png"),
      });
    });
  }

test("a late activity response cannot reopen the workspace during logout", async ({
  page,
  context,
}) => {
  const state = await workspace(page, context, { clock: true });
  await page.goto("/dashboard");
  await expect(page.locator("[data-metric]")).toHaveCount(4);
  await page.clock.fastForward(INACTIVITY_MS - WARNING_MS + 1000);
  let releaseTouch!: () => void, releaseEnd!: () => void;
  state.touchHold = new Promise<void>((resolve) => (releaseTouch = resolve));
  state.endHold = new Promise<void>((resolve) => (releaseEnd = resolve));
  try {
    await page
      .getByRole("button", { name: "Stay Signed In", exact: true })
      .click();
    await expect.poll(() => state.touches).toBeGreaterThan(0);
    await page.clock.fastForward(INACTIVITY_MS + 1000);
    await expect(
      page.getByRole("heading", { name: "Session ended", exact: true }),
    ).toBeVisible();
    const oldResponse = page.waitForResponse((response) =>
      response.url().endsWith("/touch_app_session"),
    );
    releaseTouch();
    // Drain the deliberately stale RPC response while revocation is held.
    await expect
      .poll(
        () =>
          state.requests.filter((path) => path.endsWith("/end_app_session"))
            .length,
      )
      .toBeGreaterThan(0);
    await (await oldResponse).finished();
    await page.clock.runFor(500);
    await expect(
      page.getByRole("heading", { name: "Session ended", exact: true }),
    ).toBeVisible();
    await expect(page.locator("[data-metric]")).toHaveCount(0);
    releaseEnd();
    await expect(page).toHaveURL(/\/login\?reason=inactive$/);
  } finally {
    releaseTouch();
    releaseEnd();
  }
});
