import { test, expect, type Page } from "./fixtures";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { navigate } from "./navigation";
import { demoClients } from "../../lib/demo";
import { demoDefaults } from "../../lib/interest";
import type { Client } from "../../lib/domain";
const owner = "11111111-1111-4111-8111-111111111111";
const existing: Client = {
  ...demoClients[0],
  id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
  name: "Fictional Existing Client",
  man_number: "00Ab-01",
  is_active: false,
};
async function workspace(page: Page, initial = [existing]) {
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "fictional-signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "fictional-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "fictional-man@example.test",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      ),
    { owner, token },
  );
  const state = {
    clients: structuredClone(initial),
    serverClients: structuredClone(initial),
    lookups: [] as string[],
    inserts: [] as Record<string, unknown>[],
    corrections: [] as Record<string, unknown>[],
    failedLookup: false,
    race: false,
  };
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const request = route.request(),
        url = new URL(request.url()),
        path = url.pathname;
      if (path === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({ json: demoDefaults });
      if (path.endsWith("/ledger_snapshot"))
        return route.fulfill({
          json: { clients: state.clients, loans: [], repayments: [] },
        });
      if (path.endsWith("/client_audit")) return route.fulfill({ json: [] });
      if (path.endsWith("/find_client_by_man")) {
        const { p_man_number } = request.postDataJSON();
        state.lookups.push(p_man_number);
        if (state.failedLookup)
          return route.fulfill({
            status: 403,
            json: { message: "Fictional unavailable register" },
          });
        return route.fulfill({
          json:
            state.serverClients.find(
              (c) => c.man_number?.toLowerCase() === p_man_number.toLowerCase(),
            ) ?? null,
        });
      }
      if (path.endsWith("/clients") && request.method() === "POST") {
        const data = request.postDataJSON();
        state.inserts.push(data);
        if (state.race) {
          state.serverClients.push({
            ...existing,
            man_number: data.man_number,
          });
          return route.fulfill({
            status: 409,
            json: { code: "23505", message: "Fictional unique conflict" },
          });
        }
        const saved = {
          ...existing,
          ...data,
          id: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
          is_active: true,
        };
        state.clients.push(saved);
        state.serverClients.push(saved);
        return route.fulfill({ status: 201, json: null });
      }
      if (path.endsWith("/correct_client")) {
        state.corrections.push(request.postDataJSON());
        return route.fulfill({ json: existing.id });
      }
      throw new Error("Unexpected fictional request: " + path);
    }),
  );
  await page.goto("/dashboard#clients");
  await page.getByRole("button", { name: "Add Client", exact: true }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  return state;
}
async function complete(page: Page, man: string) {
  const dialog = page.getByRole("dialog");
  await dialog.getByLabel("Man#", { exact: true }).fill(man);
  await dialog
    .getByLabel("Client name", { exact: true })
    .fill("Fictional Unsaved Client");
  await dialog
    .getByLabel("Department", { exact: true })
    .fill("Fictional Department");
  await dialog
    .getByLabel("Designation", { exact: true })
    .fill("Fictional Designation");
}
async function save(page: Page) {
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Save Client", exact: true })
    .click();
}
test("a chosen Man# starts blank and is saved as text with leading zeros through explicit registration", async ({
  page,
}) => {
  const state = await workspace(page);
  const man = page.getByRole("dialog").getByLabel("Man#", { exact: true });
  await expect(man).toHaveValue("");
  await expect(man).toHaveAttribute("type", "text");
  await expect(man).toHaveAttribute("maxlength", "50");
  await expect(man).toHaveAccessibleDescription(
    /chosen or assigned Man# manually/,
  );
  await complete(page, " 000042 ");
  expect(state.inserts).toHaveLength(0);
  await save(page);
  await expect(page.getByRole("dialog")).not.toBeVisible();
  expect(state.lookups).toEqual(["000042"]);
  expect(state.inserts).toHaveLength(1);
  expect(state.inserts[0].man_number).toBe("000042");
  expect(state.inserts[0]).not.toHaveProperty("id");
  expect(state.inserts[0]).not.toHaveProperty("owner_id");
  expect(state.corrections).toHaveLength(0);
});
for (const width of [390, 1440]) {
  test(`case-insensitive inactive duplicate previews the existing record and opens its stable identity at ${width}px`, async ({
    page,
  }) => {
    await page.setViewportSize({ width, height: 900 });
    const state = await workspace(page);
    await complete(page, "00aB-01");
    const conflict = page.getByRole("status", {
      name: "Existing Client with this Man#",
    });
    await expect(conflict).toContainText(existing.name);
    await expect(conflict).toContainText("Inactive Client");
    await expect(conflict).toContainText("discards the unsaved entries");
    const open = conflict.getByRole("button", {
      name: "Open existing Client Details",
    });
    if (width === 1440) {
      await open.focus();
      await page.keyboard.press("Enter");
    } else await open.click();
    const dialog = page.getByRole("dialog");
    await expect(
      dialog.getByRole("heading", { name: "Client Details" }),
    ).toBeVisible();
    await expect(dialog.getByLabel("Man#", { exact: true })).toHaveValue(
      existing.man_number!,
    );
    await expect(dialog.getByLabel("Client name", { exact: true })).toHaveValue(
      existing.name,
    );
    await expect(
      dialog.getByText("Internal Client ID: " + existing.id),
    ).toBeVisible();
    await expect(
      dialog.getByLabel("Active Client", { exact: true }),
    ).not.toBeChecked();
    expect(state.inserts).toHaveLength(0);
    expect(state.corrections).toHaveLength(0);
    expect(state.clients).toEqual([existing]);
  });
}
test("a duplicate added after the snapshot is shown before any insert instead of overwriting it", async ({
  page,
}) => {
  const state = await workspace(page, []);
  state.serverClients.push(existing);
  await complete(page, "00AB-01");
  await save(page);
  await expect(
    page.getByRole("status", { name: "Existing Client with this Man#" }),
  ).toContainText(existing.name);
  await expect(page.getByRole("dialog").getByRole("alert")).toContainText(
    "No Client was saved",
  );
  expect(state.inserts).toHaveLength(0);
  expect(state.corrections).toHaveLength(0);
  expect(state.serverClients).toEqual([existing]);
});
test("a unique-constraint race reloads the winning record without retrying or overwriting", async ({
  page,
}) => {
  const state = await workspace(page, []);
  state.race = true;
  await complete(page, "000777");
  await save(page);
  await expect(
    page.getByRole("status", { name: "Existing Client with this Man#" }),
  ).toContainText(existing.name);
  expect(state.inserts).toHaveLength(1);
  expect(state.lookups).toEqual(["000777", "000777"]);
  expect(state.serverClients).toHaveLength(1);
  expect(state.corrections).toHaveLength(0);
});
test("an unavailable duplicate check blocks saving, retains entered text and supports retry", async ({
  page,
}) => {
  const state = await workspace(page, []);
  state.failedLookup = true;
  await complete(page, "000042");
  await save(page);
  await expect(page.getByRole("dialog").getByRole("alert")).toContainText(
    "Could not verify this Man#",
  );
  await expect(
    page.getByRole("dialog").getByLabel("Man#", { exact: true }),
  ).toHaveValue("000042");
  expect(state.inserts).toHaveLength(0);
  state.failedLookup = false;
  await save(page);
  await expect(page.getByRole("dialog")).not.toBeVisible();
  expect(state.inserts).toHaveLength(1);
});
test("chosen pattern characters are literal text rather than wildcard matches", async ({
  page,
}) => {
  const state = await workspace(page, [
    { ...existing, man_number: "00XAbY01" },
  ]);
  const man = "00_Ab%*\\01";
  await complete(page, man);
  await save(page);
  await expect(page.getByRole("dialog")).not.toBeVisible();
  expect(state.lookups).toEqual([man]);
  expect(state.inserts[0].man_number).toBe(man);
});
test("a conflicting audited Man# correction does not reach the mutation RPC", async ({
  page,
}) => {
  const other = {
    ...existing,
    id: "cccccccc-cccc-4ccc-8ccc-cccccccccccc",
    name: "Fictional Second Client",
    man_number: "000002",
  };
  const state = await workspace(page, [existing, other]);
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Cancel", exact: true })
    .click();
  await navigate(page, "Clients");
  await page
    .getByRole("button", {
      name: "Client Details for " + existing.name,
      exact: true,
    })
    .click();
  const dialog = page.getByRole("dialog");
  await dialog.getByLabel("Man#", { exact: true }).fill(other.man_number);
  await dialog
    .getByLabel("Correction reason", { exact: true })
    .fill("Fictional identity correction reason");
  await dialog
    .getByRole("button", { name: "Save audited correction", exact: true })
    .click();
  await expect(
    page.getByRole("status", { name: "Existing Client with this Man#" }),
  ).toContainText(other.name);
  expect(state.corrections).toHaveLength(0);
  expect(state.clients).toEqual([existing, other]);
});

for (const theme of ["light", "dark"] as const) {
  test(`a maximum-length duplicate remains readable and usable on mobile in ${theme} mode`, async ({
    page,
  }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.emulateMedia({ colorScheme: theme });
    const errors: string[] = [];
    page.on("pageerror", (error) => errors.push(error.message));
    const client = { ...existing, man_number: "00" + "Ab".repeat(24) };
    await workspace(page, [client]);
    await page
      .getByRole("dialog")
      .getByLabel("Man#", { exact: true })
      .fill(client.man_number.toLowerCase());
    const conflict = page.getByRole("status", {
      name: "Existing Client with this Man#",
    });
    await expect(conflict).toContainText(client.man_number);
    await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
    await conflict.scrollIntoViewIfNeeded();
    expect(
      await page
        .getByRole("dialog")
        .evaluate((el) => el.scrollWidth <= el.clientWidth + 1),
    ).toBe(true);
    expect(
      await conflict.evaluate((el) => el.scrollWidth <= el.clientWidth + 1),
    ).toBe(true);
    expect(
      await page
        .getByRole("dialog")
        .locator(".client-register-fields label")
        .evaluateAll((labels) =>
          labels.every((label) => {
            const probe = document.createElement("span");
            probe.style.color = "var(--slate)";
            label.append(probe);
            const matches =
              getComputedStyle(label).color === getComputedStyle(probe).color;
            probe.remove();
            return matches;
          }),
        ),
    ).toBe(true);
    await page.screenshot({
      path: `/tmp/lendtrack-man-${theme}.png`,
      fullPage: true,
    });
    await conflict
      .getByRole("button", { name: "Open existing Client Details" })
      .click();
    await expect(
      page.getByRole("dialog").getByLabel("Client name", { exact: true }),
    ).toHaveValue(existing.name);
    expect(errors).toEqual([]);
  });
}
