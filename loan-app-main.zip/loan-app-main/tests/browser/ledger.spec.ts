import { navigate } from "./navigation";
import { test, expect } from "./fixtures";
test("desktop demo navigation, filtering, dialogs, and report export", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/demo");
  await expect(page.getByRole("heading", { name: "Dashboard" })).toBeVisible();
  await page.getByRole("button", { name: "Review overdue loans" }).click();
  const report = page.getByRole("region", { name: "Financial reporting" });
  await expect(report.locator("tbody")).toContainText("Grace Phiri");
  await expect(report.locator("tbody")).not.toContainText("Chanda Mwansa");
  await page
    .getByRole("button", { name: "View all loans", exact: true })
    .click();
  await page.getByRole("button", { name: "All loans", exact: true }).click();
  await page
    .getByRole("textbox", { name: "Search by Man# or Client Name" })
    .fill("Chanda");
  await expect(
    page.getByRole("cell", { name: "Chanda Mwansa chanda@example.com" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "New Loan", exact: true }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await navigate(page, "Clients");
  await expect(
    page.getByRole("heading", { name: "Client Register", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Add Client", exact: true }).click();
  await page.getByLabel("Man#", { exact: true }).fill("000999");
  await page.getByLabel("Department", { exact: true }).fill("Finance");
  await page.getByLabel("Designation", { exact: true }).fill("Analyst");
  await page.getByLabel("Client name", { exact: true }).fill("Test Client");
  await page.getByRole("button", { name: "Save Client" }).click();
  await expect(page.getByRole("dialog").getByRole("alert")).toContainText(
    "Connect your Supabase",
  );
  await page.getByRole("button", { name: "Cancel", exact: true }).click();
  await navigate(page, "Reports");
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Download .xlsx report" }).click();
  expect((await download).suggestedFilename()).toMatch(
    /client-loan-report-.*\.xlsx/,
  );
  expect(errors).toEqual([]);
});
test("mobile layout stays within viewport and navigation works", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/demo");
  await expect(page.getByRole("heading", { name: "Dashboard" })).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await navigate(page, "Repayments");
  await expect(
    page.getByRole("heading", { name: "Repayment history" }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Record Repayment Received", exact: true })
    .click();
  await expect(page.getByRole("dialog")).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
});

test("Man# search selects an existing Client and clears stale selections", async ({
  page,
}) => {
  await page.goto("/demo");
  await page.getByRole("button", { name: "New Loan", exact: true }).click();
  const dialog = page.getByRole("dialog");
  const lookup = dialog.getByRole("combobox", {
    name: "Search by Man# or Client Name",
  });
  await lookup.fill("001");
  await expect(dialog.getByRole("option")).toHaveCount(1);
  await page.keyboard.press("Enter");
  await expect(dialog.getByLabel("Client name", { exact: true })).toHaveValue(
    "Chanda Mwansa",
  );
  await expect(dialog.getByLabel("Department", { exact: true })).toHaveValue(
    "Finance",
  );
  await expect(dialog.getByLabel("Designation", { exact: true })).toHaveValue(
    "Accountant",
  );
  await expect(dialog.locator("input[name=client_id]")).toHaveValue("c1");
  await expect(
    dialog.getByLabel("Interest rate for entire term (%)"),
  ).toHaveValue("10");
  await dialog.getByLabel("Amount Disbursed (ZMW)").fill("1000");
  await expect(
    dialog.getByRole("region", { name: "Loan obligation preview" }),
  ).toContainText("1,100.00");
  await expect(
    dialog.getByRole("button", { name: "Review Loan", exact: true }),
  ).toBeEnabled();
  await lookup.fill("009999-unmatched");
  await expect(dialog.getByRole("status")).toHaveText("No client found");
  await expect(dialog.getByLabel("Client name", { exact: true })).toHaveValue(
    "",
  );
  await expect(dialog.locator("input[name=client_id]")).toHaveValue("");
  await expect(
    dialog.getByRole("button", { name: "Review Loan", exact: true }),
  ).toBeDisabled();
  await dialog.getByRole("button", { name: "Cancel", exact: true }).click();
  await navigate(page, "Clients");
  await expect(
    page.getByRole("heading", { name: "Client Register 6", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("textbox", { name: "Search by Man# or Client Name" })
    .fill("00124");
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await expect(
    page.getByRole("cell", { name: "00124", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", {
      name: "Client Details for Chanda Mwansa",
      exact: true,
    })
    .click();
  await expect(dialog.getByLabel("Man#", { exact: true })).toHaveValue("00124");
  await expect(
    dialog.getByRole("heading", { name: "Client audit trail" }),
  ).toBeVisible();
  await expect(dialog.getByLabel("Correction reason")).toBeVisible();
  await expect(
    dialog.getByRole("button", { name: "Save audited correction" }),
  ).toBeDisabled();
});

test("Client correction form fits a narrow viewport", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/demo");
  await navigate(page, "Clients");
  await page
    .getByRole("button", {
      name: "Client Details for Chanda Mwansa",
      exact: true,
    })
    .click();
  await expect(page.getByRole("dialog")).toBeVisible();
  expect(
    await page
      .getByRole("dialog")
      .evaluate((e) => e.scrollWidth <= e.clientWidth),
  ).toBe(true);
});
test("Excel import template downloads while demo uploads stay disabled", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/demo");
  await navigate(page, "Clients");
  await page.getByRole("button", { name: "Import .xlsx" }).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog.getByLabel("Import mode")).toBeDisabled();
  const download = page.waitForEvent("download");
  await dialog.getByRole("link", { name: "Download Import Template" }).click();
  expect((await download).suggestedFilename()).toBe(
    "lendtrack-import-template.xlsx",
  );
  expect(await dialog.evaluate((e) => e.scrollWidth <= e.clientWidth)).toBe(
    true,
  );
});
