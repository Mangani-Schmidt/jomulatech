import { test, expect, type Page } from "./fixtures";
import { withSessionRequests, fictionalProviderUser } from "./auth-fixture";
import { capabilitiesForRole } from "../../lib/permissions";
import { demoDefaults } from "../../lib/interest";
import { demoClients, demoLoans } from "../../lib/demo";
import { readFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import ExcelJS from "exceljs";
async function auth(page: Page) {
  await page.clock.setFixedTime(new Date("2026-11-14T10:00:00Z"));
  const actor = "11111111-1111-4111-8111-111111111111";
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({
        sub: actor,
        session_id: actor,
        exp: Math.floor(Date.now() / 1000) + 3600,
      }),
    ).toString("base64url"),
    "fictional-signature",
  ].join(".");
  await page.addInitScript(
    ({ actor, token }) => {
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "fictional",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          user: {
            id: actor,
            email: "fictional@example.test",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      );
      window.print = () => {
        (window as unknown as { printed: boolean }).printed = true;
      };
    },
    { actor, token },
  );
}
async function expenses(page: Page) {
  await auth(page);
  const day = "2026-11-14",
    first = day.slice(0, 8) + "01";
  const items = Array.from({ length: 25 }, (_, i) => ({
    id: "e" + i,
    expense_reference: "EXP-" + String(i).padStart(2, "0"),
    expense_date: first,
    amount: 0.29,
    amount_cents: 29,
    currency: "ZMW",
    category: "Fees",
    description: "Fictional fee " + String(i).padStart(2, "0") + " · École",
    payee: "Fictional bank",
    payment_method: "cash",
    external_reference: null,
    created_by: "fictional",
    created_at: day + "T08:00:00Z",
    reversed_at: null,
  }));
  const state = { export: true, view: true, requests: [] as string[] };
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const path = new URL(route.request().url()).pathname;
      state.requests.push(path);
      if (path === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({
          json: {
            ...demoDefaults,
            capabilities: {
              ...capabilitiesForRole("viewer"),
              can_view_expenses: state.view,
              can_export_reports: state.export,
            },
          },
        });
      if (path.endsWith("/has_capability"))
        return route.fulfill({
          json:
            route.request().postDataJSON().p_action === "view_expenses"
              ? state.view
              : state.export,
        });
      if (path.endsWith("/expenses"))
        return route.fulfill({
          json: [
            ...items,
            {
              ...items[0],
              id: "old",
              expense_reference: "EXP-OLD",
              description: "Prior payment reversal",
              expense_date: "2020-01-01",
              amount_cents: 101,
              reversed_at: first + "T12:00:00Z",
            },
            { ...items[0], id: "usd", currency: "USD", amount_cents: 99999 },
          ],
        });
      return route.fulfill({ json: [] });
    }),
  );
  return { state, first, day };
}
test("expense Excel, PDF and print include all filtered pages and reconciled period reversals", async ({
  page,
}, info) => {
  const { first, day } = await expenses(page);
  await page.goto("/expenses");
  await page.getByLabel("Expense activity from", { exact: true }).fill(first);
  await page
    .getByRole("button", { name: "Apply expense filters", exact: true })
    .click();
  await expect(
    page.getByLabel("Expense period totals", { exact: true }),
  ).toContainText("6.24");
  await expect(page.locator("tbody tr")).toHaveCount(20);
  const event = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Export Expenses to Excel", exact: true })
    .click();
  const file = await event;
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load((await readFile((await file.path())!)) as never);
  const sheet = wb.getWorksheet("Filtered expenses")!;
  expect(sheet.rowCount).toBe(31);
  expect(sheet.lastRow!.getCell(12).value).toBe(7.25);
  expect(sheet.lastRow!.getCell(13).value).toBe(1.01);
  expect(sheet.lastRow!.getCell(14).value).toBe(6.24);
  expect(sheet.getColumn(1).values).toContain("EXP-24");
  expect(sheet.getCell("L5").numFmt).toContain("ZMW");
  const pdfEvent = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Export Expenses to PDF", exact: true })
    .click();
  const pdf = await pdfEvent,
    path = info.outputPath("expenses.pdf");
  await pdf.saveAs(path);
  expect((await readFile(path)).subarray(0, 5).toString()).toBe("%PDF-");
  const text = execFileSync("pdftotext", [path, "-"], { encoding: "utf8" });
  expect(text).toContain("EXP-24");
  expect(text).toContain("6.24");
  expect(text).toContain("École");
  expect(text).toContain(first);
  expect(text).not.toContain("999.99");
  await page
    .getByRole("button", { name: "Print Expenses", exact: true })
    .click();
  const dialog = page.getByRole("dialog", {
    name: "Expense print preview",
    exact: true,
  });
  await expect(dialog).toContainText("EXP-24");
  await dialog
    .getByRole("button", { name: "Print Expenses", exact: true })
    .click();
  await expect
    .poll(() =>
      page.evaluate(() => (window as unknown as { printed: boolean }).printed),
    )
    .toBe(true);
  await page.emulateMedia({ media: "print" });
  await expect(page.locator(".settings-page")).not.toBeVisible();
  await page.pdf({ path: info.outputPath("expense-print.pdf"), format: "A4" });
  await page.emulateMedia({ media: "screen" });
  await dialog
    .getByRole("button", { name: "Close expense preview", exact: true })
    .click();
  await page.getByLabel("Search expenses", { exact: true }).fill("fee 00");
  await page
    .getByRole("button", { name: "Apply expense filters", exact: true })
    .click();
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await expect(
    page.getByLabel("Expense period totals", { exact: true }),
  ).toContainText("0.29");
});
test("expense export revocation blocks cached downloads and denied direct access mounts no expense data", async ({
  page,
}) => {
  const { state } = await expenses(page);
  await page.goto("/expenses");
  await expect(
    page.getByLabel("Expense period totals", { exact: true }),
  ).toBeVisible();
  const downloads: string[] = [];
  page.on("download", (d) => downloads.push(d.suggestedFilename()));
  state.export = false;
  await page
    .getByRole("button", { name: "Export Expenses to Excel", exact: true })
    .click();
  await expect(page.getByRole("main").getByRole("alert")).toContainText(
    "do not allow",
  );
  expect(downloads).toEqual([]);
  state.view = false;
  const count = state.requests.filter((p) => p.endsWith("/expenses")).length;
  await page.goto("/expenses");
  await expect(
    page.getByRole("heading", { name: "Access denied", exact: true }),
  ).toBeVisible();
  expect(state.requests.filter((p) => p.endsWith("/expenses"))).toHaveLength(
    count,
  );
});
test("repayment presets and custom range use payment dates and export the same current receipt totals", async ({
  page,
}) => {
  await auth(page);
  const day = "2026-11-14",
    first = day.slice(0, 8) + "01",
    second = day.slice(0, 8) + "02",
    loan = {
      ...demoLoans[0],
      created_at: "2020-01-01T00:00:00Z",
      disbursement_date: "2020-01-01",
    };
  const rows = [
    {
      id: "r1",
      loan_id: loan.id,
      payment_reference: "PAY-1",
      payment_date: first,
      created_at: "2020-01-01T00:00:00Z",
      amount_cents: 29,
      principal_allocation_cents: 20,
      interest_allocation_cents: 9,
    },
    {
      id: "r2",
      loan_id: loan.id,
      payment_reference: "PAY-2",
      payment_date: second,
      created_at: day + "T08:00:00Z",
      amount_cents: 100,
      reversed_at: day + "T09:00:00Z",
      principal_allocation_cents: 80,
      interest_allocation_cents: 20,
    },
    {
      id: "r3",
      loan_id: loan.id,
      payment_reference: "PAY-3",
      payment_date: day,
      created_at: day + "T08:00:00Z",
      amount_cents: 101,
      principal_allocation_cents: 80,
      interest_allocation_cents: 21,
    },
  ];
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      const path = new URL(route.request().url()).pathname;
      return route.fulfill({
        json:
          path === "/auth/v1/user"
            ? fictionalProviderUser(route)
            : path.endsWith("/loan_defaults")
              ? { ...demoDefaults, capabilities: capabilitiesForRole("viewer") }
              : path.endsWith("/has_capability")
                ? true
                : path.endsWith("/ledger_snapshot")
                  ? { clients: demoClients, loans: [loan], repayments: rows }
                  : [],
      });
    }),
  );
  await page.goto("/dashboard#repayments");
  await expect(page.locator("tbody tr")).toHaveCount(3);
  await page
    .getByRole("combobox", { name: "Repayment period", exact: true })
    .selectOption("Today");
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await expect(
    page.getByLabel("Filtered repayment totals", { exact: true }),
  ).toContainText("1.01");
  await page
    .getByRole("combobox", { name: "Repayment period", exact: true })
    .selectOption("Custom Date Range");
  await page.getByLabel("Payment date from", { exact: true }).fill(first);
  await page.getByLabel("Payment date to", { exact: true }).fill(second);
  await expect(page.locator("tbody tr")).toHaveCount(2);
  await expect(
    page.getByLabel("Filtered repayment totals", { exact: true }),
  ).toContainText("0.29");
  const event = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Export Repayments to Excel", exact: true })
    .click();
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load((await readFile((await (await event).path())!)) as never);
  const sheet = wb.getWorksheet("Filtered repayments")!;
  expect(sheet.rowCount).toBe(7);
  expect(sheet.lastRow!.getCell(12).value).toBe(0.29);
  expect(sheet.getColumn(1).values).not.toContain("PAY-3");
});

test("revoking expense view access blocks an already-open print preview", async ({
  page,
}) => {
  const { state } = await expenses(page);
  await page.goto("/expenses");
  await expect(
    page.getByLabel("Expense period totals", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Print Expenses", exact: true })
    .click();
  const dialog = page.getByRole("dialog", {
    name: "Expense print preview",
    exact: true,
  });
  await expect(dialog).toBeVisible();
  state.view = false;
  await dialog
    .getByRole("button", { name: "Print Expenses", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Access denied", exact: true }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => (window as unknown as { printed?: boolean }).printed,
    ),
  ).not.toBe(true);
});
