import { capabilitiesForRole } from "../../lib/permissions";
import { test, expect, type Page } from "./fixtures";
import type { Route } from "@playwright/test";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { demoReportSource } from "../../lib/demo";
import { demoDefaults } from "../../lib/interest";
import { today } from "../../lib/domain";
import {
  buildReport,
  defaultReportFilters,
  reportMoney,
} from "../../lib/reporting";
const owner = "11111111-1111-4111-8111-111111111111";
async function workspace(
  page: Page,
  financial: (route: Route) => Promise<void>,
) {
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "fictional-signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) => {
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "fictional-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "fictional-dashboard@example.test",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      );
    },
    { owner, token },
  );
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const path = new URL(route.request().url()).pathname;
      if (path === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({
          json: {
            ...demoDefaults,
            capabilities: {
              ...capabilitiesForRole("administrator"),
              is_admin: true,
              can_post_repayments: true,
              can_manage_expenses: true,
              role: "administrator",
            },
          },
        });
      if (path.endsWith("/ledger_snapshot"))
        return route.fulfill({
          json: {
            clients: demoReportSource.clients,
            loans: demoReportSource.loans,
            repayments: demoReportSource.repayments,
          },
        });
      if (path.endsWith("/report_source_filtered")) return financial(route);
      throw new Error("Unexpected fictional request: " + path);
    }),
  );
}
test("a failed refresh never replaces actual balances with zero and retry restores the summary", async ({
  page,
}) => {
  let fail = false;
  await workspace(page, (route) =>
    fail
      ? route.fulfill({
          status: 503,
          json: { code: "TEST_UNAVAILABLE", message: "Service unavailable" },
        })
      : route.fulfill({ json: demoReportSource }),
  );
  await page.goto("/dashboard");
  const report = page.getByRole("region", { name: "Financial reporting" });
  const quick = page.getByRole("region", { name: "Quick actions" });
  for (const name of ["New Loan", "Add Client", "Record Repayment Received"])
    await expect(
      quick.getByRole("button", { name, exact: true }),
    ).toBeEnabled();
  const expected = buildReport(demoReportSource, defaultReportFilters(today()));
  expect(expected.totals.owed).toBeGreaterThan(0);
  await expect(report.locator('[data-metric="owed"] strong')).toHaveText(
    reportMoney(expected.totals.owed, "ZMW"),
  );
  fail = true;
  await report.getByText("Change dates and filters", { exact: true }).click();
  await report
    .getByRole("button", { name: "Refresh summary", exact: true })
    .click();
  await expect(report.getByRole("alert")).toContainText(
    "Financial summary unavailable",
  );
  await expect(report.locator("[data-metric]")).toHaveCount(0);
  await expect(
    report.getByText("No loans in this selection", { exact: true }),
  ).toHaveCount(0);
  await expect(page.locator("table")).toHaveCount(0);
  fail = false;
  await report.getByRole("button", { name: "Retry financial summary" }).click();
  await expect(report.locator('[data-metric="owed"] strong')).toHaveText(
    reportMoney(expected.totals.owed, "ZMW"),
  );
  await expect(report.getByRole("alert")).toHaveCount(0);
});
test("a pending request has no balance cards, while a successful empty snapshot explicitly shows zero", async ({
  page,
}) => {
  let release!: () => void;
  const held = new Promise<void>((resolve) => {
    release = resolve;
  });
  await workspace(page, async (route) => {
    await held;
    return route.fulfill({
      json: {
        ...demoReportSource,
        clients: [],
        loans: [],
        repayments: [],
        terms_audit: [],
        status_audit: [],
        repayment_audit: [],
      },
    });
  });
  await page.goto("/dashboard");
  const report = page.getByRole("region", { name: "Financial reporting" });
  await expect(report.getByRole("status")).toContainText(
    "Loading financial summary",
  );
  await expect(report.locator("[data-metric]")).toHaveCount(0);
  await expect(
    report.getByText("No loans in this selection", { exact: true }),
  ).toHaveCount(0);
  release();
  await expect(
    report.getByText("No loans in this selection", { exact: true }),
  ).toBeVisible();
  await expect(report.locator("[data-metric]")).toHaveCount(4);
  await expect(report.locator('[data-metric="owed"] strong')).toHaveText(
    reportMoney(0, "ZMW"),
  );
  await expect(report.getByRole("alert")).toHaveCount(0);
});
test("an incomplete financial response is unavailable and never presented as an empty balance", async ({
  page,
}) => {
  await workspace(page, (route) =>
    route.fulfill({ json: { ...demoReportSource, repayments: null } }),
  );
  await page.goto("/dashboard");
  const report = page.getByRole("region", { name: "Financial reporting" });
  await expect(report.getByRole("alert")).toContainText(
    "reporting response was incomplete",
  );
  await expect(
    report.getByRole("button", { name: "Retry financial summary" }),
  ).toBeVisible();
  await expect(report.locator("[data-metric]")).toHaveCount(0);
  await expect(
    report.getByText("No loans in this selection", { exact: true }),
  ).toHaveCount(0);
});

for (const outcome of ["profit", "loss", "break-even"] as const)
  test(`reviewed report shows ${outcome} from interest and costs without counting principal`, async ({
    page,
  }) => {
    const f = defaultReportFilters(today());
    const base = buildReport({ ...demoReportSource, expenses: [] }, f);
    const cost =
      outcome === "profit"
        ? 0
        : base.recordedResult! + (outcome === "loss" ? 100 : 0);
    const expense = {
      id: "test-expense",
      expense_reference: "EXP-FICTIONAL",
      amount: cost / 100,
      amount_cents: cost,
      currency: f.currency,
      expense_date: f.from,
      category: "Fees",
      description: "Fictional expense",
      payment_method: "cash",
      payee: null,
      external_reference: null,
      created_by: owner,
      created_at: new Date().toISOString(),
      reversed_at: null,
      reversed_by: null,
      reversal_reason: null,
    };
    const source = {
      ...demoReportSource,
      expenses: cost ? [expense] : [],
      ledger_event_count: 42,
      certifications: [
        {
          id: "fictional-cert",
          from_date: f.from,
          to_date: f.to,
          currency: f.currency,
          ledger_event_count: 42,
          created_by: owner,
          created_at: new Date().toISOString(),
          reason: "Reviewed fictional costs",
          revoked_at: null,
        },
      ],
    };
    await workspace(page, (route) => route.fulfill({ json: source }));
    await page.goto("/dashboard");
    const panel = page.getByRole("region", {
      name: "Profit and expenses",
      exact: true,
    });
    await expect(panel.getByRole("heading")).toHaveText(
      outcome === "profit"
        ? "Profit this period"
        : outcome === "loss"
          ? "Loss this period"
          : "Break-even this period",
    );
    await panel
      .getByText("See how this was calculated", { exact: true })
      .click();
    await expect(panel.locator("[data-expense-total]")).toHaveText(
      reportMoney(cost, f.currency),
    );
    await expect(panel.locator(".performance-result")).toHaveText(
      reportMoney(Math.abs(base.recordedResult! - cost), f.currency),
    );
  });

test("verified empty costs show zero, and later unavailable costs cannot retain that zero or a profit", async ({
  page,
}) => {
  let hidden = false;
  await workspace(page, (route) =>
    route.fulfill({
      json: { ...demoReportSource, expenses: hidden ? null : [] },
    }),
  );
  await page.goto("/dashboard");
  const panel = page.getByRole("region", {
    name: "Profit and expenses",
    exact: true,
  });
  await expect(panel.getByRole("heading")).toHaveText(
    "Result from recorded entries",
  );
  await panel.getByText("See how this was calculated", { exact: true }).click();
  await expect(panel.locator("[data-expense-total]")).toHaveText(
    reportMoney(0, "ZMW"),
  );
  hidden = true;
  const report = page.getByRole("region", { name: "Financial reporting" });
  await report.getByText("Change dates and filters", { exact: true }).click();
  await report
    .getByRole("button", { name: "Refresh summary", exact: true })
    .click();
  await expect(panel.locator("[data-expense-total]")).toHaveText("Unavailable");
  await expect(panel.locator(".performance-result")).toHaveText(
    "Not available",
  );
});

test("a permitted Reports view retains business results when standalone loan and repayment modules are hidden", async ({
  page,
}) => {
  await workspace(page, (route) => route.fulfill({ json: demoReportSource }));
  await page.route(
    "https://register-tests.supabase.co/rest/v1/rpc/loan_defaults",
    (route) =>
      route.fulfill({
        json: {
          ...demoDefaults,
          capabilities: {
            ...capabilitiesForRole("viewer"),
            can_view_loans: false,
            can_view_repayments: false,
            can_view_dashboard: false,
            can_view_reports: true,
          },
        },
      }),
  );
  await page.goto("/dashboard#reports");
  await expect(
    page.getByRole("region", { name: "Profit and expenses", exact: true }),
  ).toBeVisible();
  const nav = page.getByRole("navigation", { name: "Main navigation" });
  await expect(
    nav.getByRole("link", { name: "Loan History", exact: true }),
  ).toHaveCount(0);
  await expect(
    nav.getByRole("link", { name: "Repayments", exact: true }),
  ).toHaveCount(0);
  await expect(
    page.locator('[data-metric="interestReceived"] strong'),
  ).toBeVisible();
});
