import { capabilitiesForRole } from "../../lib/permissions";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { navigate } from "./navigation";
import { test, expect } from "./fixtures";
import { demoClients } from "../../lib/demo";
import { demoDefaults, dueDate } from "../../lib/interest";
import { today, type Loan } from "../../lib/domain";
test("multiple loans retain separate references and an audited write-off never becomes Repayment Received", async ({
  page,
}) => {
  const owner = "11111111-1111-4111-8111-111111111111";
  const first = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
    second = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb";
  const stamp = new Date().toISOString();
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "test-signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "test-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "admin@example.com",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      ),
    { owner, token },
  );
  const base: Loan = {
    id: first,
    client_id: "c1",
    principal_cents: 100000,
    interest_cents: 10000,
    balance_cents: 110000,
    loan_reference: "LN-00000101",
    disbursement_date: today(),
    due_date: dueDate(today(), 30),
    created_at: stamp,
    updated_at: stamp,
    created_by: owner,
    creator_inferred: false,
    lifecycle_status: "active",
    status: "active",
    interest_rate_bps: 1000,
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    term_days: 30,
    currency: "ZMW",
    business_timezone: "Africa/Lusaka",
    terms_revision: 1,
    total_obligation_cents: 110000,
  };
  let loans: Loan[] = [
    base,
    {
      ...base,
      id: second,
      loan_reference: "LN-00000102",
      balance_cents: 50000,
    },
  ];
  let wrote = false;
  const statusAudit: unknown[] = [];
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const url = new URL(route.request().url());
      const path = url.pathname;
      const respond = (data: unknown) =>
        route.fulfill({
          contentType: "application/json",
          body: JSON.stringify(data),
        });
      if (path.endsWith("/loan_defaults"))
        return respond({
          ...demoDefaults,
          capabilities: {
            ...capabilitiesForRole("administrator"),
            is_admin: true,
            can_post_repayments: true,
            can_override_rate: true,
          },
        });
      if (path.endsWith("/ledger_snapshot"))
        return respond({
          clients: demoClients,
          loans,
          repayments: [
            {
              id: "receipt-1",
              loan_id: second,
              amount_cents: 60000,
              created_at: stamp,
            },
          ],
        });
      if (path.endsWith("/clients")) return respond(demoClients);
      if (path.endsWith("/loan_register")) {
        const id = url.searchParams.get("id")?.replace("eq.", "");
        return respond(id ? loans.find((l) => l.id === id) : loans);
      }
      if (path.endsWith("/repayment_register"))
        return respond([
          {
            id: "receipt-1",
            loan_id: second,
            amount_cents: 60000,
            created_at: stamp,
          },
        ]);
      if (path.endsWith("/loan_terms_audit")) return respond([]);
      if (path.endsWith("/loan_status_audit")) return respond(statusAudit);
      if (path.endsWith("/write_off_loan")) {
        const body = route.request().postDataJSON();
        expect(body).toMatchObject({
          p_loan_id: first,
          p_expected_balance_cents: 110000,
          p_expected_terms_revision: 1,
          p_reason: "Approved unrecoverable balance",
          p_confirm: true,
        });
        wrote = true;
        loans = loans.map((l) =>
          l.id === first
            ? {
                ...l,
                lifecycle_status: "written_off",
                status: "written_off",
                written_off_cents: 110000,
                written_off_reason: body.p_reason,
                written_off_at: stamp,
                written_off_by: owner,
              }
            : l,
        );
        statusAudit.push({
          id: "status-1",
          action: "write_off",
          reason: body.p_reason,
          actor_id: owner,
          created_at: stamp,
          before_status: "active",
          after_status: "written_off",
        });
        return respond(first);
      }
      return respond([]);
    }),
  );
  await page.goto("/dashboard");
  await page
    .getByRole("button", { name: "View all loans", exact: true })
    .click();
  await expect(
    page.getByRole("cell", { name: "LN-00000101", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("cell", { name: "LN-00000102", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("columnheader", { name: "Amount Disbursed", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("textbox", { name: "Search by Man# or Client Name" })
    .fill("LN-00000101");
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await page
    .getByRole("button", {
      name: "View loan terms for Chanda Mwansa · LN-00000101",
      exact: true,
    })
    .click();
  const dialog = page.getByRole("dialog");
  await expect(dialog.getByText(owner, { exact: true }).first()).toBeVisible();
  await expect(
    dialog.getByRole("button", { name: "Confirm write-off", exact: true }),
  ).toBeDisabled();
  await dialog
    .getByLabel("Write-off reason")
    .fill("Approved unrecoverable balance");
  expect(wrote).toBe(false);
  await dialog
    .getByRole("checkbox", {
      name: "I confirm the unpaid balance and authorize this write-off.",
    })
    .check();
  await dialog
    .getByRole("button", { name: "Confirm write-off", exact: true })
    .click();
  await expect(dialog).not.toBeVisible();
  expect(wrote).toBe(true);
  expect(loans[0].balance_cents).toBe(110000);
  expect(loans[1].balance_cents).toBe(50000);
  await page
    .getByRole("textbox", { name: "Search by Man# or Client Name" })
    .fill("");
  await page.getByRole("button", { name: "Written off", exact: true }).click();
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await page
    .getByRole("button", {
      name: "View loan terms for Chanda Mwansa · LN-00000101",
      exact: true,
    })
    .click();
  await expect(
    dialog
      .locator(".audit-trail")
      .getByText("Approved unrecoverable balance", { exact: true }),
  ).toHaveCount(1);
  await expect(
    dialog.getByRole("button", { name: "Save audited loan adjustment" }),
  ).toHaveCount(0);
  await expect(
    dialog.getByRole("button", { name: "Confirm write-off", exact: true }),
  ).toHaveCount(0);
  await expect(
    dialog.getByRole("heading", { name: "Loan status history" }),
  ).toBeVisible();
  await dialog.getByRole("button", { name: "Close dialog" }).click();
  await navigate(page, "Repayments");
  await expect(
    page.getByRole("columnheader", { name: "Repayment Received", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Record Repayment Received", exact: true })
    .click();
  await expect(dialog.getByRole("option", { name: /LN-00000101/ })).toHaveCount(
    0,
  );
  await expect(dialog.getByRole("option", { name: /LN-00000102/ })).toHaveCount(
    1,
  );
});
