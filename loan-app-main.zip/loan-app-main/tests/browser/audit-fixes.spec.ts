import { capabilitiesForRole } from "../../lib/permissions";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { test, expect, type Page } from "./fixtures";
import { demoClients } from "../../lib/demo";
import { demoDefaults, dueDate } from "../../lib/interest";
import { today, type Loan, type Repayment } from "../../lib/domain";
const owner = "11111111-1111-4111-8111-111111111111",
  loanId = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";
const user = {
  id: owner,
  email: "audit@example.test",
  aud: "authenticated",
  role: "authenticated",
  app_metadata: {},
  user_metadata: {},
  created_at: "2026-01-01T00:00:00Z",
};
function token(aal = "aal1") {
  return [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({
        sub: owner,
        exp: Math.floor(Date.now() / 1000) + 3600,
        aal,
        amr:
          aal === "aal2"
            ? [{ method: "totp", timestamp: Math.floor(Date.now() / 1000) }]
            : [],
      }),
    ).toString("base64url"),
    "fictional-signature",
  ].join(".");
}
async function auth(page: Page) {
  await page.addInitScript(
    ({ user, token }) => {
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "fictional-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user,
        }),
      );
    },
    { user, token: token() },
  );
}
const capabilities = {
  ...capabilitiesForRole("administrator"),
  is_admin: true,
  can_override_rate: true,
  can_post_repayments: true,
  can_import: true,
  can_manage_expenses: true,
  role: "administrator",
};
test("password recovery requests the exact security redirect without exposing account existence", async ({
  page,
}) => {
  let requested = false;
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const url = new URL(route.request().url());
      if (url.pathname.endsWith("/recover")) {
        expect(url.searchParams.get("redirect_to")).toBe(
          "http://127.0.0.1:3002/security",
        );
        expect(route.request().postDataJSON().email).toBe(
          "fictional-recovery@example.test",
        );
        requested = true;
        return route.fulfill({ json: {} });
      }
      return route.fulfill({ json: [] });
    }),
  );
  await page.goto("/forgot-password");
  await page
    .getByLabel("Email", { exact: true })
    .fill("fictional-recovery@example.test");
  await page
    .getByRole("button", { name: "Send recovery link", exact: true })
    .click();
  await expect(page.locator(".auth-form").getByRole("status")).toContainText(
    "If an account exists",
  );
  expect(requested).toBe(true);
});
test("a signed-in security session updates only matching passwords of at least six characters", async ({
  page,
}) => {
  await auth(page);
  let updates = 0;
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const path = new URL(route.request().url()).pathname;
      if (path.endsWith("/user") && route.request().method() === "PUT") {
        expect(route.request().postDataJSON().password).toBe("abc123");
        updates++;
        return route.fulfill({ json: user });
      }
      if (path.endsWith("/user"))
        return route.fulfill({ json: { ...user, factors: [] } });
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({ json: { ...demoDefaults, capabilities } });
      if (path.endsWith("/account_security"))
        return route.fulfill({
          json: {
            role: "administrator",
            admin_mfa_required: false,
            recent_assurance: false,
          },
        });
      return route.fulfill({ json: [] });
    }),
  );
  await page.goto("/security");
  await expect(
    page.getByLabel("New password", { exact: true }),
  ).toHaveAttribute("minlength", "6");
  await page.getByLabel("New password", { exact: true }).fill("abc12");
  await page.getByLabel("Repeat new password", { exact: true }).fill("abc12");
  await page
    .getByRole("button", { name: "Update password", exact: true })
    .click();
  await expect(page.locator(".notice.error")).toContainText("at least 6");
  expect(updates).toBe(0);
  await page.getByLabel("New password", { exact: true }).fill("abc123");
  await page.getByLabel("Repeat new password", { exact: true }).fill("abcdef");
  await page
    .getByRole("button", { name: "Update password", exact: true })
    .click();
  await expect(page.locator(".notice.error")).toContainText(
    "Passwords must match.",
  );
  expect(updates).toBe(0);
  await page.getByLabel("Repeat new password", { exact: true }).fill("abc123");
  await page
    .getByRole("button", { name: "Update password", exact: true })
    .click();
  await expect(page.locator(".notice.success")).toContainText(
    "Password updated",
  );
  await expect(page.getByLabel("New password", { exact: true })).toHaveValue(
    "",
  );
  expect(updates).toBe(1);
});
function loan(): Loan {
  return {
    id: loanId,
    client_id: demoClients[0].id,
    loan_reference: "LN-AUDIT-1",
    principal_cents: 100000,
    interest_cents: 10000,
    balance_cents: 110000,
    principal_outstanding_cents: 100000,
    interest_outstanding_cents: 10000,
    terms_revision: 1,
    disbursement_date: today(),
    due_date: dueDate(today(), 30),
    created_at: new Date().toISOString(),
    lifecycle_status: "active",
    currency: "ZMW",
  };
}
test("Client Register paginates without losing searchable leading-zero Clients", async ({
  page,
}) => {
  await auth(page);
  const clients = Array.from({ length: 25 }, (_, i) => ({
    ...demoClients[0],
    id: "c" + i,
    name: "Fictional Client " + String(i).padStart(3, "0"),
    man_number: String(i).padStart(6, "0"),
  }));
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const path = new URL(route.request().url()).pathname;
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({ json: { ...demoDefaults, capabilities } });
      if (path.endsWith("/ledger_snapshot"))
        return route.fulfill({ json: { clients, loans: [], repayments: [] } });
      return route.fulfill({ json: [] });
    }),
  );
  await page.goto("/dashboard/#clients");
  await expect(page.locator("tbody tr")).toHaveCount(20);
  await page.getByRole("button", { name: "Next Clients", exact: true }).click();
  await expect(page.locator("tbody tr")).toHaveCount(5);
  await expect(page.locator("tbody")).toContainText("000024");
  await page
    .getByRole("textbox", { name: "Search by Man# or Client Name" })
    .fill("000024");
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await expect(page.locator("tbody")).toContainText("Fictional Client 024");
});
for (const committed of [true, false])
  test(`uncertain repayment survives reload and recovers its original key (${committed ? "committed" : "not committed"})`, async ({
    page,
  }) => {
    await auth(page);
    let current = loan();
    const original = { ...current };
    let receipts: Repayment[] = [];
    const calls: any[] = [];
    let saved: any = null;
    let statuses = 0;
    await page.route(
      "https://register-tests.supabase.co/**",
      withSessionRequests(async (route) => {
        const path = new URL(route.request().url()).pathname,
          respond = (data: unknown) => route.fulfill({ json: data });
        if (path.endsWith("/loan_defaults"))
          return respond({ ...demoDefaults, capabilities });
        if (path.endsWith("/ledger_snapshot"))
          return respond({
            clients: demoClients,
            loans: [current],
            repayments: receipts,
          });
        if (path.endsWith("/report_source_filtered"))
          return respond({
            generated_at: new Date().toISOString(),
            timezone: "Africa/Lusaka",
            clients: demoClients,
            loans: [current],
            repayments: receipts,
            terms_audit: [
              {
                id: "terms",
                loan_id: loanId,
                action: "originate",
                after_data: original,
                created_at: original.created_at,
              },
            ],
            status_audit: [],
            repayment_audit: [],
          });
        if (path.endsWith("/posting_request_status")) {
          statuses++;
          expect(route.request().postDataJSON().p_request_id).toBe(
            calls[0].p_request_id,
          );
          return respond(saved);
        }
        if (path.endsWith("/post_repayment")) {
          const body = route.request().postDataJSON();
          calls.push(body);
          if (calls.length > 1) expect(body).toEqual(calls[0]);
          if ((committed || calls.length > 1) && !saved) {
            const receipt: Repayment = {
              id: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
              loan_id: loanId,
              amount_cents: 15000,
              interest_allocation_cents: 10000,
              principal_allocation_cents: 5000,
              payment_date: today(),
              payment_method: "cash",
              payment_reference: "PAY-AUDIT-1",
              created_at: new Date().toISOString(),
              posting_status: "posted",
            };
            receipts = [receipt];
            current = {
              ...current,
              balance_cents: 95000,
              interest_outstanding_cents: 0,
              principal_outstanding_cents: 95000,
            };
            saved = { repayment_id: receipt.id };
          }
          if (calls.length === 1) return route.abort("failed");
          return respond(saved);
        }
        if (path.endsWith("/receipt_document"))
          return respond({
            generated_at: new Date().toISOString(),
            receipt: receipts[0],
            audit: [],
          });
        if (path.endsWith("/user")) return respond(user);
        return respond([]);
      }),
    );
    await page.goto("/dashboard/#repayments");
    await page
      .getByRole("button", { name: "Record Repayment Received", exact: true })
      .click();
    let dialog = page.getByRole("dialog");
    await dialog
      .getByRole("combobox", { name: "Loan", exact: true })
      .selectOption(loanId);
    await dialog.getByLabel("Repayment Received (ZMW)").fill("150");
    await dialog
      .getByRole("combobox", { name: "Payment method", exact: true })
      .selectOption("cash");
    await dialog
      .getByRole("button", { name: "Review Repayment", exact: true })
      .click();
    await dialog.getByRole("checkbox").check();
    await dialog
      .getByRole("button", { name: "Confirm Repayment Received", exact: true })
      .click();
    await expect(
      dialog.getByRole("button", { name: "Recover pending transaction" }),
    ).toBeVisible();
    await expect(
      dialog.getByRole("button", {
        name: "Confirm Repayment Received",
        exact: true,
      }),
    ).toBeDisabled();
    await page.reload();
    await page
      .getByRole("button", { name: "Record Repayment Received", exact: true })
      .click();
    dialog = page.getByRole("dialog");
    await expect(dialog.getByLabel("Repayment Received (ZMW)")).toBeDisabled();
    await dialog
      .getByRole("button", { name: "Recover pending transaction" })
      .click();
    if (!committed) {
      await expect(dialog.getByRole("alert")).toContainText(
        "Re-enter and review",
      );
      await expect(dialog.getByLabel("Repayment Received (ZMW)")).toBeEnabled();
      await dialog
        .getByRole("combobox", { name: "Loan", exact: true })
        .selectOption(loanId);
      await dialog.getByLabel("Repayment Received (ZMW)").fill("150");
      await dialog
        .getByRole("combobox", { name: "Payment method", exact: true })
        .selectOption("cash");
      await dialog
        .getByRole("button", { name: "Review Repayment", exact: true })
        .click();
      await dialog.getByRole("checkbox").check();
      await dialog
        .getByRole("button", {
          name: "Confirm Repayment Received",
          exact: true,
        })
        .click();
    }
    await expect(dialog.locator(".print-area")).toContainText("PAY-AUDIT-1");
    expect(statuses).toBe(1);
    expect(calls).toHaveLength(committed ? 1 : 2);
    expect(receipts).toHaveLength(1);
    expect(current.balance_cents).toBe(95000);
    expect(
      await page.evaluate(
        (id) => localStorage.getItem("lendwell:pending-posting:" + id),
        owner,
      ),
    ).toBeNull();
  });

test("a delayed older ledger snapshot cannot overwrite a completed Client registration", async ({
  page,
}) => {
  await auth(page);
  let reads = 0;
  let release!: () => void;
  const held = new Promise<void>((resolve) => {
    release = resolve;
  });
  const created = {
    ...demoClients[0],
    id: "fictional-new-client",
    man_number: "000099",
    name: "New Snapshot Client",
  };
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const path = new URL(route.request().url()).pathname;
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({ json: { ...demoDefaults, capabilities } });
      if (path.endsWith("/ledger_snapshot")) {
        reads++;
        if (reads === 1) {
          await held;
          return route.fulfill({
            json: { clients: [], loans: [], repayments: [] },
          });
        }
        return route.fulfill({
          json: { clients: [created], loans: [], repayments: [] },
        });
      }
      if (path.endsWith("/find_client_by_man"))
        return route.fulfill({ json: null });
      if (path.endsWith("/clients") && route.request().method() === "POST")
        return route.fulfill({ status: 201, json: null });
      return route.fulfill({ json: [] });
    }),
  );
  await page.goto("/dashboard/#clients");
  await expect.poll(() => reads).toBe(1);
  await page.getByRole("button", { name: "Add Client", exact: true }).click();
  const dialog = page.getByRole("dialog");
  await dialog.getByLabel("Man#", { exact: true }).fill(created.man_number!);
  await dialog.getByLabel("Client name", { exact: true }).fill(created.name);
  await dialog.getByLabel("Department", { exact: true }).fill("Finance");
  await dialog.getByLabel("Designation", { exact: true }).fill("Analyst");
  await dialog
    .getByRole("button", { name: "Save Client", exact: true })
    .click();
  await expect(dialog).not.toBeVisible();
  await expect(page.locator("tbody")).toContainText(created.name);
  const response = page.waitForResponse((r) =>
    r.url().endsWith("/ledger_snapshot"),
  );
  release();
  await response;
  await page.evaluate(
    () =>
      new Promise<void>((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
      ),
  );
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await expect(page.locator("tbody")).toContainText(created.name);
  expect(reads).toBe(2);
});

test("coverage approval enables exact business profit and a later revision removes it", async ({
  page,
}) => {
  await auth(page);
  const original = loan(),
    receipt = {
      id: "r1",
      loan_id: loanId,
      amount_cents: 15000,
      interest_allocation_cents: 10000,
      principal_allocation_cents: 5000,
      payment_date: today(),
      created_at: new Date().toISOString(),
    };
  let revision = 1;
  const certifications: any[] = [];
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const path = new URL(route.request().url()).pathname,
        respond = (data: unknown) => route.fulfill({ json: data });
      if (path.endsWith("/loan_defaults"))
        return respond({ ...demoDefaults, capabilities });
      if (path.endsWith("/ledger_snapshot"))
        return respond({
          clients: demoClients,
          loans: [original],
          repayments: [receipt],
        });
      if (path.endsWith("/report_source_filtered"))
        return respond({
          generated_at: new Date().toISOString(),
          timezone: "Africa/Lusaka",
          ledger_event_count: revision,
          certifications,
          clients: demoClients,
          loans: [original],
          repayments: [receipt],
          terms_audit: [
            {
              id: "a1",
              loan_id: loanId,
              action: "originate",
              created_at: original.created_at,
              after_data: original,
            },
          ],
          status_audit: [],
          repayment_audit: [],
          expenses: [],
        });
      if (path.endsWith("/certify_reporting_period")) {
        const p = route.request().postDataJSON();
        expect(p).toMatchObject({
          p_expenses_complete: true,
          p_losses_complete: true,
          p_expected_event_count: 1,
          p_confirm: true,
        });
        certifications.push({
          id: "coverage-1",
          from_date: p.p_from,
          to_date: p.p_to,
          currency: "ZMW",
          ledger_event_count: 1,
          created_by: owner,
          created_at: new Date().toISOString(),
          revoked_at: null,
          reason: p.p_reason,
        });
        return respond({ certification_id: "coverage-1" });
      }
      return respond([]);
    }),
  );
  await page.goto("/dashboard/#reports");
  const report = page.getByRole("region", { name: "Financial reporting" });
  await expect(
    report.getByRole("heading", {
      name: "Result from recorded entries",
      exact: true,
    }),
  ).toBeVisible();
  await report
    .getByText("Reporting coverage approval", { exact: true })
    .click();
  await report
    .getByLabel("Coverage approval or revocation reason")
    .fill("Fictional complete expenses and losses reviewed");
  await report.getByLabel(/All paid business expenses/).check();
  await report.getByLabel(/All recognized principal losses/).check();
  await report.getByLabel(/I approve this period and snapshot/).check();
  await report
    .getByRole("button", { name: "Approve reporting coverage" })
    .click();
  await expect(
    report.getByRole("heading", { name: "Profit this period", exact: true }),
  ).toBeVisible();
  await expect(report).toContainText("coverage-1");
  revision = 2;
  await report.getByText("Report filters", { exact: true }).click();
  await report.getByRole("button", { name: "Refresh report snapshot" }).click();
  await expect(
    report.getByRole("heading", { name: "Profit this period", exact: true }),
  ).toHaveCount(0);
});

test("audit history reaches older than 100 entries using stable cursors", async ({
  page,
}) => {
  await auth(page);
  const stamp = Date.now();
  const events = Array.from({ length: 101 }, (_, i) => ({
    id: "aaaaaaaa-aaaa-4aaa-8aaa-" + String(i + 1).padStart(12, "0"),
    created_at: new Date(stamp - i * 1000).toISOString(),
    entity_type: "Client",
    action: "correct",
    reason: `Fictional event ${i + 1}`,
    actor_id: owner,
  }));
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const url = new URL(route.request().url()),
        path = url.pathname;
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({ json: { ...demoDefaults, capabilities } });
      if (path.endsWith("/user_roles"))
        return route.fulfill({
          json: [
            {
              user_id: owner,
              role: "administrator",
              revision: 1,
              is_active: true,
            },
          ],
        });
      if (path.endsWith("/audit_events")) {
        const or = url.searchParams.get("or") ?? "";
        const cursor = events.findIndex((e) => or.includes(e.id));
        const values = events.slice(cursor + 1);
        return route.fulfill({
          json: values.slice(0, 51),
          headers: {
            "content-range": `0-${Math.min(50, values.length - 1)}/${values.length}`,
          },
        });
      }
      return route.fulfill({ json: [] });
    }),
  );
  await page.goto("/audit-logs");
  await expect(
    page.getByText("Fictional event 50", { exact: false }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Older audit entries" }).click();
  await expect(
    page.getByText("Fictional event 100", { exact: false }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Older audit entries" }).click();
  await expect(
    page.getByText("Fictional event 101", { exact: false }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Older audit entries" }),
  ).toBeDisabled();
});

test("authenticator enrollment and recent verification precede policy approval", async ({
  page,
}) => {
  await auth(page);
  let verified = false,
    required = false,
    enrolled = false;
  const factorId = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb";
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      const req = route.request(),
        path = new URL(req.url()).pathname,
        respond = (data: unknown) => route.fulfill({ json: data });
      if (path.endsWith("/loan_defaults"))
        return respond({ ...demoDefaults, capabilities });
      if (path.endsWith("/account_security"))
        return respond({
          role: "administrator",
          admin_mfa_required: required,
          recent_assurance: verified,
        });
      if (path.endsWith("/user"))
        return respond({
          ...user,
          factors: enrolled
            ? [
                {
                  id: factorId,
                  factor_type: "totp",
                  status: verified ? "verified" : "unverified",
                  friendly_name: "Fictional authenticator",
                },
              ]
            : [],
        });
      if (path.endsWith("/factors") && req.method() === "POST") {
        enrolled = true;
        return respond({
          id: factorId,
          type: "totp",
          totp: {
            qr_code:
              '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><rect width="20" height="20"/></svg>',
            secret: "FICTIONALSETUPKEY",
            uri: "otpauth://totp/Fictional",
          },
        });
      }
      if (path.endsWith("/challenge"))
        return respond({
          id: "challenge-1",
          expires_at: Math.floor(Date.now() / 1000) + 60,
        });
      if (path.endsWith("/verify")) {
        expect(req.postDataJSON().code).toBe("123456");
        verified = true;
        return respond({
          access_token: token("aal2"),
          refresh_token: "fictional-refresh",
          token_type: "bearer",
          expires_in: 3600,
          user: {
            ...user,
            factors: [
              {
                id: factorId,
                factor_type: "totp",
                status: "verified",
                friendly_name: "Fictional authenticator",
              },
            ],
          },
        });
      }
      if (path.endsWith("/set_admin_mfa_policy")) {
        expect(req.postDataJSON()).toMatchObject({
          p_required: true,
          p_confirm: true,
        });
        expect(verified).toBe(true);
        required = true;
        return respond({ admin_mfa_required: true });
      }
      return respond([]);
    }),
  );
  await page.goto("/security");
  await page.getByRole("button", { name: "Set up an authenticator" }).click();
  await expect(page.getByLabel("Manual authenticator setup key")).toHaveValue(
    "FICTIONALSETUPKEY",
  );
  await page.getByLabel("Six-digit authenticator code").fill("123456");
  await page
    .getByRole("button", { name: "Verify authenticator", exact: true })
    .click();
  await expect(page.getByLabel("Manual authenticator setup key")).toHaveCount(
    0,
  );
  await page.getByLabel(/Require recent authenticator verification/).check();
  await page
    .getByLabel("Policy change reason")
    .fill("Fictional approved business security policy");
  await page.getByLabel(/I approve this business policy/).check();
  await page
    .getByRole("button", { name: "Save authentication policy" })
    .click();
  await expect(page.getByRole("status")).toContainText("saved and audited");
  expect(required).toBe(true);
});
