import { test, expect } from "./fixtures";
import { navigate } from "./navigation";
const labels = [
  "Dashboard",
  "Clients",
  "Loan History",
  "New Loan",
  "Repayments",
  "Reports",
  "Excel Imports",
  "Settings",
];
for (const width of [390, 1440])
  test(`navigation and financial review preserve details at ${width}px`, async ({
    page,
  }) => {
    const errors: string[] = [];
    page.on("pageerror", (e) => errors.push(e.message));
    await page.setViewportSize({ width, height: 950 });
    await page.goto("/demo");
    if (width === 390)
      await page
        .getByRole("button", { name: "Open navigation", exact: true })
        .click();
    const nav = page.getByRole("navigation", { name: "Main navigation" });
    expect(await nav.getByRole("link").allTextContents()).toEqual(labels);
    await nav.getByRole("link", { name: "New Loan", exact: true }).focus();
    await page.keyboard.press("Enter");
    await expect(page).toHaveURL(/#new-loan$/);
    await expect(
      page.getByRole("heading", { name: "New Loan", exact: true }),
    ).toBeFocused();
    const lookup = page.getByRole("combobox", {
      name: "Search by Man# or Client Name",
    });
    await lookup.fill("00124");
    await page.keyboard.press("Enter");
    await page.getByLabel("Amount Disbursed (ZMW)").fill("1000");
    await page
      .getByRole("button", { name: "Review Loan", exact: true })
      .click();
    const loanReview = page.getByRole("region", { name: "Confirm New Loan" });
    await expect(loanReview.getByRole("heading")).toBeFocused();
    await expect(loanReview).toContainText("Chanda Mwansa");
    await expect(loanReview).toContainText("00124");
    await expect(loanReview).toContainText("1,100.00");
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    await expect(
      loanReview.getByRole("button", { name: "Confirm Loan", exact: true }),
    ).toBeDisabled();
    await loanReview
      .getByRole("button", { name: "Back to Loan Details" })
      .click();
    await expect(page.getByLabel("Client name", { exact: true })).toHaveValue(
      "Chanda Mwansa",
    );
    await page.getByLabel("Amount Disbursed (ZMW)").fill("1500");
    await page
      .getByRole("button", { name: "Review Loan", exact: true })
      .click();
    await expect(loanReview).toContainText("1,650.00");
    await loanReview.getByRole("checkbox").focus();
    await page.keyboard.press("Space");
    await expect(
      loanReview.getByRole("button", { name: "Confirm Loan", exact: true }),
    ).toBeEnabled();
    await loanReview
      .getByRole("button", { name: "Back to Loan Details" })
      .click();
    await page.getByRole("button", { name: "Cancel", exact: true }).click();
    await expect(page).toHaveURL(/#dashboard$/);
    await navigate(page, "Repayments");
    await page
      .getByRole("button", { name: "Record Repayment Received", exact: true })
      .click();
    const dialog = page.getByRole("dialog");
    await dialog.getByRole("combobox").first().selectOption("l5");
    await dialog
      .getByLabel("Repayment Received (ZMW)", { exact: true })
      .fill("150");
    await dialog
      .getByLabel("Payment method", { exact: true })
      .selectOption("cash");
    await dialog
      .getByRole("button", { name: "Review Repayment", exact: true })
      .click();
    const repayment = dialog.getByRole("region", {
      name: "Confirm Repayment Received",
      exact: true,
    });
    await expect(repayment.getByRole("heading")).toBeFocused();
    await expect(repayment).toContainText("Peter Zulu");
    await expect(repayment).toContainText("LN-00000005");
    await expect(repayment).toContainText("13,050.00");
    expect(await dialog.evaluate((e) => e.scrollWidth <= e.clientWidth)).toBe(
      true,
    );
    await expect(
      repayment.getByRole("button", {
        name: "Confirm Repayment Received",
        exact: true,
      }),
    ).toBeDisabled();
    await repayment
      .getByRole("button", { name: "Back to Repayment Details" })
      .click();
    await expect(
      dialog.getByLabel("Repayment Received (ZMW)", { exact: true }),
    ).toHaveValue("150");
    expect(await dialog.evaluate((e) => e.scrollWidth <= e.clientWidth)).toBe(
      true,
    );
    await page.keyboard.press("Escape");
    await navigate(page, "Excel Imports");
    await expect(
      page.getByRole("heading", { name: "Excel Imports", exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("link", { name: "Download Import Template" }),
    ).toBeVisible();
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    expect(errors).toEqual([]);
  });
test("keyboard Client actions expose consistent summaries, scoped histories, and native focus return", async ({
  page,
}) => {
  await page.goto("/demo/#clients");
  await expect(
    page.getByRole("heading", { name: "Client Register", exact: true }),
  ).toBeFocused();
  await page.getByRole("link", { name: "Skip to main content" }).focus();
  await page.keyboard.press("Enter");
  await expect(page.getByRole("main")).toBeFocused();
  await expect(page).toHaveURL(/#clients$/);
  await page
    .getByRole("textbox", { name: "Search by Man# or Client Name" })
    .fill("00124");
  const details = page.getByRole("button", {
    name: "Client Details for Chanda Mwansa",
    exact: true,
  });
  await details.focus();
  await page.keyboard.press("Enter");
  const dialog = page.getByRole("dialog", { name: "Client Details" });
  await expect(dialog).toBeVisible();
  const summary = dialog.getByRole("region", {
    name: "Client financial summary",
  });
  await expect(summary).toContainText("Total Amount Disbursed to Client");
  await expect(summary).toContainText("Client Outstanding Balance");
  await expect(summary).toContainText("Interest Income per Client");
  await expect(summary).toContainText("15,000.00");
  await expect(summary).toContainText("11,000.00");
  await expect(summary).toContainText("1,500.00");
  await page.keyboard.press("Escape");
  await expect(details).toBeFocused();
  await page
    .getByRole("button", {
      name: "Client Loan History for Chanda Mwansa",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("heading", { name: "Client Loan History", exact: true }),
  ).toBeVisible();
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await expect(page.locator("tbody")).toContainText("LN-00000001");
  await page.goBack();
  await expect(
    page.getByRole("heading", { name: "Client Register", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", {
      name: "Client Statement for Chanda Mwansa",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("dialog", { name: "Client Statement" }),
  ).toBeVisible();
});
