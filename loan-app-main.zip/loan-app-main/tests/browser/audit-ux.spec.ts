import { test, expect } from "./fixtures";
test("overdue drill-down preserves department and dated report scope", async ({
  page,
}) => {
  await page.goto("/demo");
  const report = page.getByRole("region", { name: "Financial reporting" });
  await report.getByText("Change dates and filters", { exact: true }).click();
  await report.getByText("More filters", { exact: true }).click();
  await report
    .getByRole("combobox", { name: "Department", exact: true })
    .selectOption("Operations");
  await report.getByRole("button", { name: "Apply report filters" }).click();
  await expect(
    report.locator(".report-scope").filter({ hasText: "Balances:" }),
  ).toContainText("1 overdue loans");
  const date = await report.getByLabel("Balances as of").inputValue();
  await report.getByRole("button", { name: "Review overdue loans" }).click();
  await expect(
    report.getByRole("combobox", { name: "Department", exact: true }),
  ).toHaveValue("Operations");
  await expect(report.getByLabel("Balances as of")).toHaveValue(date);
  await expect(
    report.getByRole("combobox", { name: "Loan status as of date" }),
  ).toHaveValue("Overdue");
  await expect(report.locator("tbody tr")).toHaveCount(1);
  await expect(report.locator("tbody")).toContainText("Grace Phiri");
  await expect(report.locator("tbody")).not.toContainText("Mary Tembo");
});
test("financial labels meet contrast and mobile tables remain contained and keyboard-focusable", async ({
  page,
}) => {
  await page.goto("/demo");
  await expect(
    page.locator(".report-metrics .stat-card > span").first(),
  ).toBeVisible();
  const colors = await page
    .locator(".report-metrics .stat-card > span")
    .first()
    .evaluate((el) => {
      let p: Element | null = el;
      let background = "";
      while (p) {
        background = getComputedStyle(p).backgroundColor;
        if (background !== "rgba(0, 0, 0, 0)" && background !== "transparent")
          break;
        p = p.parentElement;
      }
      return { foreground: getComputedStyle(el).color, background };
    });
  const lum = (s: string) => {
    const c = s
      .match(/[\d.]+/g)!
      .slice(0, 3)
      .map(Number)
      .map((x) => {
        x /= 255;
        return x <= 0.04045 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
      });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  };
  const a = lum(colors.foreground),
    b = lum(colors.background);
  expect(
    (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05),
  ).toBeGreaterThanOrEqual(4.5);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/demo/#clients");
  await expect(
    page.getByRole("heading", { name: "Client Register", exact: true }),
  ).toBeVisible();
  expect(
    await page.evaluate(() => document.documentElement.scrollWidth),
  ).toBeLessThanOrEqual(390);
  await expect(page.getByLabel("Scrollable records").first()).toHaveAttribute(
    "tabindex",
    "0",
  );
});
