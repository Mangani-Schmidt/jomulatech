import { withSessionRequests } from "./auth-fixture";
import { test, expect, type Page } from "./fixtures";
import { demoDefaults } from "../../lib/interest";
const id = "11111111-1111-4111-8111-111111111111";
const user = {
  id,
  email: "fictional-auth@example.test",
  aud: "authenticated",
  role: "authenticated",
  app_metadata: {},
  user_metadata: { is_admin: true },
  created_at: "2026-01-01T00:00:00Z",
  factors: [],
};
const token = [
  "eyJhbGciOiJIUzI1NiJ9",
  Buffer.from(
    JSON.stringify({ sub: id, exp: Math.floor(Date.now() / 1000) + 3600 }),
  ).toString("base64url"),
  "fictional-signature",
].join(".");
const session = {
  access_token: token,
  refresh_token: "fictional-refresh",
  expires_in: 3600,
  expires_at: Math.floor(Date.now() / 1000) + 3600,
  token_type: "bearer",
  user,
};
async function signedIn(page: Page) {
  await page.addInitScript(
    (session) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify(session),
      ),
    session,
  );
}
for (const mode of ["light", "dark"] as const)
  test(`public landing is private-data free and usable at phone width in ${mode}`, async ({
    page,
  }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.emulateMedia({ colorScheme: mode });
    const internal: string[] = [];
    page.on("request", (r) => {
      if (r.url().includes("/rest/v1/")) internal.push(r.url());
    });
    await page.goto("/");
    await expect(
      page.getByRole("heading", {
        name: "Keep your lending business on track.",
        exact: true,
      }),
    ).toBeVisible();
    await expect(
      page.getByRole("link", { name: "Sign Up", exact: true }).first(),
    ).toBeVisible();
    await expect(
      page.getByRole("link", { name: "Log In", exact: true }).first(),
    ).toBeVisible();
    await expect(page.locator("[data-metric],table")).toHaveCount(0);
    await expect(
      page.getByRole("navigation", { name: "Main navigation" }),
    ).toHaveCount(0);
    await expect(page.locator("body")).not.toContainText("Chanda Mwansa");
    expect(internal).toEqual([]);
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth),
    ).toBeLessThanOrEqual(390);
  });
test("authenticated landing keeps public content free of dashboard shortcuts and demo prompts", async ({
  page,
}) => {
  await signedIn(page);
  const requests: string[] = [];
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      const path = new URL(route.request().url()).pathname;
      requests.push(path);
      return route.fulfill({
        json: path.endsWith("/user")
          ? user
          : path.endsWith("/has_capability")
            ? true
            : [],
      });
    }),
  );
  await page.goto("/");
  await expect(
    page.getByRole("link", { name: "Open Dashboard", exact: false }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: "Explore demo", exact: true }),
  ).toHaveCount(0);
  expect(
    requests.every((p) =>
      ["/auth/v1/user", "/rest/v1/rpc/has_capability"].includes(p),
    ),
  ).toBe(true);
  await expect(page.locator("[data-metric],table")).toHaveCount(0);
});
for (const route of [
  "/dashboard",
  "/settings",
  "/expenses",
  "/administration",
  "/users",
  "/audit-logs",
  "/security",
])
  test(`anonymous access to ${route} redirects before rendering internal content`, async ({
    page,
  }) => {
    const requests: string[] = [];
    page.on("request", (r) => {
      if (r.url().includes("/rest/v1/")) requests.push(r.url());
    });
    await page.goto(route);
    await expect(page).toHaveURL(/\/login\?next=/);
    await expect(
      page.getByRole("heading", { name: "Log In", exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("navigation", { name: "Main navigation" }),
    ).toHaveCount(0);
    await expect(page.locator("[data-metric],table")).toHaveCount(0);
    expect(requests).toEqual([]);
  });
test("an unassigned account cannot open records even with Administrator signup metadata", async ({
  page,
}) => {
  await signedIn(page);
  const privateReads: string[] = [];
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      const path = new URL(route.request().url()).pathname;
      if (path.endsWith("/user")) return route.fulfill({ json: user });
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({
          status: 403,
          json: { code: "42501", message: "Permission denied" },
        });
      privateReads.push(path);
      return route.fulfill({ json: [] });
    }),
  );
  await page.goto("/dashboard");
  await expect(
    page.getByRole("heading", { name: "Business access pending", exact: true }),
  ).toBeVisible();
  await expect(page.locator("[data-metric],table")).toHaveCount(0);
  expect(privateReads).toEqual([]);
});
test("a forged cached session is rejected by identity verification before membership or record reads", async ({
  page,
}) => {
  await signedIn(page);
  let reads = 0;
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      if (new URL(route.request().url()).pathname.endsWith("/user"))
        return route.fulfill({
          status: 401,
          json: { code: "bad_jwt", message: "Invalid token" },
        });
      reads++;
      return route.fulfill({ json: demoDefaults });
    }),
  );
  await page.goto("/dashboard");
  await expect(page).toHaveURL(/\/login\?next=/);
  expect(reads).toBe(0);
});
test("a failed membership check keeps records closed and offers retry", async ({
  page,
}) => {
  await signedIn(page);
  let privateReads = 0;
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      const path = new URL(route.request().url()).pathname;
      if (path.endsWith("/user")) return route.fulfill({ json: user });
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({ status: 503, json: { message: "Unavailable" } });
      privateReads++;
      return route.fulfill({ json: [] });
    }),
  );
  await page.goto("/dashboard");
  await expect(
    page.getByRole("button", { name: "Retry access check" }),
  ).toBeVisible();
  await expect(page.locator("[data-metric],table")).toHaveCount(0);
  expect(privateReads).toBe(0);
});
test("expired recovery links offer an understandable error and a fresh recovery request", async ({
  page,
}) => {
  await page.goto(
    "/security#error=access_denied&error_code=otp_expired&error_description=private-provider-detail",
  );
  await expect(page).toHaveURL(/\/login\?next=/);
  await expect(page.locator(".auth-form").getByRole("alert")).toContainText(
    "invalid or expired",
  );
  await expect(page.locator(".auth-form")).not.toContainText(
    "private-provider-detail",
  );
  await page
    .getByRole("link", { name: "Forgot password?", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Reset your password" }),
  ).toBeVisible();
});
test("signup validates five characters, accepts six, supports visibility and never grants a role", async ({
  page,
}) => {
  const calls: Record<string, unknown>[] = [];
  const extra: string[] = [];
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      if (new URL(route.request().url()).pathname.endsWith("/signup")) {
        calls.push(route.request().postDataJSON());
        return route.fulfill({ json: { ...user, identities: [] } });
      }
      extra.push(route.request().url());
      return route.fulfill({ json: [] });
    }),
  );
  await page.goto("/signup");
  await page.getByLabel("Email", { exact: true }).fill(user.email);
  await page.getByLabel("Password", { exact: true }).fill("abc12");
  await page.getByRole("button", { name: "Sign Up", exact: true }).click();
  await expect(page.locator(".auth-form").getByRole("alert")).toContainText(
    "at least 6",
  );
  expect(calls).toHaveLength(0);
  await page.getByLabel("Password", { exact: true }).fill("abc123");
  await page
    .getByRole("button", { name: "Show password", exact: true })
    .click();
  await expect(page.getByLabel("Password", { exact: true })).toHaveAttribute(
    "type",
    "text",
  );
  await page
    .getByRole("button", { name: "Hide password", exact: true })
    .click();
  await page.getByRole("button", { name: "Sign Up", exact: true }).click();
  await expect(page.locator(".auth-form").getByRole("status")).toContainText(
    "Administrator must assign",
  );
  expect(calls).toHaveLength(1);
  expect(calls[0]).toMatchObject({ email: user.email, password: "abc123" });
  expect(calls[0]).not.toHaveProperty("role");
  expect(calls[0]).not.toHaveProperty("is_admin");
  expect(extra).toEqual([]);
});
test("login shows a loading state and a six-character session opens the protected dashboard", async ({
  page,
}) => {
  let release!: () => void;
  const held = new Promise<void>((resolve) => {
    release = resolve;
  });
  let posts = 0;
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const path = new URL(route.request().url()).pathname;
      if (path.endsWith("/token")) {
        posts++;
        expect(route.request().postDataJSON().password).toBe("abc123");
        await held;
        return route.fulfill({ json: session });
      }
      if (path.endsWith("/user")) return route.fulfill({ json: user });
      if (path.endsWith("/loan_defaults"))
        return route.fulfill({ json: demoDefaults });
      if (path.endsWith("/ledger_snapshot"))
        return route.fulfill({
          json: { clients: [], loans: [], repayments: [] },
        });
      if (path.endsWith("/report_source_filtered"))
        return route.fulfill({
          json: {
            generated_at: new Date().toISOString(),
            timezone: "Africa/Lusaka",
            clients: [],
            loans: [],
            repayments: [],
            terms_audit: [],
            status_audit: [],
            repayment_audit: [],
          },
        });
      return route.fulfill({ json: [] });
    }),
  );
  await page.goto("/login?next=%2Fdashboard%23clients");
  await page.getByLabel("Email", { exact: true }).fill(user.email);
  await page.getByLabel("Password", { exact: true }).fill("abc123");
  await page.getByRole("button", { name: "Log In", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Logging in…", exact: true }),
  ).toBeDisabled();
  release();
  await expect(page).toHaveURL(/\/dashboard#clients$/);
  await expect(
    page.getByRole("heading", { name: "Client Register", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("link", { name: "Explore demo", exact: true }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: "Exit demo", exact: true }),
  ).toHaveCount(0);
  expect(posts).toBe(1);
});
test("invalid login reports a helpful error and re-enables retry", async ({
  page,
}) => {
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) =>
      route.fulfill({
        status: 400,
        headers: {
          "X-Supabase-Api-Version": "2024-01-01",
          "Access-Control-Expose-Headers": "X-Supabase-Api-Version",
        },
        json: {
          code: "invalid_credentials",
          message: "Invalid login credentials",
        },
      }),
    ),
  );
  await page.goto("/login");
  await page.getByLabel("Email", { exact: true }).fill(user.email);
  await page.getByLabel("Password", { exact: true }).fill("abc123");
  await page.getByRole("button", { name: "Log In", exact: true }).click();
  await expect(page.locator(".auth-form").getByRole("alert")).toContainText(
    "incorrect",
  );
  await expect(
    page.getByRole("button", { name: "Log In", exact: true }),
  ).toBeEnabled();
});
