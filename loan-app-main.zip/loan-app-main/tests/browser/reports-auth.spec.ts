import ExcelJS from "exceljs";
import { withSessionRequests } from "./auth-fixture";
import { navigate } from "./navigation";
import { test, expect } from "./fixtures";
import { readFile } from "node:fs/promises";
import { demoClients } from "../../lib/demo";
import { today } from "../../lib/domain";
import { demoDefaults, dueDate } from "../../lib/interest";
test("authorized reporting loads one owned snapshot and exports all filtered pages", async ({
  page,
}) => {
  const owner = "11111111-1111-4111-8111-111111111111";
  const first = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
    second = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb";
  const stamp = new Date().toISOString();
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "test-signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "test-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "admin@example.com",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      ),
    { owner, token },
  );

  const day = today();
  const clients = Array.from({ length: 23 }, (_, i) => ({
    ...demoClients[0],
    id: `c${i}`,
    name: `Client ${String(i).padStart(2, "0")}`,
    man_number: `00${i}`,
    department: i === 22 ? "Health" : "Finance",
  }));
  const loans = clients.map((c, i) => ({
    id: `l${i}`,
    client_id: c.id,
    loan_reference: `LN-${i}`,
    principal_cents: 100000,
    interest_cents: 10000,
    balance_cents: 110000,
    currency: "ZMW",
    disbursement_date: day,
    due_date: dueDate(day, 30),
    created_at: stamp,
  }));
  const source = {
    generated_at: stamp,
    timezone: "Africa/Lusaka",
    clients,
    loans,
    repayments: [],
    terms_audit: loans.map((l) => ({
      id: `a${l.id}`,
      loan_id: l.id,
      action: "originate",
      created_at: stamp,
      after_data: l,
      before_data: null,
      reason: "Origination",
    })),
    status_audit: [],
    repayment_audit: [],
  };
  let snapshots = 0;
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests(async (route) => {
      const url = route.request().url();
      let data: unknown = [];
      if (url.includes("/auth/v1/user"))
        data = { id: owner, email: "admin@example.com" };
      else if (url.includes("/rpc/has_capability")) data = true;
      else if (url.includes("/rpc/loan_defaults")) data = demoDefaults;
      else if (url.includes("/rpc/report_source")) {
        data = source;
        snapshots++;
      } else if (url.includes("/ledger_snapshot"))
        data = { clients, loans, repayments: [] };
      else if (url.includes("/loan_register")) data = loans;
      else if (url.includes("/clients")) data = clients;
      await route.fulfill({ json: data });
    }),
  );
  await page.goto("/dashboard");
  await navigate(page, "Reports");
  const report = page.getByRole("region", { name: "Financial reporting" });
  await report.getByText("Report filters", { exact: true }).click();
  await report.getByText("More filters", { exact: true }).click();
  await expect(report.locator("tbody tr")).toHaveCount(10);
  await expect(report).toContainText("Page 1 of 3");
  await report.getByRole("button", { name: "Next page" }).click();
  await expect(report).toContainText("Page 2 of 3");
  await report.getByRole("button", { name: "Next page" }).click();
  await expect(report.locator("tbody tr")).toHaveCount(3);
  await report
    .getByRole("combobox", { name: "Department", exact: true })
    .selectOption("Finance");
  await report.getByRole("button", { name: "Apply report filters" }).click();
  await expect(report).toContainText("Page 1 of 3");
  const event = page.waitForEvent("download");
  await report.getByRole("button", { name: "Download Client CSV" }).click();
  const file = await event;
  const csv = await readFile((await file.path())!, "utf8");
  for (let i = 0; i < 22; i++)
    expect(csv).toContain(`Client ${String(i).padStart(2, "0")}`);
  expect(csv).not.toContain("Client 22");
  await expect(
    report.getByLabel("Disbursement counts", { exact: true }),
  ).toContainText("Clients Receiving Loans: 22");
  const excelEvent = page.waitForEvent("download");
  await report
    .getByRole("button", { name: "Download .xlsx report", exact: true })
    .click();
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(
    (await readFile((await (await excelEvent).path())!)) as never,
  );
  const sheet = workbook.getWorksheet("Filtered loans")!;
  expect(sheet.rowCount).toBe(27);
  expect(sheet.getCell("B5").value).toBe("000");
  expect(sheet.lastRow!.getCell(12).value).toBe(22000);
  expect(sheet.getColumn(1).values).not.toContain("Client 22");

  await report
    .getByRole("button", { name: "Preview printable report" })
    .click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toContainText("Client 21");
  await expect(dialog).not.toContainText("Client 22");
  await page.keyboard.press("Escape");
  expect(snapshots).toBeGreaterThan(0);
});
