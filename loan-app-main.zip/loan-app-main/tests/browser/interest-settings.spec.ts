import { capabilitiesForRole } from "../../lib/permissions";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { navigate } from "./navigation";
import { test, expect, type Page } from "./fixtures";
import { dueDate } from "../../lib/interest";
import { demoDefaults } from "../../lib/interest";
import { demoClients } from "../../lib/demo";
async function session(page: Page) {
  const owner = "11111111-1111-4111-8111-111111111111";
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) =>
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "test-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "admin@example.com",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      ),
    { owner, token },
  );
}
test("a non-administrator cannot view the Settings form", async ({ page }) => {
  await session(page);
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) =>
      route.fulfill({
        contentType: "application/json",
        body: JSON.stringify(demoDefaults),
      }),
    ),
  );
  await page.route("https://register-tests.supabase.co/auth/v1/user", (route) =>
    route.fulfill({ json: fictionalProviderUser(route) }),
  );
  await page.goto("/settings");
  await expect(
    page.getByRole("region", { name: "Access denied" }).getByRole("alert"),
  ).toContainText("Your current business permissions do not allow");
  await expect(
    page.getByRole("button", { name: "Save future defaults" }),
  ).toHaveCount(0);
});
test("administrator changes future defaults with a reason and sees the settings audit", async ({
  page,
}) => {
  await session(page);
  let value = {
    ...demoDefaults,
    capabilities: {
      ...capabilitiesForRole("administrator"),
      is_admin: true,
      can_override_rate: true,
    },
  };
  let audits: unknown[] = [];
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const path = new URL(route.request().url()).pathname;
      const respond = (body: unknown) =>
        route.fulfill({
          contentType: "application/json",
          body: JSON.stringify(body),
        });
      if (path.endsWith("/loan_defaults")) return respond(value);
      if (path.endsWith("/settings_audit")) return respond(audits);
      if (path.endsWith("/save_interest_settings")) {
        const body = route.request().postDataJSON();
        expect(body.p_settings).toMatchObject({
          default_rate_bps: 1500,
          default_term_days: 60,
          calculation_method: "one_time_flat",
          rate_basis: "entire_term",
        });
        expect(body.p_expected_revision).toBe(1);
        expect(body.p_reason).toBe("Approved future lending policy");
        const before = value.settings;
        value = {
          ...value,
          settings: {
            ...before,
            default_rate_bps: 1500,
            default_term_days: 60,
            revision: 2,
          },
        };
        audits = [
          {
            id: "change",
            actor_id: "admin",
            before_data: before,
            after_data: value.settings,
            reason: body.p_reason,
            created_at: new Date().toISOString(),
          },
        ];
        return respond(value.settings);
      }
      return respond([]);
    }),
  );
  await page.goto("/settings");
  await expect(
    page.getByLabel("Default interest rate for entire term (%)"),
  ).toHaveValue("10");
  await expect(page.getByLabel("Interest calculation method")).toHaveValue(
    "One-time flat interest",
  );
  await expect(page.getByLabel("Rate basis")).toHaveValue("Entire loan term");
  await page.getByLabel("Default interest rate for entire term (%)").fill("15");
  await page.getByLabel("Default loan term (days)").fill("60");
  await page
    .getByLabel("Settings change reason")
    .fill("Approved future lending policy");
  await page.getByRole("button", { name: "Save future defaults" }).click();
  await expect(
    page.getByText("Defaults updated. Existing loans are unchanged."),
  ).toBeVisible();
  await expect(
    page.getByLabel("Default interest rate for entire term (%)"),
  ).toHaveValue("15");
  await expect(
    page.getByText("Approved future lending policy", { exact: true }),
  ).toBeVisible();
  await page.setViewportSize({ width: 390, height: 844 });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
});
test("loan origination previews actual obligation and records an authorized rate override", async ({
  page,
}) => {
  await session(page);
  let loans: unknown[] = [];
  let submitted = false;
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const path = new URL(route.request().url()).pathname;
      const respond = (body: unknown) =>
        route.fulfill({
          contentType: "application/json",
          body: JSON.stringify(body),
        });
      if (path.endsWith("/loan_defaults"))
        return respond({
          ...demoDefaults,
          capabilities: {
            ...capabilitiesForRole("administrator"),
            is_admin: true,
            can_override_rate: true,
          },
        });
      if (path.endsWith("/ledger_snapshot"))
        return respond({ clients: demoClients, loans, repayments: [] });
      if (path.endsWith("/clients")) return respond(demoClients);
      if (path.endsWith("/loan_register")) return respond(loans);
      if (path.endsWith("/originate_loan")) {
        const body = route.request().postDataJSON();
        expect(body.p_details).toMatchObject({
          client_id: "c1",
          principal_cents: 100000,
          rate_bps: 1200,
          term_days: 30,
          calculation_method: "one_time_flat",
          rate_basis: "entire_term",
          settings_revision: 1,
          override_reason: "Approved Client rate exception",
        });
        expect(body.p_confirm).toBe(true);
        submitted = true;
        loans = [
          {
            id: "new-loan",
            ...body.p_details,
            principal_cents: 100000,
            interest_cents: 12000,
            balance_cents: 112000,
            due_date: dueDate(
              body.p_details.disbursement_date,
              body.p_details.term_days,
            ),
            created_at: new Date().toISOString(),
          },
        ];
        return respond("new-loan");
      }
      return respond([]);
    }),
  );
  await page.goto("/dashboard");
  await page.getByRole("button", { name: "New Loan", exact: true }).click();
  const dialog = page.getByRole("dialog");
  await dialog
    .getByRole("combobox", { name: "Search by Man# or Client Name" })
    .fill("00124");
  await page.keyboard.press("Enter");
  await dialog.getByLabel("Amount Disbursed (ZMW)").fill("1000.00");
  await expect(
    dialog.getByLabel("Interest rate for entire term (%)"),
  ).toHaveValue("10");
  await dialog.getByLabel("Interest rate for entire term (%)").fill("12");
  await dialog
    .getByLabel("Rate override reason")
    .fill("Approved Client rate exception");
  await expect(
    dialog.getByRole("region", { name: "Loan obligation preview" }),
  ).toContainText("1,120.00");
  await dialog
    .getByRole("button", { name: "Review Loan", exact: true })
    .click();
  await expect(
    dialog.getByRole("button", { name: "Confirm Loan", exact: true }),
  ).toBeDisabled();
  expect(submitted).toBe(false);
  await dialog.getByRole("checkbox").check();
  await dialog
    .getByRole("button", { name: "Confirm Loan", exact: true })
    .click();
  await expect(dialog).not.toBeVisible();
  expect(submitted).toBe(true);
  await page.setViewportSize({ width: 390, height: 844 });
  await navigate(page, "Settings");
  await expect(
    page.getByLabel("Default interest rate for entire term (%)"),
  ).toHaveValue("10");
});
