import { test, expect } from "./fixtures";
import { navigate } from "./navigation";
import { chooseTheme } from "./theme";

test("desktop sidebar remembers collapse across pages and tabs, keeping icon links accessible", async ({
  page,
  context,
}) => {
  await page.goto("/demo");
  await page
    .getByRole("button", { name: "Collapse sidebar", exact: true })
    .click();
  await expect(page.locator("html")).toHaveAttribute(
    "data-sidebar",
    "collapsed",
  );
  await expect(page.locator(".desktop-sidebar")).toHaveCSS("width", "80px");
  await page.reload();
  await expect(
    page.getByRole("button", { name: "Expand sidebar", exact: true }),
  ).toBeVisible();
  await navigate(page, "Settings");
  await expect(page.locator(".desktop-sidebar")).toHaveCSS("width", "80px");
  await expect(
    page.getByRole("link", { name: "Settings", exact: true }),
  ).toHaveAttribute("aria-current", "page");
  const other = await context.newPage();
  await other.goto("/demo");
  await page
    .getByRole("button", { name: "Expand sidebar", exact: true })
    .click();
  await expect(other.locator("html")).toHaveAttribute(
    "data-sidebar",
    "expanded",
  );
  await expect(page.locator(".desktop-sidebar")).toHaveCSS("width", "238px");
  await other.close();
});

test("phone drawer traps focus, supports Escape/backdrop and closes on keyboard navigation", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/demo");
  const trigger = page.getByRole("button", {
    name: "Open navigation",
    exact: true,
  });
  await expect(page.locator(".desktop-sidebar")).not.toBeVisible();
  await trigger.click();
  const drawer = page.getByRole("dialog", { name: "Workspace navigation" });
  const close = drawer.getByRole("button", {
    name: "Close navigation",
    exact: true,
  });
  await expect(close).toBeFocused();
  await expect(drawer).toHaveCSS("animation-name", "none");
  await drawer.getByRole("link").last().focus();
  await page.keyboard.press("Tab");
  expect(await drawer.evaluate((e) => e.contains(document.activeElement))).toBe(
    true,
  );
  await page.keyboard.press("Tab");
  expect(await drawer.evaluate((e) => e.contains(document.activeElement))).toBe(
    true,
  );
  await page.keyboard.press("Escape");
  await expect(drawer).not.toBeVisible();
  await expect(trigger).toBeFocused();
  await trigger.click();
  await page.mouse.click(385, 400);
  await expect(drawer).not.toBeVisible();
  await expect(trigger).toBeFocused();
  await trigger.click();
  await drawer.getByRole("link", { name: "New Loan", exact: true }).focus();
  await page.keyboard.press("Enter");
  await expect(drawer).not.toBeVisible();
  await expect(
    page.getByRole("heading", { name: "New Loan", exact: true }),
  ).toBeFocused();
  await expect(page.locator("body")).not.toHaveCSS("overflow", "hidden");
});

for (const width of [390, 820, 1440])
  for (const theme of ["light", "dark"] as const)
    test(`usable forms and upper-right theme at ${width}px in ${theme}`, async ({
      page,
    }, testInfo) => {
      const errors: string[] = [];
      page.on("pageerror", (e) => errors.push(e.message));
      await page.setViewportSize({ width, height: 1000 });
      await page.goto("/demo");
      await chooseTheme(page, theme);
      await navigate(page, "New Loan");
      const themeBox = await page
        .getByRole("button", { name: "Choose color theme" })
        .boundingBox();
      expect(themeBox!.x + themeBox!.width).toBeGreaterThan(width - 60);
      expect(themeBox!.y).toBeLessThan(70);
      const form = page.locator("form").filter({
        has: page.getByLabel("Amount Disbursed (ZMW)", { exact: true }),
      });
      await expect(form.locator(".required-legend")).toHaveCount(1);
      const requirements = await form
        .locator("input[required],select[required],textarea[required]")
        .evaluateAll((fields) =>
          fields.every((field) => {
            const input = field as HTMLInputElement;
            return Array.from(input.labels ?? []).some((label) =>
              label.querySelector(".required-mark"),
            );
          }),
        );
      expect(requirements).toBe(true);
      const date = page.getByLabel("Disbursement date", { exact: true });
      await page.evaluate(() => {
        (window as unknown as { pickerRequests: number }).pickerRequests = 0;
        HTMLInputElement.prototype.showPicker = function () {
          (window as unknown as { pickerRequests: number }).pickerRequests++;
        };
      });
      await date.click({ position: { x: 18, y: 18 } });
      expect(
        await page.evaluate(
          () =>
            (window as unknown as { pickerRequests: number }).pickerRequests,
        ),
      ).toBe(1);
      await page.evaluate(() => {
        HTMLInputElement.prototype.showPicker = () => {
          throw new DOMException("Unavailable", "NotAllowedError");
        };
      });
      await date.click();
      await date.fill("2026-01-02");
      await expect(date).toHaveValue("2026-01-02");
      await date.fill("");
      await expect(date).toHaveValue("");
      await date.fill("2026-01-02");
      await page
        .getByLabel("Amount Disbursed (ZMW)", { exact: true })
        .fill("1000");
      await expect(
        page.getByRole("button", { name: "Review Loan", exact: true }),
      ).toBeDisabled();
      await expect(
        page.getByLabel("Amount Disbursed (ZMW)", { exact: true }),
      ).toHaveValue("1000");
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
      ).toBe(true);
      await page
        .getByRole("heading", { name: "New Loan", exact: true })
        .focus();
      await page.evaluate(() => window.scrollTo(0, 0));
      await page.screenshot({
        path: testInfo.outputPath(`loan-${width}-${theme}.png`),
        fullPage: true,
        animations: "disabled",
      });
      if (width === 390) {
        await page
          .getByRole("button", { name: "Open navigation", exact: true })
          .click();
        await page.screenshot({
          path: testInfo.outputPath(`drawer-${theme}.png`),
          animations: "disabled",
        });
      }
      expect(errors).toEqual([]);
    });
