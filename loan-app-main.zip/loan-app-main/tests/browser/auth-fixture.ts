import type { Route } from "@playwright/test";
/** Explicit fictional identity-provider response for legacy workspace fixtures.
 * PostgreSQL tests independently verify the database's membership/RLS rules. */
export function fictionalProviderUser(route: Route) {
  const request = route.request();
  if (new URL(request.url()).origin !== "https://register-tests.supabase.co")
    throw new Error("Fictional Auth origin required");
  const token = request.headers().authorization?.replace(/^Bearer /, "") ?? "";
  const claims = JSON.parse(
    Buffer.from(token.split(".")[1], "base64url").toString(),
  );
  return {
    id: claims.sub,
    email: "fictional-staff@example.test",
    aud: "authenticated",
    role: "authenticated",
    app_metadata: {},
    user_metadata: {},
    created_at: "2026-01-01T00:00:00Z",
    factors: [],
  };
}

/** Explicit session registration for the older fictional workspace contracts.
 * Inactivity tests supply their own clock-aware session responses instead. */
export function withSessionRequests(handler: (route: Route) => unknown) {
  return async (route: Route) => {
    const path = new URL(route.request().url()).pathname;
    if (
      [
        "/rest/v1/rpc/app_session_status",
        "/rest/v1/rpc/touch_app_session",
      ].includes(path)
    ) {
      await route.fulfill({
        json: {
          active: true,
          registered: true,
          server_now: new Date().toISOString(),
          last_activity_at: new Date().toISOString(),
        },
      });
      return;
    }
    if (path === "/rest/v1/rpc/client_deletion_status")
      return route.fulfill({
        json: { can_delete: false, reason: "Fictional retained history" },
      });
    if (path === "/rest/v1/rpc/end_app_session") {
      await route.fulfill({ json: null });
      return;
    }
    if (path === "/auth/v1/logout") {
      await route.fulfill({ status: 204 });
      return;
    }
    await handler(route);
  };
}
