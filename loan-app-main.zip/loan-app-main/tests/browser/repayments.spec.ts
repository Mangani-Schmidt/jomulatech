import { capabilitiesForRole } from "../../lib/permissions";
import { fictionalProviderUser, withSessionRequests } from "./auth-fixture";
import { navigate } from "./navigation";
import { test, expect } from "./fixtures";
import { demoClients } from "../../lib/demo";
import { demoDefaults, dueDate } from "../../lib/interest";
import { today, type Loan, type Repayment } from "../../lib/domain";
test("posts an allocated payment, prints a receipt, reverses it, and prints a net-zero Client statement", async ({
  page,
}, testInfo) => {
  const owner = "11111111-1111-4111-8111-111111111111",
    id = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
    receiptId = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb";
  const stamp = new Date().toISOString();
  const client = demoClients[0];
  const token = [
    "eyJhbGciOiJIUzI1NiJ9",
    Buffer.from(
      JSON.stringify({ sub: owner, exp: Math.floor(Date.now() / 1000) + 3600 }),
    ).toString("base64url"),
    "test-signature",
  ].join(".");
  await page.addInitScript(
    ({ owner, token }) => {
      localStorage.setItem(
        "sb-register-tests-auth-token",
        JSON.stringify({
          access_token: token,
          refresh_token: "test-refresh",
          token_type: "bearer",
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          expires_in: 3600,
          user: {
            id: owner,
            email: "admin@example.com",
            aud: "authenticated",
            role: "authenticated",
            app_metadata: {},
            user_metadata: {},
            created_at: "2026-01-01T00:00:00Z",
          },
        }),
      );
      window.print = () => {
        (window as unknown as Record<string, unknown>).__printed = true;
      };
    },
    { owner, token },
  );
  let loan: Loan = {
    id,
    client_id: client.id,
    loan_reference: "LN-00000001",
    principal_cents: 100000,
    interest_cents: 10000,
    balance_cents: 110000,
    interest_outstanding_cents: 10000,
    principal_outstanding_cents: 100000,
    interest_repaid_cents: 0,
    principal_repaid_cents: 0,
    disbursement_date: today(),
    due_date: dueDate(today(), 30),
    created_at: stamp,
    updated_at: stamp,
    lifecycle_status: "active",
    status: "active",
    interest_rate_bps: 1000,
    term_days: 30,
    terms_revision: 1,
    calculation_method: "one_time_flat",
    currency: "ZMW",
  };
  let receipts: Repayment[] = [];
  const audits: unknown[] = [];
  await page.route(
    "https://register-tests.supabase.co/**",
    withSessionRequests((route) => {
      if (new URL(route.request().url()).pathname === "/auth/v1/user")
        return route.fulfill({ json: fictionalProviderUser(route) });
      const path = new URL(route.request().url()).pathname;
      const respond = (data: unknown) =>
        route.fulfill({
          contentType: "application/json",
          body: JSON.stringify(data),
        });
      if (path.endsWith("/loan_defaults"))
        return respond({
          ...demoDefaults,
          capabilities: {
            ...capabilitiesForRole("administrator"),
            is_admin: true,
            can_post_repayments: true,
            can_override_rate: true,
          },
        });
      if (path.endsWith("/ledger_snapshot"))
        return respond({
          clients: demoClients,
          loans: [loan],
          repayments: receipts,
        });
      if (path.endsWith("/clients")) return respond(demoClients);
      if (path.endsWith("/loan_register"))
        return respond(
          route.request().url().includes("id=eq.") ? loan : [loan],
        );
      if (path.endsWith("/repayment_register")) return respond(receipts);
      if (path.endsWith("/post_repayment")) {
        const body = route.request().postDataJSON();
        expect(body.p_details).toMatchObject({
          loan_id: id,
          amount_cents: 15000,
          payment_date: today(),
          payment_method: "bank_transfer",
          external_reference: "BANK-001",
          expected_balance_cents: 110000,
          expected_interest_outstanding_cents: 10000,
          expected_principal_outstanding_cents: 100000,
        });
        expect(body.p_confirm).toBe(true);
        receipts = [
          {
            id: receiptId,
            loan_id: id,
            client_id: client.id,
            loan_reference: "LN-00000001",
            amount_cents: 15000,
            payment_reference: "PAY-00000001",
            payment_date: today(),
            payment_method: "bank_transfer",
            external_reference: "BANK-001",
            interest_allocation_cents: 10000,
            principal_allocation_cents: 5000,
            created_by: owner,
            created_at: stamp,
            updated_at: stamp,
            posting_status: "posted",
            posting_sequence: 1,
            receipt_snapshot: {
              client: {
                id: client.id,
                name: client.name,
                man_number: client.man_number,
              },
              currency: "ZMW",
              loan_reference: "LN-00000001",
              balance_after_cents: 95000,
            },
          },
        ];
        loan = {
          ...loan,
          balance_cents: 95000,
          interest_outstanding_cents: 0,
          principal_outstanding_cents: 95000,
        };
        audits.push({
          id: "audit-post",
          action: "post",
          reason: "Repayment Received posted",
          actor_id: owner,
          created_at: stamp,
        });
        return respond({ repayment_id: receiptId });
      }
      if (path.endsWith("/receipt_document"))
        return respond({
          generated_at: stamp,
          receipt: receipts[0],
          audit: audits,
        });
      if (path.endsWith("/reverse_repayment")) {
        const body = route.request().postDataJSON();
        expect(body).toMatchObject({
          p_repayment_id: receiptId,
          p_reason: "Verified erroneous cash receipt",
          p_confirm: true,
        });
        receipts = [
          {
            ...receipts[0],
            posting_status: "reversed",
            reversed_at: stamp,
            reversed_by: owner,
            reversal_reason: body.p_reason,
          },
        ];
        loan = {
          ...loan,
          balance_cents: 110000,
          interest_outstanding_cents: 10000,
          principal_outstanding_cents: 100000,
        };
        audits.push({
          id: "audit-reverse",
          action: "reverse",
          reason: body.p_reason,
          actor_id: owner,
          created_at: stamp,
        });
        return respond({ repayment_id: receiptId });
      }
      if (path.endsWith("/has_capability")) {
        expect(route.request().postDataJSON().p_action).toBe("export_reports");
        return respond(true);
      }
      if (path.endsWith("/client_statement"))
        return respond({
          client,
          generated_at: stamp,
          loans: [loan],
          repayments: receipts,
          repayment_audit: audits,
          terms_audit: [],
          status_audit: [],
        });
      return respond([]);
    }),
  );
  await page.goto("/dashboard");
  await navigate(page, "Repayments");
  await page
    .getByRole("button", { name: "Record Repayment Received", exact: true })
    .click();
  const dialog = page.getByRole("dialog");
  await dialog
    .getByRole("combobox", { name: "Loan", exact: true })
    .selectOption(id);
  await dialog.getByLabel("Repayment Received (ZMW)").fill("1200");
  await expect(dialog.getByRole("alert")).toContainText("Overpayment");
  await dialog.getByLabel("Repayment Received (ZMW)").fill("150.00");
  await dialog
    .getByRole("combobox", { name: "Payment method", exact: true })
    .selectOption("bank_transfer");
  await dialog.getByLabel("External reference").fill("BANK-001");
  await expect(
    dialog.getByRole("region", { name: "Repayment allocation preview" }),
  ).toContainText("100.00");
  await expect(
    dialog.getByRole("region", { name: "Repayment allocation preview" }),
  ).toContainText("50.00");
  await dialog
    .getByRole("button", { name: "Review Repayment", exact: true })
    .click();
  await dialog.getByRole("checkbox").check();
  await dialog
    .getByRole("button", { name: "Confirm Repayment Received", exact: true })
    .click();
  await expect(dialog.locator(".print-area")).toContainText("PAY-00000001");
  await expect(dialog.locator(".print-area")).toContainText(client.name);
  await dialog
    .getByRole("button", { name: "Print receipt", exact: true })
    .click();
  await expect
    .poll(() =>
      page.evaluate(
        () => (window as unknown as Record<string, unknown>).__printed,
      ),
    )
    .toBe(true);
  await page.emulateMedia({ media: "print" });
  await expect(dialog.locator(".receipt-controls")).not.toBeVisible();
  const pdf = await page.pdf({
    path: testInfo.outputPath("receipt.pdf"),
    format: "A4",
    printBackground: true,
  });
  expect(pdf.byteLength).toBeGreaterThan(2000);
  await page.emulateMedia({ media: "screen" });
  await dialog
    .getByLabel("Reversal reason", { exact: true })
    .fill("Verified erroneous cash receipt");
  await dialog
    .getByRole("checkbox", {
      name: "I authorize reversal of this Repayment Received entry.",
    })
    .check();
  await dialog
    .getByRole("button", { name: "Reverse posted payment", exact: true })
    .click();
  await expect(dialog.locator(".print-area")).toContainText(
    "REVERSED — financial effect excluded",
  );
  await expect(dialog.locator(".print-area")).toContainText(
    "Verified erroneous cash receipt",
  );
  await dialog.getByRole("button", { name: "Close dialog" }).click();
  await expect(
    page.getByRole("cell", { name: "Reversed", exact: false }).first(),
  ).toBeVisible();
  await navigate(page, "Clients");
  await page
    .getByRole("button", {
      name: "Client Statement for Chanda Mwansa",
      exact: true,
    })
    .click();
  await expect(dialog.locator(".print-area")).toContainText(
    "Net Repayment Received: K 0.00",
  );
  await expect(dialog.locator(".print-area")).toContainText("PAY-00000001");
  await expect(dialog.locator(".print-area")).toContainText("Reversed");
  await page.emulateMedia({ media: "print" });
  await expect(page.locator(".app-shell > main")).not.toBeVisible();
  await expect(dialog.locator(".print-actions")).not.toBeVisible();
  const statement = await page.pdf({
    path: testInfo.outputPath("statement.pdf"),
    format: "A4",
    printBackground: true,
  });
  expect(statement.byteLength).toBeGreaterThan(2000);
  await page.emulateMedia({ media: "screen" });
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await dialog.evaluate((e) => e.scrollWidth <= e.clientWidth)).toBe(
    true,
  );
});
