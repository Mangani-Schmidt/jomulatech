import { test, expect } from "./fixtures";
import { withSessionRequests, fictionalProviderUser } from "./auth-fixture";
import { capabilitiesForRole } from "../../lib/permissions";
import { demoClients } from "../../lib/demo";
import { demoDefaults } from "../../lib/interest";
for (const remove of [true, false])
  test(`authorized Client ${remove ? "deletion" : "archival"} requires confirmation and refreshes the register`, async ({
    page,
  }) => {
    const actor = "11111111-1111-4111-8111-111111111111";
    const token = [
      "eyJhbGciOiJIUzI1NiJ9",
      Buffer.from(
        JSON.stringify({
          sub: actor,
          session_id: actor,
          exp: Math.floor(Date.now() / 1000) + 3600,
        }),
      ).toString("base64url"),
      "fictional-signature",
    ].join(".");
    await page.addInitScript(
      ({ actor, token }) =>
        localStorage.setItem(
          "sb-register-tests-auth-token",
          JSON.stringify({
            access_token: token,
            refresh_token: "fictional-refresh",
            expires_at: Math.floor(Date.now() / 1000) + 3600,
            expires_in: 3600,
            token_type: "bearer",
            user: {
              id: actor,
              aud: "authenticated",
              role: "authenticated",
              app_metadata: {},
              user_metadata: {},
              created_at: "2026-01-01T00:00:00Z",
            },
          }),
        ),
      { actor, token },
    );
    let clients = [{ ...demoClients[0] }],
      writes = 0;
    await page.route(
      "https://register-tests.supabase.co/**",
      withSessionRequests(async (route) => {
        const path = new URL(route.request().url()).pathname;
        if (path === "/auth/v1/user")
          return route.fulfill({ json: fictionalProviderUser(route) });
        if (path.endsWith("/loan_defaults"))
          return route.fulfill({
            json: {
              ...demoDefaults,
              capabilities: {
                ...capabilitiesForRole("administrator"),
                can_delete_clients: true,
              },
            },
          });
        if (path.endsWith("/ledger_snapshot"))
          return route.fulfill({
            json: { clients, loans: [], repayments: [] },
          });
        if (path.endsWith(remove ? "/delete_client" : "/correct_client")) {
          const body = route.request().postDataJSON();
          expect(body.p_reason).toBe("Approved fictional register cleanup");
          expect(body.p_client_id).toBe(demoClients[0].id);
          if (remove) {
            expect(body.p_confirm).toBe(true);
            clients = [];
          } else {
            expect(body.p_details.is_active).toBe(false);
            clients = [{ ...clients[0], is_active: false }];
          }
          writes++;
          return route.fulfill({
            json: remove ? { deleted: true } : demoClients[0].id,
          });
        }
        return route.fulfill({ json: [] });
      }),
    );
    // Override the legacy status fixture with explicit eligibility for this case.
    await page.route("**/rest/v1/rpc/client_deletion_status", (route) =>
      route.fulfill({
        json: {
          can_delete: remove,
          reason: remove
            ? null
            : "Loan history must be retained. Archive/Deactivate instead.",
        },
      }),
    );
    await page.goto("/dashboard#clients");
    await page
      .getByRole("button", {
        name: `Client Details for ${demoClients[0].name}`,
        exact: true,
      })
      .click();
    const dialog = page.getByRole("dialog", {
      name: "Client Details",
      exact: true,
    });
    const action = dialog.getByRole("button", {
      name: remove ? "Delete Client permanently" : "Archive/Deactivate",
      exact: true,
    });
    await expect(action).toBeDisabled();
    expect(writes).toBe(0);
    if (!remove)
      await expect(
        dialog.getByRole("button", { name: "Delete Client permanently" }),
      ).toBeDisabled();
    await dialog
      .getByLabel("Deletion / archival reason", { exact: true })
      .fill("Approved fictional register cleanup");
    await dialog
      .getByRole("checkbox", {
        name: "I confirm the selected Client action and retention of audit history.",
        exact: true,
      })
      .check();
    await action.click();
    await expect(dialog).not.toBeVisible();
    expect(writes).toBe(1);
    if (remove)
      await expect(page.locator("tbody")).not.toContainText(
        demoClients[0].name,
      );
    else await expect(page.locator("tbody")).toContainText("Inactive");
  });
