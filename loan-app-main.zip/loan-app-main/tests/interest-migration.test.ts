import { PGlite } from "@electric-sql/pglite";
import { it, expect } from "vitest";
import { readFileSync } from "node:fs";
it("preserves historical charges, records only known rates, and supports audited legacy adjustment", async () => {
  const db = new PGlite();
  const owner = "11111111-1111-4111-8111-111111111111";
  try {
    await db.exec(
      `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;insert into auth.users values('${owner}');`,
    );
    for (const name of [
      "001_ledger",
      "002_client_register",
      "003_excel_import",
    ])
      await db.exec(readFileSync(`supabase/migrations/${name}.sql`, "utf8"));
    await db.exec(
      `select set_config('request.jwt.claim.sub','${owner}',false);set role authenticated`,
    );
    const {
      rows: [client],
    } = await db.query<{ id: string }>(
      "insert into public.clients(man_number,name,department,designation) values('LEGACY1','Legacy Client','Health','Nurse') returning id",
    );
    const {
      rows: [fixed],
    } = await db.query<{ id: string }>(
      "select public.create_loan($1,100000,7777,current_date+30) as id",
      [client.id],
    );
    const terms = {
      disbursement_date: "2026-01-01",
      interest_type: "flat_percent",
      interest_value: "10.05",
      term_days: 30,
      due_rule: "days_after_disbursement",
    };
    const rows = [
      {
        source_no: "1",
        man_number: "IMPORT1",
        name: "Imported Client",
        department: "Health",
        designation: "Nurse",
        amount: "100.00",
        man_numeric: false,
        parse_errors: [],
      },
    ];
    const {
      rows: [batch],
    } = await db.query<{ id: string }>(
      "select public.preview_import($1,$2,$3,$4,$5) as id",
      [
        "old.xlsx",
        "c".repeat(64),
        "loans",
        JSON.stringify(terms),
        JSON.stringify(rows),
      ],
    );
    await db.query("select public.commit_import($1,1,true)", [batch.id]);
    const before = (
      await db.query(
        "select id,client_id,principal_cents,interest_cents,balance_cents,due_date,disbursement_date,created_at from public.loans order by id",
      )
    ).rows;
    await db.exec("reset role");
    await db.exec(
      readFileSync("supabase/migrations/004_interest_settings.sql", "utf8"),
    );
    await db.exec("set role authenticated");
    expect(
      (
        await db.query(
          "select id,client_id,principal_cents,interest_cents,balance_cents,due_date,disbursement_date,created_at from public.loans order by id",
        )
      ).rows,
    ).toEqual(before);
    const {
      rows: [legacy],
    } = await db.query<any>("select * from public.loans where id=$1", [
      fixed.id,
    ]);
    expect(legacy.interest_rate_bps).toBeNull();
    expect(legacy.calculation_method).toBe("legacy_fixed_charge");
    expect(Number(legacy.interest_cents)).toBe(7777);
    const {
      rows: [known],
    } = await db.query<any>(
      "select * from public.loans where import_batch_id=$1",
      [batch.id],
    );
    expect(known.interest_rate_bps).toBe(1005);
    expect(known.calculation_method).toBe("one_time_flat");
    await db.query(
      "select public.record_repayment($1,10000,gen_random_uuid())",
      [fixed.id],
    );
    await db.exec(
      `reset role;insert into public.account_permissions values('${owner}',true,true);set role authenticated`,
    );
    await db.query(
      "select public.adjust_loan_terms($1,500,30,1,$2,gen_random_uuid(),true)",
      [fixed.id, "Verified conversion to one-time flat terms"],
    );
    const {
      rows: [adjusted],
    } = await db.query<any>("select * from public.loans where id=$1", [
      fixed.id,
    ]);
    expect(adjusted.interest_rate_bps).toBe(500);
    expect(Number(adjusted.interest_cents)).toBe(5000);
    expect(Number(adjusted.balance_cents)).toBe(95000);
    expect(adjusted.settings_revision).toBeNull();
    const { rows: audit } = await db.query<any>(
      "select * from public.loan_terms_audit where loan_id=$1 order by created_at",
      [fixed.id],
    );
    expect(audit.map((a) => a.action)).toEqual(["baseline", "adjust"]);
    expect(audit[0].actor_id).toBeNull();
    expect(audit[1].before_data.interest_cents).toBe(7777);
    const beforeRegister = (
      await db.query(
        "select id,client_id,principal_cents,interest_cents,balance_cents,due_date,created_at from public.loans order by id",
      )
    ).rows;
    await db.exec("reset role");
    await db.exec(
      readFileSync("supabase/migrations/005_loan_register.sql", "utf8"),
    );
    await db.exec("set role authenticated");
    expect(
      (
        await db.query(
          "select id,client_id,principal_cents,interest_cents,balance_cents,due_date,created_at from public.loan_register order by id",
        )
      ).rows,
    ).toEqual(beforeRegister);
    const { rows: registered } = await db.query<any>(
      "select * from public.loan_register order by id",
    );
    expect(new Set(registered.map((l) => l.loan_reference)).size).toBe(2);
    expect(registered.every((l) => l.created_by === owner)).toBe(true);
    expect(registered.find((l) => l.id === fixed.id).creator_inferred).toBe(
      true,
    );
    expect(
      registered.find((l) => l.import_batch_id === batch.id).creator_inferred,
    ).toBe(false);
  } finally {
    await db.close();
  }
}, 30000);
