import { PGlite } from "@electric-sql/pglite";
import { it, expect } from "vitest";
import { readFileSync, readdirSync } from "node:fs";

it("upgrades an existing ledger without changing financial history, IDs or prior role access", async () => {
  const db = new PGlite();
  const owner = "11111111-1111-4111-8111-111111111111";
  const officer = "22222222-2222-4222-8222-222222222222";
  const cashier = "33333333-3333-4333-8333-333333333333";
  const viewer = "44444444-4444-4444-8444-444444444444";
  async function value(sql: string, args: unknown[] = []): Promise<any> {
    return Object.values(
      (await db.query<Record<string, any>>(sql, args)).rows[0],
    )[0];
  }
  try {
    await db.exec(
      `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`,
    );
    const files = readdirSync("supabase/migrations").sort();
    for (const file of files.filter((f) => f < "013"))
      await db.exec(readFileSync("supabase/migrations/" + file, "utf8"));
    for (const id of [owner, officer, cashier, viewer])
      await db.query("insert into auth.users values($1)", [id]);
    await db.exec(
      `insert into public.businesses(id,name) values('${owner}','Fictional migration business');insert into public.ledger_settings(owner_id) values('${owner}');insert into public.user_roles(user_id,owner_id,role) values('${owner}','${owner}','administrator'),('${officer}','${owner}','loan_officer'),('${cashier}','${owner}','cashier'),('${viewer}','${owner}','viewer');select set_config('request.jwt.claim.sub','${owner}',false);set role authenticated;`,
    );
    const client = await value(
      "insert into public.clients(man_number,name,department,designation) values('000090','Fictional preserved Client','Finance','Analyst') returning id",
    );
    const day = await value(
      "select to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD')",
    );
    const loan = await value(
      "select public.originate_loan($1,gen_random_uuid(),true)",
      [
        JSON.stringify({
          client_id: client,
          expected_client_revision: 1,
          principal_cents: 100000,
          rate_bps: 1000,
          term_days: 30,
          disbursement_date: day,
          settings_revision: 1,
          calculation_method: "one_time_flat",
          rate_basis: "entire_term",
        }),
      ],
    );
    await value("select public.post_repayment($1,gen_random_uuid(),true)", [
      JSON.stringify({
        loan_id: loan,
        amount_cents: 15000,
        payment_date: day,
        payment_method: "cash",
        expected_balance_cents: 110000,
        expected_terms_revision: 1,
        expected_interest_outstanding_cents: 10000,
        expected_principal_outstanding_cents: 100000,
      }),
    ]);
    await db.exec("reset role");
    const tables = [
      "clients",
      "loans",
      "repayments",
      "client_audit",
      "loan_terms_audit",
      "loan_status_audit",
      "repayment_audit",
      "ledger_settings",
      "financial_operations",
    ];
    const before = new Map<string, unknown>();
    for (const table of tables)
      before.set(
        table,
        await value(
          `select coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),'[]') from public.${table} t`,
        ),
      );
    const rolesBefore = (
      await db.query(
        "select user_id,role,is_active,revision,updated_at from public.user_roles order by user_id",
      )
    ).rows;
    for (const file of files.filter((f) => f >= "013"))
      await db.exec(readFileSync("supabase/migrations/" + file, "utf8"));
    for (const table of tables)
      expect(
        await value(
          `select coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),'[]') from public.${table} t`,
        ),
      ).toEqual(before.get(table));
    expect(
      (
        await db.query(
          "select user_id,role,is_active,revision,updated_at from public.user_roles order by user_id",
        )
      ).rows,
    ).toEqual(rolesBefore);
    expect(
      await value(
        "select count(*) from public.audit_events where reason like 'Migration 013:%'",
      ),
    ).toBe(4);
    for (const id of [owner, officer, cashier, viewer]) {
      await db.query("select set_config('request.jwt.claim.sub',$1,false)", [
        id,
      ]);
      await db.query("select set_config('request.jwt.claims',$1,false)", [
        JSON.stringify({ session_id: id }),
      ]);
      await db.exec(
        "set role authenticated;select public.touch_app_session();",
      );
      const d = await value("select public.loan_defaults()");
      expect(d.capabilities).toMatchObject({
        can_read: true,
        can_view_dashboard: true,
        can_view_clients: true,
        can_view_loans: true,
        can_view_repayments: true,
        can_view_reports: true,
        can_view_expenses: true,
        can_export_reports: true,
        can_register_clients: [owner, officer].includes(id),
        can_post_repayments: [owner, cashier].includes(id),
        can_manage_users: id === owner,
        can_import: id === owner,
      });
      expect(await value("select count(*) from public.loan_register")).toBe(1);
      await db.exec("reset role");
    }
  } finally {
    await db.close();
  }
}, 30000);
