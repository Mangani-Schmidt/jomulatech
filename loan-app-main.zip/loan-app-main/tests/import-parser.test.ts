import { describe, it, expect } from "vitest";
import ExcelJS from "exceljs";
import { readWorkbook, mappedRows } from "../lib/import-server";
import { GET as template } from "../app/api/imports/template/route";
const headers = ["no#", "name", "man#", "department", "designation", "amount"];
async function workbook(
  rows: unknown[][],
  configure?: (sheet: ExcelJS.Worksheet) => void,
) {
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet("Data");
  rows.forEach((row) => sheet.addRow(row));
  configure?.(sheet);
  return new File([await wb.xlsx.writeBuffer()], "data.xlsx");
}
const row = [1, "Mary Tembo", "00124", "Health", "Nurse", 1000];
describe("bounded server spreadsheet parser", () => {
  it("reads standard columns case-insensitively and keeps Man# as text", async () => {
    const { sheet, inspection } = await readWorkbook(
      await workbook([headers.map((h) => h.toUpperCase()), row]),
    );
    expect(inspection.mapping.man_number).toBe(3);
    const rows = mappedRows(sheet, inspection.mapping);
    expect(rows[0].man_number).toBe("00124");
    expect(rows[0].source_no).toBe("1");
    expect(rows[0].amount).toBe("1000");
  });
  it("supports reordered headers and explicit nonstandard column mapping", async () => {
    const { sheet, inspection } = await readWorkbook(
      await workbook([
        ["Employee", "Value", "Full name", "Unit", "Role", "Row"],
        ["00124", 1000, "Mary Tembo", "Health", "Nurse", 7],
      ]),
    );
    expect(inspection.mapping.man_number).toBe(0);
    const rows = mappedRows(sheet, {
      man_number: 1,
      amount: 2,
      name: 3,
      department: 4,
      designation: 5,
      source_no: 6,
    });
    expect(rows[0].source_no).toBe("7");
    expect(rows[0].man_number).toBe("00124");
    expect(() => mappedRows(sheet, { ...inspection.mapping, name: 1 })).toThrow(
      "Map all six",
    );
  });
  it("flags numeric Man# and recovers zero-pad formatting when available", async () => {
    const { sheet, inspection } = await readWorkbook(
      await workbook(
        [headers, [...row.slice(0, 2), 124, ...row.slice(3)]],
        (s) => {
          s.getRow(2).getCell(3).numFmt = "00000";
        },
      ),
    );
    const parsed = mappedRows(sheet, inspection.mapping)[0];
    expect(parsed.man_number).toBe("00124");
    expect(parsed.man_numeric).toBe(true);
  });
  it("flags lost numeric precision and formulas without evaluating them", async () => {
    const { sheet, inspection } = await readWorkbook(
      await workbook([
        headers,
        [
          1,
          { formula: "1+1" },
          1234567890123456,
          "Health",
          "Nurse",
          { formula: "2+2", result: 4 },
        ],
      ]),
    );
    const parsed = mappedRows(sheet, inspection.mapping)[0];
    expect(parsed.parse_errors.join(" ")).toContain("formula");
    expect(parsed.parse_errors.join(" ")).toContain("precision");
    expect(parsed.amount).toBe("FORMULA_NOT_SUPPORTED");
  });
  it("does not auto-map ambiguous duplicate headers", async () => {
    const { inspection } = await readWorkbook(
      await workbook([
        ["no#", "name", "man#", "MAN#", "designation", "amount"],
        row,
      ]),
    );
    expect(inspection.mapping.man_number).toBe(0);
  });
  it("enforces type, size, row, and archive limits", async () => {
    await expect(readWorkbook(new File(["bad"], "data.csv"))).rejects.toThrow(
      ".xlsx",
    );
    await expect(
      readWorkbook(
        new File([new Uint8Array(2 * 1024 * 1024 + 1)], "data.xlsx"),
      ),
    ).rejects.toThrow("2 MB");
    await expect(readWorkbook(new File(["bad"], "data.xlsx"))).rejects.toThrow(
      "archive",
    );
    await expect(
      readWorkbook(
        await workbook([headers, ...Array.from({ length: 501 }, () => row)]),
      ),
    ).rejects.toThrow("500");
  });
  it("rejects a compressed archive expanding beyond 20 MB", async () => {
    const { default: JSZip } = await import("jszip");
    const zip = new JSZip();
    zip.file("oversized.xml", "x".repeat(21 * 1024 * 1024));
    await expect(
      readWorkbook(
        new File(
          [
            new Uint8Array(
              await zip.generateAsync({
                type: "uint8array",
                compression: "DEFLATE",
              }),
            ),
          ],
          "bomb.xlsx",
        ),
      ),
    ).rejects.toThrow("archive limits");
  });
  it("downloads a usable template with text Man# and the six columns", async () => {
    const response = await template();
    expect(response.headers.get("content-disposition")).toContain(
      "template.xlsx",
    );
    const file = new File([await response.arrayBuffer()], "template.xlsx");
    const { sheet, inspection } = await readWorkbook(file);
    expect(inspection.columns.map((c) => c.label)).toEqual(headers);
    expect(mappedRows(sheet, inspection.mapping)[0].man_number).toBe("00124");
  });
});
