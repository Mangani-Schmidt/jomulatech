import { PGlite } from "@electric-sql/pglite";
import { beforeAll, afterAll, it, expect } from "vitest";
import { readFileSync } from "node:fs";
const db = new PGlite();
const owner = "11111111-1111-4111-8111-111111111111",
  other = "22222222-2222-4222-8222-222222222222";
let client: string, a: string, b: string;
let businessDay: string;
const receipt = "33333333-3333-4333-8333-333333333333";
const writeRequest = "44444444-4444-4444-8444-444444444444";
async function scalar<T = any>(sql: string, args: unknown[] = []) {
  const { rows } = await db.query<Record<string, T>>(sql, args);
  return Object.values(rows[0])[0];
}
async function user(id: string) {
  await db.exec(
    `reset role;select set_config('request.jwt.claim.sub','${id}',false);set role authenticated`,
  );
}
async function admin(id = owner) {
  await db.exec(
    `reset role;insert into public.account_permissions values('${id}',true,true) on conflict(user_id) do update set is_admin=true,can_override_rate=true;set role authenticated`,
  );
}
async function originate(change: Record<string, unknown> = {}) {
  return scalar<string>(
    "select public.originate_loan($1,gen_random_uuid(),true)",
    [
      JSON.stringify({
        client_id: client,
        principal_cents: 100000,
        rate_bps: 1000,
        term_days: 30,
        disbursement_date: businessDay,
        calculation_method: "one_time_flat",
        rate_basis: "entire_term",
        settings_revision: 1,
        override_reason: "",
        ...change,
      }),
    ],
  );
}
async function loan(id: string) {
  return scalar("select to_jsonb(l) from public.loan_register l where id=$1", [
    id,
  ]);
}
async function writeOff(
  id: string,
  balance: number,
  reason = "Approved unrecoverable debt write-off",
  request = writeRequest,
  version = 1,
  confirm = true,
) {
  return scalar("select public.write_off_loan($1,$2,$3,$4,$5,$6)", [
    id,
    balance,
    version,
    reason,
    request,
    confirm,
  ]);
}
beforeAll(async () => {
  await db.exec(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;insert into auth.users values('${owner}'),('${other}');`,
  );
  for (const name of [
    "001_ledger",
    "002_client_register",
    "003_excel_import",
    "004_interest_settings",
    "005_loan_register",
  ])
    await db.exec(readFileSync(`supabase/migrations/${name}.sql`, "utf8"));
  await user(owner);
  businessDay = await scalar(
    "select to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD')",
  );
  client = await scalar(
    "insert into public.clients(man_number,name,department,designation) values('00124','Mary Tembo','Health','Nurse') returning id",
  );
}, 30000);
afterAll(() => db.close());
it("allows multiple independently referenced loans for one Client", async () => {
  a = await originate();
  b = await originate();
  const first = await loan(a),
    second = await loan(b);
  expect(a).not.toBe(b);
  expect(first.client_id).toBe(client);
  expect(second.client_id).toBe(client);
  expect(first.loan_reference).toMatch(/^LN-\d{8,}$/);
  expect(first.loan_reference).not.toBe(second.loan_reference);
  expect(first).toMatchObject({
    amount_disbursed_cents: 100000,
    principal_cents: 100000,
    interest_rate_bps: 1000,
    calculation_method: "one_time_flat",
    interest_cents: 10000,
    total_obligation_cents: 110000,
    currency: "ZMW",
    status: "active",
    lifecycle_status: "active",
    created_by: owner,
    creator_inferred: false,
  });
  expect(first.updated_at).toBe(first.created_at);
});
it("rejects zero/negative amounts, unsupported rates, missing fields and inconsistent dates", async () => {
  for (const change of [
    { principal_cents: 0 },
    { principal_cents: -1 },
    { rate_bps: 10001 },
    { rate_bps: -1 },
    { client_id: null },
    { disbursement_date: null },
    { term_days: 0 },
    { disbursement_date: "2099-01-01" },
    { disbursement_date: "2026-02-31" },
    { calculation_method: "compound" },
  ])
    await expect(originate(change)).rejects.toThrow();
  expect(Number(await scalar("select count(*) from public.loans"))).toBe(2);
});
it("defines due-today as Active and starts Overdue on the next business date", async () => {
  const get = (date: string, balance = 100, state = "active") =>
    scalar(
      "select public.loan_effective_status($1,'2026-11-13',$2,'Africa/Lusaka',$3)",
      [balance, state, date],
    );
  expect(await get("2026-11-13")).toBe("active");
  expect(await get("2026-11-14")).toBe("overdue");
  expect(await get("2026-11-14", 0)).toBe("settled");
  expect(await get("2026-11-14", 100, "written_off")).toBe("written_off");
  const overdue = await originate({ disbursement_date: "2026-01-01" });
  expect((await loan(overdue)).status).toBe("overdue");
});
it("updates timestamps and settles only the targeted loan when Repayment Received covers its obligation", async () => {
  await scalar("select public.record_repayment($1,10000,gen_random_uuid())", [
    a,
  ]);
  const partial = await loan(a);
  expect(partial.status).toBe("active");
  expect(partial.updated_at).not.toBe(partial.created_at);
  await scalar("select public.record_repayment($1,100000,$2)", [a, receipt]);
  const settled = await loan(a);
  expect(settled).toMatchObject({
    status: "settled",
    lifecycle_status: "settled",
    balance_cents: 0,
  });
  expect((await loan(b)).balance_cents).toBe(110000);
  await scalar("select public.record_repayment($1,100000,$2)", [a, receipt]);
  expect((await loan(a)).updated_at).toBe(settled.updated_at);
  expect(
    Number(
      await scalar(
        "select count(*) from public.loan_status_audit where loan_id=$1 and action='settle'",
        [a],
      ),
    ),
  ).toBe(1);
});
it("allows only explicit audited administrator adjustments to reopen a settled obligation", async () => {
  await admin();
  await scalar(
    "select public.adjust_loan_terms($1,2000,60,1,$2,gen_random_uuid(),true)",
    [a, "Approved adjusted total obligation"],
  );
  expect(await loan(a)).toMatchObject({
    status: "active",
    lifecycle_status: "active",
    balance_cents: 10000,
  });
  const audit = await scalar(
    "select to_jsonb(a) from public.loan_status_audit a where loan_id=$1 and action='reopen'",
    [a],
  );
  expect(audit).toMatchObject({
    before_status: "settled",
    after_status: "active",
    actor_id: owner,
  });
});
it("requires authorization, a reason, confirmation, and a current balance for write-off", async () => {
  await user(other);
  await expect(writeOff(b, 110000)).rejects.toThrow("Administrator");
  await user(owner);
  await expect(
    writeOff(b, 110000, "short", writeRequest, 1, false),
  ).rejects.toThrow("confirmation");
  await expect(writeOff(b, 110000, "")).rejects.toThrow("reason");
  await scalar("select public.record_repayment($1,5000,$2)", [
    b,
    "55555555-5555-4555-8555-555555555555",
  ]);
  await expect(writeOff(b, 110000)).rejects.toThrow("balance or terms changed");
});
it("writes off an unpaid balance without changing disbursement, obligation, or receipt history", async () => {
  const count = Number(await scalar("select count(*) from public.repayments"));
  await writeOff(b, 105000);
  const closed = await loan(b);
  expect(closed).toMatchObject({
    status: "written_off",
    lifecycle_status: "written_off",
    balance_cents: 105000,
    written_off_cents: 105000,
    written_off_by: owner,
    principal_cents: 100000,
    total_obligation_cents: 110000,
    created_by: owner,
  });
  expect(closed.written_off_reason).toBe(
    "Approved unrecoverable debt write-off",
  );
  expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
    count,
  );
  const audit = await scalar(
    "select to_jsonb(a) from public.loan_status_audit a where loan_id=$1 and action='write_off'",
    [b],
  );
  expect(audit).toMatchObject({
    before_status: "active",
    after_status: "written_off",
    actor_id: owner,
  });
});
it("makes write-off retries idempotent and rejects a reused request for different details", async () => {
  const before = await loan(b);
  await writeOff(b, 105000);
  expect((await loan(b)).updated_at).toBe(before.updated_at);
  expect(
    Number(
      await scalar(
        "select count(*) from public.loan_status_audit where loan_id=$1 and action='write_off'",
        [b],
      ),
    ),
  ).toBe(1);
  await expect(
    writeOff(b, 105000, "Different approved reason"),
  ).rejects.toThrow("Request ID");
  await expect(
    writeOff(
      b,
      105000,
      "Approved unrecoverable debt write-off",
      "66666666-6666-4666-8666-666666666666",
    ),
  ).rejects.toThrow("already written off");
});
it("closes written-off loans to new receipts/adjustments but permits safe receipt retries", async () => {
  await expect(
    scalar("select public.record_repayment($1,1,gen_random_uuid())", [b]),
  ).rejects.toThrow("closed");
  await expect(
    scalar(
      "select public.adjust_loan_terms($1,1500,30,1,$2,gen_random_uuid(),true)",
      [b, "Attempted write-off adjustment"],
    ),
  ).rejects.toThrow("closed");
  await scalar("select public.record_repayment($1,5000,$2)", [
    b,
    "55555555-5555-4555-8555-555555555555",
  ]);
  expect((await loan(b)).written_off_cents).toBe(105000);
});
it("does not write off settled loans or automatically write off overdue loans", async () => {
  const id = await originate();
  await scalar("select public.record_repayment($1,110000,gen_random_uuid())", [
    id,
  ]);
  await expect(
    writeOff(
      id,
      0,
      "No balance to write off",
      "77777777-7777-4777-8777-777777777777",
    ),
  ).rejects.toThrow("Settled");
  const overdue = await originate({ disbursement_date: "2026-01-01" });
  expect((await loan(overdue)).lifecycle_status).toBe("active");
  expect((await loan(overdue)).status).toBe("overdue");
});
it("assigns metadata/references to imported loans and returns the reference in import results", async () => {
  const rows = [
    {
      source_no: "100",
      man_number: "00124",
      name: "Mary Tembo",
      department: "Health",
      designation: "Nurse",
      amount: "100.00",
      man_numeric: false,
      parse_errors: [],
    },
  ];
  const terms = {
    disbursement_date: businessDay,
    interest_type: "flat_percent",
    interest_value: "10",
    term_days: 30,
    due_rule: "days_after_disbursement",
    settings_revision: 1,
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    override_reason: "",
  };
  const id = await scalar("select public.preview_import($1,$2,$3,$4,$5)", [
    "loans.xlsx",
    "d".repeat(64),
    "loans",
    JSON.stringify(terms),
    JSON.stringify(rows),
  ]);
  await scalar("select public.commit_import($1,1,true)", [id]);
  const report = await scalar("select public.import_report($1)", [id]);
  expect(report.rows[0].loan_reference).toMatch(/^LN-\d{8,}$/);
  const imported = await loan(report.rows[0].loan_id);
  expect(imported.created_by).toBe(owner);
  expect(imported.lifecycle_status).toBe("active");
});
it("enforces RLS on the view and audit and prevents direct status/reference changes", async () => {
  await expect(
    db.query(
      "update public.loans set loan_reference='LN-99999999' where id=$1",
      [a],
    ),
  ).rejects.toThrow("permission denied");
  await expect(
    db.query("update public.loans set lifecycle_status='settled' where id=$1", [
      b,
    ]),
  ).rejects.toThrow("permission denied");
  await expect(
    db.query("delete from public.loan_status_audit"),
  ).rejects.toThrow("permission denied");
  await expect(
    db.query("select nextval('public.loan_reference_sequence')"),
  ).rejects.toThrow("permission denied");
  await user(other);
  await admin(other);
  expect(
    Number(await scalar("select count(*) from public.loan_register")),
  ).toBe(0);
  expect(
    Number(await scalar("select count(*) from public.loan_status_audit")),
  ).toBe(0);
  await expect(writeOff(a, 10000)).rejects.toThrow("Loan not found");
  await db.exec("reset role;set role anon");
  await expect(db.query("select * from public.loan_register")).rejects.toThrow(
    "permission denied",
  );
  await user(owner);
});
