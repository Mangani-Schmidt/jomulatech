import { beforeEach, afterEach, it, expect, vi } from "vitest";
import ExcelJS from "exceljs";
const mocks = vi.hoisted(() => ({ getUser: vi.fn(), rpc: vi.fn() }));
vi.mock("@supabase/supabase-js", () => ({
  createClient: () => ({ auth: { getUser: mocks.getUser }, rpc: mocks.rpc }),
}));
import { POST as inspect } from "../app/api/imports/inspect/route";
import { POST as preview } from "../app/api/imports/preview/route";
import { GET as history } from "../app/api/imports/history/route";
import { GET as report } from "../app/api/imports/report/route";
import { POST as commit } from "../app/api/imports/commit/route";
beforeEach(() => {
  vi.stubEnv("NEXT_PUBLIC_SUPABASE_URL", "https://test.supabase.co");
  vi.stubEnv("NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY", "test-key");
  mocks.getUser
    .mockReset()
    .mockResolvedValue({ data: { user: { id: "user" } }, error: null });
  mocks.rpc.mockReset().mockImplementation(async (name: string) => ({
    data:
      name === "has_capability"
        ? true
        : name === "import_report"
          ? { batch: { id: "batch" }, rows: [] }
          : "batch",
    error: null,
  }));
});
afterEach(() => vi.unstubAllEnvs());
async function upload() {
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet("Import");
  sheet.addRow(["no#", "name", "man#", "department", "designation", "amount"]);
  sheet.addRow([1, "Mary Tembo", "00124", "Health", "Nurse", 1000]);
  const form = new FormData();
  form.set("file", new File([await wb.xlsx.writeBuffer()], "data.xlsx"));
  return form;
}
const request = (body: FormData) =>
  new Request("http://localhost/api/imports/preview", {
    method: "POST",
    headers: { Authorization: "Bearer verified-token" },
    body,
  });
it("requires a server-verified Auth user before parsing uploads", async () => {
  mocks.getUser.mockResolvedValue({
    data: { user: null },
    error: { message: "invalid" },
  });
  const response = await inspect(request(await upload()));
  expect(response.status).toBe(401);
  expect(mocks.getUser).toHaveBeenCalledWith("verified-token");
  expect(mocks.rpc).not.toHaveBeenCalled();
});
it("rejects missing bearer credentials and oversized uploads", async () => {
  const body = await upload();
  const response = await inspect(
    new Request("http://local", { method: "POST", body }),
  );
  expect(response.status).toBe(401);
  const large = new Request("http://local", {
    method: "POST",
    headers: {
      Authorization: "Bearer verified-token",
      "Content-Type": "multipart/form-data; boundary=test",
    },
    body: new Uint8Array(2400000),
  });
  expect((await inspect(large)).status).toBe(413);
});
it("re-parses the uploaded workbook on the server and stages only mapped rows", async () => {
  const body = await upload();
  body.set("mode", "clients");
  body.set("terms", "{}");
  body.set(
    "mapping",
    JSON.stringify({
      source_no: 1,
      name: 2,
      man_number: 3,
      department: 4,
      designation: 5,
      amount: 6,
    }),
  );
  const response = await preview(request(body));
  expect(response.status).toBe(200);
  expect(response.headers.get("Cache-Control")).toBe("no-store");
  const staged = mocks.rpc.mock.calls.find(
    ([name]) => name === "preview_import",
  )![1];
  expect(staged.p_rows[0]).toMatchObject({
    source_no: "1",
    man_number: "00124",
    amount: "1000",
  });
  expect(staged.p_rows[0]).not.toHaveProperty("owner_id");
  expect(staged.p_mode).toBe("clients");
  expect(staged.p_file_sha256).toMatch(/^[a-f0-9]{64}$/);
});
it("rejects incomplete or overlapping mappings before the database call", async () => {
  const body = await upload();
  body.set("mapping", "{}");
  const response = await preview(request(body));
  expect(response.status).toBe(400);
  expect(mocks.rpc.mock.calls.map(([name]) => name)).toEqual([
    "has_capability",
  ]);
});
it("never infers confirmation or import mode from amount", async () => {
  const response = await commit(
    new Request("http://local", {
      method: "POST",
      headers: {
        Authorization: "Bearer verified-token",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ batch_id: "batch", preview_version: 1 }),
    }),
  );
  expect(response.status).toBe(200);
  expect(mocks.rpc).toHaveBeenCalledWith("commit_import", {
    p_batch_id: "batch",
    p_preview_version: 1,
    p_confirm: false,
  });
});

it("denies a verified non-administrator before reading an upload", async () => {
  mocks.rpc.mockResolvedValue({ data: false, error: null });
  const response = await inspect(request(await upload()));
  expect(response.status).toBe(403);
  expect(mocks.rpc).toHaveBeenCalledWith("has_capability", {
    p_action: "imports",
  });
});

it.each([
  ["inspect", inspect, "POST"],
  ["preview", preview, "POST"],
  ["commit", commit, "POST"],
  ["history", history, "GET"],
  ["report", report, "GET"],
] as const)(
  "rejects direct %s API access before reading or writing import data when capability is denied",
  async (name, handler, method) => {
    mocks.rpc.mockResolvedValue({ data: false, error: null });
    const response = await handler(
      new Request(`http://localhost/api/imports/${name}`, {
        method,
        headers: { Authorization: "Bearer verified-token" },
      }),
    );
    expect(response.status).toBe(403);
    expect(response.headers.get("Cache-Control")).toBe("no-store");
    expect(mocks.getUser).toHaveBeenCalledWith("verified-token");
    expect(mocks.rpc.mock.calls).toEqual([
      [
        "has_capability",
        {
          p_action:
            name === "history" || name === "report"
              ? "view_imports"
              : "imports",
        },
      ],
    ]);
  },
);
