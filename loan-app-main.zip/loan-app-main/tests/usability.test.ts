import { describe, it, expect } from "vitest";
import { formatBusinessTimestamp } from "../lib/business-time";
import { sidebarPreference } from "../lib/sidebar";
describe("business occurrence times", () => {
  it("shows the exact timestamp in the business timezone across midnight", () => {
    expect(formatBusinessTimestamp("2026-11-13T22:30:45Z")).toBe(
      "14 Nov 2026, 00:30:45 Africa/Lusaka",
    );
    expect(formatBusinessTimestamp("2026-11-14T00:30:45+02:00")).toBe(
      formatBusinessTimestamp("2026-11-13T22:30:45Z"),
    );
  });
  it("never fabricates a time for date-only, missing or offset-free history", () => {
    expect(formatBusinessTimestamp("2026-11-14")).toBe(
      "14 Nov 2026 · Time not recorded",
    );
    expect(formatBusinessTimestamp("2026-11-14T10:30:00")).toBe(
      "14 Nov 2026 · Time not recorded",
    );
    expect(formatBusinessTimestamp(null)).toBe("Not recorded");
    expect(formatBusinessTimestamp("unavailable")).toBe("Not recorded");
    expect(formatBusinessTimestamp("2026-02-30")).toBe("Not recorded");
    expect(formatBusinessTimestamp("2026-02-30T10:00:00Z")).toBe(
      "Not recorded",
    );
  });
});
it("restores only a valid collapsed preference, defaulting to expanded", () => {
  expect(sidebarPreference("collapsed")).toBe("collapsed");
  for (const value of [null, "expanded", "<script>", false])
    expect(sidebarPreference(value)).toBe("expanded");
});
