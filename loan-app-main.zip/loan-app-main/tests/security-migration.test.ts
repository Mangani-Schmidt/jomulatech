import { PGlite } from "@electric-sql/pglite";
import { it, expect } from "vitest";
import { readFileSync, readdirSync } from "node:fs";
it("upgrades maximum-value financial history to decimal storage without changing IDs, allocations or audits", async () => {
  const db = new PGlite();
  const owner = "11111111-1111-4111-8111-111111111111";
  async function value(sql: string, args: unknown[] = []): Promise<any> {
    const r = await db.query<Record<string, any>>(sql, args);
    return Object.values(r.rows[0])[0];
  }
  try {
    await db.exec(
      `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;insert into auth.users values('${owner}');`,
    );
    for (const file of readdirSync("supabase/migrations")
      .sort()
      .filter((f) => f < "008"))
      await db.exec(readFileSync("supabase/migrations/" + file, "utf8"));
    await db.query(
      "insert into public.account_permissions values($1,true,true)",
      [owner],
    );
    await db.exec(
      `select set_config('request.jwt.claim.sub','${owner}',false);set role authenticated`,
    );
    const day = await value(
      "select to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD')",
    );
    const client = await value(
      "insert into public.clients(man_number,name,department,designation) values('00001','Legacy Client','Finance','Analyst') returning id",
    );
    const loan = await value(
      "select public.originate_loan($1,gen_random_uuid(),true)",
      [
        JSON.stringify({
          client_id: client,
          principal_cents: 99999999999,
          rate_bps: 10000,
          term_days: 30,
          disbursement_date: day,
          settings_revision: 1,
          calculation_method: "one_time_flat",
          rate_basis: "entire_term",
          override_reason: "Approved maximum-value migration fixture",
        }),
      ],
    );
    await value("select public.post_repayment($1,gen_random_uuid(),true)", [
      JSON.stringify({
        loan_id: loan,
        amount_cents: 123456789,
        payment_date: day,
        payment_method: "bank_transfer",
        expected_balance_cents: 199999999998,
        expected_terms_revision: 1,
        expected_interest_outstanding_cents: 99999999999,
        expected_principal_outstanding_cents: 99999999999,
      }),
    ]);
    const before = await value("select public.report_source()");
    await db.exec("reset role");
    await db.exec(
      readFileSync("supabase/migrations/008_roles_and_expenses.sql", "utf8"),
    );
    await db.exec("set role authenticated");
    const after = await value("select public.report_source()");
    expect(after.loans).toEqual(before.loans);
    expect(after.repayments).toEqual(before.repayments);
    expect(after.terms_audit).toEqual(before.terms_audit);
    expect(after.status_audit).toEqual(before.status_audit);
    expect(after.repayment_audit).toEqual(before.repayment_audit);
    const projected = await value(
      "select to_jsonb(l) from public.loan_register l where id=$1",
      [loan],
    );
    expect(projected.principal_outstanding_cents).toBe(99999999999);
    expect(projected.interest_outstanding_cents).toBe(99876543210);
    expect(projected.amount_disbursed).toBe(999999999.99);
    expect(await value("select public.has_capability('admin')")).toBe(true);
  } finally {
    await db.close();
  }
}, 30000);
it("executes the documented first-Administrator bootstrap and refuses to move a staff identity between businesses", async () => {
  const db = new PGlite();
  const owner = "11111111-1111-4111-8111-111111111111",
    staff = "22222222-2222-4222-8222-222222222222";
  try {
    await db.exec(
      `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key,email text unique);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;insert into auth.users values('${owner}','administrator@example.com'),('${staff}','staff@example.com');`,
    );
    for (const file of readdirSync("supabase/migrations").sort())
      await db.exec(readFileSync("supabase/migrations/" + file, "utf8"));
    await db.exec(
      `select set_config('request.jwt.claim.sub','${owner}',false);select set_config('request.jwt.claims','{"session_id":"${owner}"}',false);set role authenticated;select public.touch_app_session();`,
    );
    await expect(
      db.query(
        "select public.manage_user_role($1,'administrator',true,0,'Attempted self promotion',gen_random_uuid(),true)",
        [owner],
      ),
    ).rejects.toThrow("Permission denied");
    await db.exec("reset role");
    const doc = readFileSync("README.md", "utf8");
    const sql = doc.match(/```sql\n(begin;\ndo \$\$[\s\S]*?commit;)\n```/)?.[1];
    expect(sql).toBeTruthy();
    await db.exec(sql!);
    await db.exec("set role authenticated");
    const defaults = await db.query<{ value: any }>(
      "select public.loan_defaults() as value",
    );
    expect(defaults.rows[0].value.capabilities).toMatchObject({
      is_admin: true,
      role: "administrator",
      can_import: true,
    });
    await db.query(
      "select public.manage_user_role($1,'cashier',true,0,'Approved staff Cashier access',gen_random_uuid(),true)",
      [staff],
    );
    await db.exec("reset role");
    await expect(
      db.exec(sql!.replace("administrator@example.com", "staff@example.com")),
    ).rejects.toThrow("already belongs to another business");
    await db.exec("rollback");
    const rows = await db.query<{ owner_id: string }>(
      "select owner_id from public.user_roles where user_id=$1",
      [staff],
    );
    expect(rows.rows[0].owner_id).toBe(owner);
  } finally {
    await db.close();
  }
}, 30000);
