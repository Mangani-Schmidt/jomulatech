import { it, expect } from "vitest";
import {
  receivedCents,
  repaymentAllocation,
  netReceived,
} from "../lib/repayments";
import type { Loan, Repayment } from "../lib/domain";
it("supports full-obligation amounts beyond the principal limit without floats", () => {
  expect(receivedCents("1999999999.98")).toBe(199999999998);
  expect(receivedCents("0.01")).toBe(1);
  for (const value of ["0", "-1", "1.001", "NaN", "2000000000"])
    expect(() => receivedCents(value)).toThrow();
});
it("previews partial/full interest-first allocations and rejects overpayment", () => {
  const l = {
    balance_cents: 110000,
    principal_cents: 100000,
    interest_cents: 10000,
    interest_outstanding_cents: 10000,
    principal_outstanding_cents: 100000,
  } as Loan;
  expect(repaymentAllocation(l, 15000)).toEqual({
    interest: 10000,
    principal: 5000,
    balanceAfter: 95000,
  });
  expect(repaymentAllocation(l, 110000)).toEqual({
    interest: 10000,
    principal: 100000,
    balanceAfter: 0,
  });
  expect(() => repaymentAllocation(l, 110001)).toThrow("Overpayment");
});
it("excludes reversed receipts from net financial effect while preserving the rows", () => {
  const rows = [
    { amount_cents: 1000, posting_status: "posted" },
    {
      amount_cents: 500,
      posting_status: "reversed",
      reversed_at: "2026-11-13",
    },
  ] as Repayment[];
  expect(netReceived(rows)).toBe(1000);
  expect(rows).toHaveLength(2);
});
