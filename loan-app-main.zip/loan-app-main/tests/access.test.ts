import { it, expect } from "vitest";
import { hasCapability, type Capabilities } from "../lib/access";
it("does not grant access while capabilities are missing or from a role name alone", () => {
  expect(hasCapability(null, "can_read")).toBe(false);
  expect(hasCapability(undefined, "is_admin")).toBe(false);
  expect(
    hasCapability(
      { role: "administrator", is_admin: false, can_override_rate: false },
      "can_read",
    ),
  ).toBe(false);
});
it("uses each explicit database flag without inferring other grants from Administrator", () => {
  const flags: Capabilities = {
    can_read: true,
    is_admin: true,
    can_override_rate: false,
    can_import: false,
  };
  expect(hasCapability(flags, "is_admin")).toBe(true);
  expect(hasCapability(flags, "can_import")).toBe(false);
  expect(hasCapability(flags, "can_override_rate")).toBe(false);
  expect(hasCapability({ ...flags, can_read: false }, "is_admin")).toBe(false);
});
