import { afterEach, beforeEach, expect, it, vi } from "vitest";
import {
  pendingPosting,
  rememberPosting,
  forgetPosting,
  clearPostingMemory,
  allowPostingReentry,
} from "../lib/posting-intent";
let values: Map<string, string>;
beforeEach(() => {
  clearPostingMemory();
  values = new Map();
  vi.stubGlobal("localStorage", {
    getItem: (k: string) => values.get(k) ?? null,
    setItem: (k: string, v: string) => values.set(k, v),
    removeItem: (k: string) => values.delete(k),
  });
});
afterEach(() => vi.unstubAllGlobals());
it("preserves one actor-scoped posting body/key across remounts and rejects a replacement intent", () => {
  const body = {
    p_details: { amount_cents: 15000, expected_balance_cents: 110000 },
  };
  const first = rememberPosting("fictional-actor", "post_repayment", body);
  expect(pendingPosting("fictional-actor")).toEqual(first);
  expect(rememberPosting("fictional-actor", "post_repayment", body).id).toBe(
    first.id,
  );
  expect(() =>
    rememberPosting("fictional-actor", "post_repayment", {
      p_details: { amount_cents: 15000, expected_balance_cents: 95000 },
    }),
  ).toThrow("earlier posting");
  expect(pendingPosting("another-fictional-actor")).toBeNull();
  forgetPosting("fictional-actor", "different-request");
  expect(pendingPosting("fictional-actor")).toEqual(first);
  forgetPosting("fictional-actor", first.id);
  expect(pendingPosting("fictional-actor")).toBeNull();
  expect(
    rememberPosting("fictional-actor", "post_repayment", body).id,
  ).not.toBe(first.id);
});
it("fails closed before sending when a stored intent is corrupt or persistence is unavailable", () => {
  values.set("lendwell:pending-posting:fictional-actor", "not JSON");
  expect(() => pendingPosting("fictional-actor")).toThrow("cannot be read");
  values.set("lendwell:pending-posting:fictional-actor", "null");
  expect(() => pendingPosting("fictional-actor")).toThrow("cannot be read");
  values.clear();
  vi.stubGlobal("localStorage", {
    getItem: () => null,
    setItem: () => {
      throw new Error("Storage unavailable");
    },
  });
  expect(() =>
    rememberPosting("fictional-actor", "post_expense", { amount: "1.00" }),
  ).toThrow("Storage unavailable");
});
it("recovers a pre-rename intent without changing its request key or reviewed payload", () => {
  const previous = {
    version: 1,
    id: "11111111-1111-4111-8111-111111111111",
    operation: "post_repayment",
    body: {
      p_details: {
        loan_id: "fictional-loan",
        amount_cents: 15000,
        expected_balance_cents: 110000,
      },
      p_confirm: true,
    },
    createdAt: "2026-11-01T00:00:00Z",
  };
  values.set(
    "lendwell:pending-posting:fictional-actor",
    JSON.stringify(previous),
  );
  expect(pendingPosting("fictional-actor")).toEqual({
    ...previous,
    version: 2,
  });
  expect(
    rememberPosting("fictional-actor", "post_repayment", previous.body),
  ).toEqual({ ...previous, version: 2 });
  expect(values.size).toBe(1);
});

it("persists only opaque references and removes legacy financial payloads", () => {
  const intent = rememberPosting("fictional-actor", "post_repayment", {
    p_details: { amount_cents: 15000, loan_id: "private-loan" },
  });
  const raw = values.get("lendwell:pending-posting:fictional-actor")!;
  expect(raw).not.toContain("amount_cents");
  expect(raw).not.toContain("private-loan");
  clearPostingMemory();
  expect(pendingPosting("fictional-actor")).toMatchObject({
    id: intent.id,
    body: null,
  });
});

it("re-entry after a payload-free reload retains the original key and operation", () => {
  const first = rememberPosting("fictional-actor", "post_repayment", {
    amount: "150.00",
  });
  clearPostingMemory();
  expect(() =>
    rememberPosting("fictional-actor", "post_repayment", { amount: "150.00" }),
  ).toThrow("earlier posting");
  allowPostingReentry("fictional-actor");
  expect(() =>
    rememberPosting("fictional-actor", "originate_loan", { amount: "150.00" }),
  ).toThrow("earlier posting");
  const next = rememberPosting("fictional-actor", "post_repayment", {
    amount: "150.00",
  });
  expect(next).toMatchObject({
    id: first.id,
    reentered: true,
    body: { amount: "150.00" },
  });
  expect(values.get("lendwell:pending-posting:fictional-actor")).not.toContain(
    "150.00",
  );
  forgetPosting("fictional-actor", next.id);
  expect(pendingPosting("fictional-actor")).toBeNull();
});
