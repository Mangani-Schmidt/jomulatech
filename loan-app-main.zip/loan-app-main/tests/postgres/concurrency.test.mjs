import { before, after, test } from "node:test";
import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { setTimeout as delay } from "node:timers/promises";
import { createIsolatedPostgres } from "../support/isolated-postgres.mjs";
const actor = {
  admin: "11111111-1111-4111-8111-111111111111",
  cashier1: "22222222-2222-4222-8222-222222222222",
  cashier2: "33333333-3333-4333-8333-333333333333",
};
const literal = (value) => "'" + String(value).replaceAll("'", "''") + "'";
let db,
  day,
  sequence = 0;
const asActor = (id, sql) =>
  `begin;select set_config('request.jwt.claim.sub',${literal(id)},true);select set_config('request.jwt.claims',${literal(JSON.stringify({ session_id: id }))},true);set local role authenticated;select case when public.app_session_active() then null else public.touch_app_session() end;${sql};commit;`;
async function jsonAs(id, expression) {
  return db.json(asActor(id, "select to_jsonb(" + expression + ")"));
}
async function loan() {
  return jsonAs(
    actor.admin,
    `public.originate_loan(${literal(JSON.stringify({ client_id: await db.json("select to_jsonb(id) from public.clients limit 1;"), expected_client_revision: 1, principal_cents: 100000, rate_bps: 1000, term_days: 30, disbursement_date: day, settings_revision: 1, calculation_method: "one_time_flat", rate_basis: "entire_term", override_reason: "" }))}::jsonb,${literal(randomUUID())},true)`,
  );
}
async function state(id) {
  return db.json(
    `select to_jsonb(l) from public.loan_register l where id=${literal(id)};`,
  );
}
function details(id, amount, l) {
  return {
    loan_id: id,
    amount_cents: amount,
    payment_date: day,
    payment_method: "cash",
    expected_balance_cents: l.balance_cents,
    expected_terms_revision: l.terms_revision,
    expected_interest_outstanding_cents: l.interest_outstanding_cents,
    expected_principal_outstanding_cents: l.principal_outstanding_cents,
  };
}
const post = (d, key) =>
  `select public.post_repayment(${literal(JSON.stringify(d))}::jsonb,${literal(key)},true);`;
async function authSession(id) {
  const s = db.session("finance_" + ++sequence);
  await s.query(
    `begin;select set_config('request.jwt.claim.sub',${literal(id)},true);select set_config('request.jwt.claims',${literal(JSON.stringify({ session_id: id }))},true);set local role authenticated;`,
  );
  const identity = await s.json(
    "select jsonb_build_object('user',current_user,'rls',row_security_active('public.loans'),'pid',pg_backend_pid());",
  );
  assert.equal(identity.user, "authenticated");
  assert.equal(identity.rls, true);
  return { s, pid: identity.pid };
}
async function waitBlocked(waiter, blocker) {
  const deadline = Date.now() + 7000;
  while (Date.now() < deadline) {
    const blocked = await db.json(
      `select to_jsonb(${blocker}=any(pg_blocking_pids(${waiter})));`,
    );
    if (blocked) return;
    await delay(30);
  }
  assert.fail(
    "Competing PostgreSQL connection never waited on the expected lock.",
  );
}
async function ledger(id) {
  return db.json(
    `select jsonb_build_object('count',count(*),'received',coalesce(sum(amount_cents) filter(where reversed_at is null),0),'audit',(select count(*) from public.repayment_audit a join public.repayments r on r.id=a.repayment_id where r.loan_id=${literal(id)})) from public.repayments where loan_id=${literal(id)};`,
  );
}
before(
  async () => {
    db = await createIsolatedPostgres();
    await db.seed(
      `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`,
    );
    for (const name of (
      await readdir(new URL("../../supabase/migrations/", import.meta.url))
    ).sort())
      await db.seed(
        await readFile(
          new URL("../../supabase/migrations/" + name, import.meta.url),
          "utf8",
        ),
      );
    await db.seed(
      `insert into auth.users values('${actor.admin}'),('${actor.cashier1}'),('${actor.cashier2}');insert into public.businesses(id,name) values('${actor.admin}','Fictional concurrency business');insert into public.ledger_settings(owner_id) values('${actor.admin}');insert into public.user_roles(user_id,owner_id,role) values('${actor.admin}','${actor.admin}','administrator'),('${actor.cashier1}','${actor.admin}','cashier'),('${actor.cashier2}','${actor.admin}','cashier');`,
    );
    await db.run(
      asActor(
        actor.admin,
        "insert into public.clients(man_number,name,department,designation) values('000042','Fictional Client Alpha','Fictional Department','Fictional Designation')",
      ),
    );
    for (const id of Object.values(actor))
      await db.run(asActor(id, "select 1"));
    day = await db.json(
      "select to_jsonb(to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD')); ",
    );
    console.log(
      "Isolated PostgreSQL: " +
        (await db.json("select to_jsonb(current_setting('server_version'));")),
    );
  },
  { timeout: 120000 },
);
after(async () => {
  if (db) await db.destroy();
});

test(
  "competing Cashiers cannot overpay one loan and the loser receives a clear overpayment error",
  async () => {
    const id = await loan(),
      l = await state(id),
      a = await authSession(actor.cashier1),
      b = await authSession(actor.cashier2);
    try {
      await a.s.json(post(details(id, 70000, l), randomUUID()));
      const competing = b.s
        .json(post(details(id, 70000, l), randomUUID()))
        .then(
          (value) => ({ value }),
          (error) => ({ error }),
        );
      await waitBlocked(b.pid, a.pid);
      await a.s.query("commit;");
      const result = await competing;
      assert.match(result.error?.message ?? "", /Overpayment/);
      assert.equal((await state(id)).balance_cents, 40000);
      assert.deepEqual(await ledger(id), {
        count: 1,
        received: 70000,
        audit: 1,
      });
    } finally {
      await a.s.close();
      await b.s.close();
    }
  },
  { timeout: 15000 },
);

test(
  "a valid competing amount with a stale preview is rejected, then a reviewed retry settles exactly",
  async () => {
    const id = await loan(),
      l = await state(id),
      a = await authSession(actor.cashier1),
      b = await authSession(actor.cashier2);
    try {
      await a.s.json(post(details(id, 60000, l), randomUUID()));
      const competing = b.s
        .json(post(details(id, 50000, l), randomUUID()))
        .then(
          (value) => ({ value }),
          (error) => ({ error }),
        );
      await waitBlocked(b.pid, a.pid);
      await a.s.query("commit;");
      assert.match(
        (await competing).error?.message ?? "",
        /balance or terms changed/,
      );
      const fresh = await state(id);
      await jsonAs(
        actor.cashier2,
        `public.post_repayment(${literal(JSON.stringify(details(id, 50000, fresh)))}::jsonb,${literal(randomUUID())},true)`,
      );
      assert.equal((await state(id)).status, "settled");
      assert.deepEqual(await ledger(id), {
        count: 2,
        received: 110000,
        audit: 2,
      });
    } finally {
      await a.s.close();
      await b.s.close();
    }
  },
  { timeout: 15000 },
);

test("recovery status waits for an in-flight Cashier request and returns its one saved receipt", async () => {
  const id = await loan(),
    l = await state(id),
    key = randomUUID(),
    d = details(id, 15000, l),
    a = await authSession(actor.cashier1),
    b = await authSession(actor.cashier2);
  try {
    const first = await a.s.json(post(d, key));
    const status = b.s.json(
      `select public.posting_request_status(${literal(key)},'post_repayment');`,
    );
    await waitBlocked(b.pid, a.pid);
    await a.s.query("commit;");
    assert.deepEqual(await status, first);
    await b.s.query("commit;");
    assert.equal((await state(id)).balance_cents, 95000);
    assert.deepEqual(await ledger(id), { count: 1, received: 15000, audit: 1 });
  } finally {
    await a.s.close();
    await b.s.close();
  }
});

test(
  "the same request from two staff connections returns one receipt after waiting on its request lock",
  async () => {
    const id = await loan(),
      l = await state(id),
      key = randomUUID(),
      d = details(id, 60000, l),
      a = await authSession(actor.cashier1),
      b = await authSession(actor.cashier2);
    try {
      const first = await a.s.json(post(d, key));
      const competing = b.s.json(post(d, key));
      await waitBlocked(b.pid, a.pid);
      await a.s.query("commit;");
      assert.deepEqual(await competing, first);
      await b.s.query("commit;");
      assert.deepEqual(await ledger(id), {
        count: 1,
        received: 60000,
        audit: 1,
      });
      assert.equal(
        await db.json(
          `select to_jsonb(count(*)) from public.financial_operations where request_id=${literal(key)};`,
        ),
        1,
      );
    } finally {
      await a.s.close();
      await b.s.close();
    }
  },
  { timeout: 15000 },
);

test(
  "a concurrent reused request with different details cannot change the first posting",
  async () => {
    const id = await loan(),
      l = await state(id),
      key = randomUUID(),
      a = await authSession(actor.cashier1),
      b = await authSession(actor.cashier2);
    try {
      await a.s.json(post(details(id, 60000, l), key));
      const competing = b.s.json(post(details(id, 50000, l), key)).then(
        (value) => ({ value }),
        (error) => ({ error }),
      );
      await waitBlocked(b.pid, a.pid);
      await a.s.query("commit;");
      assert.match(
        (await competing).error?.message ?? "",
        /Request ID already used for a different/,
      );
      assert.equal((await state(id)).balance_cents, 50000);
      assert.deepEqual(await ledger(id), {
        count: 1,
        received: 60000,
        audit: 1,
      });
    } finally {
      await a.s.close();
      await b.s.close();
    }
  },
  { timeout: 15000 },
);

test(
  "a competing authorized rate adjustment includes the repayment committed under the same loan lock",
  async () => {
    const id = await loan(),
      l = await state(id),
      a = await authSession(actor.cashier1),
      b = await authSession(actor.admin);
    try {
      await a.s.json(post(details(id, 60000, l), randomUUID()));
      const competing = b.s.json(
        `select to_jsonb(public.adjust_loan_terms(${literal(id)},2000,30,1,'Approved fictional rate adjustment',${literal(randomUUID())},true));`,
      );
      await waitBlocked(b.pid, a.pid);
      await a.s.query("commit;");
      assert.equal(await competing, id);
      await b.s.query("commit;");
      const updated = await state(id);
      assert.equal(updated.balance_cents, 60000);
      assert.equal(updated.interest_outstanding_cents, 10000);
      assert.equal(updated.principal_outstanding_cents, 50000);
      assert.equal(updated.terms_revision, 2);
    } finally {
      await a.s.close();
      await b.s.close();
    }
  },
  { timeout: 15000 },
);

test(
  "rolling back a held posting releases its request and leaves only the waiting Cashier receipt",
  async () => {
    const id = await loan(),
      l = await state(id),
      key = randomUUID(),
      d = details(id, 60000, l),
      a = await authSession(actor.cashier1),
      b = await authSession(actor.cashier2);
    try {
      const rolledBack = await a.s.json(post(d, key));
      const competing = b.s.json(post(d, key));
      await waitBlocked(b.pid, a.pid);
      await a.s.query("rollback;");
      const saved = await competing;
      assert.notEqual(saved.repayment_id, rolledBack.repayment_id);
      await b.s.query("commit;");
      assert.deepEqual(await ledger(id), {
        count: 1,
        received: 60000,
        audit: 1,
      });
      assert.equal(
        await db.json(
          `select to_jsonb(created_by) from public.repayments where id=${literal(saved.repayment_id)};`,
        ),
        actor.cashier2,
      );
    } finally {
      await a.s.close();
      await b.s.close();
    }
  },
  { timeout: 15000 },
);

test(
  "revocation waits for an authorized in-flight receipt, then denies later posts and RLS reads",
  async () => {
    const id = await loan(),
      l = await state(id),
      a = await authSession(actor.cashier1),
      b = await authSession(actor.admin);
    try {
      await a.s.json(post(details(id, 60000, l), randomUUID()));
      const revoking = b.s.json(
        `select public.manage_user_role(${literal(actor.cashier1)},'cashier',false,1,'Approved fictional staff suspension',${literal(randomUUID())},true);`,
      );
      await waitBlocked(b.pid, a.pid);
      await a.s.query("commit;");
      assert.equal((await revoking).is_active, false);
      await b.s.query("commit;");
      await assert.rejects(
        jsonAs(
          actor.cashier1,
          `public.post_repayment('{}',${literal(randomUUID())},true)`,
        ),
        /Permission denied/,
      );
      assert.equal(
        await db.json(
          asActor(
            actor.cashier1,
            "select to_jsonb(count(*)) from public.loan_register",
          ),
        ),
        0,
      );
      assert.deepEqual(await ledger(id), {
        count: 1,
        received: 60000,
        audit: 1,
      });
    } finally {
      await a.s.close();
      await b.s.close();
    }
  },
  { timeout: 15000 },
);

test(
  "competing case-varied manual Man# registrations commit one Client and one identity audit",
  async () => {
    const man = "00Ab-" + randomUUID(),
      a = await authSession(actor.admin),
      b = await authSession(actor.admin);
    const insert = (value) =>
      `insert into public.clients(man_number,name,department,designation) values(${literal(value)},'Fictional Concurrent Client','Fictional Department','Fictional Designation') returning to_jsonb(id);`;
    try {
      const id = await a.s.json(insert(man));
      const competing = b.s.json(insert(man.toUpperCase())).then(
        (value) => ({ value }),
        (error) => ({ error }),
      );
      await waitBlocked(b.pid, a.pid);
      await a.s.query("commit;");
      assert.match((await competing).error?.message ?? "", /unique constraint/);
      // The fixture uses psql ON_ERROR_STOP: the rejected connection exits and
      // PostgreSQL rolls its transaction back before this fresh lookup.
      const found = await jsonAs(
        actor.admin,
        `public.find_client_by_man(${literal(man.toUpperCase())})`,
      );
      assert.equal(found.id, id);
      assert.equal(found.man_number, man);
      const counts = await db.json(
        `select jsonb_build_object('clients',(select count(*) from public.clients where lower(man_number)=lower(${literal(man)})),'audits',(select count(*) from public.client_audit where client_id=${literal(id)}));`,
      );
      assert.deepEqual(counts, { clients: 1, audits: 1 });
    } finally {
      await a.s.close();
      await b.s.close();
    }
  },
  { timeout: 15000 },
);

test(
  "activity waiting on a session lock cannot revive a session that expired while waiting",
  async () => {
    const sid = randomUUID();
    const claims = literal(JSON.stringify({ session_id: sid }));
    await db.run(
      asActor(
        actor.admin,
        `select set_config('request.jwt.claims',${claims},true);select public.touch_app_session()`,
      ),
    );
    const hold = db.session("session_expiry_holder"),
      waiter = await authSession(actor.admin);
    try {
      await waiter.s.query(
        `select set_config('request.jwt.claims',${claims},true);`,
      );
      await hold.query(
        `begin;select session_id from public.app_sessions where session_id=${literal(sid)} for update;`,
      );
      const holdPid = await hold.json("select to_jsonb(pg_backend_pid());");
      const pending = waiter.s.json("select public.touch_app_session();");
      await waitBlocked(waiter.pid, holdPid);
      // Expire it after the waiting RPC's statement began. Statement-start time
      // would incorrectly allow revival; the post-lock wall clock must reject it.
      await hold.query(
        `update public.app_sessions set last_activity_at=clock_timestamp()-interval '15 minutes' where session_id=${literal(sid)};commit;`,
      );
      assert.equal((await pending).active, false);
      await waiter.s.query("commit;");
      assert.equal(
        await db.json(
          `select to_jsonb(revocation_reason) from public.app_sessions where session_id=${literal(sid)};`,
        ),
        "inactive",
      );
    } finally {
      await hold.close();
      await waiter.s.close();
    }
  },
  { timeout: 15000 },
);
