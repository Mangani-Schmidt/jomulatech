import { test } from "node:test";
import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { createIsolatedPostgres } from "../support/isolated-postgres.mjs";

const actors = {
  admin: "11111111-1111-4111-8111-111111111111",
  cashier: "22222222-2222-4222-8222-222222222222",
  viewer: "33333333-3333-4333-8333-333333333333",
  foreign: "44444444-4444-4444-8444-444444444444",
};
const literal = (v) => "'" + String(v).replaceAll("'", "''") + "'";
const asActor = (id, sql) =>
  `begin;select set_config('request.jwt.claim.sub',${literal(id)},true);select set_config('request.jwt.claims',${literal(JSON.stringify({ session_id: id }))},true);set local role authenticated;select case when public.app_session_active() then null else public.touch_app_session() end;${sql};commit;`;
async function invoke(db, id, expression) {
  return db.json(asActor(id, "select to_jsonb(" + expression + ")"));
}
async function manifest(db) {
  const tables = await db.json(
    "select jsonb_agg(tablename order by tablename) from pg_tables where schemaname='public';",
  );
  assert.equal(tables.length, 20);
  // Compare every persisted row, not only portfolio totals: IDs, original
  // actors/timestamps, request keys, allocations and audit history must survive.
  const entries = [];
  for (const table of tables) {
    assert.match(table, /^[a-z_]+$/);
    entries.push(
      `${literal(table)},(select coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),'[]'::jsonb) from public.${table} t)`,
    );
  }
  entries.push(
    "'reference_sequences',(select jsonb_agg(jsonb_build_object('name',sequencename,'start',start_value,'increment',increment_by,'last',last_value) order by sequencename) from pg_sequences where schemaname='public')",
  );
  entries.push(
    "'auth_stub_users',(select jsonb_agg(to_jsonb(u) order by u.id) from auth.users u)",
  );
  return db.json("select jsonb_build_object(" + entries.join(",") + ");");
}
async function security(db) {
  return db.json(`select jsonb_build_object(
    'schema_usage',(select jsonb_object_agg(r,has_schema_privilege(r,'public','USAGE')) from unnest(array['anon','authenticated']) r),
    'tables',(select jsonb_agg(jsonb_build_object('name',c.relname,'rls',c.relrowsecurity,'acl',coalesce(c.relacl,acldefault('r',c.relowner))) order by c.relname) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r'),
    'policies',(select jsonb_agg(to_jsonb(p) order by p.tablename,p.policyname) from pg_policies p where p.schemaname='public'),
    'functions',(select jsonb_agg(jsonb_build_object('signature',p.oid::regprocedure::text,'acl',coalesce(p.proacl,acldefault('f',p.proowner)),'definer',p.prosecdef,'config',p.proconfig) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public')
  );`);
}

test(
  "a fictional backup restores history, exact allocations, request keys, RLS and posting capability into a fresh isolated database",
  { timeout: 120000 },
  async () => {
    const source = await createIsolatedPostgres();
    let restored;
    try {
      await source.seed(`create role anon;create role authenticated;
        grant usage on schema public to anon,authenticated;
        create schema auth;create table auth.users(id uuid primary key);
        create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
        grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`);
      for (const name of (
        await readdir(new URL("../../supabase/migrations/", import.meta.url))
      ).sort())
        await source.seed(
          await readFile(
            new URL("../../supabase/migrations/" + name, import.meta.url),
            "utf8",
          ),
        );
      await source.seed(`insert into auth.users values ${Object.values(actors)
        .map((id) => "(" + literal(id) + ")")
        .join(",")};
        insert into public.businesses(id,name) values('${actors.admin}','Fictional recovery business'),('${actors.foreign}','Fictional separate business');
        insert into public.ledger_settings(owner_id) values('${actors.admin}'),('${actors.foreign}');
        insert into public.user_roles(user_id,owner_id,role) values('${actors.admin}','${actors.admin}','administrator'),('${actors.cashier}','${actors.admin}','cashier'),('${actors.viewer}','${actors.admin}','viewer'),('${actors.foreign}','${actors.foreign}','administrator');`);
      for (const id of Object.values(actors))
        await source.run(asActor(id, "select 1"));
      const register = (db, id, man) =>
        db.json(
          asActor(
            id,
            `insert into public.clients(man_number,name,department,designation) values(${literal(man)},'Fictional Recovery Client','Fictional Department','Fictional Designation') returning to_jsonb(id)`,
          ),
        );
      const client = await register(source, actors.admin, "000042");
      await register(source, actors.foreign, "000042");
      const day = await source.json(
        "select to_jsonb(to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD'));",
      );
      const loanId = await invoke(
        source,
        actors.admin,
        `public.originate_loan(${literal(JSON.stringify({ client_id: client, expected_client_revision: 1, principal_cents: 100005, rate_bps: 1000, term_days: 30, disbursement_date: day, settings_revision: 1, calculation_method: "one_time_flat", rate_basis: "entire_term", override_reason: "" }))}::jsonb,${literal(randomUUID())},true)`,
      );
      const state = (db) =>
        db.json(
          `select to_jsonb(l) from public.loan_register l where id=${literal(loanId)};`,
        );
      const details = (l, amount) => ({
        loan_id: loanId,
        amount_cents: amount,
        payment_date: day,
        payment_method: "cash",
        expected_balance_cents: l.balance_cents,
        expected_terms_revision: l.terms_revision,
        expected_interest_outstanding_cents: l.interest_outstanding_cents,
        expected_principal_outstanding_cents: l.principal_outstanding_cents,
      });
      const post = (data, key) =>
        `public.post_repayment(${literal(JSON.stringify(data))}::jsonb,${literal(key)},true)`;
      const first = await invoke(
        source,
        actors.cashier,
        post(details(await state(source), 15000), randomUUID()),
      );
      await invoke(
        source,
        actors.admin,
        `public.reverse_repayment(${literal(first.repayment_id)},'Approved fictional recovery reversal',${literal(randomUUID())},true)`,
      );
      const key = randomUUID(),
        data = details(await state(source), 5000),
        payment = await invoke(source, actors.cashier, post(data, key));
      await invoke(
        source,
        actors.admin,
        `public.post_expense(${literal(JSON.stringify({ amount: "0.29", expense_date: day, currency: "ZMW", category: "Fictional bank fees", description: "Fictional restoration drill fee", payment_method: "cash", external_reference: "" }))}::jsonb,${literal(randomUUID())},true)`,
      );
      const eventCount = await invoke(
        source,
        actors.admin,
        "public.reporting_revision()",
      );
      await invoke(
        source,
        actors.admin,
        `public.certify_reporting_period(${literal(day)}::date,${literal(day)}::date,'ZMW','Fictional reviewed recovery-period coverage',true,true,${eventCount},${literal(randomUUID())},true)`,
      );
      await source.run(
        asActor(
          actors.admin,
          `select set_config('request.jwt.claims',jsonb_build_object('session_id',auth.uid(),'aal','aal2','amr',jsonb_build_array(jsonb_build_object('method','totp','timestamp',extract(epoch from statement_timestamp()))))::text,true);select public.set_admin_mfa_policy(true,'Fictional recovery security policy',${literal(randomUUID())},true)`,
        ),
      );
      const before = await manifest(source),
        beforeSecurity = await security(source),
        beforeReport = await invoke(
          source,
          actors.viewer,
          "public.report_source()",
        ),
        dump = await source.dump();
      assert.ok(dump.includes("CREATE POLICY"));
      assert.ok(dump.includes("Fictional Recovery Client"));

      restored = await createIsolatedPostgres();
      // pg_dump includes database objects, not cluster roles. The only dropped
      // schema is the verified empty default schema in this fresh container.
      assert.equal(
        await restored.json(
          "select to_jsonb(count(*)) from pg_tables where schemaname='public';",
        ),
        0,
      );
      await restored.seed(
        "create role anon;create role authenticated;drop schema public;",
      );
      await restored.seed(dump);
      assert.deepEqual(await manifest(restored), before);
      assert.deepEqual(await security(restored), beforeSecurity);
      const recoveryChecks = await readFile(
        new URL(
          "../../supabase/verification/recovery-checks.sql",
          import.meta.url,
        ),
        "utf8",
      );
      await restored.run(recoveryChecks);
      // The runbook check must also detect a broken restore, rather than merely
      // execute successfully against fixtures. This affects only our container.
      await restored.run(
        "alter table public.loans disable row level security;",
      );
      try {
        await assert.rejects(
          restored.run(recoveryChecks),
          /Missing table or disabled RLS: loans/,
        );
      } finally {
        await restored.run(
          "alter table public.loans enable row level security;",
        );
      }
      assert.deepEqual(await security(restored), beforeSecurity);
      const restoredReport = await invoke(
        restored,
        actors.viewer,
        "public.report_source()",
      );
      // Generation time belongs to this read, unlike persisted effective dates
      // and actor timestamps already compared in the complete row manifest.
      assert.ok(Date.parse(restoredReport.generated_at));
      delete beforeReport.generated_at;
      delete restoredReport.generated_at;
      assert.deepEqual(restoredReport, beforeReport);
      assert.equal((await state(restored)).balance_cents, 105006);
      assert.equal((await state(restored)).interest_outstanding_cents, 5001);
      assert.equal((await state(restored)).principal_outstanding_cents, 100005);
      assert.equal(
        await invoke(
          restored,
          actors.viewer,
          "(select count(*) from public.clients)",
        ),
        1,
      );
      assert.equal(
        await invoke(
          restored,
          actors.viewer,
          "row_security_active('public.loans')",
        ),
        true,
      );
      await assert.rejects(
        restored.run(asActor(actors.viewer, "delete from public.repayments")),
        /permission denied/,
      );
      await assert.rejects(
        restored.run(
          asActor(actors.viewer, "select " + post(data, randomUUID())),
        ),
        /permission|authorized|Cashier/i,
      );
      // A retry made after recovery must not collect the same money again.
      assert.deepEqual(
        await invoke(restored, actors.cashier, post(data, key)),
        payment,
      );
      assert.deepEqual(await manifest(restored), before);
      const next = details(await state(restored), 105006);
      await invoke(restored, actors.cashier, post(next, randomUUID()));
      assert.equal((await state(restored)).status, "settled");
      assert.equal((await state(restored)).balance_cents, 0);
    } finally {
      if (restored) await restored.destroy();
      await source.destroy();
    }
  },
);
