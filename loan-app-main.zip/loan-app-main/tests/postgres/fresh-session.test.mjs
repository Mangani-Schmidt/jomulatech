import { test } from "node:test";
import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import { createIsolatedPostgres } from "../support/isolated-postgres.mjs";

const actor = "11111111-1111-4111-8111-111111111111";
const claim = JSON.stringify({ session_id: actor });
const asActor = (sql) =>
  `begin;
   select set_config('request.jwt.claim.sub','${actor}',true);
   select set_config('request.jwt.claims','${claim}',true);
   set local role authenticated;
   ${sql};
   commit;`;

test(
  "first use reports an active session immediately, without revoking a fresh login",
  { timeout: 120000 },
  async () => {
    const db = await createIsolatedPostgres();
    try {
      await db.seed(`create role anon; create role authenticated;
      grant usage on schema public to anon, authenticated;
      create schema auth;
      create table auth.users(id uuid primary key);
      create function auth.uid() returns uuid language sql stable
        as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
      grant usage on schema auth to authenticated;
      grant execute on function auth.uid() to authenticated;`);
      for (const name of (
        await readdir(new URL("../../supabase/migrations/", import.meta.url))
      ).sort())
        await db.seed(
          await readFile(
            new URL("../../supabase/migrations/" + name, import.meta.url),
            "utf8",
          ),
        );
      await db.seed(`insert into auth.users values('${actor}');`);

      const first = await db.json(
        asActor("select to_jsonb(public.touch_app_session())"),
      );
      assert.equal(
        first.active,
        true,
        "first touch must not falsely report expiry",
      );
      assert.equal(first.registered, true);
      assert.ok(Date.parse(first.last_activity_at));
      assert.ok(Date.parse(first.server_now));

      const status = await db.json(
        asActor("select to_jsonb(public.app_session_status())"),
      );
      assert.equal(status.active, true);

      const revoked = await db.json(
        asActor(
          "select public.end_app_session('inactive'); select to_jsonb(public.touch_app_session())",
        ),
      );
      assert.equal(revoked.active, false, "revoked sessions cannot be revived");

      const persisted = await db.json(
        `select jsonb_build_object('count',count(*),'revoked',bool_and(revoked_at is not null)) from public.app_sessions where user_id='${actor}'`,
      );
      assert.equal(persisted.count, 1);
      assert.equal(persisted.revoked, true);
    } finally {
      await db.destroy();
    }
  },
);
