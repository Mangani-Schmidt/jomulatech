import { it, expect } from "vitest";
import { ScopedSnapshotCache } from "../lib/scoped-snapshot";
it("reuses only the same verified access scope and filter selection", () => {
  const cache = new ScopedSnapshotCache<string>();
  cache.setScope("actor-a:session-a:business-a:grants-a");
  cache.write(
    "actor-a:session-a:business-a:grants-a",
    "ZMW:2026-01",
    "private-a",
  );
  expect(
    cache.read("actor-a:session-a:business-a:grants-a", "ZMW:2026-01"),
  ).toBe("private-a");
  for (const other of [
    "actor-b:session-a:business-a:grants-a",
    "actor-a:session-b:business-a:grants-a",
    "actor-a:session-a:business-b:grants-a",
    "actor-a:session-a:business-a:grants-b",
  ])
    expect(cache.read(other, "ZMW:2026-01")).toBeNull();
  expect(
    cache.read("actor-a:session-a:business-a:grants-a", "USD:2026-01"),
  ).toBeNull();
});
it("clears sensitive snapshots on scope changes and rejects late writes from the old scope", () => {
  const cache = new ScopedSnapshotCache<string>();
  cache.setScope("a");
  cache.write("a", "selection", "private");
  cache.setScope("b");
  cache.write("a", "selection", "late-old-response");
  expect(cache.read("b", "selection")).toBeNull();
  cache.setScope("a");
  expect(cache.read("a", "selection")).toBeNull();
  cache.write("a", "selection", "private");
  cache.clear();
  cache.write("a", "selection", "late-after-logout");
  expect(cache.read("a", "selection")).toBeNull();
});
it("expires display snapshots and bounds selections without changing authoritative data", () => {
  let now = 1000;
  const cache = new ScopedSnapshotCache<number>(() => now);
  cache.setScope("a");
  cache.write("a", "selection", 29);
  now += 60001;
  expect(cache.read("a", "selection")).toBeNull();
  for (let i = 0; i < 7; i++) cache.write("a", String(i), i);
  expect(cache.read("a", "0")).toBeNull();
  expect(cache.read("a", "6")).toBe(6);
});
