import { PGlite } from "@electric-sql/pglite";
import { it, expect } from "vitest";
import { readFileSync } from "node:fs";
it("preserves legacy receipt amounts, reconstructs marked allocations, and keeps old write-off retries inert", async () => {
  const db = new PGlite();
  const owner = "11111111-1111-4111-8111-111111111111";
  const receiptRequest = "33333333-3333-4333-8333-333333333333",
    writeRequest = "44444444-4444-4444-8444-444444444444";
  try {
    await db.exec(
      `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;insert into auth.users values('${owner}');`,
    );
    for (const name of [
      "001_ledger",
      "002_client_register",
      "003_excel_import",
      "004_interest_settings",
      "005_loan_register",
    ])
      await db.exec(readFileSync(`supabase/migrations/${name}.sql`, "utf8"));
    await db.exec(
      `insert into public.account_permissions values('${owner}',true,true);select set_config('request.jwt.claim.sub','${owner}',false);set role authenticated`,
    );
    const {
      rows: [client],
    } = await db.query<{ id: string }>(
      "insert into public.clients(man_number,name,department,designation) values('00124','Legacy Client','Health','Nurse') returning id",
    );
    const {
      rows: [day],
    } = await db.query<{ date: string }>(
      "select to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD') as date",
    );
    const {
      rows: [loan],
    } = await db.query<{ id: string }>(
      "select public.originate_loan($1,gen_random_uuid(),true) as id",
      [
        JSON.stringify({
          client_id: client.id,
          principal_cents: 100000,
          rate_bps: 1000,
          term_days: 30,
          disbursement_date: day.date,
          settings_revision: 1,
          calculation_method: "one_time_flat",
          rate_basis: "entire_term",
          override_reason: "",
        }),
      ],
    );
    const {
      rows: [receipt],
    } = await db.query<{ id: string }>(
      "select public.record_repayment($1,15000,$2) as id",
      [loan.id, receiptRequest],
    );
    await db.query("select public.write_off_loan($1,95000,1,$2,$3,true)", [
      loan.id,
      "Approved historical write-off",
      writeRequest,
    ]);
    const before = (
      await db.query(
        "select id,loan_id,amount_cents,created_at from public.repayments",
      )
    ).rows;
    await db.exec("reset role");
    await db.exec(
      readFileSync("supabase/migrations/006_repayments.sql", "utf8"),
    );
    await db.exec("set role authenticated");
    expect(
      (
        await db.query(
          "select id,loan_id,amount_cents,created_at from public.repayments",
        )
      ).rows,
    ).toEqual(before);
    const {
      rows: [after],
    } = await db.query<any>("select * from public.repayments");
    expect(after.metadata_inferred).toBe(true);
    expect(Number(after.interest_allocation_cents)).toBe(10000);
    expect(Number(after.principal_allocation_cents)).toBe(5000);
    expect(after.payment_method).toBe("not_recorded");
    await db.query(
      "select public.reverse_write_off($1,$2,$3,gen_random_uuid(),true)",
      [loan.id, writeRequest, "Verified historical write-off mistake"],
    );
    await db.query("select public.write_off_loan($1,95000,1,$2,$3,true)", [
      loan.id,
      "Approved historical write-off",
      writeRequest,
    ]);
    const {
      rows: [active],
    } = await db.query<any>("select * from public.loan_register");
    expect(active.lifecycle_status).toBe("active");
    expect(Number(active.balance_cents)).toBe(95000);
    await db.query(
      "select public.reverse_repayment($1,$2,gen_random_uuid(),true)",
      [receipt.id, "Verified historical payment error"],
    );
    const {
      rows: [cached],
    } = await db.query<{ id: string }>(
      "select public.record_repayment($1,15000,$2) as id",
      [loan.id, receiptRequest],
    );
    expect(cached.id).toBe(receipt.id);
    const {
      rows: [total],
    } = await db.query<any>("select balance_cents from public.loan_register");
    expect(Number(total.balance_cents)).toBe(110000);
  } finally {
    await db.close();
  }
}, 30000);
