import { it, expect } from "vitest";
import { flatInterest, rateBps, dueDate } from "../lib/interest";
it("calculates flat interest with exact integer half-up rounding", () => {
  expect(flatInterest(100000, 1000)).toBe(10000);
  expect(flatInterest(1, 5000)).toBe(1);
  expect(flatInterest(99999999999, 10000)).toBe(99999999999);
  expect(flatInterest(100000, 0)).toBe(0);
});
it("converts percent to basis points and rejects unsupported terms", () => {
  expect(rateBps("12.34")).toBe(1234);
  expect(() => rateBps("100.01")).toThrow();
  expect(() => rateBps("1.001")).toThrow();
  expect(() => flatInterest(100, 100, "compound")).toThrow("Unsupported");
  expect(() => flatInterest(100, 100, "one_time_flat", "monthly")).toThrow(
    "Unsupported",
  );
});
it("uses disbursement plus term days without timezone drift", () => {
  expect(dueDate("2026-01-01", 30)).toBe("2026-01-31");
  expect(dueDate("2028-02-28", 2)).toBe("2028-03-01");
  expect(() => dueDate("2026-02-31", 30)).toThrow();
});
