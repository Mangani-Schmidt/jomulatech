import { PGlite } from "@electric-sql/pglite";
import { beforeAll, afterAll, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { buildReport, defaultReportFilters } from "../lib/reporting";
const db = new PGlite();
const owner = "11111111-1111-4111-8111-111111111111",
  other = "22222222-2222-4222-8222-222222222222";
let client: string, loanId: string, day: string;
async function scalar(sql: string, args: unknown[] = []): Promise<any> {
  const { rows } = await db.query<Record<string, any>>(sql, args);
  return Object.values(rows[0])[0];
}
async function user(id: string) {
  await db.exec(
    `reset role;select set_config('request.jwt.claim.sub','${id}',false);set role authenticated`,
  );
}
beforeAll(async () => {
  await db.exec(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;insert into auth.users values('${owner}'),('${other}');`,
  );
  for (const name of [
    "001_ledger",
    "002_client_register",
    "003_excel_import",
    "004_interest_settings",
    "005_loan_register",
    "006_repayments",
    "007_reporting",
  ])
    await db.exec(readFileSync(`supabase/migrations/${name}.sql`, "utf8"));
  await user(owner);
  day = await scalar(
    "select to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD')",
  );
  client = await scalar(
    "insert into public.clients(man_number,name,department,designation) values('00124','Mary Tembo','Health','Nurse') returning id",
  );
  loanId = await scalar(
    "select public.originate_loan($1,gen_random_uuid(),true)",
    [
      JSON.stringify({
        client_id: client,
        principal_cents: 100000,
        rate_bps: 1000,
        term_days: 30,
        disbursement_date: day,
        settings_revision: 1,
        calculation_method: "one_time_flat",
        rate_basis: "entire_term",
        override_reason: "",
      }),
    ],
  );
}, 30000);
afterAll(() => db.close());

it("returns all reporting sources in one owned PostgreSQL snapshot", async () => {
  const source = await scalar("select public.report_source()");
  expect(source.clients.map((c: any) => c.id)).toEqual([client]);
  expect(source.loans[0].id).toBe(loanId);
  expect(source.terms_audit[0].action).toBe("originate");
  const r = buildReport(source, defaultReportFilters(day));
  expect(r.totals.disbursed).toBe(100000);
  expect(r.totals.interest).toBe(10000);
});
it("reconciles actual posting, reversal and adjustment snapshots with the report engine", async () => {
  const l = await scalar(
    "select to_jsonb(l) from public.loan_register l where id=$1",
    [loanId],
  );
  const posted = await scalar(
    "select public.post_repayment($1,gen_random_uuid(),true)",
    [
      JSON.stringify({
        loan_id: loanId,
        amount_cents: 15000,
        payment_date: day,
        payment_method: "cash",
        expected_balance_cents: l.balance_cents,
        expected_terms_revision: l.terms_revision,
        expected_interest_outstanding_cents: l.interest_outstanding_cents,
        expected_principal_outstanding_cents: l.principal_outstanding_cents,
      }),
    ],
  );
  let source = await scalar("select public.report_source()");
  expect(buildReport(source, defaultReportFilters(day)).totals).toMatchObject({
    received: 15000,
    interestReceived: 10000,
    principalReceived: 5000,
    principal: 95000,
    interest: 0,
    owed: 95000,
  });
  await db.exec(
    `reset role;insert into public.account_permissions values('${owner}',true,true);set role authenticated`,
  );
  await scalar(
    "select public.reverse_repayment($1,'Verified incorrect receipt',gen_random_uuid(),true)",
    [posted.repayment_id],
  );
  await scalar(
    "select public.adjust_loan_terms($1,1500,60,1,'Approved loan rate adjustment',gen_random_uuid(),true)",
    [loanId],
  );
  source = await scalar("select public.report_source()");
  expect(source.repayment_audit).toHaveLength(2);
  expect(buildReport(source, defaultReportFilters(day)).totals).toMatchObject({
    received: 0,
    interestReceived: 0,
    principal: 100000,
    interest: 15000,
    owed: 115000,
    interestAdjusted: 5000,
  });
  await scalar(
    "select public.write_off_loan($1,115000,2,'Approved unrecoverable principal',gen_random_uuid(),true)",
    [loanId],
  );
  source = await scalar("select public.report_source()");
  expect(buildReport(source, defaultReportFilters(day)).totals).toMatchObject({
    recognizedLoss: 100000,
    writtenOff: 115000,
    collectible: 0,
  });
});
it("keeps every source array private under RLS and denies anonymous execution", async () => {
  await user(other);
  const source = await scalar("select public.report_source()");
  for (const key of [
    "clients",
    "loans",
    "repayments",
    "terms_audit",
    "status_audit",
    "repayment_audit",
  ])
    expect(source[key]).toEqual([]);
  await db.exec("reset role;set role anon");
  await expect(scalar("select public.report_source()")).rejects.toThrow(
    "permission denied",
  );
});
