import { hasCapability } from "../lib/access";
import { PGlite } from "@electric-sql/pglite";
import { beforeAll, afterAll, beforeEach, afterEach, it, expect } from "vitest";
import { readFileSync, readdirSync } from "node:fs";
import { randomUUID } from "node:crypto";
import ExcelJS from "exceljs";
import { readWorkbook, mappedRows } from "../lib/import-server";
import { buildReport, defaultReportFilters } from "../lib/reporting";
const db = new PGlite();
const users = {
  admin: "11111111-1111-4111-8111-111111111111",
  officer: "22222222-2222-4222-8222-222222222222",
  cashier: "33333333-3333-4333-8333-333333333333",
  viewer: "44444444-4444-4444-8444-444444444444",
  foreign: "55555555-5555-4555-8555-555555555555",
};
let client: string, day: string;
// Each case rolls back a fictional ledger. Savepoints give expected failures
// the same rollback boundary as separate PostgREST RPC transactions.
async function query(sql: string, args: unknown[] = []) {
  await db.exec("savepoint fixture_statement");
  try {
    const result = await db.query<Record<string, any>>(sql, args);
    await db.exec("release savepoint fixture_statement");
    return result;
  } catch (e) {
    await db.exec(
      "rollback to savepoint fixture_statement;release savepoint fixture_statement",
    );
    throw e;
  }
}
async function scalar(sql: string, args: unknown[] = []): Promise<any> {
  const r = await query(sql, args);
  return Object.values(r.rows[0])[0];
}
async function actor(id: string) {
  await db.exec(
    `reset role;insert into auth.users values('${id}') on conflict do nothing;select set_config('request.jwt.claim.sub','${id}',true);select set_config('request.jwt.claims','{"session_id":"${id}"}',true);set local role authenticated;select public.touch_app_session()`,
  );
}
const row = (extra: Record<string, unknown> = {}) => ({
  source_no: "1",
  name: "Fictional Client Alpha",
  man_number: "000042",
  department: "Fictional Department",
  designation: "Fictional Designation",
  amount: "1000.00",
  man_numeric: false,
  parse_errors: [],
  ...extra,
});
async function defaults() {
  return scalar("select public.loan_defaults()");
}
async function loan(extra: Record<string, unknown> = {}) {
  const d = await defaults();
  return scalar("select public.originate_loan($1,gen_random_uuid(),true)", [
    JSON.stringify({
      client_id: client,
      expected_client_revision: await scalar(
        "select revision from public.clients where id=$1",
        [client],
      ),
      principal_cents: 100000,
      rate_bps: d.settings.default_rate_bps,
      term_days: 30,
      disbursement_date: day,
      settings_revision: d.settings.revision,
      calculation_method: "one_time_flat",
      rate_basis: "entire_term",
      override_reason: "",
      ...extra,
    }),
  ]);
}
async function preview(
  rows: unknown[],
  mode = "clients",
  terms: Record<string, unknown> = {},
  filename = "fictional.xlsx",
) {
  return scalar("select public.preview_import($1,$2,$3,$4,$5)", [
    filename,
    "a".repeat(64),
    mode,
    JSON.stringify(terms),
    JSON.stringify(rows),
  ]);
}
const terms = () => ({
  disbursement_date: day,
  interest_type: "flat_percent",
  interest_value: "10",
  due_rule: "days_after_disbursement",
  term_days: 30,
  settings_revision: 1,
  calculation_method: "one_time_flat",
  rate_basis: "entire_term",
});
async function getLoan(id: string) {
  return scalar("select to_jsonb(l) from public.loan_register l where id=$1", [
    id,
  ]);
}
async function paymentDetails(
  id: string,
  amount: number,
  extra: Record<string, unknown> = {},
) {
  const l = await getLoan(id);
  return {
    loan_id: id,
    amount_cents: amount,
    payment_date: day,
    payment_method: "cash",
    expected_balance_cents: l.balance_cents,
    expected_terms_revision: l.terms_revision,
    expected_interest_outstanding_cents: l.interest_outstanding_cents,
    expected_principal_outstanding_cents: l.principal_outstanding_cents,
    ...extra,
  };
}
beforeAll(async () => {
  await db.exec(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`,
  );
  for (const name of readdirSync("supabase/migrations").sort())
    await db.exec(readFileSync("supabase/migrations/" + name, "utf8"));
  for (const id of Object.values(users))
    await db.query("insert into auth.users values($1)", [id]);
  await db.exec(
    `insert into public.businesses(id,name) values('${users.admin}','Fictional Test Business'),('${users.foreign}','Fictional Other Business');insert into public.ledger_settings(owner_id) values('${users.admin}'),('${users.foreign}');insert into public.user_roles(user_id,owner_id,role) values('${users.admin}','${users.admin}','administrator'),('${users.officer}','${users.admin}','loan_officer'),('${users.cashier}','${users.admin}','cashier'),('${users.viewer}','${users.admin}','viewer'),('${users.foreign}','${users.foreign}','administrator');`,
  );
}, 30000);
beforeEach(async () => {
  await db.exec("begin");
  await actor(users.admin);
  day = await scalar(
    "select to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD')",
  );
  client = await scalar(
    "insert into public.clients(man_number,name,department,designation,email) values('000042','Fictional Client Alpha','Fictional Department','Fictional Designation','alpha@example.test') returning id",
  );
});
afterEach(() => db.exec("rollback"));
afterAll(() => db.close());
it("latest-schema registration preserves text Man# and prevents duplicates and history breakage", async () => {
  await actor(users.officer);
  expect(
    await scalar("select man_number from public.clients where id=$1", [client]),
  ).toBe("000042");
  await expect(
    query(
      "insert into public.clients(man_number,name,department,designation) values(' 000042 ','Fictional Duplicate','Fictional Department','Fictional Designation')",
    ),
  ).rejects.toThrow("unique");
  const id = await loan();
  await scalar("select public.correct_client($1,$2,$3,1)", [
    client,
    JSON.stringify({
      ...row(),
      man_number: "000099",
      source_no: undefined,
      amount: undefined,
      man_numeric: undefined,
      parse_errors: undefined,
      phone: "",
      email: "alpha@example.test",
      address: "",
      is_active: true,
    }),
    "Verified fictional Man# correction",
  ]);
  expect((await getLoan(id)).client_id).toBe(client);
  expect(
    await scalar("select man_number from public.clients where id=$1", [client]),
  ).toBe("000099");
  expect(
    Number(
      await scalar(
        "select count(*) from public.client_audit where client_id=$1",
        [client],
      ),
    ),
  ).toBe(2);
});
it("maps a real XLSX into latest-schema diagnostics and repeats its register import without loans or overwrites", async () => {
  await query(
    "insert into public.clients(man_number,name,department,designation) values('000043','Fictional Client Beta','Fictional Department','Fictional Designation')",
  );
  const wb = new ExcelJS.Workbook(),
    sheet = wb.addWorksheet("Fictional register");
  sheet.addRow(["VALUE", "EMPLOYEE", "FULL NAME", "UNIT", "ROLE", "ROW"]);
  for (const values of [
    [
      "ignored",
      "000042",
      "Fictional Client Alpha",
      "Fictional Department",
      "Fictional Designation",
      1,
    ],
    [
      "not money",
      "000044",
      "Fictional Client Gamma",
      "Fictional Department",
      "Fictional Designation",
      2,
    ],
    [
      10,
      "000043",
      "Conflicting Fictional Name",
      "Fictional Department",
      "Fictional Designation",
      3,
    ],
    [
      10,
      "000045",
      "Fictional Duplicate One",
      "Fictional Department",
      "Fictional Designation",
      4,
    ],
    [
      10,
      "000045",
      "Fictional Duplicate Two",
      "Fictional Department",
      "Fictional Designation",
      5,
    ],
    [10, "000046", "Fictional Invalid Row", "", "Fictional Designation", 6],
  ])
    sheet.addRow(values);
  const parsed = await readWorkbook(
    new File([await wb.xlsx.writeBuffer()], "fictional-register.xlsx"),
  );
  const rows = mappedRows(parsed.sheet, {
    amount: 1,
    man_number: 2,
    name: 3,
    department: 4,
    designation: 5,
    source_no: 6,
  });
  expect(rows[0].man_number).toBe("000042");
  const id = await preview(rows);
  const report = await scalar("select public.import_report($1)", [id]);
  expect(report.batch).toMatchObject({
    accepted: 1,
    rejected: 4,
    unchanged: 1,
  });
  expect(Number(await scalar("select count(*) from public.clients"))).toBe(2);
  await scalar("select public.commit_import($1,1,true)", [id]);
  expect(Number(await scalar("select count(*) from public.clients"))).toBe(3);
  expect(Number(await scalar("select count(*) from public.loans"))).toBe(0);
  expect(
    await scalar("select name from public.clients where man_number='000043'"),
  ).toBe("Fictional Client Beta");
  const repeated = await preview(
    [...rows]
      .reverse()
      .map((r, i) => ({ ...r, source_no: String(i + 20), amount: "999999" })),
    "clients",
    {},
    "renamed-fictional.xlsx",
  );
  expect(repeated).toBe(id);
  await scalar("select public.commit_import($1,1,true)", [id]);
  expect(Number(await scalar("select count(*) from public.client_audit"))).toBe(
    3,
  );
});
it("the downloadable dummy workbook imports ten text-Man# Clients and ten reviewed loans exactly once", async () => {
  const bytes = new Uint8Array(
    readFileSync("public/samples/lendtrack-dummy-clients.xlsx"),
  );
  const parsed = await readWorkbook(
    new File([bytes], "lendtrack-dummy-clients.xlsx"),
  );
  const rows = mappedRows(parsed.sheet, parsed.inspection.mapping, "clients");
  const register = await preview(rows, "clients");
  await scalar("select public.commit_import($1,1,true)", [register]);
  expect(Number(await scalar("select count(*) from public.clients"))).toBe(11);
  expect(Number(await scalar("select count(*) from public.loans"))).toBe(0);
  expect(
    await scalar(
      "select man_number from public.clients where man_number='009001'",
    ),
  ).toBe("009001");
  const loans = await preview(rows, "loans", terms());
  expect(Number(await scalar("select count(*) from public.loans"))).toBe(0);
  await scalar("select public.commit_import($1,1,true)", [loans]);
  await scalar("select public.commit_import($1,1,true)", [loans]);
  expect(Number(await scalar("select count(*) from public.loans"))).toBe(10);
  expect(
    Number(await scalar("select sum(principal_cents) from public.loans")),
  ).toBe(2125000);
  expect(
    Number(await scalar("select sum(interest_cents) from public.loans")),
  ).toBe(212500);
  expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
    0,
  );
});
it.each([
  "disbursement_date",
  "interest_type",
  "interest_value",
  "due_rule",
  "term_days",
  "calculation_method",
  "rate_basis",
  "settings_revision",
])(
  "latest loan imports require %s with no financial or Client side effects",
  async (field) => {
    const missing: Record<string, unknown> = { ...terms() };
    delete missing[field];
    await expect(
      preview(
        [row({ man_number: "000044", name: "Fictional New Client" })],
        "loans",
        missing,
      ),
    ).rejects.toThrow();
    expect(Number(await scalar("select count(*) from public.clients"))).toBe(1);
    expect(Number(await scalar("select count(*) from public.loans"))).toBe(0);
    expect(
      Number(await scalar("select count(*) from public.import_batches")),
    ).toBe(0);
  },
);
it("latest loan import creates disbursements only after confirmation and deduplicates reordered formatted rows", async () => {
  const rows = [
    row({ amount: "1000.04" }),
    row({
      source_no: "2",
      man_number: "000044",
      name: "Fictional Client Gamma",
      amount: "50.00",
    }),
  ];
  const id = await preview(rows, "loans", terms());
  await expect(
    scalar("select public.commit_import($1,1,false)", [id]),
  ).rejects.toThrow("confirmation");
  expect(Number(await scalar("select count(*) from public.loans"))).toBe(0);
  expect(Number(await scalar("select count(*) from public.clients"))).toBe(1);
  await scalar("select public.commit_import($1,1,true)", [id]);
  expect(Number(await scalar("select count(*) from public.loans"))).toBe(2);
  expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
    0,
  );
  const amounts = await scalar(
    "select jsonb_agg(jsonb_build_object('principal',principal_cents,'interest',interest_cents) order by principal_cents) from public.loans",
  );
  expect(amounts).toEqual([
    { principal: 5000, interest: 500 },
    { principal: 100004, interest: 10000 },
  ]);
  const again = await preview(
    [...rows].reverse().map((r, i) => ({
      ...r,
      source_no: String(i + 10),
      amount: r.amount === "50.00" ? "050.0" : "01000.04",
    })),
    "loans",
    { ...terms(), interest_value: "10.00" },
    "fictional-copy.xlsx",
  );
  expect(again).toBe(id);
  await scalar("select public.commit_import($1,1,true)", [again]);
  expect(Number(await scalar("select count(*) from public.loans"))).toBe(2);
});
it("latest settings changes affect future loans only and round a half-ngwee correctly", async () => {
  const old = await loan(),
    before = await getLoan(old),
    d = await defaults();
  await scalar("select public.save_interest_settings($1,1,$2)", [
    JSON.stringify({ ...d.settings, default_rate_bps: 1250 }),
    "Approved fictional future default rate",
  ]);
  expect(await getLoan(old)).toEqual(before);
  const next = await loan({ principal_cents: 10004 });
  expect(await getLoan(next)).toMatchObject({
    principal_cents: 10004,
    interest_rate_bps: 1250,
    interest_cents: 1251,
    total_obligation_cents: 11255,
    settings_revision: 2,
  });
});
it("latest partial payment, settlement, reversal and duplicate retries reconcile both allocation buckets", async () => {
  const id = await loan();
  await actor(users.cashier);
  const details = await paymentDetails(id, 15000),
    key = randomUUID();
  const first = await scalar("select public.post_repayment($1,$2,true)", [
    JSON.stringify(details),
    key,
  ]);
  expect(
    await scalar("select public.post_repayment($1,$2,true)", [
      JSON.stringify(details),
      key,
    ]),
  ).toEqual(first);
  expect(await getLoan(id)).toMatchObject({
    balance_cents: 95000,
    principal_outstanding_cents: 95000,
    interest_outstanding_cents: 0,
  });
  await scalar("select public.post_repayment($1,gen_random_uuid(),true)", [
    JSON.stringify(await paymentDetails(id, 95000)),
  ]);
  expect((await getLoan(id)).status).toBe("settled");
  await actor(users.admin);
  const reversal = randomUUID();
  await scalar("select public.reverse_repayment($1,$2,$3,true)", [
    first.repayment_id,
    "Approved fictional receipt reversal",
    reversal,
  ]);
  await scalar("select public.reverse_repayment($1,$2,$3,true)", [
    first.repayment_id,
    "Approved fictional receipt reversal",
    reversal,
  ]);
  expect(await getLoan(id)).toMatchObject({
    balance_cents: 15000,
    principal_outstanding_cents: 5000,
    interest_outstanding_cents: 10000,
  });
  expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
    2,
  );
});
it("historical filters reconstruct actual dated receipts, later reversals and term changes from the latest snapshot", async () => {
  const id = await loan({ disbursement_date: "2020-01-01" });
  await actor(users.cashier);
  const payment = await scalar(
    "select public.post_repayment($1,gen_random_uuid(),true)",
    [
      JSON.stringify(
        await paymentDetails(id, 15000, { payment_date: "2020-01-10" }),
      ),
    ],
  );
  await actor(users.admin);
  await scalar(
    "select public.reverse_repayment($1,$2,gen_random_uuid(),true)",
    [payment.repayment_id, "Approved fictional later reversal"],
  );
  await scalar(
    "select public.adjust_loan_terms($1,2000,30,1,$2,gen_random_uuid(),true)",
    [id, "Approved fictional later rate adjustment"],
  );
  const source = await scalar("select public.report_source()");
  const old = buildReport(source, {
    ...defaultReportFilters(day),
    from: "2020-01-01",
    to: "2020-01-31",
    asOf: "2020-01-31",
  });
  expect(old.totals).toMatchObject({
    disbursed: 100000,
    received: 15000,
    interestReceived: 10000,
    principal: 95000,
    interest: 0,
    owed: 95000,
  });
  expect(old.loans[0].status).toBe("Active");
  const today = buildReport(source, {
    ...defaultReportFilters(day),
    from: day,
    to: day,
    asOf: day,
  });
  expect(today.totals).toMatchObject({
    received: -15000,
    interestReceived: -10000,
    interestAdjusted: 10000,
    principal: 100000,
    interest: 20000,
    owed: 120000,
  });
  expect((await getLoan(id)).balance_cents).toBe(today.totals.owed);
});
it("latest RLS remains active for staff and prevents cross-business and direct financial writes", async () => {
  await loan();
  await actor(users.viewer);
  expect(await scalar("select row_security_active('public.loans')")).toBe(true);
  await expect(
    query("update public.loans set balance_cents=0"),
  ).rejects.toThrow("permission denied");
  await expect(
    query("update public.user_roles set role='administrator'"),
  ).rejects.toThrow("permission denied");
  await actor(users.foreign);
  const source = await scalar("select public.report_source()");
  expect(source.clients).toEqual([]);
  expect(source.loans).toEqual([]);
  expect(source.repayments).toEqual([]);
  expect(source.expenses).toEqual([]);
});

it("UI capability flags match the final database policy for every staff role and fail closed for unassigned identities", async () => {
  const actions = {
    can_read: "read",
    is_admin: "admin",
    can_override_rate: "admin",
    can_register_clients: "clients",
    can_originate: "originate",
    can_post_repayments: "repayments",
    can_import: "imports",
    can_manage_expenses: "expenses",
  } as const;
  for (const id of [users.admin, users.officer, users.cashier, users.viewer]) {
    await actor(id);
    const actual = await defaults();
    for (const key of Object.keys(actions) as (keyof typeof actions)[]) {
      const databaseDecision = await scalar(
        "select public.has_capability($1)",
        [actions[key]],
      );
      expect(hasCapability(actual.capabilities, key), `${id}: ${key}`).toBe(
        databaseDecision,
      );
    }
  }
  await actor(randomUUID());
  expect(await scalar("select public.has_capability('read')")).toBe(false);
  await expect(defaults()).rejects.toThrow("Permission denied");
});

it("an authorized per-loan rate override snapshots and audits its terms without changing Settings or later rewriting loan history", async () => {
  const original = await defaults();
  const id = await loan({
    rate_bps: 1250,
    override_reason: "Approved fictional per-loan exception",
  });
  const actual = await getLoan(id);
  expect(actual).toMatchObject({
    interest_rate_bps: 1250,
    default_rate_bps_at_origination: 1000,
    settings_revision: 1,
    rate_override_reason: "Approved fictional per-loan exception",
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    interest_cents: 12500,
    total_obligation_cents: 112500,
  });
  expect(await defaults()).toEqual(original);
  expect(
    await scalar("select count(*)::integer from public.settings_audit"),
  ).toBe(0);
  const audit = await scalar(
    "select to_jsonb(a) from public.loan_terms_audit a where loan_id=$1 and action='originate'",
    [id],
  );
  expect(audit.after_data).toMatchObject({
    interest_rate_bps: 1250,
    default_rate_bps_at_origination: 1000,
    rate_override_reason: "Approved fictional per-loan exception",
  });
  await scalar("select public.save_interest_settings($1,1,$2)", [
    JSON.stringify({ ...original.settings, default_rate_bps: 2000 }),
    "Approved fictional future default",
  ]);
  const future = await loan();
  expect(await getLoan(future)).toMatchObject({
    interest_rate_bps: 2000,
    default_rate_bps_at_origination: 2000,
    settings_revision: 2,
    interest_cents: 20000,
  });
  expect(await getLoan(id)).toEqual(actual);
});
it("the final schema denies an unauthorized per-loan rate and stale rate terms without creating a loan", async () => {
  await actor(users.officer);
  await expect(
    loan({
      rate_bps: 1250,
      override_reason: "Fictional unauthorized override attempt",
    }),
  ).rejects.toThrow("override permission");
  await actor(users.admin);
  const d = await defaults();
  await scalar("select public.save_interest_settings($1,1,$2)", [
    JSON.stringify({ ...d.settings, default_rate_bps: 1500 }),
    "Approved fictional changed default",
  ]);
  await expect(
    loan({
      rate_bps: 1000,
      settings_revision: 1,
      override_reason: "Fictional stale review",
    }),
  ).rejects.toThrow("Defaults changed");
  expect(await scalar("select count(*)::integer from public.loans")).toBe(0);
});

it("manual text Man# uses case-insensitive business uniqueness, literal lookup and stable internal relationships on conflicting corrections", async () => {
  const original = await scalar(
    "select to_jsonb(c) from public.clients c where id=$1",
    [client],
  );
  const loanId = await loan();
  const other = await scalar(
    "insert into public.clients(man_number,name,department,designation) values($1,'Fictional Assigned Client','Fictional Department','Fictional Designation') returning id",
    ["00_Ab%*\\01"],
  );
  expect(
    await scalar("select public.find_client_by_man($1)->>'id'", [
      " 00_ab%*\\01 ",
    ]),
  ).toBe(other);
  await expect(
    query(
      "insert into public.clients(man_number,name,department,designation) values($1,'Fictional Duplicate','Fictional Department','Fictional Designation')",
      ["00_AB%*\\01"],
    ),
  ).rejects.toThrow("unique");
  await expect(
    scalar("select public.correct_client($1,$2,$3,1)", [
      client,
      JSON.stringify({
        ...original,
        id: undefined,
        owner_id: undefined,
        created_by: undefined,
        created_at: undefined,
        updated_at: undefined,
        revision: undefined,
        man_number: "00_AB%*\\01",
      }),
      "Fictional conflicting identity correction",
    ]),
  ).rejects.toThrow("unique");
  expect(
    await scalar("select to_jsonb(c) from public.clients c where id=$1", [
      client,
    ]),
  ).toEqual(original);
  expect((await getLoan(loanId)).client_id).toBe(client);
  await actor(users.viewer);
  expect(
    await scalar("select public.find_client_by_man($1)->>'id'", [
      " 00_ab%*\\01 ",
    ]),
  ).toBe(other);
  await actor(users.foreign);
  expect(
    await scalar("select public.find_client_by_man($1)", ["00_ab%*\\01"]),
  ).toBeNull();
});

it("exact Man# lookup has restricted execution, denies inactive membership and validates on the server", async () => {
  expect(
    await scalar(
      "select has_function_privilege('anon','public.find_client_by_man(text)','execute')",
    ),
  ).toBe(false);
  expect(
    await scalar(
      "select prosecdef from pg_proc where oid='public.find_client_by_man(text)'::regprocedure",
    ),
  ).toBe(false);
  expect(
    await scalar("select public.find_client_by_man('000042')->>'id'"),
  ).toBe(client);
  for (const value of ["42", "00004_", "00004%", "*42", "00_ab%*\\02"])
    expect(
      await scalar("select public.find_client_by_man($1)", [value]),
    ).toBeNull();
  for (const value of [null, " ", "x".repeat(51), "00\t1"])
    await expect(
      scalar("select public.find_client_by_man($1)", [value]),
    ).rejects.toThrow("1–50");
  await db.exec("reset role");
  await db.query(
    "update public.user_roles set is_active=false where user_id=$1",
    [users.viewer],
  );
  await actor(users.viewer);
  await expect(
    scalar("select public.find_client_by_man('000042')"),
  ).rejects.toThrow("Permission denied");
});

it("role presets and explicit module capabilities preserve the prior role grants", async () => {
  const { rolePermissions, permissionFlags } =
    await import("../lib/permissions");
  for (const [id, role] of [
    [users.admin, "administrator"],
    [users.officer, "loan_officer"],
    [users.cashier, "cashier"],
    [users.viewer, "viewer"],
  ] as const) {
    await actor(id);
    expect(
      await scalar(
        "select permissions from public.user_roles where user_id=auth.uid()",
      ),
    ).toEqual(rolePermissions(role));
    const caps = (await defaults()).capabilities;
    for (const [flag, key] of Object.entries(permissionFlags))
      expect(caps[flag], flag).toBe(
        await scalar("select public.has_capability($1)", [key]),
      );
  }
});
it("restricts data/RPCs independently of module navigation and never treats denied finance as zero", async () => {
  const { rolePermissions } = await import("../lib/permissions");
  const p = Object.fromEntries(
    Object.keys(rolePermissions("viewer")).map((k) => [k, false]),
  );
  p.view_clients = true;
  await scalar(
    "select public.manage_user_access($1,'viewer',true,$2,1,'Approved fictional Client register only',gen_random_uuid(),true)",
    [users.viewer, JSON.stringify(p)],
  );
  await actor(users.viewer);
  expect(await scalar("select count(*)::int from public.clients")).toBe(1);
  expect(await scalar("select count(*)::int from public.loans")).toBe(0);
  await expect(scalar("select public.report_source()")).rejects.toThrow(
    "Reporting access",
  );
  await expect(
    scalar("select public.client_statement($1)", [client]),
  ).rejects.toThrow("Permission denied");
  await expect(
    scalar("select public.correct_client($1,$2,'Unauthorized edit',1)", [
      client,
      JSON.stringify({}),
    ]),
  ).rejects.toThrow("Permission denied");
  const caps = (await defaults()).capabilities;
  expect(caps.can_view_clients).toBe(true);
  expect(caps.can_view_dashboard).toBe(false);
  expect(caps.can_register_clients).toBe(false);
  expect(await scalar("select public.reporting_revision()")).toBeNull();
});
it("audits membership creation and permission changes, rejects stale edits and duplicate submissions", async () => {
  const { rolePermissions } = await import("../lib/permissions");
  const fresh = randomUUID();
  await db.exec("reset role");
  await db.query("insert into auth.users values($1)", [fresh]);
  await actor(users.admin);
  const p = rolePermissions("viewer"),
    key = randomUUID();
  const args = [fresh, JSON.stringify(p), key];
  const sql =
    "select public.manage_user_access($1,'viewer',true,$2,0,'Approved fictional new business user',$3,true)";
  const added = await scalar(sql, args);
  expect(added.permissions).toEqual(p);
  expect(await scalar(sql, args)).toEqual(added);
  expect(
    await scalar(
      "select count(*)::int from public.audit_events where entity_id=$1 and source_table='user_roles'",
      [fresh],
    ),
  ).toBe(1);
  const restricted = { ...p, view_reports: false, export_reports: false };
  await scalar(
    "select public.manage_user_access($1,'viewer',true,$2,1,'Approved fictional report restriction',gen_random_uuid(),true)",
    [fresh, JSON.stringify(restricted)],
  );
  expect(
    await scalar(
      "select after_data->'permissions' from public.audit_events where entity_id=$1 order by created_at desc limit 1",
      [fresh],
    ),
  ).toEqual(restricted);
  await expect(
    scalar(
      "select public.manage_user_access($1,'viewer',true,$2,1,'Fictional stale overwrite',gen_random_uuid(),true)",
      [fresh, JSON.stringify(p)],
    ),
  ).rejects.toThrow("Permissions changed");
});
it("prevents self-removal, role escalation, unauthorized user management and unknown grants", async () => {
  const { rolePermissions } = await import("../lib/permissions");
  await expect(
    scalar(
      "select public.manage_user_access($1,'administrator',true,$2,1,'Fictional self lockout',gen_random_uuid(),true)",
      [
        users.admin,
        JSON.stringify({ ...rolePermissions("administrator"), users: false }),
      ],
    ),
  ).rejects.toThrow("own Administrator");
  await expect(
    scalar(
      "select public.manage_user_access($1,'viewer',true,$2,1,'Fictional invalid grant',gen_random_uuid(),true)",
      [
        users.viewer,
        JSON.stringify({ ...rolePermissions("viewer"), users: true }),
      ],
    ),
  ).rejects.toThrow("eligible business role");
  await expect(
    scalar(
      "select public.manage_user_access($1,'viewer',true,$2,1,'Fictional unsupported key',gen_random_uuid(),true)",
      [
        users.viewer,
        JSON.stringify({ ...rolePermissions("viewer"), erase_ledger: true }),
      ],
    ),
  ).rejects.toThrow("every supported");
  await actor(users.officer);
  await expect(
    scalar(
      "select public.manage_user_role($1,'administrator',true,1,'Fictional unauthorized promotion',gen_random_uuid(),true)",
      [users.officer],
    ),
  ).rejects.toThrow("Permission denied");
});
it("an Administrator's role does not bypass explicitly disabled sensitive actions or Audit Logs", async () => {
  await db.exec("reset role");
  await db.query(
    'update public.user_roles set permissions=permissions||\'{"adjustments":false,"view_audit":false,"settings":false}\' where user_id=$1',
    [users.admin],
  );
  await actor(users.admin);
  expect(await scalar("select public.has_capability('admin')")).toBe(true);
  expect(await scalar("select public.has_capability('adjustments')")).toBe(
    false,
  );
  expect(await scalar("select count(*)::int from public.audit_events")).toBe(0);
  await expect(
    scalar(
      "select public.adjust_loan_terms(gen_random_uuid(),1000,30,1,'Fictional denied adjustment',gen_random_uuid(),true)",
    ),
  ).rejects.toThrow("Permission denied");
  await expect(
    scalar(
      "select public.posting_request_status(gen_random_uuid(),'correct_repayment')",
    ),
  ).rejects.toThrow("Permission denied");
  const d = await defaults();
  await expect(
    scalar(
      "select public.save_interest_settings($1,1,'Fictional denied Settings')",
      [JSON.stringify(d.settings)],
    ),
  ).rejects.toThrow("Permission denied");
  await db.exec("reset role");
  await db.query(
    `update public.user_roles set permissions=permissions||'{"adjustments":true,"view_repayments":false}' where user_id=$1`,
    [users.admin],
  );
  await actor(users.admin);
  await expect(
    scalar(
      "select public.posting_request_status(gen_random_uuid(),'correct_repayment')",
    ),
  ).rejects.toThrow("Permission denied");
});
it("server inactivity denies direct reads/posts and an expired Auth session cannot be revived", async () => {
  await db.exec("reset role");
  await db.query(
    "update public.app_sessions set last_activity_at=clock_timestamp()-interval '15 minutes 1 second' where session_id=$1",
    [users.admin],
  );
  await db.exec("set local role authenticated");
  expect(await scalar("select public.app_session_active()")).toBe(false);
  expect(await scalar("select public.current_ledger_id()")).toBeNull();
  expect(await scalar("select count(*)::int from public.clients")).toBe(0);
  await expect(scalar("select public.loan_defaults()")).rejects.toThrow(
    "inactivity",
  );
  expect((await scalar("select public.touch_app_session()")).active).toBe(
    false,
  );
  expect(await scalar("select public.has_capability('read')")).toBe(false);
  await db.exec("reset role");
  const next = randomUUID();
  await db.query("select set_config('request.jwt.claims',$1,true)", [
    JSON.stringify({ session_id: next }),
  ]);
  await db.exec("set local role authenticated");
  expect((await scalar("select public.touch_app_session()")).active).toBe(true);
  expect(await scalar("select public.has_capability('read')")).toBe(true);
});
it("explicit session end rejects still-signed JWT claims, missing session IDs, direct session mutation and anonymous execution", async () => {
  await scalar("select public.end_app_session('inactive')");
  expect(await scalar("select public.app_session_active()")).toBe(false);
  expect((await scalar("select public.touch_app_session()")).active).toBe(
    false,
  );
  await expect(
    query("update public.app_sessions set revoked_at=null"),
  ).rejects.toThrow("permission denied");
  expect(
    await scalar(
      "select has_function_privilege('anon','public.touch_app_session()','execute')",
    ),
  ).toBe(false);
  await scalar("select set_config('request.jwt.claims','{}',true)");
  await expect(scalar("select public.touch_app_session()")).rejects.toThrow(
    "verified Supabase",
  );
});

it("delegates Client imports without granting manual registration or loan origination", async () => {
  const { rolePermissions } = await import("../lib/permissions");
  await scalar(
    "select public.manage_user_access($1,'viewer',true,$2,1,'Approved delegated Client imports',gen_random_uuid(),true)",
    [
      users.viewer,
      JSON.stringify({
        ...rolePermissions("viewer"),
        imports: true,
        view_imports: true,
      }),
    ],
  );
  await actor(users.viewer);
  expect(await scalar("select public.has_capability('imports')")).toBe(true);
  expect((await defaults()).capabilities.can_import).toBe(true);
  expect(await scalar("select public.has_capability('clients')")).toBe(false);
  const batch = await preview([
    row({ man_number: "000099", name: "Fictional imported Client" }),
  ]);
  expect(await scalar("select count(*)::int from public.clients")).toBe(1);
  expect(await scalar("select count(*)::int from public.loans")).toBe(0);
  await scalar("select public.commit_import($1,1,true)", [batch]);
  await scalar("select public.commit_import($1,1,true)", [batch]);
  expect(await scalar("select count(*)::int from public.clients")).toBe(2);
  expect(await scalar("select count(*)::int from public.loans")).toBe(0);
  await expect(preview([row()], "loans", terms())).rejects.toThrow(
    "Permission denied",
  );
  await expect(
    scalar(
      "insert into public.clients(man_number,name,department,designation) values('0099','Denied Client','Finance','Analyst') returning id",
    ),
  ).rejects.toThrow();
});
it("deletes only an explicitly authorized unlinked Client and retains immutable audit identity", async () => {
  const { rolePermissions } = await import("../lib/permissions");
  await expect(
    scalar(
      "select public.delete_client($1,1,'Approved removal',gen_random_uuid(),true)",
      [client],
    ),
  ).rejects.toThrow("Permission denied");
  await scalar(
    "select public.manage_user_access($1,'administrator',true,$2,1,'Explicit approved deletion access',gen_random_uuid(),true)",
    [
      users.admin,
      JSON.stringify({
        ...rolePermissions("administrator"),
        delete_clients: true,
      }),
    ],
  );
  expect(
    (await scalar("select public.client_deletion_status($1)", [client]))
      .can_delete,
  ).toBe(true);
  expect((await defaults()).capabilities.can_delete_clients).toBe(true);
  const key = randomUUID();
  const args = [client, key];
  const sql =
    "select public.delete_client($1,1,'Approved duplicate register cleanup',$2,true)";
  const deleted = await scalar(sql, args);
  expect(await scalar(sql, args)).toEqual(deleted);
  expect(
    await scalar("select count(*)::int from public.clients where id=$1", [
      client,
    ]),
  ).toBe(0);
  await db.exec("reset role");
  expect(
    await scalar(
      "select count(*)::int from public.client_audit where client_id=$1 and action='delete'",
      [client],
    ),
  ).toBe(1);
  expect(
    await scalar(
      "select count(*)::int from public.client_identities where id=$1",
      [client],
    ),
  ).toBe(1);
});
it("blocks deletion for financial history and retention holds while audited archival preserves loans", async () => {
  const { rolePermissions } = await import("../lib/permissions");
  await scalar(
    "select public.manage_user_access($1,'administrator',true,$2,1,'Explicit approved lifecycle access',gen_random_uuid(),true)",
    [
      users.admin,
      JSON.stringify({
        ...rolePermissions("administrator"),
        delete_clients: true,
      }),
    ],
  );
  await db.exec("reset role");
  await query(
    "update public.client_identities set retention_reason='Legal retention hold' where id=$1",
    [client],
  );
  await db.exec("set local role authenticated");
  expect(
    (await scalar("select public.client_deletion_status($1)", [client]))
      .can_delete,
  ).toBe(false);
  await expect(
    scalar(
      "select public.delete_client($1,1,'Attempt during retention hold',gen_random_uuid(),true)",
      [client],
    ),
  ).rejects.toThrow("Legal retention hold");
  await db.exec("reset role");
  await query(
    "update public.client_identities set retention_reason=null where id=$1",
    [client],
  );
  await db.exec("set local role authenticated");
  const id = await loan();
  expect(
    (await scalar("select public.client_deletion_status($1)", [client])).reason,
  ).toContain("Loan");
  await expect(
    scalar(
      "select public.delete_client($1,1,'Approved removal attempt',gen_random_uuid(),true)",
      [client],
    ),
  ).rejects.toThrow("history");
  const c = await scalar(
    "select to_jsonb(c) from public.clients c where id=$1",
    [client],
  );
  const details = Object.fromEntries(
    [
      "man_number",
      "name",
      "department",
      "designation",
      "phone",
      "email",
      "address",
    ].map((k) => [k, c[k]]),
  );
  await scalar(
    "select public.correct_client($1,$2,'Approved Client archival',1)",
    [client, JSON.stringify({ ...details, is_active: false })],
  );
  expect((await getLoan(id)).client_id).toBe(client);
  expect(
    await scalar("select is_active from public.clients where id=$1", [client]),
  ).toBe(false);
  await expect(loan()).rejects.toThrow();
});
