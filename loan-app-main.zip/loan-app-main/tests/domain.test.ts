import { describe, it, expect } from "vitest";
import {
  cents,
  clientSchema,
  status,
  findClients,
  type Client,
  type Loan,
} from "../lib/domain";

describe("monetary inputs", () => {
  it("converts decimal strings exactly", () => {
    expect(cents("123.45")).toBe(12345);
    expect(cents("0.01")).toBe(1);
    expect(cents("15.1")).toBe(1510);
  });
  it.each(["-1", "NaN", "1e3", "0.001", "1,000", "", "1000000000"])(
    "rejects invalid amount %s",
    (value) => expect(() => cents(value)).toThrow(),
  );
  it("validates Client names and contact fields", () => {
    expect(clientSchema.safeParse({ name: "A" }).success).toBe(false);
    expect(
      clientSchema.safeParse({ name: "Jane Doe", email: "broken" }).success,
    ).toBe(false);
  });
  it("treats a due-today loan as active and zero-balance loans as settled", () => {
    const loan = { balance_cents: 1, due_date: "2026-11-12" } as Loan;
    expect(status(loan, "2026-11-12")).toBe("Active");
    expect(status(loan, "2026-11-13")).toBe("Overdue");
    expect(status({ ...loan, balance_cents: 0 }, "2026-11-13")).toBe("Settled");
  });
});
describe("Client register inputs", () => {
  const valid = {
    man_number: "00124",
    name: "Mary Tembo",
    department: "Health",
    designation: "Nurse",
  };
  it("requires Man#, department and designation", () => {
    for (const field of ["man_number", "department", "designation"])
      expect(clientSchema.safeParse({ ...valid, [field]: "" }).success).toBe(
        false,
      );
    expect(clientSchema.parse(valid).man_number).toBe("00124");
  });
  it("searches Man# as text without creating a Client", () => {
    const clients = [{ ...valid, id: "existing" }] as Client[];
    expect(findClients(clients, "001")[0].id).toBe("existing");
    expect(findClients(clients, "HEALTH")).toHaveLength(1);
    expect(findClients(clients, "unmatched")).toHaveLength(0);
    expect(clients).toHaveLength(1);
  });
});

it("prioritizes Written off and excludes it from collectible balances", () => {
  const loan = {
    id: "l1",
    balance_cents: 100,
    due_date: "2026-01-01",
    lifecycle_status: "written_off",
  } as Loan;
  expect(status(loan, "2026-11-13")).toBe("Written off");
});
