import { it, expect } from "vitest";
import {
  authSchema,
  emailSchema,
  passwordUpdateSchema,
  MIN_PASSWORD_LENGTH,
  safeReturnPath,
  authError,
} from "../lib/auth";
it("uses a six-character minimum consistently and never trims passwords", () => {
  expect(MIN_PASSWORD_LENGTH).toBe(6);
  expect(
    authSchema.safeParse({ email: " person@example.test ", password: "abc123" })
      .success,
  ).toBe(true);
  expect(
    authSchema.safeParse({ email: "person@example.test", password: "abc12" })
      .success,
  ).toBe(false);
  expect(
    passwordUpdateSchema.safeParse({ password: "abc123", repeat: "abc123" })
      .success,
  ).toBe(true);
  expect(
    passwordUpdateSchema.safeParse({ password: "abc12", repeat: "abc12" })
      .success,
  ).toBe(false);
  expect(
    passwordUpdateSchema.safeParse({ password: "abc123", repeat: "abc124" })
      .success,
  ).toBe(false);
  expect(
    authSchema.parse({ email: "person@example.test", password: " abc12" })
      .password,
  ).toBe(" abc12");
  expect(emailSchema.safeParse("not-an-email").success).toBe(false);
});
it.each([
  "https://evil.invalid",
  "//evil.invalid",
  "/\\evil.invalid",
  "/login",
  "/signup",
  "/dashboard@evil.invalid",
  "/dashboard\n",
  "/%2f%2fevil.invalid",
  null,
])("rejects unsafe or circular return paths: %s", (value) => {
  expect(safeReturnPath(value)).toBe("/dashboard");
});
it("preserves only allowed internal destinations and their filters", () => {
  expect(safeReturnPath("/dashboard?view=loans#clients")).toBe(
    "/dashboard?view=loans#clients",
  );
  expect(safeReturnPath("/security")).toBe("/security");
  expect(safeReturnPath("/expenses")).toBe("/expenses");
});
it("gives understandable provider failures without logging or echoing sensitive responses", () => {
  expect(
    authError({ code: "invalid_credentials", message: "private payload" }),
  ).toContain("incorrect");
  expect(authError({ code: "weak_password" })).toContain(
    "hosted password policy",
  );
  expect(authError({ code: "email_not_confirmed" })).toContain(
    "Confirm your email",
  );
  expect(authError({ code: "signup_disabled" })).toContain("invitation");
  expect(authError({ status: 429 })).toContain("Too many");
  expect(authError({ message: "secret token" })).not.toContain("secret");
});
