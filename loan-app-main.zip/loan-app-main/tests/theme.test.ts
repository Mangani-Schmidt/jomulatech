import { expect, it } from "vitest";
import { runInNewContext } from "node:vm";
import {
  themeStartupScript,
  themeStorageKey,
  themePreference,
  resolvedTheme,
} from "../lib/theme";
it.each([
  [null, false, "system", "light"],
  [null, true, "system", "dark"],
  ["light", true, "light", "light"],
  ["dark", false, "dark", "dark"],
  ["system", true, "system", "dark"],
  ["invalid", true, "system", "dark"],
  ["<script>invalid</script>", false, "system", "light"],
])(
  "initial head script resolves stored %s and device dark=%s before React",
  (stored, deviceDark, preference, theme) => {
    const root = {
      dataset: {} as Record<string, string>,
      style: {} as Record<string, string>,
    };
    runInNewContext(themeStartupScript, {
      localStorage: {
        getItem: (key: string) => {
          expect(key).toBe(themeStorageKey);
          return stored;
        },
      },
      document: { documentElement: root },
      window: { matchMedia: () => ({ matches: deviceDark }) },
    });
    expect(root.dataset).toEqual({ theme, themePreference: preference });
    expect(root.style.colorScheme).toBe(theme);
  },
);
it("defaults to the device preference when browser storage is blocked", () => {
  const root = {
    dataset: {} as Record<string, string>,
    style: {} as Record<string, string>,
  };
  runInNewContext(themeStartupScript, {
    localStorage: {
      getItem: () => {
        throw new Error("Blocked");
      },
    },
    document: { documentElement: root },
    window: { matchMedia: () => ({ matches: true }) },
  });
  expect(root.dataset).toEqual({ theme: "dark", themePreference: "system" });
});
it("normalizes unknown preferences without accepting scripts or changing explicit modes", () => {
  for (const value of [undefined, null, {}, "Dark", "<script>"])
    expect(themePreference(value)).toBe("system");
  expect(resolvedTheme("dark", false)).toBe("dark");
  expect(resolvedTheme("light", true)).toBe("light");
});
