import { describe, it, expect } from "vitest";
import {
  buildReport,
  defaultReportFilters,
  reportCSV,
  csvCell,
  type ReportSource,
  type ReportAudit,
} from "../lib/reporting";
import { demoClients } from "../lib/demo";
const loan = {
  id: "l1",
  client_id: "c1",
  loan_reference: "LN-00000001",
  currency: "ZMW",
  principal_cents: 100000,
  interest_cents: 15000,
  balance_cents: 105000,
  disbursement_date: "2026-01-01",
  due_date: "2026-03-01",
  created_at: "2026-01-01T09:00:00Z",
};
const origin = { ...loan, interest_cents: 10000, due_date: "2026-01-31" };
const audit = (
  action: string,
  date: string,
  after: typeof loan,
  before: ReportAudit["before_data"] = null,
): ReportAudit => ({
  id: action + date,
  loan_id: "l1",
  action,
  created_at: date + "T09:00:00Z",
  after_data: after,
  before_data: before,
  reason: "Verified report test",
});
function source(): ReportSource {
  return {
    generated_at: "2026-11-13T12:00:00Z",
    timezone: "Africa/Lusaka",
    clients: [demoClients[0]],
    loans: [loan],
    terms_audit: [
      audit("originate", "2026-01-01", origin),
      audit("adjust", "2026-02-01", loan, origin),
    ],
    status_audit: [],
    repayment_audit: [],
    repayments: [
      {
        id: "r1",
        loan_id: "l1",
        amount_cents: 20000,
        interest_allocation_cents: 10000,
        principal_allocation_cents: 10000,
        payment_date: "2026-01-10",
        created_at: "2026-01-10T09:00:00Z",
        reversed_at: "2026-02-10T09:00:00Z",
      },
      {
        id: "r2",
        loan_id: "l1",
        amount_cents: 10000,
        interest_allocation_cents: 5000,
        principal_allocation_cents: 5000,
        payment_date: "2026-02-05",
        created_at: "2026-02-05T09:00:00Z",
      },
    ],
  };
}
const filters = (from = "2026-01-01", to = "2026-01-31", asOf = to) => ({
  ...defaultReportFilters(asOf),
  from,
  to,
  asOf,
});
describe("effective date reports", () => {
  it("separates period activity from historical balances and future terms/reversals", () => {
    const r = buildReport(source(), filters());
    expect(r.totals).toMatchObject({
      disbursed: 100000,
      received: 20000,
      principalReceived: 10000,
      interestReceived: 10000,
      expectedInterest: 10000,
      principal: 90000,
      interest: 0,
      owed: 90000,
      interestAdjusted: 0,
    });
    expect(r.loans[0].due_date).toBe("2026-01-31");
    expect(r.loans[0].status).toBe("Active");
  });
  it("applies reversals on their effective date without rewriting January activity", () => {
    const r = buildReport(source(), filters("2026-02-01", "2026-02-28"));
    expect(r.totals).toMatchObject({
      disbursed: 0,
      received: -10000,
      principalReceived: -5000,
      interestReceived: -5000,
      expectedInterest: 0,
      interestAdjusted: 5000,
      principal: 95000,
      interest: 10000,
      owed: 105000,
    });
    expect(
      buildReport(source(), filters("2026-01-01", "2026-01-31", "2026-02-28"))
        .totals.received,
    ).toBe(20000);
  });
  it("uses payment effective dates even when posted later and labels the snapshot for restatement", () => {
    const s = source();
    s.repayments[0].created_at = "2026-01-25T09:00:00Z";
    const r = buildReport(s, filters("2026-01-01", "2026-01-15"));
    expect(r.totals.received).toBe(20000);
    expect(r.generated_at).toBe(s.generated_at);
  });
  it("keeps status as of date and excludes written off balances from overdue/collectible", () => {
    const s = source();
    s.status_audit = [
      { ...audit("write_off", "2026-02-15", loan), request_id: "decision" },
    ];
    const before = buildReport(s, filters("2026-02-01", "2026-02-14"));
    expect(before.totals.recognizedLoss).toBe(0);
    expect(before.loans[0].status).toBe("Active");
    const r = buildReport(s, filters("2026-02-01", "2026-03-10"));
    expect(r.loans[0].status).toBe("Written off");
    expect(r.totals).toMatchObject({
      owed: 105000,
      writtenOff: 105000,
      collectible: 0,
      overdue: 0,
      recognizedLoss: 95000,
    });
    s.status_audit.push(
      audit("reverse_write_off", "2026-03-15", loan, {
        ...loan,
        written_off_request_id: "decision",
      }),
    );
    const reversed = buildReport(s, filters("2026-03-01", "2026-03-20"));
    expect(reversed.totals.recognizedLoss).toBe(-95000);
    expect(reversed.totals.overdue).toBe(105000);
    expect(reversed.loans[0].status).toBe("Overdue");
  });
  it("does not combine currencies and uses current Client dimensions with all filters", () => {
    const s = source();
    s.loans.push({ ...loan, id: "usd", currency: "USD" });
    const f = filters();
    expect(buildReport(s, f).loans).toHaveLength(1);
    expect(
      buildReport(s, {
        ...f,
        search: "00124",
        department: "Finance",
        designation: "Accountant",
        status: "Active",
      }).clients[0].disbursed,
    ).toBe(100000);
    for (const extra of [
      { search: "absent" },
      { department: "Health" },
      { designation: "Teacher" },
      { status: "Settled" },
      { disbursedFrom: "2026-01-02" },
      { disbursedTo: "2025-12-31" },
    ])
      expect(buildReport(s, { ...f, ...extra }).loans).toHaveLength(0);
  });
  it("counts multiple loans per Client, and never includes a future disbursement", () => {
    const s = source();
    s.loans.push(
      { ...origin, id: "l2" },
      { ...origin, id: "future", disbursement_date: "2026-03-01" },
    );
    s.terms_audit.push({
      ...audit("originate", "2026-01-01", origin),
      loan_id: "l2",
    });
    const r = buildReport(s, filters());
    expect(r.clients).toHaveLength(1);
    expect(r.clients[0].loanCount).toBe(2);
    expect(r.totals.disbursed).toBe(200000);
  });
  it("preserves reported history before reversal and excludes its effect after reversal", () => {
    const a = buildReport(source(), filters("2026-02-01", "2026-02-09"));
    expect(a.totals.owed).toBe(85000);
    const b = buildReport(source(), filters("2026-02-01", "2026-02-10"));
    expect(b.totals.owed).toBe(105000);
  });
  it("rejects dates outside known allocation history instead of inventing historic balances", () => {
    const s = source();
    s.repayments[0].metadata_inferred = true;
    s.repayment_audit = [
      {
        id: "base",
        repayment_id: "r1",
        action: "baseline",
        created_at: "2026-03-01T00:00:00Z",
        reason: "Inferred allocations",
      },
    ];
    expect(() => buildReport(s, filters())).toThrow("begins 2026-03-01");
    expect(buildReport(s, filters("2026-03-01", "2026-03-10")).inferred).toBe(
      true,
    );
  });
  it("rejects incompatible backdated allocations and unsupported or inconsistent dates", () => {
    const s = source();
    s.repayments[0].interest_allocation_cents = 20000;
    s.repayments[0].principal_allocation_cents = 0;
    expect(() => buildReport(s, filters())).toThrow("Backdated allocations");
    for (const f of [
      { to: "2026-02-30" },
      { from: "2026-02-02" },
      { asOf: "2026-01-10" },
      { asOf: "2027-01-01" },
      { currency: "ALL" + "X" },
      { status: "Approved" },
    ])
      expect(() => buildReport(source(), { ...filters(), ...f })).toThrow();
  });
});
describe("matching exports", () => {
  it("exports exactly the filtered scope, current identity and separate metrics, including negative reversal activity", () => {
    const s = source();
    s.clients.push({ ...demoClients[1], name: "Excluded Client" });
    s.loans.push({ ...origin, id: "other", client_id: "c2" });
    s.terms_audit.push({
      ...audit("originate", "2026-01-01", origin),
      loan_id: "other",
    });
    const r = buildReport(s, {
      ...filters("2026-02-01", "2026-02-28"),
      search: "00124",
    });
    const csv = reportCSV(r, "loans");
    expect(csv).toContain("LN-00000001");
    expect(csv).toContain("00124");
    expect(csv).not.toContain("Excluded Client");
    expect(csv).toContain("Interest Income Received");
    expect(csv).toContain(
      "Unallocated: Client/loan filters applied; Net Profit unavailable",
    );
    expect(csv).toContain("2026-02-28");
    expect(r.totals.interestReceived).toBe(-5000);
  });
  it("escapes formula injection, quotes, commas, and multiline values", () => {
    expect(csvCell(' =HYPERLINK("bad")')).toBe('"\' =HYPERLINK(""bad"")"');
    expect(csvCell("\t@SUM(1)")).toContain("'");
    expect(csvCell('Tembo, "Mary"\nHealth')).toBe('"Tembo, ""Mary""\nHealth"');
    expect(csvCell(-50)).toBe('"-50"');
  });
});
it("treats linked corrections as posting-date adjustments without double-counting prior collections", () => {
  const s = source();
  s.loans[0] = { ...origin, balance_cents: 95000 };
  s.terms_audit = [audit("originate", "2026-01-01", origin)];
  s.repayments = [
    s.repayments[0],
    {
      id: "replacement",
      loan_id: "l1",
      amount_cents: 15000,
      interest_allocation_cents: 10000,
      principal_allocation_cents: 5000,
      payment_date: "2026-01-10",
      created_at: "2026-02-10T09:00:00Z",
      replaces_repayment_id: "r1",
    },
  ];
  expect(buildReport(s, filters()).totals).toMatchObject({
    received: 20000,
    owed: 90000,
  });
  expect(
    buildReport(s, filters("2026-02-01", "2026-02-28")).totals,
  ).toMatchObject({
    received: -5000,
    interestReceived: 0,
    principalReceived: -5000,
    owed: 95000,
  });
});
it("reports effective-date business expenses and never allocates them through Client filters", () => {
  const s = source();
  s.expenses = [
    {
      id: "e1",
      expense_reference: "EXP-0000000001",
      expense_date: "2026-01-05",
      amount: 10.29,
      amount_cents: 1029,
      currency: "ZMW",
      category: "Bank fees",
      description: "Bank transfer cost",
      payee: null,
      payment_method: "bank_transfer",
      external_reference: null,
      created_by: "admin",
      created_at: "2026-01-05T09:00:00Z",
      reversed_at: "2026-02-01T09:00:00Z",
      reversed_by: "admin",
      reversal_reason: "Verified incorrect expense",
    },
  ];
  expect(buildReport(s, filters()).expenses).toBe(1029);
  expect(buildReport(s, filters("2026-02-01", "2026-02-28")).expenses).toBe(
    -1029,
  );
  const filtered = buildReport(s, { ...filters(), department: "Finance" });
  expect(filtered.expenses).toBeNull();
  expect(filtered.expenseScope).toBe("unallocated");
  expect(reportCSV(filtered, "clients")).toContain(
    "Unallocated: Client/loan filters applied",
  );
});

it("treats loaded empty expenses as zero without certifying profit or redacted data", () => {
  const s = source();
  s.expenses = [];
  const r = buildReport(s, filters());
  expect(r.expenses).toBe(0);
  expect(r.recordedResult).toBe(
    r.totals.interestReceived - r.totals.recognizedLoss,
  );
  expect(r.netProfit).toBeNull();
  for (const expenses of [undefined, null]) {
    const hidden = buildReport({ ...s, expenses }, filters());
    expect(hidden.expenses).toBeNull();
    expect(hidden.recordedResult).toBeNull();
    expect(hidden.netProfit).toBeNull();
  }
  const filtered = buildReport(s, { ...filters(), search: "00124" });
  expect(filtered.expenses).toBeNull();
  expect(filtered.recordedResult).toBeNull();
  expect(reportCSV(r, "clients")).toContain(
    "Result from recorded entries (not final profit)",
  );
});
it("distinguishes recorded profit, loss and break-even and keeps certification snapshot-bound", () => {
  const s = source();
  s.expenses = [];
  s.ledger_event_count = 42;
  const f = filters();
  const original = buildReport(s, f);
  const baseExpense = {
    id: "e1",
    amount: 0,
    payee: null,
    external_reference: null,
    reversed_by: null,
    reversal_reason: null,
    expense_reference: "EXP-FICTIONAL",
    currency: "ZMW",
    expense_date: f.from,
    category: "Fees",
    description: "Fictional fees",
    amount_cents: original.totals.interestReceived,
    payment_method: "cash",
    created_by: "fictional",
    created_at: f.from + "T10:00:00Z",
    reversed_at: null,
  };
  const cert = {
    id: "test-cert",
    from_date: f.from,
    to_date: f.to,
    currency: "ZMW",
    ledger_event_count: 42,
    created_by: "fictional",
    created_at: f.to + "T10:00:00Z",
    reason: "Reviewed expenses and losses",
    revoked_at: null,
  };
  for (const delta of [-100, 0, 100]) {
    const r = buildReport(
      {
        ...s,
        certifications: [cert],
        expenses: [
          { ...baseExpense, amount_cents: baseExpense.amount_cents + delta },
        ],
      },
      f,
    );
    expect(r.recordedResult).toBe(0 - delta);
    expect(r.netProfit).toBe(0 - delta);
  }
  expect(
    buildReport({ ...s, certifications: [cert], expenses: null }, f).netProfit,
  ).toBeNull();
  expect(
    buildReport({ ...s, certifications: [cert], ledger_event_count: 43 }, f)
      .netProfit,
  ).toBeNull();
  expect(
    buildReport(
      { ...s, certifications: [{ ...cert, revoked_at: f.to + "T11:00:00Z" }] },
      f,
    ).netProfit,
  ).toBeNull();
  expect(
    buildReport({ ...s, expenses: [{ ...baseExpense, currency: "USD" }] }, f)
      .expenses,
  ).toBe(0);
});
