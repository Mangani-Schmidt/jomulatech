import { PGlite } from "@electric-sql/pglite";
import { beforeAll, afterAll, it, expect } from "vitest";
import { readFileSync } from "node:fs";
const db = new PGlite();
const owner = "11111111-1111-4111-8111-111111111111",
  other = "22222222-2222-4222-8222-222222222222";
let client: string;
let loan: string;
async function scalar<T = any>(sql: string, args: unknown[] = []) {
  const { rows } = await db.query<Record<string, T>>(sql, args);
  return Object.values(rows[0])[0];
}
async function user(id: string) {
  await db.exec(
    `reset role;select set_config('request.jwt.claim.sub','${id}',false);set role authenticated`,
  );
}
async function grant(admin: boolean, override: boolean) {
  await db.exec(
    `reset role;insert into public.account_permissions values('${owner}',${admin},${override}) on conflict(user_id) do update set is_admin=excluded.is_admin,can_override_rate=excluded.can_override_rate;set role authenticated`,
  );
}
async function defaults() {
  return scalar("select public.loan_defaults()");
}
async function details(change: Record<string, unknown> = {}) {
  const d = await defaults();
  return {
    client_id: client,
    principal_cents: 100000,
    rate_bps: d.settings.default_rate_bps,
    term_days: d.settings.default_term_days,
    disbursement_date: "2026-01-01",
    settings_revision: d.settings.revision,
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    override_reason: "",
    ...change,
  };
}
async function originate(
  change: Record<string, unknown> = {},
  request?: string,
) {
  return scalar<string>(
    "select public.originate_loan($1,coalesce($2::uuid,gen_random_uuid()),true)",
    [JSON.stringify(await details(change)), request ?? null],
  );
}
async function save(change: Record<string, unknown> = {}) {
  const d = await defaults();
  return scalar("select public.save_interest_settings($1,$2,$3)", [
    JSON.stringify({ ...d.settings, ...change }),
    d.settings.revision,
    "Verified future default change",
  ]);
}
async function adjust(
  rate: number,
  days: number,
  revision: number,
  reason = "Authorized one-time charge adjustment",
  id?: string,
) {
  return scalar(
    "select public.adjust_loan_terms($1,$2,$3,$4,$5,coalesce($6::uuid,gen_random_uuid()),true)",
    [loan, rate, days, revision, reason, id ?? null],
  );
}
const row = {
  source_no: "1",
  man_number: "IMPORT1",
  name: "Imported Client",
  department: "Health",
  designation: "Nurse",
  amount: "100.00",
  man_numeric: false,
  parse_errors: [],
};
async function preview(terms: Record<string, unknown>) {
  return scalar<string>("select public.preview_import($1,$2,$3,$4,$5)", [
    "loans.xlsx",
    "b".repeat(64),
    "loans",
    JSON.stringify(terms),
    JSON.stringify([row]),
  ]);
}
async function terms() {
  const d = await defaults();
  return {
    disbursement_date: "2026-01-01",
    interest_type: "flat_percent",
    interest_value: String(d.settings.default_rate_bps / 100),
    term_days: 30,
    due_rule: "days_after_disbursement",
    settings_revision: d.settings.revision,
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    override_reason: "",
  };
}
beforeAll(async () => {
  await db.exec(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;insert into auth.users values('${owner}'),('${other}');`,
  );
  for (const name of [
    "001_ledger",
    "002_client_register",
    "003_excel_import",
    "004_interest_settings",
  ])
    await db.exec(readFileSync(`supabase/migrations/${name}.sql`, "utf8"));
  await user(owner);
  client = await scalar(
    "insert into public.clients(man_number,name,department,designation) values('00124','Mary Tembo','Health','Nurse') returning id",
  );
}, 30000);
afterAll(() => db.close());
it("provides supported defaults without granting administrator privileges at sign-up", async () => {
  const d = await defaults();
  expect(d.settings).toMatchObject({
    default_rate_bps: 1000,
    default_term_days: 30,
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    currency: "ZMW",
    rounding_rule: "half_up_2",
    business_timezone: "Africa/Lusaka",
  });
  expect(d.capabilities).toEqual({ is_admin: false, can_override_rate: false });
  await expect(save({ default_rate_bps: 1200 })).rejects.toThrow(
    "Administrator",
  );
  await expect(
    db.query("update public.account_permissions set is_admin=true"),
  ).rejects.toThrow("permission denied");
  await expect(
    db.query(
      "insert into public.account_permissions(user_id,is_admin) values($1,true)",
      [owner],
    ),
  ).rejects.toThrow("permission denied");
});
it("calculates a one-time flat charge exactly, including half-ngwee rounding", async () => {
  expect(
    Number(
      await scalar(
        "select public.flat_interest_cents(100000,1000,'one_time_flat','entire_term')",
      ),
    ),
  ).toBe(10000);
  expect(
    Number(
      await scalar(
        "select public.flat_interest_cents(1,5000,'one_time_flat','entire_term')",
      ),
    ),
  ).toBe(1);
  await expect(
    scalar(
      "select public.flat_interest_cents(100000,1000,'compound','monthly')",
    ),
  ).rejects.toThrow("Unsupported");
});
it("originates at defaults and persists the actual terms and obligation", async () => {
  loan = await originate();
  const l = await scalar("select to_jsonb(l) from public.loans l where id=$1", [
    loan,
  ]);
  expect(l).toMatchObject({
    interest_rate_bps: 1000,
    interest_cents: 10000,
    total_obligation_cents: 110000,
    balance_cents: 110000,
    term_days: 30,
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    settings_revision: 1,
    default_rate_bps_at_origination: 1000,
  });
  expect(l.due_date).toBe("2026-01-31");
  expect(
    Number(
      await scalar(
        "select count(*) from public.loan_terms_audit where loan_id=$1",
        [loan],
      ),
    ),
  ).toBe(1);
});
it("blocks unsupported methods, rate bases, and the old fixed-charge origination RPC", async () => {
  await expect(originate({ calculation_method: "compound" })).rejects.toThrow(
    "Only one-time",
  );
  await expect(originate({ rate_basis: "monthly" })).rejects.toThrow(
    "Only one-time",
  );
  await expect(
    db.query("select public.create_loan($1,100,10,current_date+30)", [client]),
  ).rejects.toThrow("permission denied");
});
it("rejects unauthorized overrides and requires a reason for authorized overrides", async () => {
  await expect(
    originate({
      rate_bps: 1200,
      override_reason: "Business approved override",
    }),
  ).rejects.toThrow("override permission");
  await grant(false, true);
  await expect(originate({ rate_bps: 1200 })).rejects.toThrow(
    "override reason",
  );
  const id = await originate({
    rate_bps: 1200,
    override_reason: "Approved Client rate exception",
  });
  expect(
    await scalar("select rate_override_reason from public.loans where id=$1", [
      id,
    ]),
  ).toBe("Approved Client rate exception");
  await expect(save()).rejects.toThrow("Administrator");
});
it("makes loan creation idempotent and rejects a reused ID with different terms", async () => {
  const id = "33333333-3333-4333-8333-333333333333";
  const first = await originate({}, id);
  expect(await originate({}, id)).toBe(first);
  await expect(originate({ principal_cents: 999 }, id)).rejects.toThrow(
    "different loan terms",
  );
});
it("allows administrators to change defaults while preserving all existing loan terms", async () => {
  await grant(true, true);
  const before = (await db.query("select * from public.loans order by id"))
    .rows;
  await save({ default_rate_bps: 1200, default_term_days: 45 });
  expect(
    (await db.query("select * from public.loans order by id")).rows,
  ).toEqual(before);
  const id = await originate();
  expect(
    await scalar("select interest_rate_bps from public.loans where id=$1", [
      id,
    ]),
  ).toBe(1200);
  expect(
    await scalar("select term_days from public.loans where id=$1", [id]),
  ).toBe(45);
  const audit = await scalar("select to_jsonb(a) from public.settings_audit a");
  expect(audit.actor_id).toBe(owner);
  expect(audit.before_data.default_rate_bps).toBe(1000);
  expect(audit.after_data.default_rate_bps).toBe(1200);
});
it("rejects unsupported settings and stale previews rather than changing confirmed values", async () => {
  for (const change of [
    { calculation_method: "compound" },
    { rate_basis: "monthly" },
    { currency: "USD" },
    { rounding_rule: "truncate" },
    { business_timezone: "UTC" },
  ])
    await expect(save(change)).rejects.toThrow();
  await expect(originate({ settings_revision: 1 })).rejects.toThrow(
    "Defaults changed",
  );
});
it("requires an explicit administrator adjustment with reason and expected revision", async () => {
  await expect(adjust(2000, 60, 1, "")).rejects.toThrow("adjustment reason");
  await grant(false, true);
  await expect(adjust(2000, 60, 1)).rejects.toThrow("Administrator");
  await grant(true, true);
  await expect(adjust(2000, 60, 0)).rejects.toThrow("Loan terms changed");
  await expect(
    db.query("update public.loans set interest_cents=0 where id=$1", [loan]),
  ).rejects.toThrow("permission denied");
});
it("adjusts only the selected loan, retaining repayments and an immutable audit trail", async () => {
  await db.query("select public.record_repayment($1,50000,gen_random_uuid())", [
    loan,
  ]);
  const request = "44444444-4444-4444-8444-444444444444";
  await adjust(2000, 60, 1, "Approved extension and rate adjustment", request);
  const l = await scalar("select to_jsonb(l) from public.loans l where id=$1", [
    loan,
  ]);
  expect(l).toMatchObject({
    interest_cents: 20000,
    total_obligation_cents: 120000,
    balance_cents: 70000,
    interest_rate_bps: 2000,
    term_days: 60,
    terms_revision: 2,
    default_rate_bps_at_origination: 1000,
    settings_revision: 1,
  });
  expect(
    Number(
      await scalar(
        "select sum(amount_cents) from public.repayments where loan_id=$1",
        [loan],
      ),
    ),
  ).toBe(50000);
  const count = Number(
    await scalar("select count(*) from public.loan_terms_audit"),
  );
  await adjust(2000, 60, 1, "Approved extension and rate adjustment", request);
  expect(
    Number(await scalar("select count(*) from public.loan_terms_audit")),
  ).toBe(count);
  await expect(db.query("delete from public.loan_terms_audit")).rejects.toThrow(
    "permission denied",
  );
  await expect(
    db.query("update public.settings_audit set reason='changed'"),
  ).rejects.toThrow("permission denied");
});
it("prevents an adjustment below repayments already received", async () => {
  await db.query("select public.record_repayment($1,70000,gen_random_uuid())", [
    loan,
  ]);
  await expect(adjust(0, 30, 2)).rejects.toThrow("less than payments");
  expect(
    Number(
      await scalar("select balance_cents from public.loans where id=$1", [
        loan,
      ]),
    ),
  ).toBe(0);
});
it("enforces snapshots and shows principal, interest, and obligation for imported loans", async () => {
  await expect(
    preview({ ...(await terms()), interest_type: "fixed" }),
  ).rejects.toThrow("Only one-time");
  const id = await preview(await terms());
  const report = await scalar("select public.import_report($1)", [id]);
  expect(report.rows[0].data).toMatchObject({
    principal_cents: 10000,
    interest_cents: 1200,
    total_obligation_cents: 11200,
    rate_bps: 1200,
  });
  await scalar("select public.commit_import($1,1,true)", [id]);
  const l = await scalar(
    "select to_jsonb(l) from public.loans l where import_batch_id=$1",
    [id],
  );
  expect(l).toMatchObject({
    interest_rate_bps: 1200,
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
    settings_revision: 2,
    total_obligation_cents: 11200,
  });
});
it("invalidates staged imports when administrator defaults change", async () => {
  const t = { ...(await terms()), term_days: 31 };
  const id = await preview(t);
  await save({ default_rate_bps: 1300 });
  await expect(
    scalar("select public.commit_import($1,1,true)", [id]),
  ).rejects.toThrow("Defaults changed");
  await expect(preview(t)).rejects.toThrow("Defaults changed");
});
it("isolates settings and audit access and denies anonymous operations", async () => {
  await user(other);
  const d = await defaults();
  expect(d.settings.default_rate_bps).toBe(1000);
  expect(d.capabilities.is_admin).toBe(false);
  expect(
    Number(await scalar("select count(*) from public.settings_audit")),
  ).toBe(0);
  expect(
    Number(await scalar("select count(*) from public.loan_terms_audit")),
  ).toBe(0);
  await expect(adjust(2000, 60, 2)).rejects.toThrow("Administrator");
  await db.exec("reset role;set role anon");
  await expect(defaults()).rejects.toThrow("permission denied");
  await user(owner);
});
it("rechecks override authority at import confirmation when permissions have been revoked", async () => {
  const id = await preview({
    ...(await terms()),
    interest_value: "15",
    override_reason: "Approved exception for imported loans",
  });
  await grant(false, false);
  await expect(
    scalar("select public.commit_import($1,1,true)", [id]),
  ).rejects.toThrow("override permission");
  await grant(true, true);
});
