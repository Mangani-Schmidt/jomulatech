import { PGlite } from "@electric-sql/pglite";
import { beforeAll, afterAll, describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
const db = new PGlite();
const owner = "11111111-1111-4111-8111-111111111111";
const other = "22222222-2222-4222-8222-222222222222";
let clientId: string;
let loanId: string;
async function user(id: string) {
  await db.exec(
    `reset role; select set_config('request.jwt.claim.sub','${id}',false); set role authenticated;`,
  );
}
async function scalar<T>(sql: string, args: unknown[] = []) {
  const result = await db.query<Record<string, T>>(sql, args);
  return Object.values(result.rows[0])[0];
}
beforeAll(async () => {
  await db.exec(
    `create role anon; create role authenticated; create schema auth; create table auth.users(id uuid primary key); create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub', true),'')::uuid$$; grant usage on schema auth to authenticated; grant execute on function auth.uid() to authenticated; insert into auth.users values ('${owner}'),('${other}');`,
  );
  await db.exec(readFileSync("supabase/migrations/001_ledger.sql", "utf8"));
  await db.exec(
    readFileSync("supabase/migrations/002_client_register.sql", "utf8"),
  );
  await user(owner);
  clientId = await scalar<string>(
    "insert into public.clients(man_number,name,department,designation) values ('00124','Mary Tembo','Health','Nurse') returning id",
  );
  loanId = await scalar<string>(
    "select public.create_loan($1,100000,10000,current_date+30)",
    [clientId],
  );
}, 30000);
afterAll(async () => {
  await db.close();
});
describe("PostgreSQL financial boundary", () => {
  it("creates a loan with principal plus fixed interest", async () => {
    expect(
      Number(
        await scalar("select balance_cents from public.loans where id=$1", [
          loanId,
        ]),
      ),
    ).toBe(110000);
  });
  it("prevents direct mutation of a balance", async () => {
    await expect(
      db.query("update public.loans set balance_cents=0 where id=$1", [loanId]),
    ).rejects.toThrow("permission denied");
  });
  it("records a repayment once across retries", async () => {
    const request = "33333333-3333-4333-8333-333333333333";
    const a = await scalar("select public.record_repayment($1,10000,$2)", [
      loanId,
      request,
    ]);
    const b = await scalar("select public.record_repayment($1,10000,$2)", [
      loanId,
      request,
    ]);
    expect(a).toBe(b);
    expect(
      Number(
        await scalar("select balance_cents from public.loans where id=$1", [
          loanId,
        ]),
      ),
    ).toBe(100000);
  });
  it("rejects reused request keys with different amounts", async () => {
    await expect(
      db.query("select public.record_repayment($1,9999,$2)", [
        loanId,
        "33333333-3333-4333-8333-333333333333",
      ]),
    ).rejects.toThrow("Request already used");
  });
  it("rejects overpayments without changing balance or history", async () => {
    await expect(
      db.query("select public.record_repayment($1,100001,gen_random_uuid())", [
        loanId,
      ]),
    ).rejects.toThrow("Amount must");
    expect(
      Number(
        await scalar("select balance_cents from public.loans where id=$1", [
          loanId,
        ]),
      ),
    ).toBe(100000);
    expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
      1,
    );
  });
  it("rejects zero and negative payments", async () => {
    for (const amount of [0, -1])
      await expect(
        db.query("select public.record_repayment($1,$2,gen_random_uuid())", [
          loanId,
          amount,
        ]),
      ).rejects.toThrow("Amount must");
  });
  it("rejects negative interest and past due dates", async () => {
    await expect(
      db.query("select public.create_loan($1,100,-1,current_date+1)", [
        clientId,
      ]),
    ).rejects.toThrow("Invalid loan");
    await expect(
      db.query("select public.create_loan($1,100,0,current_date-1)", [
        clientId,
      ]),
    ).rejects.toThrow("Invalid due date");
  });
  it("isolates accounts through RLS and RPC ownership checks", async () => {
    await user(other);
    expect(Number(await scalar("select count(*) from public.clients"))).toBe(0);
    expect(Number(await scalar("select count(*) from public.loans"))).toBe(0);
    expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
      0,
    );
    await expect(
      db.query("select public.create_loan($1,100,0,current_date+1)", [
        clientId,
      ]),
    ).rejects.toThrow("Client not found");
    await expect(
      db.query("select public.record_repayment($1,1,gen_random_uuid())", [
        loanId,
      ]),
    ).rejects.toThrow("Loan not found");
    await user(owner);
  });
  it("rolls back every Client in an invalid import", async () => {
    await expect(
      db.query("select public.import_clients($1)", [
        JSON.stringify([{ name: "Valid Client" }, { name: "X" }]),
      ]),
    ).rejects.toThrow();
    expect(Number(await scalar("select count(*) from public.clients"))).toBe(1);
  });
  it("imports a valid workbook batch atomically", async () => {
    expect(
      await scalar("select public.import_clients($1)", [
        JSON.stringify([
          {
            man_number: "00224",
            department: "Finance",
            designation: "Accountant",
            name: "Chanda Mwansa",
            email: "chanda@example.com",
            phone: "+26097",
          },
        ]),
      ]),
    ).toBe(1);
  });
  it("denies unauthenticated access to tables and functions", async () => {
    await db.exec("reset role; set role anon;");
    await expect(db.query("select * from public.clients")).rejects.toThrow(
      "permission denied",
    );
    await expect(
      db.query("select public.create_loan($1,1,0,current_date+1)", [clientId]),
    ).rejects.toThrow("permission denied");
    await user(owner);
  });
  it("pays off a loan and preserves history", async () => {
    await db.query(
      "select public.record_repayment($1,100000,gen_random_uuid())",
      [loanId],
    );
    expect(
      Number(
        await scalar("select balance_cents from public.loans where id=$1", [
          loanId,
        ]),
      ),
    ).toBe(0);
    await expect(db.query("delete from public.repayments")).rejects.toThrow(
      "permission denied",
    );
  });
});

const details = (changes: Record<string, unknown> = {}) => ({
  man_number: "00124",
  name: "Mary Tembo",
  department: "Health",
  designation: "Nurse",
  phone: "",
  email: "",
  address: "",
  is_active: true,
  ...changes,
});
async function correct(
  changes: Record<string, unknown>,
  reason = "Verified Client correction",
  revision = 1,
) {
  return scalar<string>("select public.correct_client($1,$2,$3,$4)", [
    clientId,
    JSON.stringify(details(changes)),
    reason,
    revision,
  ]);
}
describe("Client register boundary", () => {
  it("stores leading zeros and records the authenticated creator", async () => {
    const c = await scalar<Record<string, unknown>>(
      "select to_jsonb(c) from public.clients c where id=$1",
      [clientId],
    );
    expect(c.man_number).toBe("00124");
    expect(c.created_by).toBe(owner);
    expect(c.created_at).toBe(c.updated_at);
  });
  it("rejects duplicates including case variants and outer whitespace", async () => {
    await expect(
      db.query(
        "insert into public.clients(man_number,name,department,designation) values (' 00124 ','Duplicate Client','Health','Nurse')",
      ),
    ).rejects.toThrow("unique");
    await db.query(
      "insert into public.clients(man_number,name,department,designation) values ('AB01','Another Client','Health','Nurse')",
    );
    await expect(
      db.query(
        "insert into public.clients(man_number,name,department,designation) values ('ab01','Another Client','Health','Nurse')",
      ),
    ).rejects.toThrow("unique");
  });
  it("requires register fields for new records", async () => {
    await expect(
      db.query("insert into public.clients(name) values ('Incomplete Client')"),
    ).rejects.toThrow("clients_register_required");
  });
  it("prevents direct updates and spoofed creation metadata", async () => {
    await expect(
      db.query("update public.clients set man_number='changed' where id=$1", [
        clientId,
      ]),
    ).rejects.toThrow("permission denied");
    await expect(
      db.query(
        "insert into public.clients(man_number,name,department,designation,created_by) values ('009','Spoof Client','Health','Nurse',$1)",
        [other],
      ),
    ).rejects.toThrow("permission denied");
  });
  it("requires a meaningful correction reason and strict active status", async () => {
    await expect(correct({ name: "Mary Corrected" }, "")).rejects.toThrow(
      "correction reason",
    );
    await expect(correct({ is_active: "false" })).rejects.toThrow(
      "must be boolean",
    );
    expect(
      await scalar("select name from public.clients where id=$1", [clientId]),
    ).toBe("Mary Tembo");
  });
  it("blocks foreign-account corrections and audit reads", async () => {
    await user(other);
    expect(
      Number(await scalar("select count(*) from public.client_audit")),
    ).toBe(0);
    await expect(correct({ name: "Wrong Account" })).rejects.toThrow(
      "Client not found",
    );
    await user(owner);
  });
  it("atomically corrects all details and keeps loan history linked", async () => {
    await correct(
      {
        man_number: "000777",
        name: "Mary Tembo Updated",
        department: "Finance",
        designation: "Analyst",
        phone: "+26097",
        email: "mary@example.com",
        address: "Lusaka",
        is_active: false,
      },
      "Verified employment and Man# correction",
    );
    const c = await scalar<Record<string, unknown>>(
      "select to_jsonb(c) from public.clients c where id=$1",
      [clientId],
    );
    expect(c.man_number).toBe("000777");
    expect(c.revision).toBe(2);
    expect(c.created_by).toBe(owner);
    expect(c.updated_at).not.toBe(c.created_at);
    expect(
      await scalar("select client_id from public.loans where id=$1", [loanId]),
    ).toBe(clientId);
    const audit = await scalar<Record<string, unknown>>(
      "select to_jsonb(a) from public.client_audit a where client_id=$1 and action='correct'",
      [clientId],
    );
    expect(audit.actor_id).toBe(owner);
    expect(audit.reason).toContain("Verified employment");
    expect((audit.before_data as Record<string, unknown>).man_number).toBe(
      "00124",
    );
    expect((audit.after_data as Record<string, unknown>).man_number).toBe(
      "000777",
    );
  });
  it("rejects stale corrections without overwriting newer details", async () => {
    await expect(correct({ name: "Stale Edit" })).rejects.toThrow(
      "Client changed",
    );
    expect(
      await scalar("select name from public.clients where id=$1", [clientId]),
    ).toBe("Mary Tembo Updated");
  });
  it("rejects loans for inactive Clients while preserving repayments", async () => {
    await expect(
      db.query("select public.create_loan($1,100,0,current_date+1)", [
        clientId,
      ]),
    ).rejects.toThrow("Active, complete Client not found");
  });
  it("rejects duplicate Man# corrections and leaves no audit entry", async () => {
    const count = Number(
      await scalar("select count(*) from public.client_audit"),
    );
    await expect(
      correct({ man_number: "00224" }, "Duplicate correction attempt", 2),
    ).rejects.toThrow("unique");
    expect(
      Number(await scalar("select count(*) from public.client_audit")),
    ).toBe(count);
    expect(
      await scalar("select man_number from public.clients where id=$1", [
        clientId,
      ]),
    ).toBe("000777");
  });
  it("rejects metadata and owner changes through the correction API", async () => {
    await expect(
      correct({ owner_id: other }, "Unauthorized owner change", 2),
    ).rejects.toThrow("Unexpected Client field");
  });
  it("rolls back imports and audit entries on a duplicate Man#", async () => {
    const count = Number(
      await scalar("select count(*) from public.client_audit"),
    );
    await expect(
      db.query("select public.import_clients($1)", [
        JSON.stringify([
          details({ man_number: "NEW01" }),
          details({ man_number: "00224" }),
        ]),
      ]),
    ).rejects.toThrow("unique");
    expect(
      Number(
        await scalar(
          "select count(*) from public.clients where man_number='NEW01'",
        ),
      ),
    ).toBe(0);
    expect(
      Number(await scalar("select count(*) from public.client_audit")),
    ).toBe(count);
  });
  it("keeps audit records immutable and denies anonymous correction", async () => {
    await expect(db.query("delete from public.client_audit")).rejects.toThrow(
      "permission denied",
    );
    await expect(
      db.query("update public.client_audit set reason='changed'"),
    ).rejects.toThrow("permission denied");
    await db.exec("reset role; set role anon");
    await expect(correct({})).rejects.toThrow("permission denied");
    await user(owner);
  });
});
