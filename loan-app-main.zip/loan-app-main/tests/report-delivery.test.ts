import { it, expect } from "vitest";
import ExcelJS from "exceljs";
import { reportWorkbook, workbookMoney } from "../lib/workbook";
import { buildReport, defaultReportFilters } from "../lib/reporting";
import { buildExpenseReport } from "../lib/expense-report";
import { expenseWorkbook, financialWorkbook } from "../lib/report-exports";
import { expensePDFDefinition } from "../lib/expense-pdf";
import { periodRange, repaymentPeriod, exactSum } from "../lib/report-period";
import { demoClients } from "../lib/demo";
import type { Expense, Loan } from "../lib/domain";
import type { ReportSource } from "../lib/reporting";
const base: Loan = {
  id: "a",
  client_id: demoClients[0].id,
  principal_cents: 10000,
  interest_cents: 1000,
  balance_cents: 11000,
  disbursement_date: "2026-02-01",
  due_date: "2026-03-01",
  created_at: "2026-02-01T00:00:00Z",
  currency: "ZMW",
  lifecycle_status: "active",
};
function source(): ReportSource {
  const loans = [
    base,
    {
      ...base,
      id: "b",
      disbursement_date: "2026-02-28",
      created_at: "2026-02-28T00:00:00Z",
    },
    {
      ...base,
      id: "old",
      disbursement_date: "2026-01-01",
      created_at: "2026-01-01T00:00:00Z",
    },
    { ...base, id: "other", currency: "USD", client_id: demoClients[1].id },
  ];
  return {
    generated_at: "2026-03-01T12:00:00Z",
    timezone: "Africa/Lusaka",
    clients: demoClients,
    loans,
    repayments: [],
    repayment_audit: [],
    status_audit: [],
    terms_audit: loans.map((l) => ({
      id: "a" + l.id,
      loan_id: l.id,
      created_at: l.created_at,
      action: "originate",
      after_data: l,
      before_data: null,
      reason: "Fictional origination",
    })),
  };
}
const filters = {
  ...defaultReportFilters("2026-03-01"),
  from: "2026-02-01",
  to: "2026-02-28",
};
it("counts distinct Clients with filtered period disbursements, separately from matching loans and currencies", () => {
  const r = buildReport(source(), filters);
  expect(r.clientsReceivingLoans).toBe(1);
  expect(r.loansIssued).toBe(2);
  expect(r.loans).toHaveLength(3);
  expect(r.totals.disbursed).toBe(20000);
  expect(
    buildReport(source(), { ...filters, department: "Missing" })
      .clientsReceivingLoans,
  ).toBe(0);
  expect(
    buildReport(source(), { ...filters, from: "2026-03-01", to: "2026-03-01" })
      .clientsReceivingLoans,
  ).toBe(0);
});
it("writes real XLSX with text identifiers and unexecuted malicious strings, frozen headers, filters and numeric totals", async () => {
  const wb = reportWorkbook(
    "Fictional report",
    [["Currency", "ZMW"]],
    [
      {
        name: "Data",
        currency: "ZMW",
        columns: [
          { label: "Man#" },
          { label: "Name" },
          { label: "Amount", kind: "money" },
          { label: "Date", kind: "date" },
        ],
        rows: [
          [
            "00001",
            '=HYPERLINK("https://fictional.invalid")',
            0.29,
            "2026-02-01",
          ],
          ["00002", "+1", 1.01, "2026-02-02"],
        ],
        totals: ["TOTAL", "", 1.3, ""],
      },
    ],
  );
  const bytes = await wb.xlsx.writeBuffer();
  expect(Buffer.from(bytes).subarray(0, 2).toString()).toBe("PK");
  const parsed = new ExcelJS.Workbook();
  await parsed.xlsx.load(bytes);
  const sheet = parsed.getWorksheet("Data")!;
  expect(sheet.getCell("A5").value).toBe("00001");
  expect(sheet.getCell("B5").type).toBe(ExcelJS.ValueType.String);
  expect(sheet.getCell("B5").formula).toBeUndefined();
  expect(sheet.getCell("C7").value).toBe(1.3);
  expect(sheet.getCell("C5").numFmt).toContain("ZMW");
  expect(sheet.getCell("D5").type).toBe(ExcelJS.ValueType.Date);
  expect(sheet.views[0]).toMatchObject({ state: "frozen", ySplit: 4 });
  expect(sheet.autoFilter).toBeTruthy();
  expect(sheet.pageSetup.printTitlesRow).toBe("1:4");
  expect(sheet.getCell("A6").fill).toHaveProperty("fgColor");
});
it("financial workbook uses report rows/totals, includes count and explicit activity/as-of scope", () => {
  const r = buildReport(source(), filters),
    wb = financialWorkbook(r);
  expect(wb.getWorksheet("Filtered loans")!.rowCount).toBe(r.loans.length + 5);
  expect(wb.getWorksheet("Report scope")!.getColumn(1).values).toContain(
    "Clients Receiving Loans",
  );
  expect(wb.getWorksheet("Filtered loans")!.lastRow!.getCell(12).value).toBe(
    200,
  );
});
const expense = (extra: Partial<Expense> = {}): Expense => ({
  id: "e",
  expense_reference: "EXP-1",
  expense_date: "2026-01-31",
  amount: 0.29,
  amount_cents: 29,
  currency: "ZMW",
  category: "Fees",
  description: "Fictional fee",
  payee: "Bank",
  payment_method: "cash",
  external_reference: null,
  created_by: "fictional",
  created_at: "2026-01-31T12:00:00Z",
  reversed_at: "2026-02-01T00:00:00Z",
  reversed_by: "fictional",
  reversal_reason: "Fictional reversal",
  ...extra,
});
it("expense period includes a later reversal of an older payment, excludes other currencies and keeps exact pennies", () => {
  const f = {
    from: "2026-02-01",
    to: "2026-02-28",
    currency: "ZMW",
    search: "",
    category: "",
    status: "" as const,
  };
  const r = buildExpenseReport(
    [
      expense(),
      expense({
        id: "paid",
        expense_date: "2026-02-28",
        reversed_at: null,
        amount_cents: 101,
      }),
      expense({ id: "usd", currency: "USD" }),
      expense({ id: "future", expense_date: "2026-03-01", reversed_at: null }),
    ],
    f,
    "2026-03-01T12:00:00Z",
  );
  expect(r.items).toHaveLength(2);
  expect(r.paid).toBe(101);
  expect(r.reversed).toBe(29);
  expect(r.net).toBe(72);
  expect(
    expenseWorkbook(r).getWorksheet("Filtered expenses")!.lastRow!.getCell(14)
      .value,
  ).toBe(0.72);
  expect(expensePDFDefinition(r).pageOrientation).toBe("landscape");
  expect(buildExpenseReport([expense()], { ...f, category: "Other" }).net).toBe(
    0,
  );
});
it("period presets respect business-calendar month/week/year boundaries and inclusive payment dates", () => {
  expect(periodRange("This Week", "2026-03-01")).toEqual({
    from: "2026-02-23",
    to: "2026-03-01",
  });
  expect(periodRange("This Week", "2026-01-01").from).toBe("2025-12-29");
  expect(periodRange("This Month", "2024-02-29").from).toBe("2024-02-01");
  const rows = [
    {
      id: "a",
      loan_id: "old-loan",
      amount_cents: 29,
      principal_allocation_cents: 20,
      interest_allocation_cents: 9,
      payment_date: "2026-02-01",
      created_at: "2026-01-01T00:00:00Z",
    },
    {
      id: "b",
      loan_id: "new-loan",
      amount_cents: 100,
      payment_date: "2026-02-28",
      created_at: "2026-03-01T00:00:00Z",
      reversed_at: "2026-03-01T00:00:00Z",
    },
    {
      id: "c",
      loan_id: "old",
      amount_cents: 10,
      created_at: "2026-01-31T22:30:00Z",
      principal_allocation_cents: 0,
      interest_allocation_cents: 10,
    },
  ];
  const r = repaymentPeriod(rows, "2026-02-01", "2026-02-28");
  expect(r.rows).toHaveLength(3);
  expect(r.received).toBe(39);
  expect(r.principal).toBe(20);
  expect(r.interest).toBe(19);
  const unknown = repaymentPeriod(
    [
      {
        ...rows[0],
        principal_allocation_cents: undefined,
        interest_allocation_cents: undefined,
      },
    ],
    "2026-02-01",
    "2026-02-28",
  );
  expect(unknown.received).toBe(29);
  expect(unknown.principal).toBeNull();
  expect(unknown.interest).toBeNull();
  expect(() => repaymentPeriod(rows, "2026-02-30", "2026-03-01")).toThrow(
    "real dates",
  );
  expect(() => exactSum([Number.MAX_SAFE_INTEGER, 1])).toThrow("exact range");
});

it("exports high precision monetary totals as exact decimal text beyond Excel precision", () => {
  expect(workbookMoney(9007199254740991)).toBe("90071992547409.91");
  expect(workbookMoney(-9007199254740991)).toBe("-90071992547409.91");
});
