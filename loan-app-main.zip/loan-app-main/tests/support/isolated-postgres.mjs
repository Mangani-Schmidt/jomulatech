import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import { setTimeout as delay } from "node:timers/promises";

// Always the local daemon. Never inherit a remote Docker context, database URL,
// PGHOST, Supabase credential, or dotenv configuration as a fixture destination.
const selectors = [
  "DOCKER_HOST",
  "DOCKER_CONTEXT",
  "DOCKER_TLS",
  "DOCKER_TLS_VERIFY",
  "DOCKER_CERT_PATH",
];
const dockerEnv = { ...process.env };
for (const key of selectors) delete dockerEnv[key];
const dockerPrefix = ["--host=unix:///var/run/docker.sock"];
function launch(args) {
  return spawn("docker", [...dockerPrefix, ...args], {
    env: dockerEnv,
    stdio: ["pipe", "pipe", "pipe"],
  });
}
function command(args, input = "") {
  return new Promise((resolve, reject) => {
    const child = launch(args);
    let out = "",
      err = "";
    child.stdout.on("data", (b) => (out += b));
    child.stderr.on("data", (b) => (err += b));
    child.on("error", () =>
      reject(
        new Error(
          "Local Docker is required. No external database fallback is allowed.",
        ),
      ),
    );
    child.on("close", (code) =>
      code === 0
        ? resolve(out.trim())
        : reject(new Error(err.trim() || "Local Docker command failed.")),
    );
    child.stdin.on("error", () => {});
    child.stdin.end(input);
  });
}
export function assertOwnedMetadata(metadata, nonce) {
  if (
    metadata?.Config?.Labels?.["loan-app.test-run"] !== nonce ||
    metadata?.HostConfig?.NetworkMode !== "none" ||
    metadata?.HostConfig?.ReadonlyRootfs !== true ||
    Object.keys(metadata?.HostConfig?.PortBindings ?? {}).length ||
    metadata?.Mounts?.some((m) => m.Type !== "tmpfs")
  )
    throw new Error(
      "Refusing to seed or remove an unowned, networked or persistent database container.",
    );
}
export function assertTestIdentity(identity, database, nonce) {
  if (
    !/^lendwell_test_[a-f0-9]{12}$/.test(database) ||
    identity?.database !== database ||
    identity?.nonce !== nonce
  )
    throw new Error(
      "Refusing fixtures outside the fresh, marked test database.",
    );
}
export class SqlSession {
  constructor(child) {
    this.child = child;
    this.buffer = "";
    this.stderr = "";
    this.pending = null;
    this.closed = false;
    this.finished = new Promise((resolve) =>
      child.on("close", (code) => {
        this.closed = true;
        this.pending?.reject(
          new Error(
            this.stderr.trim() || `PostgreSQL session exited (${code}).`,
          ),
        );
        this.pending = null;
        resolve(code);
      }),
    );
    child.stdout.on("data", (b) => {
      this.buffer += b;
      const p = this.pending;
      if (!p) return;
      const lines = this.buffer.split(/\r?\n/);
      const end = lines.indexOf(p.marker);
      if (end < 0) return;
      this.buffer = lines.slice(end + 1).join("\n");
      this.pending = null;
      p.resolve(lines.slice(0, end).join("\n").trim());
    });
    child.stderr.on("data", (b) => (this.stderr += b));
    child.on("error", (e) => this.pending?.reject(e));
    child.stdin.on("error", () => {});
  }
  query(sql) {
    if (this.closed || this.pending)
      return Promise.reject(
        new Error("Session closed or already executing a statement."),
      );
    const marker = "done_" + randomUUID().replaceAll("-", "");
    this.stderr = "";
    return new Promise((resolve, reject) => {
      this.pending = { marker, resolve, reject };
      this.child.stdin.write(sql + "\n\\echo " + marker + "\n");
    });
  }
  async json(sql) {
    return JSON.parse((await this.query(sql)).split("\n").at(-1));
  }
  async close() {
    if (!this.closed) {
      if (this.pending) this.child.kill();
      else this.child.stdin.end("rollback;\n\\q\n");
    }
    await this.finished;
  }
}
export async function createIsolatedPostgres(...options) {
  if (options.length)
    throw new Error(
      "Test databases do not accept URLs, credentials, target options, or existing containers.",
    );
  const { image } = JSON.parse(
    await readFile(new URL("./postgres-image.json", import.meta.url), "utf8"),
  );
  if (!/^postgres:17-bookworm@sha256:[a-f0-9]{64}$/.test(image))
    throw new Error("Use the reviewed digest-pinned PostgreSQL test image.");
  await command(["info", "--format", "{{.ServerVersion}}"]);
  const nonce = randomUUID(),
    database = "lendwell_test_" + nonce.replaceAll("-", "").slice(0, 12);
  const id = await command([
    "run",
    "--detach",
    "--rm",
    "--network",
    "none",
    "--read-only",
    "--label",
    "loan-app.test-run=" + nonce,
    "--tmpfs",
    "/var/lib/postgresql/data:rw,nosuid",
    "--tmpfs",
    "/var/run/postgresql:rw,nosuid",
    "--tmpfs",
    "/tmp:rw,nosuid",
    "-e",
    "POSTGRES_HOST_AUTH_METHOD=trust",
    "-e",
    "POSTGRES_DB=" + database,
    image,
    "-c",
    "listen_addresses=",
    "-c",
    "fsync=off",
    "-c",
    "jit=off",
    "-c",
    "log_statement=none",
    "-c",
    "statement_timeout=15000",
    "-c",
    "lock_timeout=10000",
    "-c",
    "idle_in_transaction_session_timeout=20000",
  ]);
  if (!/^[a-f0-9]{64}$/.test(id))
    throw new Error("Docker did not return a new test container ID.");
  const sessions = new Set();
  const psql = [
    "exec",
    "-i",
    id,
    "psql",
    "-X",
    "-qAt",
    "--no-password",
    "-v",
    "ON_ERROR_STOP=1",
    "-U",
    "postgres",
    "-d",
    database,
  ];
  const run = (sql) => command(psql, sql);
  const metadata = async () => JSON.parse(await command(["inspect", id]))[0];
  async function destroy() {
    for (const s of sessions) await s.close();
    const m = await metadata();
    assertOwnedMetadata(m, nonce);
    await command(["rm", "--force", id]);
  }
  try {
    assertOwnedMetadata(await metadata(), nonce);
    const deadline = Date.now() + 45000;
    let ready = false;
    while (Date.now() < deadline) {
      try {
        await run("select 1;");
        ready = true;
        break;
      } catch {
        await delay(150);
      }
    }
    if (!ready) throw new Error("Isolated PostgreSQL did not become ready.");
    await run(
      `create schema test_support;create table test_support.run_identity(nonce text primary key);insert into test_support.run_identity values('${nonce}');`,
    );
    async function assertSafe() {
      assertOwnedMetadata(await metadata(), nonce);
      const identity = JSON.parse(
        await run(
          "select jsonb_build_object('database',current_database(),'nonce',(select nonce from test_support.run_identity));",
        ),
      );
      assertTestIdentity(identity, database, nonce);
    }
    await assertSafe();
    return Object.freeze({
      run,
      async json(sql) {
        return JSON.parse((await run(sql)).split("\n").at(-1));
      },
      async seed(sql) {
        await assertSafe();
        return run(sql);
      },
      async dump() {
        // Fictional SQL stays in memory. Never accept source/target options or
        // include the harness marker, which must remain unique on restoration.
        await assertSafe();
        return command([
          "exec",
          id,
          "pg_dump",
          "--no-owner",
          "--schema=public",
          "--schema=auth",
          "-U",
          "postgres",
          "-d",
          database,
        ]);
      },
      session(name) {
        if (!/^[a-zA-Z0-9_-]{1,50}$/.test(name))
          throw new Error("Invalid test session name.");
        const args = [...psql];
        args.splice(2, 0, "-e", "PGAPPNAME=" + name);
        const session = new SqlSession(launch(args));
        sessions.add(session);
        return session;
      },
      destroy,
    });
  } catch (e) {
    await destroy();
    throw e;
  }
}
