/** Fixtures have no hosted target. Browser traffic is limited to its loopback app. */
export function testAppOrigin(baseURL: string | undefined) {
  if (!baseURL) throw new Error("A loopback test app URL is required.");
  const url = new URL(baseURL);
  if (
    url.protocol !== "http:" ||
    url.hostname !== "127.0.0.1" ||
    !["3000", "3002"].includes(url.port) ||
    url.username ||
    url.password
  )
    throw new Error(
      "Fixture browser tests require the loopback app on port 3000 or 3002.",
    );
  return url.origin;
}
export function permittedBrowserRequest(requestURL: string, appOrigin: string) {
  const url = new URL(requestURL);
  return url.protocol === "data:" || url.origin === testAppOrigin(appOrigin);
}
