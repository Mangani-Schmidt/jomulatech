import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import ExcelJS from "exceljs";
import sample from "../lib/import-sample.json";
import {
  previewSampleImport,
  sampleMapping,
  sampleFilename,
} from "../lib/import-demo";
import { demoClients } from "../lib/demo";
import { today } from "../lib/domain";
import { readWorkbook, mappedRows } from "../lib/import-server";
import type { ImportTerms } from "../lib/import";
const terms: Partial<ImportTerms> = {
  calculation_method: "one_time_flat",
  rate_basis: "entire_term",
  disbursement_date: today(),
  interest_type: "flat_percent",
  interest_value: "10",
  due_rule: "days_after_disbursement",
  term_days: 30,
};
describe("fictional import workbook and isolated walkthrough", () => {
  it("keeps the previous workbook URL identical to the rebranded download", () => {
    const current = readFileSync("public/samples/" + sampleFilename);
    const previous = readFileSync("public/samples/lendwell-dummy-clients.xlsx");
    expect(current.equals(previous)).toBe(true);
  });
  it("ships a parseable six-column workbook with ten text Man# values and the exact bundled rows", async () => {
    const bytes = new Uint8Array(
      readFileSync("public/samples/" + sampleFilename),
    );
    const { sheet, inspection } = await readWorkbook(
      new File([bytes], sampleFilename),
    );
    expect(inspection.rowCount).toBe(10);
    expect(inspection.mapping).toEqual(sampleMapping);
    expect(sheet.getCell("C2").type).toBe(ExcelJS.ValueType.String);
    expect(sheet.getColumn(3).numFmt).toBe("@");
    const rows = mappedRows(sheet, sampleMapping, "clients");
    expect(rows.map((r) => r.man_number)).toEqual(
      sample.map((r) => r.man_number),
    );
    for (const [index, row] of rows.entries()) {
      expect(row).toMatchObject({
        ...sample[index],
        amount: String(Number(sample[index].amount)),
        man_numeric: false,
        parse_errors: [],
      });
    }
    expect(rows.reduce((sum, r) => sum + Number(r.amount) * 100, 0)).toBe(
      2125000,
    );
  });
  it("requires an explicit mode and previews Client details without interpreting amount", () => {
    expect(() => previewSampleImport("", sampleMapping, {})).toThrow(
      "explicit import mode",
    );
    const result = previewSampleImport("clients", sampleMapping, {});
    expect(result.batch).toMatchObject({
      accepted: 10,
      rejected: 0,
      unchanged: 0,
      terms: {},
      status: "preview",
    });
    expect(result.rows[0].data.man_number).toBe("009001");
    for (const r of result.rows) {
      expect(r.loan_id).toBeNull();
      expect(r.data.principal_cents).toBeUndefined();
      expect(r.data.interest_cents).toBeUndefined();
    }
  });
  it("requires date, method, rate, due-date rule and term before a loan preview", () => {
    for (const field of [
      "disbursement_date",
      "calculation_method",
      "rate_basis",
      "interest_type",
      "interest_value",
      "due_rule",
      "term_days",
    ] as const) {
      const missing = { ...terms };
      delete missing[field];
      expect(
        () => previewSampleImport("loans", sampleMapping, missing),
        field,
      ).toThrow();
    }
    const result = previewSampleImport("loans", sampleMapping, terms);
    expect(result.batch.accepted).toBe(10);
    expect(
      result.rows.reduce((sum, r) => sum + r.data.principal_cents!, 0),
    ).toBe(2125000);
    expect(
      result.rows.reduce((sum, r) => sum + r.data.interest_cents!, 0),
    ).toBe(212500);
    expect(
      result.rows.reduce((sum, r) => sum + r.data.total_obligation_cents!, 0),
    ).toBe(2337500);
  });
  it("validates column mappings and rejects duplicate Man# instead of pretending the preview succeeded", () => {
    expect(() =>
      previewSampleImport("clients", { ...sampleMapping, man_number: 1 }, {}),
    ).toThrow("different source columns");
    const result = previewSampleImport(
      "clients",
      { ...sampleMapping, man_number: 4, department: 3 },
      {},
    );
    expect(result.batch).toMatchObject({ accepted: 0, rejected: 10 });
    expect(
      result.rows.every((r) =>
        r.errors.includes("Duplicate Man# in this workbook."),
      ),
    ).toBe(true);
  });
  it("shows unchanged matches and conflicting identities without modifying any Client", () => {
    const client = { ...demoClients[0], ...sample[0] };
    const original = structuredClone(client);
    expect(
      previewSampleImport("clients", sampleMapping, {}, [client]).batch
        .unchanged,
    ).toBe(1);
    const conflict = { ...client, name: "Different fictional Client" };
    const result = previewSampleImport("clients", sampleMapping, {}, [
      conflict,
    ]);
    expect(result.batch.rejected).toBe(1);
    expect(result.rows[0].errors.join(" ")).toContain("will not overwrite");
    expect(client).toEqual(original);
  });
});
