import { test, expect } from "../browser/fixtures";
import { navigate } from "../browser/navigation";
import { fictionalProviderUser } from "../browser/auth-fixture";
import { capabilitiesForRole } from "../../lib/permissions";
import { demoReportSource } from "../../lib/demo";
import { demoDefaults } from "../../lib/interest";
import { mkdir, writeFile } from "node:fs/promises";
import { performance } from "node:perf_hooks";
for (const sample of [1, 2, 3])
  test(`navigation sample ${sample}`, async ({ page }, testInfo) => {
    const delayMs = 150,
      actor = "11111111-1111-4111-8111-111111111111";
    const token = [
      "eyJhbGciOiJIUzI1NiJ9",
      Buffer.from(
        JSON.stringify({
          sub: actor,
          session_id: actor,
          exp: Math.floor(Date.now() / 1000) + 3600,
        }),
      ).toString("base64url"),
      "fictional-signature",
    ].join(".");
    await page.addInitScript(
      ({ actor, token }) =>
        localStorage.setItem(
          "sb-register-tests-auth-token",
          JSON.stringify({
            access_token: token,
            refresh_token: "fictional",
            token_type: "bearer",
            expires_at: Math.floor(Date.now() / 1000) + 3600,
            expires_in: 3600,
            user: {
              id: actor,
              email: "benchmark@example.test",
              aud: "authenticated",
              role: "authenticated",
              app_metadata: {},
              user_metadata: {},
              created_at: "2026-01-01T00:00:00Z",
            },
          }),
        ),
      { actor, token },
    );
    const requests: { path: string; start: number; ms?: number }[] = [];
    let inflight = 0;
    await page.route("https://register-tests.supabase.co/**", async (route) => {
      const path = new URL(route.request().url()).pathname,
        entry = { path, start: performance.now(), ms: 0 };
      requests.push(entry);
      inflight++;
      await new Promise((r) => setTimeout(r, delayMs));
      let data: unknown;
      if (path === "/auth/v1/user") data = fictionalProviderUser(route);
      else if (
        path.endsWith("/app_session_status") ||
        path.endsWith("/touch_app_session")
      )
        data = {
          active: true,
          registered: true,
          server_now: new Date().toISOString(),
          last_activity_at: new Date().toISOString(),
        };
      else if (path.endsWith("/loan_defaults"))
        data = {
          ...demoDefaults,
          capabilities: capabilitiesForRole("administrator"),
        };
      else if (path.endsWith("/ledger_snapshot"))
        data = {
          clients: demoReportSource.clients,
          loans: demoReportSource.loans,
          repayments: demoReportSource.repayments,
        };
      else if (path.endsWith("/report_source_filtered"))
        data = demoReportSource;
      else if (path.endsWith("/list_business_users")) data = [];
      else if (path.endsWith("/has_capability")) data = true;
      else if (path.endsWith("/audit_events") || path.endsWith("/expenses"))
        data = [];
      else throw new Error("Unexpected benchmark request: " + path);
      await route.fulfill({ json: data });
      entry.ms = performance.now() - entry.start;
      inflight--;
    });
    let documentNavigations = 0;
    page.on("request", (r) => {
      if (r.isNavigationRequest() && r.resourceType() === "document")
        documentNavigations++;
    });
    const results: unknown[] = [];
    async function step(
      name: string,
      action: () => Promise<unknown>,
      ready: () => Promise<unknown>,
    ) {
      const offset = requests.length,
        start = performance.now(),
        documentsBefore = documentNavigations;
      await page.evaluate(() => {
        const probe = { hiddenMs: 0, last: performance.now(), running: true };
        (window as unknown as { probe: typeof probe }).probe = probe;
        function frame() {
          if (!probe.running) return;
          const now = performance.now();
          const h = document.querySelector("main h1");
          if (!h || !h.getClientRects().length || h.closest("[hidden]"))
            probe.hiddenMs += now - probe.last;
          probe.last = now;
          requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
      });
      await action();
      await ready();
      const readyMs = performance.now() - start;
      await expect.poll(() => inflight, { intervals: [25] }).toBe(0);
      await new Promise((r) => setTimeout(r, 40));
      await expect.poll(() => inflight, { intervals: [25] }).toBe(0);
      const counts: Record<string, number> = {};
      for (const r of requests.slice(offset))
        counts[r.path] = (counts[r.path] ?? 0) + 1;
      const hiddenMs = await page.evaluate(() => {
        const p = (
          window as unknown as {
            probe?: { running: boolean; hiddenMs: number };
          }
        ).probe;
        if (!p) return null;
        p.running = false;
        return Math.round(p.hiddenMs);
      });
      results.push({
        name,
        ready_ms: Math.round(readyMs),
        settled_ms: Math.round(performance.now() - start),
        content_hidden_ms: hiddenMs,
        documents: documentNavigations - documentsBefore,
        requests: counts,
      });
    }
    await step(
      "initial_dashboard",
      () => page.goto("/dashboard"),
      () => expect(page.locator('[data-metric="owed"] strong')).toBeVisible(),
    );
    for (const [name, heading] of [
      ["Clients", "Client Register"],
      ["Client Loan History", "Client Loan History"],
      ["Repayments", "Every payment accounted for."],
      ["Reports", "Reports"],
    ] as const)
      await step(
        name,
        () => navigate(page, name),
        async () => {
          await expect(
            page.getByRole("heading", { name: heading, exact: true }),
          ).toBeVisible();
          if (name === "Reports")
            await expect(
              page.locator('[data-metric="owed"] strong'),
            ).toBeVisible();
        },
      );
    // Deterministic SDK visibility recovery + paired focus event, without recording activity.
    await step(
      "tab_return",
      () =>
        page.evaluate(() => {
          Object.defineProperty(document, "visibilityState", {
            configurable: true,
            get: () => "hidden",
          });
          document.dispatchEvent(
            new Event("visibilitychange", { bubbles: true }),
          );
          Object.defineProperty(document, "visibilityState", {
            configurable: true,
            get: () => "visible",
          });
          document.dispatchEvent(
            new Event("visibilitychange", { bubbles: true }),
          );
          window.dispatchEvent(new Event("focus"));
        }),
      async () => {
        await expect
          .poll(
            () =>
              requests.filter((r) => r.path.endsWith("/app_session_status"))
                .length,
          )
          .toBeGreaterThan(1);
        await expect.poll(() => inflight, { intervals: [25] }).toBe(0);
        await expect(
          page.getByRole("heading", {
            name: "Reports",
            exact: true,
          }),
        ).toBeVisible();
      },
    );
    await step(
      "Expenses route",
      () => navigate(page, "Expenses"),
      () =>
        expect(
          page.getByRole("heading", { name: "Expenses", exact: true }),
        ).toBeVisible(),
    );
    await step(
      "Clients return",
      () => navigate(page, "Clients"),
      () =>
        expect(
          page.getByRole("heading", { name: "Client Register", exact: true }),
        ).toBeVisible(),
    );
    const js = await page.evaluate(() =>
      performance
        .getEntriesByType("resource")
        .filter((e) => e.name.includes("/_next/") && e.name.includes(".js"))
        .map((e) => ({
          url: new URL(e.name).pathname,
          bytes: (e as PerformanceResourceTiming).transferSize,
        })),
    );
    const payload = {
      sample,
      api_latency_ms: delayMs,
      server:
        "local Next production build; fictional provider, no hosted connections",
      results,
      js_transfer_bytes: js.reduce((sum, x) => sum + x.bytes, 0),
      js_requests: js.length,
      request_timings: requests,
    };
    const out = process.env.PERFORMANCE_OUTPUT_DIR ?? testInfo.outputDir;
    await mkdir(out, { recursive: true });
    await writeFile(
      `${out}/navigation-${sample}.json`,
      JSON.stringify(payload, null, 2),
    );
  });
