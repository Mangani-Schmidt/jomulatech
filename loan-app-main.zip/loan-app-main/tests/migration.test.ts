import { it, expect } from "vitest";
import { PGlite } from "@electric-sql/pglite";
import { readFileSync } from "node:fs";
it("upgrades an existing ledger without fabricating Man# or breaking loan history", async () => {
  const db = new PGlite();
  const owner = "11111111-1111-4111-8111-111111111111";
  try {
    await db.exec(
      `create role anon; create role authenticated; create schema auth; create table auth.users(id uuid primary key); create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub', true),'')::uuid$$; grant usage on schema auth to authenticated; grant execute on function auth.uid() to authenticated; insert into auth.users values ('${owner}');`,
    );
    await db.exec(readFileSync("supabase/migrations/001_ledger.sql", "utf8"));
    await db.exec(
      `select set_config('request.jwt.claim.sub','${owner}',false); set role authenticated`,
    );
    const {
      rows: [client],
    } = await db.query<{ id: string; created_at: string }>(
      "insert into public.clients(name) values ('Legacy Client') returning id, created_at",
    );
    await db.query("select public.create_loan($1,10000,100,current_date+1)", [
      client.id,
    ]);
    await db.exec("reset role");
    await db.exec(
      readFileSync("supabase/migrations/002_client_register.sql", "utf8"),
    );
    await db.exec(
      readFileSync("supabase/migrations/003_excel_import.sql", "utf8"),
    );
    await db.exec("set role authenticated");
    const {
      rows: [upgraded],
    } = await db.query<{
      id: string;
      man_number: null;
      created_at: string;
      created_by: string;
      revision: number;
    }>("select * from public.clients where id=$1", [client.id]);
    expect(upgraded.man_number).toBeNull();
    expect(upgraded.id).toBe(client.id);
    expect(upgraded.created_at).toEqual(client.created_at);
    expect(upgraded.created_by).toBe(owner);
    await expect(
      db.query("select public.create_loan($1,100,0,current_date+1)", [
        client.id,
      ]),
    ).rejects.toThrow("Active, complete");
    const {
      rows: [baseline],
    } = await db.query<{ action: string; actor_id: null }>(
      "select * from public.client_audit where client_id=$1",
      [client.id],
    );
    expect(baseline.action).toBe("baseline");
    expect(baseline.actor_id).toBeNull();
    await db.query("select public.correct_client($1,$2,$3,1)", [
      client.id,
      JSON.stringify({
        man_number: "000001",
        name: "Legacy Client",
        department: "Health",
        designation: "Nurse",
        is_active: true,
      }),
      "Completed from verified Client records",
    ]);
    const {
      rows: [loan],
    } = await db.query<{ client_id: string; balance_cents: number }>(
      "select * from public.loans",
    );
    expect(loan.client_id).toBe(client.id);
    expect(Number(loan.balance_cents)).toBe(10100);
    await db.query(
      "select public.record_repayment((select id from public.loans),100,gen_random_uuid())",
    );
    const {
      rows: [auditCount],
    } = await db.query<{ count: number }>(
      "select count(*) from public.client_audit",
    );
    expect(Number(auditCount.count)).toBe(2);
  } finally {
    await db.close();
  }
}, 30000);
