import { PGlite } from "@electric-sql/pglite";
import { beforeAll, afterAll, it, expect } from "vitest";
import { readFileSync } from "node:fs";
const db = new PGlite();
const owner = "11111111-1111-4111-8111-111111111111",
  other = "22222222-2222-4222-8222-222222222222";
let client: string, loanId: string, first: string, second: string;
let day: string;
const firstRequest = "33333333-3333-4333-8333-333333333333";
async function scalar<T = any>(sql: string, args: unknown[] = []) {
  const { rows } = await db.query<Record<string, T>>(sql, args);
  return Object.values(rows[0])[0];
}
async function user(id: string) {
  await db.exec(
    `reset role;select set_config('request.jwt.claim.sub','${id}',false);set role authenticated`,
  );
}
async function admin() {
  await db.exec(
    `reset role;insert into public.account_permissions values('${owner}',true,true);set role authenticated`,
  );
}
async function loan() {
  return scalar("select to_jsonb(l) from public.loan_register l where id=$1", [
    loanId,
  ]);
}
async function details(amount: number, extra: Record<string, unknown> = {}) {
  const l = await loan();
  return {
    loan_id: loanId,
    amount_cents: amount,
    payment_date: day,
    payment_method: "cash",
    external_reference: null,
    expected_balance_cents: l.balance_cents,
    expected_terms_revision: l.terms_revision,
    expected_interest_outstanding_cents: l.interest_outstanding_cents,
    expected_principal_outstanding_cents: l.principal_outstanding_cents,
    ...extra,
  };
}
async function post(
  amount: number,
  extra: Record<string, unknown> = {},
  id?: string,
) {
  return scalar(
    "select public.post_repayment($1,coalesce($2::uuid,gen_random_uuid()),true)",
    [JSON.stringify(await details(amount, extra)), id ?? null],
  );
}
async function reverse(
  id: string,
  request?: string,
  reason = "Verified erroneous payment reversal",
) {
  return scalar(
    "select public.reverse_repayment($1,$2,coalesce($3::uuid,gen_random_uuid()),true)",
    [id, reason, request ?? null],
  );
}
async function correct(
  id: string,
  amount: number,
  extra: Record<string, unknown> = {},
  request?: string,
) {
  return scalar(
    "select public.correct_repayment($1,$2,$3,coalesce($4::uuid,gen_random_uuid()),true)",
    [
      id,
      JSON.stringify(await details(amount, extra)),
      "Verified payment record correction",
      request ?? null,
    ],
  );
}
beforeAll(async () => {
  await db.exec(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;insert into auth.users values('${owner}'),('${other}');`,
  );
  for (const name of [
    "001_ledger",
    "002_client_register",
    "003_excel_import",
    "004_interest_settings",
    "005_loan_register",
    "006_repayments",
  ])
    await db.exec(readFileSync(`supabase/migrations/${name}.sql`, "utf8"));
  await user(owner);
  day = await scalar(
    "select to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD')",
  );
  client = await scalar(
    "insert into public.clients(man_number,name,department,designation) values('00124','Mary Tembo','Health','Nurse') returning id",
  );
  loanId = await scalar(
    "select public.originate_loan($1,gen_random_uuid(),true)",
    [
      JSON.stringify({
        client_id: client,
        principal_cents: 100000,
        rate_bps: 1000,
        term_days: 30,
        disbursement_date: day,
        settings_revision: 1,
        calculation_method: "one_time_flat",
        rate_basis: "entire_term",
        override_reason: "",
      }),
    ],
  );
}, 30000);
afterAll(() => db.close());
it("posts partial payments interest first and persists reference, method, date and creator", async () => {
  const result = await post(6000, {}, firstRequest);
  first = result.repayment_id;
  const r = await scalar(
    "select to_jsonb(r) from public.repayment_register r where id=$1",
    [first],
  );
  expect(r).toMatchObject({
    amount_cents: 6000,
    interest_allocation_cents: 6000,
    principal_allocation_cents: 0,
    payment_method: "cash",
    payment_date: day,
    created_by: owner,
    posting_status: "posted",
    allocation_policy: "interest_first",
    metadata_inferred: false,
  });
  expect(r.payment_reference).toMatch(/^PAY-\d{8,}$/);
  expect((await loan()).balance_cents).toBe(104000);
  expect(r.receipt_snapshot.balance_after_cents).toBe(104000);
});
it("supports full settlement and exact principal/interest allocation", async () => {
  second = (
    await post(104000, {
      payment_method: "bank_transfer",
      external_reference: "BANK-001",
    })
  ).repayment_id;
  const r = await scalar(
    "select to_jsonb(r) from public.repayments r where id=$1",
    [second],
  );
  expect(r.interest_allocation_cents).toBe(4000);
  expect(r.principal_allocation_cents).toBe(100000);
  expect((await loan()).status).toBe("settled");
});
it("rejects overpayments, invalid dates/methods, and stale allocation previews without writes", async () => {
  const count = Number(await scalar("select count(*) from public.repayments"));
  await expect(post(1)).rejects.toThrow("Overpayment");
  await expect(post(1, { payment_date: "2099-01-01" })).rejects.toThrow(
    "Payment date",
  );
  await expect(post(1, { payment_method: "unsupported" })).rejects.toThrow(
    "supported",
  );
  await expect(post(0)).rejects.toThrow("positive");
  expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
    count,
  );
});
it("protects duplicate submissions even after the loan balance changed", async () => {
  const original = {
    loan_id: loanId,
    amount_cents: 6000,
    payment_date: day,
    payment_method: "cash",
    external_reference: null,
    expected_balance_cents: 110000,
    expected_terms_revision: 1,
    expected_interest_outstanding_cents: 10000,
    expected_principal_outstanding_cents: 100000,
  };
  const again = await scalar("select public.post_repayment($1,$2,true)", [
    JSON.stringify(original),
    firstRequest,
  ]);
  expect(again.repayment_id).toBe(first);
  await expect(post(1, {}, firstRequest)).rejects.toThrow("Request ID");
});
it("denies ordinary deletion, field edits, and unauthorized reversals or corrections", async () => {
  await expect(db.query("delete from public.repayments")).rejects.toThrow(
    "permission denied",
  );
  await expect(
    db.query("update public.repayments set amount_cents=1 where id=$1", [
      first,
    ]),
  ).rejects.toThrow("permission denied");
  await expect(reverse(first)).rejects.toThrow("Administrator");
  await expect(correct(first, 6000)).rejects.toThrow("Administrator");
  await expect(
    scalar("select public.record_repayment($1,1,gen_random_uuid())", [loanId]),
  ).rejects.toThrow("Use post_repayment");
});
it("reverses an earlier interest payment without rewriting a later principal allocation", async () => {
  await admin();
  await reverse(first, "44444444-4444-4444-8444-444444444444");
  const l = await loan();
  expect(l).toMatchObject({
    balance_cents: 6000,
    interest_outstanding_cents: 6000,
    principal_outstanding_cents: 0,
    status: "active",
  });
  const r = await scalar(
    "select to_jsonb(r) from public.repayments r where id=$1",
    [second],
  );
  expect(r.principal_allocation_cents).toBe(100000);
  expect(r.interest_allocation_cents).toBe(4000);
  const old = await scalar(
    "select to_jsonb(r) from public.repayments r where id=$1",
    [first],
  );
  expect(old.posting_status).toBe("reversed");
  expect(old.amount_cents).toBe(6000);
  expect(old.reversed_by).toBe(owner);
  const count = Number(
    await scalar("select count(*) from public.repayment_audit"),
  );
  await reverse(first, "44444444-4444-4444-8444-444444444444");
  expect(
    Number(await scalar("select count(*) from public.repayment_audit")),
  ).toBe(count);
});
it("rejects stale balances and pays restored interest with the next receipt", async () => {
  await expect(post(6000, { expected_balance_cents: 110000 })).rejects.toThrow(
    "balance or terms changed",
  );
  await expect(
    post(6000, { expected_interest_outstanding_cents: 0 }),
  ).rejects.toThrow("allocations changed");
  const id = (await post(6000)).repayment_id;
  const r = await scalar(
    "select to_jsonb(r) from public.repayments r where id=$1",
    [id],
  );
  expect(r.interest_allocation_cents).toBe(6000);
  expect(r.principal_allocation_cents).toBe(0);
  expect((await loan()).status).toBe("settled");
});
it("blocks lowering interest below posted interest allocations", async () => {
  await expect(
    scalar(
      "select public.adjust_loan_terms($1,500,30,1,$2,gen_random_uuid(),true)",
      [loanId, "Attempted lower interest after payment"],
    ),
  ).rejects.toThrow("posted interest allocations");
});
it("atomically reverses and replaces an erroneous receipt and reuses its external reference", async () => {
  const key = "55555555-5555-4555-8555-555555555555";
  const result = await correct(
    second,
    100000,
    { payment_method: "bank_transfer", external_reference: "BANK-001" },
    key,
  );
  const replacement = await scalar(
    "select to_jsonb(r) from public.repayments r where id=$1",
    [result.repayment_id],
  );
  expect(replacement.replaces_repayment_id).toBe(second);
  expect(replacement.amount_cents).toBe(100000);
  expect((await loan()).balance_cents).toBe(4000);
  expect(
    await scalar("select posting_status from public.repayments where id=$1", [
      second,
    ]),
  ).toBe("reversed");
  const cached = await scalar(
    "select result from public.financial_operations where request_id=$1",
    [key],
  );
  expect(cached.repayment_id).toBe(result.repayment_id);
});
it("rolls back reversal, balance and audit if a replacement fails validation", async () => {
  const active = await scalar(
    "select id from public.repayments where loan_id=$1 and reversed_at is null and amount_cents=100000",
    [loanId],
  );
  const before = [
    (await loan()).balance_cents,
    Number(await scalar("select count(*) from public.repayment_audit")),
  ];
  await expect(correct(active, 200000)).rejects.toThrow("Overpayment");
  expect([
    (await loan()).balance_cents,
    Number(await scalar("select count(*) from public.repayment_audit")),
  ]).toEqual(before);
  expect(
    await scalar("select posting_status from public.repayments where id=$1", [
      active,
    ]),
  ).toBe("posted");
});
it("enforces external reference uniqueness and validates a required payment date", async () => {
  await expect(
    post(1000, {
      payment_method: "bank_transfer",
      external_reference: "bank-001",
    }),
  ).rejects.toThrow("External reference");
  await expect(post(1000, { payment_date: "" })).rejects.toThrow(
    "Payment date",
  );
  await expect(post(1000, { payment_date: "1900-01-01" })).rejects.toThrow(
    "Payment date",
  );
});
it("requires write-off reversal before reversing a receipt and keeps old write-off retry inert", async () => {
  const key = "66666666-6666-4666-8666-666666666666";
  await scalar("select public.write_off_loan($1,4000,1,$2,$3,true)", [
    loanId,
    "Approved unpaid balance write-off",
    key,
  ]);
  const active = await scalar(
    "select id from public.repayments where loan_id=$1 and reversed_at is null limit 1",
    [loanId],
  );
  await expect(reverse(active)).rejects.toThrow("Reverse the write-off");
  const original = (await loan()).written_off_request_id;
  await scalar(
    "select public.reverse_write_off($1,$2,$3,gen_random_uuid(),true)",
    [loanId, original, "Verified mistaken write-off reversal"],
  );
  expect((await loan()).lifecycle_status).toBe("active");
  await scalar("select public.write_off_loan($1,4000,1,$2,$3,true)", [
    loanId,
    "Approved unpaid balance write-off",
    key,
  ]);
  expect((await loan()).lifecycle_status).toBe("active");
});
it("prints immutable receipts and statements with visible reversals and correct net effect", async () => {
  const document = await scalar("select public.receipt_document($1)", [first]);
  expect(document.receipt.payment_reference).toMatch(/^PAY-/);
  expect(document.receipt.posting_status).toBe("reversed");
  expect(document.receipt.receipt_snapshot.client.name).toBe("Mary Tembo");
  const statement = await scalar("select public.client_statement($1)", [
    client,
  ]);
  expect(
    statement.repayments.filter((r: any) => r.posting_status === "reversed")
      .length,
  ).toBe(2);
  const net = statement.repayments
    .filter((r: any) => r.posting_status === "posted")
    .reduce((sum: number, r: any) => sum + r.amount_cents, 0);
  expect(net).toBe(106000);
  expect(statement.loans[0].balance_cents).toBe(4000);
  expect(
    statement.status_audit.some((a: any) => a.action === "reverse_write_off"),
  ).toBe(true);
});
it("isolates documents and denies direct financial-operation/audit writes", async () => {
  await expect(db.query("delete from public.repayment_audit")).rejects.toThrow(
    "permission denied",
  );
  await expect(
    db.query("update public.financial_operations set result='{}'"),
  ).rejects.toThrow("permission denied");
  await user(other);
  expect(
    await scalar("select public.receipt_document($1)", [first]),
  ).toBeNull();
  expect(
    await scalar("select public.client_statement($1)", [client]),
  ).toBeNull();
  expect(
    Number(await scalar("select count(*) from public.repayment_register")),
  ).toBe(0);
  await expect(reverse(second)).rejects.toThrow("Administrator");
  await db.exec("reset role;set role anon");
  await expect(
    scalar("select public.receipt_document($1)", [first]),
  ).rejects.toThrow("permission denied");
  await user(owner);
});
