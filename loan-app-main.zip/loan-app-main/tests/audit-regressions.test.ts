import { PGlite } from "@electric-sql/pglite";
import { beforeAll, beforeEach, afterEach, afterAll, expect, it } from "vitest";
import { readFileSync, readdirSync } from "node:fs";
import { randomUUID } from "node:crypto";
import ExcelJS from "exceljs";
import { mappedRows } from "../lib/import-server";
import { buildReport, defaultReportFilters } from "../lib/reporting";
import { serviceError, definitePostingFailure } from "../lib/errors";
const db = new PGlite();
const ids = {
  admin: "11111111-1111-4111-8111-111111111111",
  cashier: "22222222-2222-4222-8222-222222222222",
  viewer: "33333333-3333-4333-8333-333333333333",
  foreign: "44444444-4444-4444-8444-444444444444",
};
let client: string, day: string;
async function query(sql: string, args: unknown[] = []) {
  await db.exec("savepoint audit_statement");
  try {
    const r = await db.query<Record<string, any>>(sql, args);
    await db.exec("release savepoint audit_statement");
    return r;
  } catch (e) {
    await db.exec(
      "rollback to savepoint audit_statement;release savepoint audit_statement",
    );
    throw e;
  }
}
async function scalar(sql: string, args: unknown[] = []): Promise<any> {
  return Object.values((await query(sql, args)).rows[0])[0];
}
async function actor(id: string) {
  await db.exec(
    `reset role;select set_config('request.jwt.claim.sub','${id}',true);select set_config('request.jwt.claims','{"session_id":"${id}"}',true);set local role authenticated;select public.touch_app_session();`,
  );
}
const details = () => ({
  client_id: client,
  expected_client_revision: 1,
  principal_cents: 100000,
  rate_bps: 1000,
  term_days: 30,
  disbursement_date: "2020-01-01",
  settings_revision: 1,
  calculation_method: "one_time_flat",
  rate_basis: "entire_term",
  override_reason: "",
});
async function loan() {
  return scalar("select public.originate_loan($1,$2,true)", [
    JSON.stringify(details()),
    randomUUID(),
  ]);
}
async function pay(id: string, amount: number, date = day, key = randomUUID()) {
  const l = await scalar(
    "select to_jsonb(l) from public.loan_register l where id=$1",
    [id],
  );
  const body = {
    loan_id: id,
    amount_cents: amount,
    payment_date: date,
    payment_method: "cash",
    expected_balance_cents: l.balance_cents,
    expected_terms_revision: l.terms_revision,
    expected_interest_outstanding_cents: l.interest_outstanding_cents,
    expected_principal_outstanding_cents: l.principal_outstanding_cents,
  };
  return scalar("select public.post_repayment($1,$2,true)", [
    JSON.stringify(body),
    key,
  ]);
}
beforeAll(async () => {
  await db.exec(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`,
  );
  for (const f of readdirSync("supabase/migrations").sort())
    await db.exec(readFileSync("supabase/migrations/" + f, "utf8"));
  for (const id of Object.values(ids))
    await db.query("insert into auth.users values($1)", [id]);
  await db.exec(
    `insert into public.businesses(id,name) values('${ids.admin}','Fictional audit business'),('${ids.foreign}','Fictional separate business');insert into public.ledger_settings(owner_id) values('${ids.admin}'),('${ids.foreign}');insert into public.user_roles(user_id,owner_id,role) values('${ids.admin}','${ids.admin}','administrator'),('${ids.cashier}','${ids.admin}','cashier'),('${ids.viewer}','${ids.admin}','viewer'),('${ids.foreign}','${ids.foreign}','administrator');`,
  );
}, 30000);
beforeEach(async () => {
  await db.exec("begin");
  await actor(ids.admin);
  day = await scalar(
    "select to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD')",
  );
  client = await scalar(
    "insert into public.clients(man_number,name,department,designation) values('000042','Fictional Audit Client','Audit','Audit') returning id",
  );
});
afterEach(() => db.exec("rollback"));
afterAll(() => db.close());

it("rejects control-bearing Man# through direct registration and correction without changing history", async () => {
  for (const man of ["000042\t", "000042\n", "000042\u007f"])
    await expect(
      query(
        "insert into public.clients(man_number,name,department,designation) values($1,'Fictional Duplicate','Audit','Audit')",
        [man],
      ),
    ).rejects.toThrow("clients_man_no_controls");
  expect(
    await scalar("select man_number from public.clients where id=$1", [client]),
  ).toBe("000042");
  await expect(
    scalar(
      "select public.correct_client($1,$2,'Fictional verified correction',1)",
      [
        client,
        JSON.stringify({
          man_number: "000042\t",
          name: "Fictional Audit Client",
          department: "Audit",
          designation: "Audit",
          is_active: true,
        }),
      ],
    ),
  ).rejects.toThrow("clients_man_no_controls");
  expect(Number(await scalar("select count(*) from public.client_audit"))).toBe(
    1,
  );
});
it("binds loan confirmation to Client revision, including Man# reassignment, without losing safe retries", async () => {
  const body = details(),
    key = randomUUID();
  const id = await scalar("select public.originate_loan($1,$2,true)", [
    JSON.stringify(body),
    key,
  ]);
  await scalar(
    "select public.correct_client($1,$2,'Fictional verified correction',1)",
    [
      client,
      JSON.stringify({
        man_number: "000099",
        name: "Fictional Audit Client",
        department: "Audit",
        designation: "Audit",
        is_active: true,
      }),
    ],
  );
  await query(
    "insert into public.clients(man_number,name,department,designation) values('000042','Fictional New Holder','Audit','Audit')",
  );
  await expect(
    scalar("select public.originate_loan($1,$2,true)", [
      JSON.stringify(body),
      randomUUID(),
    ]),
  ).rejects.toThrow("Client details changed");
  expect(
    await scalar("select public.originate_loan($1,$2,true)", [
      JSON.stringify(body),
      key,
    ]),
  ).toBe(id);
  await expect(
    scalar("select public.originate_loan_v8($1,$2,true)", [
      JSON.stringify(body),
      randomUUID(),
    ]),
  ).rejects.toThrow("permission denied");
  expect(Number(await scalar("select count(*) from public.loans"))).toBe(1);
});
it("rejects historically impossible backdated interest allocations atomically while keeping compatible backdating", async () => {
  const id = await loan();
  await scalar(
    "select public.adjust_loan_terms($1,2000,30,1,'Fictional approved rate increase',$2,true)",
    [id, randomUUID()],
  );
  await actor(ids.cashier);
  await expect(pay(id, 15000, "2020-01-10")).rejects.toThrow(
    "invalidate historical",
  );
  expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
    0,
  );
  expect(
    Number(await scalar("select count(*) from public.financial_operations")),
  ).toBe(0); // Cashier RLS hides request details too.
  await pay(id, 5000, "2020-01-10");
  const source = await scalar("select public.report_source()");
  const report = buildReport(source, {
    ...defaultReportFilters("2020-01-31"),
    from: "2020-01-01",
    to: "2020-01-31",
    asOf: "2020-01-31",
  });
  expect(report.totals).toMatchObject({
    interest: 5000,
    principal: 100000,
    owed: 105000,
    interestReceived: 5000,
  });
});
it("recovers only permitted posting results and supplies reconciling ledger positions in one snapshot", async () => {
  const id = await loan(),
    key = randomUUID();
  await actor(ids.cashier);
  const receipt = await pay(id, 15000, day, key);
  expect(
    await scalar("select public.posting_request_status($1,'post_repayment')", [
      key,
    ]),
  ).toEqual(receipt);
  expect(
    await scalar("select public.posting_request_status($1,'post_repayment')", [
      randomUUID(),
    ]),
  ).toBeNull();
  const snapshot = await scalar("select public.ledger_snapshot()");
  expect(
    snapshot.loans[0].balance_cents + snapshot.repayments[0].amount_cents,
  ).toBe(110000);
  expect(snapshot.loans[0]).toMatchObject({
    interest_outstanding_cents: 0,
    principal_outstanding_cents: 95000,
  });
  await actor(ids.viewer);
  await expect(
    scalar("select public.posting_request_status($1,'post_repayment')", [key]),
  ).rejects.toThrow("Permission denied");
  await actor(ids.foreign);
  expect(
    await scalar("select public.posting_request_status($1,'post_repayment')", [
      key,
    ]),
  ).toBeNull();
  expect((await scalar("select public.ledger_snapshot()")).loans).toEqual([]);
});
it("ignores amount-only workbook errors in register mode while preserving loan-mode and identity validation", async () => {
  const workbook = new ExcelJS.Workbook(),
    sheet = workbook.addWorksheet("Fictional");
  sheet.addRow(["no#", "name", "man#", "department", "designation", "amount"]);
  sheet.addRow([
    1,
    "Fictional Valid Client",
    "000043",
    "Audit",
    "Audit",
    { error: "#DIV/0!" },
  ]);
  const mapping = {
    source_no: 1,
    name: 2,
    man_number: 3,
    department: 4,
    designation: 5,
    amount: 6,
  };
  for (const mode of ["clients", "loans"] as const) {
    const rows = mappedRows(sheet, mapping, mode);
    expect(rows[0].parse_errors.length).toBe(mode === "clients" ? 0 : 1);
    if (mode === "clients") {
      const batch = await scalar(
        "select public.preview_import('fictional.xlsx',$1,'clients','{}',$2)",
        ["a".repeat(64), JSON.stringify(rows)],
      );
      expect(
        (await scalar("select public.import_report($1)", [batch])).batch,
      ).toMatchObject({ accepted: 1, rejected: 0 });
    }
  }
  sheet.getCell("B2").value = { error: "#VALUE!" };
  expect(mappedRows(sheet, mapping, "clients")[0].parse_errors).toContain(
    "name contains an Excel error.",
  );
});
it("gives safe, distinct recovery advice for transport, permission, authentication and version failures", () => {
  expect(serviceError({ code: "42501" })).toContain("role");
  expect(serviceError({ code: "PGRST301" })).toContain("Sign in");
  expect(serviceError({ code: "PGRST202" })).toContain(
    "only pending migrations",
  );
  expect(serviceError(new Error("Failed to fetch"))).toContain("connection");
  expect(definitePostingFailure({ code: "P0001" })).toBe(true);
  expect(definitePostingFailure({ code: "", message: "Failed to fetch" })).toBe(
    false,
  );
});

it("certifies only the reviewed business period, excludes principal, and invalidates profit on later financial events", async () => {
  const id = await loan();
  await pay(id, 15000);
  await scalar("select public.post_expense($1,$2,true)", [
    JSON.stringify({
      amount: "20.00",
      expense_date: day,
      currency: "ZMW",
      category: "Audit costs",
      description: "Fictional recorded business costs",
      payment_method: "cash",
    }),
    randomUUID(),
  ]);
  const filters = {
    ...defaultReportFilters(day),
    from: day,
    to: day,
    asOf: day,
  };
  let source = await scalar("select public.report_source_filtered($1)", [
    JSON.stringify(filters),
  ]);
  expect(buildReport(source, filters).netProfit).toBeNull();
  await expect(
    scalar(
      "select public.certify_reporting_period($1,$2,'ZMW','Fictional full coverage review',true,true,0,$3,true)",
      [day, day, randomUUID()],
    ),
  ).rejects.toThrow("Financial history changed");
  const certification = await scalar(
    "select public.certify_reporting_period($1,$2,'ZMW','Fictional full coverage review',true,true,$3,$4,true)",
    [day, day, source.ledger_event_count, randomUUID()],
  );
  await actor(ids.viewer);
  source = await scalar("select public.report_source_filtered($1)", [
    JSON.stringify(filters),
  ]);
  const report = buildReport(source, filters);
  expect(report.totals).toMatchObject({
    received: 15000,
    interestReceived: 10000,
    principalReceived: 5000,
  });
  expect(report.netProfit).toBe(8000);
  expect(report.certification?.id).toBe(certification.certification_id);
  expect(
    buildReport(source, { ...filters, department: "Audit" }).netProfit,
  ).toBeNull();
  await expect(
    scalar(
      "select public.certify_reporting_period($1,$2,'ZMW','Forbidden Viewer coverage',true,true,$3,$4,true)",
      [day, day, source.ledger_event_count, randomUUID()],
    ),
  ).rejects.toThrow("Permission denied");
  await actor(ids.admin);
  await pay(id, 1000);
  source = await scalar("select public.report_source_filtered($1)", [
    JSON.stringify(filters),
  ]);
  expect(buildReport(source, filters).netProfit).toBeNull();
});
it("supports explicit zero-expense certification and immutable audited revocation", async () => {
  const id = await loan();
  await pay(id, 5000);
  const filters = { ...defaultReportFilters(day), from: day, to: day };
  let source = await scalar("select public.report_source_filtered($1)", [
    JSON.stringify(filters),
  ]);
  const r = await scalar(
    "select public.certify_reporting_period($1,$2,'ZMW','Fictional reviewed zero expenses and losses',true,true,$3,$4,true)",
    [day, day, source.ledger_event_count, randomUUID()],
  );
  source = await scalar("select public.report_source_filtered($1)", [
    JSON.stringify(filters),
  ]);
  expect(buildReport(source, filters)).toMatchObject({
    expenses: 0,
    netProfit: 5000,
  });
  await expect(
    query("delete from public.reporting_certifications"),
  ).rejects.toThrow("permission denied");
  await scalar(
    "select public.revoke_reporting_certification($1,'Fictional approval withdrawal',$2,true)",
    [r.certification_id, randomUUID()],
  );
  source = await scalar("select public.report_source_filtered($1)", [
    JSON.stringify(filters),
  ]);
  expect(buildReport(source, filters).netProfit).toBeNull();
  expect(
    Number(
      await scalar(
        "select count(*) from public.audit_events where entity_type='Report Coverage'",
      ),
    ),
  ).toBe(2);
});
it("filters reporting history on the server with literal search and business isolation", async () => {
  await loan();
  const filters = { ...defaultReportFilters(day), from: "2020-01-01" };
  expect(
    (
      await scalar("select public.report_source_filtered($1)", [
        JSON.stringify(filters),
      ])
    ).loans,
  ).toHaveLength(1);
  expect(
    (
      await scalar("select public.report_source_filtered($1)", [
        JSON.stringify({ ...filters, search: "%" }),
      ])
    ).loans,
  ).toEqual([]);
  expect(
    (
      await scalar("select public.report_source_filtered($1)", [
        JSON.stringify({ ...filters, department: "Other" }),
      ])
    ).loans,
  ).toEqual([]);
  await actor(ids.foreign);
  const source = await scalar("select public.report_source_filtered($1)", [
    JSON.stringify(filters),
  ]);
  expect(source.loans).toEqual([]);
  expect(source.certifications).toEqual([]);
});
it("requires recent signed-session TOTP assurance for opt-in Administrator policies and privileged RPCs", async () => {
  await expect(
    scalar(
      "select public.set_admin_mfa_policy(true,'Fictional strong authentication policy',$1,true)",
      [randomUUID()],
    ),
  ).rejects.toThrow("Verify a TOTP");
  await query(
    "select set_config('request.jwt.claims',(coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb || $1::jsonb)::text,true)",
    [
      JSON.stringify({
        aal: "aal2",
        amr: [{ method: "totp", timestamp: Math.floor(Date.now() / 1000) }],
      }),
    ],
  );
  await scalar(
    "select public.set_admin_mfa_policy(true,'Fictional strong authentication policy',$1,true)",
    [randomUUID()],
  );
  expect(
    (await scalar("select public.account_security()")).admin_mfa_required,
  ).toBe(true);
  await query(
    "select set_config('request.jwt.claims',(coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb || $1::jsonb)::text,true)",
    [JSON.stringify({ aal: "aal1", user_metadata: { aal: "aal2" } })],
  );
  expect(await scalar("select public.has_capability('admin')")).toBe(false);
  await expect(
    scalar(
      "select public.manage_user_role($1,'viewer',false,1,'Fictional suspended account',$2,true)",
      [ids.viewer, randomUUID()],
    ),
  ).rejects.toThrow("Additional authentication");
  expect(await scalar("select public.has_capability('read')")).toBe(true);
  await query(
    "select set_config('request.jwt.claims',(coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb || $1::jsonb)::text,true)",
    [
      JSON.stringify({
        aal: "aal2",
        amr: [
          { method: "totp", timestamp: Math.floor(Date.now() / 1000) - 1000 },
        ],
      }),
    ],
  );
  expect(await scalar("select public.has_capability('admin')")).toBe(false);
  await query(
    "select set_config('request.jwt.claims',(coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb || $1::jsonb)::text,true)",
    [
      JSON.stringify({
        aal: "aal2",
        amr: [{ method: "totp", timestamp: Math.floor(Date.now() / 1000) }],
      }),
    ],
  );
  expect(await scalar("select public.has_capability('admin')")).toBe(true);
  await scalar(
    "select public.set_admin_mfa_policy(false,'Fictional approved policy recovery',$1,true)",
    [randomUUID()],
  );
  await query(
    "select set_config('request.jwt.claims',jsonb_build_object('session_id',auth.uid())::text,true)",
  );
  expect(await scalar("select public.has_capability('admin')")).toBe(true);
});
