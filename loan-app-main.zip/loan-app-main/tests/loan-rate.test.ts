import { it, expect } from "vitest";
import { loanRateTerms } from "../lib/loan-rate";
import { demoDefaults } from "../lib/interest";
const editable = {
  ...demoDefaults,
  settings: Object.freeze({ ...demoDefaults.settings }),
  capabilities: { ...demoDefaults.capabilities, can_override_rate: true },
};
it("recognizes the default rate by numeric value and requires no override reason", () => {
  expect(loanRateTerms("10.00", demoDefaults, "unused")).toEqual({
    bps: 1000,
    override: false,
    overrideReason: "",
  });
});
it("validates a per-loan override without mutating the frozen default snapshot", () => {
  const before = structuredClone(editable);
  expect(
    loanRateTerms("12.50", editable, "  Approved Client exception  "),
  ).toEqual({
    bps: 1250,
    override: true,
    overrideReason: "Approved Client exception",
  });
  expect(editable).toEqual(before);
});
it("rejects overrides without the explicit database capability, including interest-free exceptions", () => {
  for (const value of ["12", "0"])
    expect(() =>
      loanRateTerms(value, demoDefaults, "Approved exception"),
    ).toThrow("override permission");
});
it.each(["-1", "100.01", "1.001", "1e2", "12%", "", "100.001"])(
  "rejects unsupported rate input without silently truncating it: %s",
  (value) => {
    expect(() =>
      loanRateTerms(value, editable, "Approved exception"),
    ).toThrow();
  },
);
it("enforces the existing trimmed 5–500 character override reason rule", () => {
  expect(() => loanRateTerms("12", editable, " abcd ")).toThrow("5–500");
  expect(() => loanRateTerms("12", editable, "x".repeat(501))).toThrow("5–500");
  expect(
    loanRateTerms("12", editable, "x".repeat(5)).overrideReason,
  ).toHaveLength(5);
  expect(
    loanRateTerms("12", editable, "x".repeat(500)).overrideReason,
  ).toHaveLength(500);
});
it("accepts authorized zero and 100 percent rates using integer basis points", () => {
  expect(
    loanRateTerms("0", editable, "Approved zero-interest exception").bps,
  ).toBe(0);
  expect(
    loanRateTerms("100", editable, "Approved maximum-rate exception").bps,
  ).toBe(10000);
});

it("matches PostgreSQL character counts for Unicode audit reasons", () => {
  expect(() => loanRateTerms("12", editable, "😀😀😀")).toThrow("5–500");
  expect(loanRateTerms("12", editable, "😀😀😀😀😀").overrideReason).toBe(
    "😀😀😀😀😀",
  );
});
