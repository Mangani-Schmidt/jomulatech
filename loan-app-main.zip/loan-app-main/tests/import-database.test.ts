import { PGlite } from "@electric-sql/pglite";
import { beforeAll, afterAll, describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
const db = new PGlite();
const owner = "11111111-1111-4111-8111-111111111111";
const other = "22222222-2222-4222-8222-222222222222";
async function scalar<T = unknown>(sql: string, args: unknown[] = []) {
  const { rows } = await db.query<Record<string, T>>(sql, args);
  return Object.values(rows[0])[0];
}
const row = (change: Record<string, unknown> = {}) => ({
  source_no: "1",
  name: "Mary Tembo",
  man_number: "00124",
  department: "Health",
  designation: "Nurse",
  amount: "1000.00",
  man_numeric: false,
  parse_errors: [],
  ...change,
});
const terms = {
  disbursement_date: "2026-01-01",
  interest_type: "flat_percent",
  interest_value: "10.00",
  due_rule: "days_after_disbursement",
  term_days: 30,
};
async function preview(
  rows: unknown[],
  mode = "clients",
  loanTerms: unknown = {},
) {
  return scalar<string>("select public.preview_import($1,$2,$3,$4,$5)", [
    "book.xlsx",
    "a".repeat(64),
    mode,
    JSON.stringify(loanTerms),
    JSON.stringify(rows),
  ]);
}
async function report(id: string) {
  return scalar<any>("select public.import_report($1)", [id]);
}
async function commit(id: string, version = 1, confirm = true) {
  return scalar<string>("select public.commit_import($1,$2,$3)", [
    id,
    version,
    confirm,
  ]);
}
async function user(id: string) {
  await db.exec(
    `reset role;select set_config('request.jwt.claim.sub','${id}',false);set role authenticated`,
  );
}
beforeAll(async () => {
  await db.exec(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;insert into auth.users values('${owner}'),('${other}');`,
  );
  for (const file of ["001_ledger", "002_client_register", "003_excel_import"])
    await db.exec(readFileSync(`supabase/migrations/${file}.sql`, "utf8"));
  await user(owner);
}, 30000);
afterAll(() => db.close());
describe("staged imports and financial authorization", () => {
  it("requires explicit mode and validates server-side even without the UI", async () => {
    await expect(preview([row()], "automatic")).rejects.toThrow(
      "explicit import mode",
    );
    await expect(preview([row()], "loans")).rejects.toThrow(
      "Disbursement date",
    );
    await expect(
      preview([row()], "loans", { ...terms, interest_value: "-1" }),
    ).rejects.toThrow("interest terms");
    await expect(
      preview([row()], "loans", { ...terms, term_days: 0 }),
    ).rejects.toThrow("Term");
    await expect(preview([row()], "clients", terms)).rejects.toThrow(
      "does not accept",
    );
  });
  it("previews register details without writing Clients or loans, ignoring amount", async () => {
    const id = await preview([row({ amount: "not a monetary value" })]);
    const result = await report(id);
    expect(result.batch.accepted).toBe(1);
    expect(result.rows[0].warnings[0]).toContain("ignored");
    expect(Number(await scalar("select count(*) from public.clients"))).toBe(0);
    expect(Number(await scalar("select count(*) from public.loans"))).toBe(0);
    await expect(commit(id, 1, false)).rejects.toThrow("confirmation");
    await commit(id);
    expect(Number(await scalar("select count(*) from public.clients"))).toBe(1);
    expect(Number(await scalar("select count(*) from public.loans"))).toBe(0);
    expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
      0,
    );
    expect(await scalar("select man_number from public.clients")).toBe("00124");
    expect((await report(id)).batch.uploaded_by).toBe(owner);
  });
  it("protects duplicate submissions after filename, row number, and amount changes in register mode", async () => {
    const id = await preview([row({ source_no: "99", amount: "5000" })]);
    const result = await report(id);
    expect(result.batch.status).toBe("completed");
    expect(Number(await scalar("select count(*) from public.clients"))).toBe(1);
    await commit(id);
    expect(
      Number(await scalar("select count(*) from public.client_audit")),
    ).toBe(1);
  });
  it("classifies unchanged, conflicts, duplicates and invalid rows distinctly", async () => {
    const id = await preview([
      row(),
      row({ source_no: "2", man_number: "002", name: "New Client" }),
      row({ source_no: "3", man_number: "003", name: "One" }),
      row({ source_no: "4", man_number: "003", name: "Two" }),
      row({ source_no: "5", man_number: "00124", name: "Wrong Name" }),
      row({ source_no: "6", man_number: "004", department: "" }),
    ]);
    const result = await report(id);
    expect(result.batch).toMatchObject({
      accepted: 1,
      rejected: 5,
      unchanged: 0,
    });
    expect(result.rows[0].errors.join(" ")).toContain("Duplicate");
    expect(result.rows[5].errors.join(" ")).toContain("department");
    await commit(id);
    expect(Number(await scalar("select count(*) from public.clients"))).toBe(2);
    expect(
      await scalar("select name from public.clients where man_number='00124'"),
    ).toBe("Mary Tembo");
  });
  it("records unchanged rows without adding or overwriting a Client", async () => {
    const id = await preview([row({ man_number: "002", name: "New Client" })]);
    const result = await report(id);
    expect(result.batch.unchanged).toBe(1);
    await commit(id);
    expect((await report(id)).rows[0].client_id).toBeTruthy();
  });
  it("rejects conflicts instead of silently overwriting existing details", async () => {
    const id = await preview([row({ name: "Changed Name" })]);
    const result = await report(id);
    expect(result.batch.rejected).toBe(1);
    expect(result.rows[0].errors.join(" ")).toContain("Conflicting");
    await expect(commit(id)).rejects.toThrow("No accepted rows");
  });
  it("creates loans only with explicit terms, preserving existing loans and Clients", async () => {
    const id = await preview(
      [
        row(),
        row({
          source_no: "2",
          man_number: "005",
          name: "Another Client",
          amount: "500.01",
          man_numeric: true,
        }),
      ],
      "loans",
      terms,
    );
    const result = await report(id);
    expect(result.batch.accepted).toBe(2);
    expect(result.rows[1].warnings[0]).toContain("numerically");
    await commit(id);
    const { rows } = await db.query<any>(
      "select * from public.loans order by principal_cents desc",
    );
    expect(Number(rows[0].principal_cents)).toBe(100000);
    expect(Number(rows[0].interest_cents)).toBe(10000);
    expect(Number(rows[0].balance_cents)).toBe(110000);
    expect(String(rows[0].due_date)).toContain("Jan 31");
    expect(Number(rows[1].interest_cents)).toBe(5000);
    expect(rows[0].import_batch_id).toBe(id);
    expect(Number(await scalar("select count(*) from public.repayments"))).toBe(
      0,
    );
    await commit(id);
    expect(Number(await scalar("select count(*) from public.loans"))).toBe(2);
  });
  it("deduplicates loan submissions despite row ordering, numeric amount formatting, or no# changes", async () => {
    const id = await preview(
      [
        row({
          source_no: "200",
          man_number: "005",
          name: "Another Client",
          amount: "0500.01",
        }),
        row({ source_no: "400", amount: "1000" }),
      ],
      "loans",
      { ...terms, interest_value: "10" },
    );
    expect((await report(id)).batch.status).toBe("completed");
    await commit(id);
    expect(Number(await scalar("select count(*) from public.loans"))).toBe(2);
  });
  it("requires explicit confirmation and rejects invalid loan amounts in preview", async () => {
    const id = await preview(
      [
        row({ amount: "0" }),
        row({ source_no: "2", man_number: "100", amount: "-50" }),
        row({ source_no: "3", man_number: "101", amount: "1.001" }),
      ],
      "loans",
      terms,
    );
    expect((await report(id)).batch.rejected).toBe(3);
  });
  it("detects changed Client revisions at confirmation and supports a new preview", async () => {
    const id = await preview([row({ amount: "12.34" })], "loans", terms);
    await scalar(
      "select public.correct_client((select id from public.clients where man_number='00124'),$1,$2,1)",
      [
        JSON.stringify({
          man_number: "00124",
          name: "Mary Tembo",
          department: "Health",
          designation: "Nurse",
          phone: "updated",
          is_active: true,
        }),
        "Verified phone correction",
      ],
    );
    await expect(commit(id)).rejects.toThrow("Client register changed");
    const again = await preview([row({ amount: "12.34" })], "loans", terms);
    expect(again).toBe(id);
    await expect(commit(id, 1)).rejects.toThrow("Preview changed");
    await commit(id, 2);
    expect(Number(await scalar("select count(*) from public.loans"))).toBe(3);
  });
  it("uses fixed interest per loan and a disbursement-relative due date", async () => {
    const id = await preview(
      [
        row({
          man_number: "006",
          name: "Fixed Interest Client",
          amount: "20.00",
        }),
      ],
      "loans",
      {
        ...terms,
        interest_type: "fixed",
        interest_value: "2.55",
        term_days: 7,
      },
    );
    await commit(id);
    const {
      rows: [loan],
    } = await db.query<any>(
      "select * from public.loans where import_batch_id=$1",
      [id],
    );
    expect(Number(loan.interest_cents)).toBe(255);
    expect(Number(loan.balance_cents)).toBe(2255);
  });
  it("isolates imports/history by account and revokes the old immediate import API", async () => {
    const id = await scalar<string>(
      "select id from public.import_batches limit 1",
    );
    await user(other);
    expect(await report(id)).toBeNull();
    expect(
      Number(await scalar("select count(*) from public.import_batches")),
    ).toBe(0);
    await expect(commit(id)).rejects.toThrow("Import not found");
    await expect(
      db.query("select public.import_clients($1)", [JSON.stringify([row()])]),
    ).rejects.toThrow("permission denied");
    await expect(
      db.query("update public.import_batches set status='completed'"),
    ).rejects.toThrow("permission denied");
    await user(owner);
    await db.exec("reset role;set role anon");
    await expect(db.query("select * from public.import_rows")).rejects.toThrow(
      "permission denied",
    );
    await expect(commit(id)).rejects.toThrow("permission denied");
    await user(owner);
  });
});
it("preserves existing loans when a new register import contains amounts", async () => {
  const before = await db.query(
    "select id,client_id,principal_cents,interest_cents,balance_cents,due_date,disbursement_date from public.loans order by id",
  );
  const id = await preview([
    row({
      man_number: "NEW009",
      name: "Register Only Client",
      amount: "999999.99",
    }),
  ]);
  await commit(id);
  const after = await db.query(
    "select id,client_id,principal_cents,interest_cents,balance_cents,due_date,disbursement_date from public.loans order by id",
  );
  expect(after.rows).toEqual(before.rows);
});
it("rolls back every new Client, audit entry, and loan if a later row becomes stale", async () => {
  const id = await preview(
    [
      row({ man_number: "00001", name: "Atomic Client", amount: "50" }),
      row({
        source_no: "2",
        man_number: "002",
        name: "New Client",
        amount: "20",
      }),
    ],
    "loans",
    terms,
  );
  await scalar(
    "select public.correct_client((select id from public.clients where man_number='002'),$1,$2,1)",
    [
      JSON.stringify({
        man_number: "002",
        name: "New Client",
        department: "Health",
        designation: "Nurse",
        phone: "changed",
        is_active: true,
      }),
      "Verified updated phone",
    ],
  );
  const before = [
    Number(await scalar("select count(*) from public.clients")),
    Number(await scalar("select count(*) from public.client_audit")),
    Number(await scalar("select count(*) from public.loans")),
  ];
  await expect(commit(id)).rejects.toThrow("Client register changed");
  expect([
    Number(await scalar("select count(*) from public.clients")),
    Number(await scalar("select count(*) from public.client_audit")),
    Number(await scalar("select count(*) from public.loans")),
  ]).toEqual(before);
  expect(
    Number(
      await scalar(
        "select count(*) from public.clients where man_number='00001'",
      ),
    ),
  ).toBe(0);
  expect((await report(id)).batch.status).toBe("preview");
});
it("rejects malformed direct RPC row envelopes instead of storing unsafe report data", async () => {
  await expect(preview([null])).rejects.toThrow("rows must be objects");
  await expect(
    preview([row({ name: { unexpected: "object" } })]),
  ).rejects.toThrow("cell values must be strings");
  await expect(
    preview([row({ parse_errors: [{ bad: "diagnostic" }] })]),
  ).rejects.toThrow("Invalid row diagnostic");
});
