import { PGlite } from "@electric-sql/pglite";
import { beforeAll, afterAll, it, expect } from "vitest";
import { readFileSync, readdirSync } from "node:fs";
const db = new PGlite();
const ids = {
  admin: "11111111-1111-4111-8111-111111111111",
  officer: "22222222-2222-4222-8222-222222222222",
  cashier: "33333333-3333-4333-8333-333333333333",
  viewer: "44444444-4444-4444-8444-444444444444",
  other: "55555555-5555-4555-8555-555555555555",
  pending: "66666666-6666-4666-8666-666666666666",
};
let client: string,
  loanId: string,
  day: string,
  receipt: string,
  expense: string;
async function scalar(sql: string, args: unknown[] = []): Promise<any> {
  const { rows } = await db.query<Record<string, any>>(sql, args);
  return Object.values(rows[0])[0];
}
async function user(id: string) {
  await db.exec(
    `reset role;select set_config('request.jwt.claim.sub','${id}',false);set role authenticated`,
  );
}
async function assign(id: string, role: string, active = true, revision = 0) {
  return scalar(
    "select public.manage_user_role($1,$2,$3,$4,$5,gen_random_uuid(),true)",
    [id, role, active, revision, "Approved staff role assignment"],
  );
}
async function originate() {
  return scalar("select public.originate_loan($1,gen_random_uuid(),true)", [
    JSON.stringify({
      client_id: client,
      principal_cents: 100000,
      rate_bps: 1000,
      term_days: 30,
      disbursement_date: day,
      settings_revision: 1,
      calculation_method: "one_time_flat",
      rate_basis: "entire_term",
      override_reason: "",
    }),
  ]);
}
async function payment(amount = 15000) {
  const l = await scalar(
    "select to_jsonb(l) from public.loan_register l where id=$1",
    [loanId],
  );
  return scalar("select public.post_repayment($1,gen_random_uuid(),true)", [
    JSON.stringify({
      loan_id: loanId,
      amount_cents: amount,
      payment_date: day,
      payment_method: "cash",
      expected_balance_cents: l.balance_cents,
      expected_terms_revision: l.terms_revision,
      expected_interest_outstanding_cents: l.interest_outstanding_cents,
      expected_principal_outstanding_cents: l.principal_outstanding_cents,
    }),
  ]);
}
beforeAll(async () => {
  await db.exec(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`,
  );
  for (const id of Object.values(ids))
    await db.query("insert into auth.users values($1)", [id]);
  for (const name of readdirSync("supabase/migrations")
    .sort()
    .filter((n) => n < "008"))
    await db.exec(readFileSync("supabase/migrations/" + name, "utf8"));
  await db.query(
    "insert into public.account_permissions values($1,true,true),($2,true,true)",
    [ids.admin, ids.other],
  );
  await user(ids.admin);
  day = await scalar(
    "select to_char(statement_timestamp() at time zone 'Africa/Lusaka','YYYY-MM-DD')",
  );
  client = await scalar(
    "insert into public.clients(man_number,name,department,designation) values('00124','Mary Tembo','Health','Nurse') returning id",
  );
  loanId = await originate();
  await db.exec("reset role");
  await db.exec(
    readFileSync("supabase/migrations/008_roles_and_expenses.sql", "utf8"),
  );
  await user(ids.admin);
  await assign(ids.officer, "loan_officer");
  await assign(ids.cashier, "cashier");
  await assign(ids.viewer, "viewer");
}, 30000);
afterAll(() => db.close());
it("preserves historical records, amounts and creators while using exact numeric storage", async () => {
  const l = await scalar(
    "select to_jsonb(l) from public.loan_register l where id=$1",
    [loanId],
  );
  expect(l).toMatchObject({
    id: loanId,
    client_id: client,
    principal_cents: 100000,
    interest_cents: 10000,
    balance_cents: 110000,
    created_by: ids.admin,
    amount_disbursed: 1000,
  });
  const types = await db.query<{ data_type: string }>(
    "select data_type from information_schema.columns where table_schema=$1 and table_name=$2 and column_name in ($3,$4,$5)",
    ["public", "loans", "principal_cents", "interest_cents", "balance_cents"],
  );
  expect(types.rows.every((r) => r.data_type === "numeric")).toBe(true);
});
it("lets a Loan Officer register and correct a Client and originate, with the actual staff actor", async () => {
  await user(ids.officer);
  const c = await scalar(
    "insert into public.clients(man_number,name,department,designation) values('00025','Chanda Mwansa','Finance','Analyst') returning to_jsonb(clients)",
  );
  expect(c.owner_id).toBe(ids.admin);
  expect(c.created_by).toBe(ids.officer);
  await scalar("select public.correct_client($1,$2,$3,1)", [
    c.id,
    JSON.stringify({
      ...c,
      man_number: "00025",
      name: "Chanda Mwansa",
      department: "Finance",
      designation: "Coordinator",
      phone: "",
      email: "",
      address: "",
      is_active: true,
      ...Object.fromEntries(
        Object.keys(c)
          .filter(
            (k) =>
              ![
                "man_number",
                "name",
                "department",
                "designation",
                "phone",
                "email",
                "address",
                "is_active",
              ].includes(k),
          )
          .map((k) => [k, undefined]),
      ),
    }),
    "Verified designation correction",
  ]);
  const id = await originate();
  const l = await scalar("select to_jsonb(l) from public.loans l where id=$1", [
    id,
  ]);
  expect(l.owner_id).toBe(ids.admin);
  expect(l.created_by).toBe(ids.officer);
  await expect(payment()).rejects.toThrow("Permission denied");
  await expect(assign(ids.pending, "administrator")).rejects.toThrow(
    "Permission denied",
  );
  await expect(
    scalar(
      "select public.preview_import('file.xlsx',repeat('a',64),'clients','{}','[]')",
    ),
  ).rejects.toThrow("Permission denied");
});
it("lets a Cashier post repayments/print receipts but denies Client/loan/administrative writes", async () => {
  await user(ids.cashier);
  receipt = (await payment()).repayment_id;
  const doc = await scalar("select public.receipt_document($1)", [receipt]);
  expect(doc.receipt.created_by).toBe(ids.cashier);
  expect(doc.receipt.owner_id).toBe(ids.admin);
  expect(doc.receipt.interest_allocation_cents).toBe(10000);
  await expect(
    db.exec(
      "insert into public.clients(man_number,name,department,designation) values('00026','Denied Client','Health','Nurse')",
    ),
  ).rejects.toThrow();
  await expect(originate()).rejects.toThrow("Permission denied");
  await expect(
    scalar("select public.reverse_repayment($1,$2,gen_random_uuid(),true)", [
      receipt,
      "Attempted unauthorized reversal",
    ]),
  ).rejects.toThrow("Permission denied");
  await expect(
    scalar(
      "select public.adjust_loan_terms($1,500,30,1,$2,gen_random_uuid(),true)",
      [loanId, "Unauthorized term adjustment"],
    ),
  ).rejects.toThrow("Permission denied");
  await expect(
    scalar(
      "select public.write_off_loan($1,95000,1,$2,gen_random_uuid(),true)",
      [loanId, "Unauthorized write-off"],
    ),
  ).rejects.toThrow("Permission denied");
});
it("keeps Viewer access read-only even when bypassing the interface", async () => {
  await user(ids.viewer);
  expect((await scalar("select public.report_source()")).loans.length).toBe(2);
  expect(
    (await scalar("select public.loan_defaults()")).capabilities,
  ).toMatchObject({
    role: "viewer",
    can_read: true,
    can_register_clients: false,
    can_originate: false,
    can_post_repayments: false,
    can_import: false,
  });
  for (const sql of [
    "update public.loans set balance_cents=0",
    "delete from public.repayments",
    "insert into public.expenses(owner_id) values(null)",
    "update public.user_roles set role='administrator'",
    "delete from public.audit_events",
    "update public.ledger_settings set default_rate_bps=0",
    "update public.account_permissions set is_admin=true",
  ])
    await expect(db.exec(sql)).rejects.toThrow("permission denied");
  await expect(payment()).rejects.toThrow("Permission denied");
  await expect(originate()).rejects.toThrow("Permission denied");
  await expect(
    scalar("select public.post_expense('{}',gen_random_uuid(),true)"),
  ).rejects.toThrow("Permission denied");
});
it("requires Administrator approval for financial reversals and retains the correct audit actors", async () => {
  await user(ids.admin);
  await scalar(
    "select public.reverse_repayment($1,$2,gen_random_uuid(),true)",
    [receipt, "Approved verified repayment reversal"],
  );
  const r = await scalar(
    "select to_jsonb(r) from public.repayments r where id=$1",
    [receipt],
  );
  expect(r.reversed_by).toBe(ids.admin);
  expect(r.created_by).toBe(ids.cashier);
  const audit = await scalar(
    "select jsonb_agg(to_jsonb(a)) from public.audit_events a where entity_type='Repayment'",
  );
  expect(
    audit.some((a: any) => a.action === "post" && a.actor_id === ids.cashier),
  ).toBe(true);
  expect(
    audit.some((a: any) => a.action === "reverse" && a.actor_id === ids.admin),
  ).toBe(true);
});
it("records exact-decimal expenses idempotently and permits only authorized immutable reversals", async () => {
  const details = {
    amount: "0.29",
    expense_date: day,
    currency: "ZMW",
    category: "Bank fees",
    description: "Recorded bank transfer charge",
    payment_method: "bank_transfer",
    external_reference: "FEE-001",
  };
  const key = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";
  const post = () =>
    scalar("select public.post_expense($1,$2,true)", [
      JSON.stringify(details),
      key,
    ]);
  expense = (await post()).expense_id;
  expect((await post()).expense_id).toBe(expense);
  const e = await scalar(
    "select to_jsonb(e) from public.expenses e where id=$1",
    [expense],
  );
  expect(e.amount).toBe(0.29);
  expect(e.amount_cents).toBe(29);
  expect(e.created_by).toBe(ids.admin);
  await expect(
    scalar("select public.post_expense($1,gen_random_uuid(),true)", [
      JSON.stringify({ ...details, amount: "0.291" }),
    ]),
  ).rejects.toThrow("two decimals");
  await expect(db.exec("delete from public.expenses")).rejects.toThrow(
    "permission denied",
  );
  await scalar("select public.reverse_expense($1,$2,gen_random_uuid(),true)", [
    expense,
    "Approved duplicate bank fee reversal",
  ]);
  expect(
    await scalar("select reversed_by from public.expenses where id=$1", [
      expense,
    ]),
  ).toBe(ids.admin);
  await expect(
    scalar("select public.reverse_expense($1,$2,gen_random_uuid(),true)", [
      expense,
      "Attempted repeated expense reversal",
    ]),
  ).rejects.toThrow("already reversed");
  expect(
    Number(
      await scalar(
        "select count(*) from public.audit_events where entity_type='Expense'",
      ),
    ),
  ).toBe(2);
});
it("denies cross-business access, unassigned/suspended users, privilege spoofing and self-demotion", async () => {
  await user(ids.other);
  expect((await scalar("select public.report_source()")).loans).toEqual([]);
  await expect(
    scalar("select public.reverse_repayment($1,$2,gen_random_uuid(),true)", [
      receipt,
      "Cross-business reversal attempt",
    ]),
  ).rejects.toThrow("not found");
  await user(ids.pending);
  expect((await scalar("select public.report_source()")).clients).toEqual([]);
  await expect(scalar("select public.loan_defaults()")).rejects.toThrow(
    "Permission denied",
  );
  await user(ids.admin);
  await expect(assign(ids.other, "cashier", true, 1)).rejects.toThrow(
    "another business",
  );
  await expect(assign(ids.admin, "viewer", true, 1)).rejects.toThrow(
    "cannot demote",
  );
  await assign(ids.cashier, "cashier", false, 1);
  await user(ids.cashier);
  expect((await scalar("select public.report_source()")).loans).toEqual([]);
  await expect(
    scalar("select public.post_repayment('{}',gen_random_uuid(),true)"),
  ).rejects.toThrow("Permission denied");
});
it("restricts privileged helper execution, denies anonymous access, and fixes definer search paths", async () => {
  await user(ids.admin);
  const helpers = [
    "begin_financial_operation(uuid,text,jsonb)",
    "post_receipt_internal(jsonb,uuid,uuid)",
    "preview_import_v3(text,text,text,jsonb,jsonb)",
    "write_off_loan_v5(uuid,bigint,integer,text,uuid,boolean)",
    "require_capability(text)",
  ];
  for (const fn of helpers)
    expect(
      await scalar(
        "select has_function_privilege('authenticated',$1,'execute')",
        ["public." + fn],
      ),
    ).toBe(false);
  const unsafe = await scalar(
    "select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.prosecdef and not coalesce(p.proconfig @> array['search_path=\"\"'],false)",
  );
  expect(Number(unsafe)).toBe(0);
  await db.exec("reset role;set role anon");
  await expect(scalar("select public.report_source()")).rejects.toThrow(
    "permission denied",
  );
  await expect(scalar("select public.has_capability('admin')")).rejects.toThrow(
    "permission denied",
  );
});
it("allows only Administrators to stage and commit imports, preserving uploader and loan creator", async () => {
  await user(ids.admin);
  const row = {
    source_no: "1",
    name: "Imported Client",
    man_number: "00027",
    department: "Finance",
    designation: "Analyst",
    amount: "100.01",
    man_numeric: false,
    parse_errors: [],
  };
  const terms = {
    disbursement_date: day,
    interest_type: "flat_percent",
    interest_value: "10",
    due_rule: "days_after_disbursement",
    term_days: 30,
    settings_revision: 1,
    calculation_method: "one_time_flat",
    rate_basis: "entire_term",
  };
  const id = await scalar("select public.preview_import($1,$2,$3,$4,$5)", [
    "loans.xlsx",
    "a".repeat(64),
    "loans",
    JSON.stringify(terms),
    JSON.stringify([row]),
  ]);
  await scalar("select public.commit_import($1,1,true)", [id]);
  const report = await scalar("select public.import_report($1)", [id]);
  expect(report.batch.uploaded_by).toBe(ids.admin);
  expect(report.batch.accepted).toBe(1);
  const imported = await scalar(
    "select to_jsonb(l) from public.loans l where import_batch_id=$1",
    [id],
  );
  expect(imported).toMatchObject({
    principal_cents: 10001,
    interest_cents: 1000,
    created_by: ids.admin,
    owner_id: ids.admin,
  });
  expect(
    Number(
      await scalar(
        "select count(*) from public.audit_events where entity_type='Import' and action='import_completed'",
      ),
    ),
  ).toBe(1);
  await user(ids.officer);
  expect(await scalar("select public.import_report($1)", [id])).toBeNull();
  await expect(
    scalar("select public.commit_import($1,1,true)", [id]),
  ).rejects.toThrow("Permission denied");
});
it("ignores spoofed JWT metadata and rejects unapproved financial mutations", async () => {
  await user(ids.viewer);
  await db.query("select set_config('request.jwt.claims',$1,false)", [
    JSON.stringify({
      role: "administrator",
      user_metadata: { is_admin: true, role: "administrator" },
    }),
  ]);
  expect(await scalar("select public.is_ledger_admin()")).toBe(false);
  await expect(
    db.exec(
      "insert into public.repayments(owner_id,loan_id,amount_cents,request_id) values(gen_random_uuid(),gen_random_uuid(),1,gen_random_uuid())",
    ),
  ).rejects.toThrow("permission denied");
  await user(ids.admin);
  const before = await scalar("select count(*) from public.audit_events");
  await expect(
    scalar("select public.reverse_repayment($1,$2,gen_random_uuid(),false)", [
      receipt,
      "Unconfirmed administrator reversal",
    ]),
  ).rejects.toThrow("confirmation");
  await expect(
    scalar("select public.post_expense('{}',gen_random_uuid(),false)"),
  ).rejects.toThrow("confirmation");
  expect(await scalar("select count(*) from public.audit_events")).toBe(before);
});
