import { it, expect } from "vitest";
import { testAppOrigin, permittedBrowserRequest } from "./support/test-safety";
import {
  assertOwnedMetadata,
  assertTestIdentity,
  createIsolatedPostgres,
} from "./support/isolated-postgres.mjs";
it("refuses production, remote, credential-bearing and lookalike browser targets", () => {
  for (const value of [
    "https://production.invalid",
    "http://127.0.0.1.evil.invalid:3000",
    "http://user:password@127.0.0.1:3000",
    "http://127.0.0.1:5432",
    "http://localhost:3000",
    undefined,
  ])
    expect(() => testAppOrigin(value)).toThrow();
  expect(testAppOrigin("http://127.0.0.1:3000")).toBe("http://127.0.0.1:3000");
  expect(
    permittedBrowserRequest(
      "https://live-project.supabase.co/rest/v1/clients",
      "http://127.0.0.1:3000",
    ),
  ).toBe(false);
  expect(
    permittedBrowserRequest(
      "http://127.0.0.1:3000/api/imports/template",
      "http://127.0.0.1:3000",
    ),
  ).toBe(true);
});
it("will not accept a database URL, credential or pre-existing container for fixture seeding", async () => {
  for (const options of [
    { connectionString: "postgres://production.invalid/live" },
    { container: "existing" },
    { host: "127.0.0.1" },
  ])
    await expect(createIsolatedPostgres(options)).rejects.toThrow(
      "do not accept URLs",
    );
});
it("refuses cleanup/seeding of containers lacking this run marker or using network/persistent mounts", () => {
  const safe = {
    Config: { Labels: { "loan-app.test-run": "fictional-run" } },
    HostConfig: { NetworkMode: "none", ReadonlyRootfs: true, PortBindings: {} },
    Mounts: [{ Type: "tmpfs" }],
  };
  expect(() => assertOwnedMetadata(safe, "fictional-run")).not.toThrow();
  for (const metadata of [
    { ...safe, Config: { Labels: {} } },
    { ...safe, HostConfig: { ...safe.HostConfig, NetworkMode: "bridge" } },
    { ...safe, HostConfig: { ...safe.HostConfig, ReadonlyRootfs: false } },
    {
      ...safe,
      HostConfig: { ...safe.HostConfig, PortBindings: { "5432/tcp": [{}] } },
    },
    { ...safe, Mounts: [{ Type: "bind" }] },
    { ...safe, Mounts: [{ Type: "volume" }] },
  ])
    expect(() => assertOwnedMetadata(metadata, "fictional-run")).toThrow(
      "Refusing",
    );
});
it("requires both a fresh test database name and the nonce created for this run", () => {
  const database = "lendwell_test_012345abcdef";
  expect(() =>
    assertTestIdentity({ database, nonce: "run" }, database, "run"),
  ).not.toThrow();
  for (const [identity, name] of [
    [{ database: "postgres", nonce: "run" }, "postgres"],
    [{ database, nonce: "another-run" }, database],
    [{ database: "production", nonce: "run" }, database],
  ])
    expect(() => assertTestIdentity(identity, name, "run")).toThrow("Refusing");
});
