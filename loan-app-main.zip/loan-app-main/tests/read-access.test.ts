import { it, expect, vi } from "vitest";
import type { SupabaseClient } from "@supabase/supabase-js";
import { requireReadAccess } from "../lib/read-access";
it("asks the database for its current read decision before exporting cached data", async () => {
  const rpc = vi.fn().mockResolvedValue({ data: true, error: null });
  await requireReadAccess({ rpc } as unknown as SupabaseClient);
  expect(rpc).toHaveBeenCalledWith("has_capability", {
    p_action: "export_reports",
  });
});
it("rejects a revoked read grant", async () => {
  const rpc = vi.fn().mockResolvedValue({ data: false, error: null });
  await expect(
    requireReadAccess({ rpc } as unknown as SupabaseClient),
  ).rejects.toThrow("do not allow reports or exports");
});
it("does not treat a failed permission request as an export grant", async () => {
  const rpc = vi.fn().mockResolvedValue({
    data: true,
    error: { message: "private provider detail" },
  });
  await expect(
    requireReadAccess({ rpc } as unknown as SupabaseClient),
  ).rejects.toThrow("Could not verify read access");
});
