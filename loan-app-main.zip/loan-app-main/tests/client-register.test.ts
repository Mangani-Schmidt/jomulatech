import { it, expect, vi } from "vitest";
import type { SupabaseClient } from "@supabase/supabase-js";
import { manNumberSchema, type Client } from "../lib/domain";
import {
  findRegisteredMan,
  localManConflict,
  sameManNumber,
} from "../lib/client-register";
const record = {
  id: "existing-id",
  man_number: "00Ab-01",
  name: "Fictional Existing Client",
  is_active: false,
} as Client;
it("preserves manually assigned leading zeros and spelling while trimming surrounding spaces", () => {
  expect(manNumberSchema.parse("  000042  ")).toBe("000042");
  expect(manNumberSchema.parse("00Ab-01")).toBe("00Ab-01");
  expect(sameManNumber("000042", "42")).toBe(false);
});
it.each(["", "   ", "x".repeat(51), "00\u00071", "00\t1"])(
  "rejects a Man# outside the existing required-format rules: %s",
  (value) => {
    expect(manNumberSchema.safeParse(value).success).toBe(false);
  },
);
it("finds inactive and case-varied duplicates without changing a record or matching the current Client during correction", () => {
  const before = structuredClone(record);
  expect(localManConflict([record], " 00aB-01 ")).toEqual(record);
  expect(localManConflict([record], "00ab-01", record.id)).toBeNull();
  expect(localManConflict([record], "00ab-02")).toBeNull();
  expect(record).toEqual(before);
});
it("uses an exact scoped server lookup and returns the original internal Client ID", async () => {
  const rpc = vi.fn().mockResolvedValue({ data: record, error: null });
  expect(
    (
      await findRegisteredMan(
        { rpc } as unknown as SupabaseClient,
        "  00ab-01  ",
      )
    )?.id,
  ).toBe(record.id);
  expect(rpc).toHaveBeenCalledWith("find_client_by_man", {
    p_man_number: "00ab-01",
  });
});
it("does not treat a failed uniqueness lookup as permission to create a Client", async () => {
  const rpc = vi.fn().mockResolvedValue({
    data: null,
    error: { message: "private provider detail" },
  });
  await expect(
    findRegisteredMan({ rpc } as unknown as SupabaseClient, "000042"),
  ).rejects.toThrow("No Client was saved");
});
