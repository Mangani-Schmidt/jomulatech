import { it, expect } from "vitest";
import {
  buildReport,
  defaultReportFilters,
  type ReportSource,
} from "../lib/reporting";
import { demoClients } from "../lib/demo";
it("reconciles a 10000-loan portfolio within the interactive calculation budget", () => {
  const n = 10000,
    stamp = "2026-11-01T00:00:00Z";
  const clients = Array.from({ length: n }, (_, i) => ({
    ...demoClients[0],
    id: "c" + i,
    name: "Fictional Client " + i,
    man_number: String(i).padStart(6, "0"),
  }));
  const loans = clients.map((c, i) => ({
    id: "l" + i,
    client_id: c.id,
    principal_cents: 100000,
    interest_cents: 10000,
    balance_cents: 110000,
    due_date: "2026-12-01",
    disbursement_date: "2026-11-01",
    created_at: stamp,
    currency: "ZMW",
  }));
  const source: ReportSource = {
    generated_at: "2026-11-13T12:00:00Z",
    timezone: "Africa/Lusaka",
    clients,
    loans,
    terms_audit: loans.map((l) => ({
      id: "a" + l.id,
      loan_id: l.id,
      action: "originate",
      created_at: stamp,
      before_data: null,
      after_data: l,
      reason: "Fictional scale fixture",
    })),
    status_audit: [],
    repayments: [],
    repayment_audit: [],
    expenses: [],
  };
  const started = performance.now(),
    report = buildReport(source, defaultReportFilters("2026-11-13"));
  expect(report.clients).toHaveLength(n);
  expect(report.loans).toHaveLength(n);
  expect(report.totals).toMatchObject({
    disbursed: n * 100000,
    principal: n * 100000,
    interest: n * 10000,
    owed: n * 110000,
    interestReceived: 0,
  });
  expect(performance.now() - started).toBeLessThan(2000);
});
